# Graph Report v2 - Archive Excluded (2026-05-04)

## Summary
- **1175 nodes** · **2593 edges** · **38 communities** detected
- Extraction: See .graphify_extract_v2.json for details
- Archive/ excluded: **21% fewer communities**, **30% fewer single-node clusters**

## v1 vs v2 Comparison

| Metric | v1 (with archive/) | v2 (archive excluded) | Delta |
|--------|-------------------|----------------------|-------|
| Files | 237 | 84 | -64% |
| Words | ~287,563 | ~98,104 | -66% |
| AST Nodes | 2,926 | 1,156 | -60% |
| AST Edges | 7,746 | 2,684 | -65% |
| Communities | 48 | 38 | -21% |
| Single-node clusters | 27 | 19 | -30% |

## God Nodes (most connected)

1. `routing_decision_log_append` - 139 edges
2. `StateManager` - 109 edges
3. `CalibrationEngine` - 64 edges
4. `HybridRouter` - 63 edges
5. `FeynmanOrchestrator` - 63 edges
6. `CognitiveHealthAssessor` - 60 edges
7. `CascadeEngine` - 59 edges
8. `AnalogySelector` - 57 edges
9. `T3Executor` - 56 edges
10. `semantic_diff` - 56 edges

## Communities (by size)

### Community 0 (157 nodes, cohesion: 0.84)
Hubs: , , 

### Community 1 (155 nodes, cohesion: 0.88)
Hubs: , , 

### Community 2 (152 nodes, cohesion: 0.83)
Hubs: , , 

### Community 3 (91 nodes, cohesion: 0.69)
Hubs: , , 

### Community 4 (70 nodes, cohesion: 0.94)
Hubs: , , 

### Community 5 (70 nodes, cohesion: 0.88)
Hubs: , , 

### Community 6 (68 nodes, cohesion: 0.92)
Hubs: , , 

### Community 7 (62 nodes, cohesion: 0.87)
Hubs: , , 

### Community 8 (49 nodes, cohesion: 0.75)
Hubs: , , 

### Community 9 (48 nodes, cohesion: 0.79)
Hubs: , , 

### Community 10 (38 nodes, cohesion: 0.81)
Hubs: , , 

### Community 11 (35 nodes, cohesion: 0.91)
Hubs: , , 

### Community 12 (32 nodes, cohesion: 0.87)
Hubs: , , 

### Community 13 (32 nodes, cohesion: 0.90)
Hubs: , , 

### Community 14 (24 nodes, cohesion: 0.79)
Hubs: , , 


## Key Insights

1. **Archive/ contributed ~60% of nodes and ~65% of edges** — massively distorting the dependency view.
2. **TriggerDaemon disappears from top God Nodes** (was #3 with 124 edges in v1) — confirming it was purely archive/ legacy.
3. **FCHOrchestrator edge count drops significantly** — version transition incomplete but now visible.
4. **Community count reduced by 21%** — core structure is more focused.
5. **19 single-node communities remain** — still suggests dead code or unconnected utilities.

## Recommendations
- Remove or move archive/ directory outside the skill root before graphify runs.
- Investigate the 19 single-node communities for unused code.
- Consider adding  flag to graphify detect for common directories (archive, __pycache__, .git).