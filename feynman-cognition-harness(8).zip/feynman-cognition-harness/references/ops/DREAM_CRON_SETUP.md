---
tag: [REFERENCE]
load_when: "运维与部署指南"
---

# Dream Engine Cron Setup

The Dream Engine is designed to run as a nightly cron job via OpenClaw's cron system.

## Recommended Schedule

Run at 02:00 Asia/Shanghai (UTC+8) every day:

```bash
openclaw cron add fch-dream \
  "0 2 * * *" \
  "python3 /root/.openclaw/workspace/skills/feynman-cognition-harness/harness/dream_engine.py --scan-all --harness-dir /root/.openclaw/workspace/skills/feynman-cognition-harness/harness"
```

Or via OpenClaw's message-based cron:

```
openclaw cron add fch-dream "0 2 * * *" "python3 /path/to/dream_engine.py --scan-all"
```

## Environment Variable Alternative

Set `FCH_HARNESS_DIR` and use a simpler command:

```bash
export FCH_HARNESS_DIR=/root/.openclaw/workspace/skills/feynman-cognition-harness/harness
openclaw cron add fch-dream "0 2 * * *" "python3 \$FCH_HARNESS_DIR/dream_engine.py --scan-all"
```

## Why 02:00

- Low-priority hour: minimal chance of conflicting with active FCH runs.
- "Dream" metaphor: unconscious integration happens during "sleep".
- Asia/Shanghai aligned: cron expression is in server local time.

## Exit Codes

- `0`: Scan completed successfully with findings (or no issues).
- `2`: Insufficient data (`concepts_scanned < min_concepts_for_scan`). Not a failure; just needs more concepts.
- Non-zero other: Runtime error.

## Report Location

Reports are saved to `harness/dreams/dream_YYYYMMDD_HHMMSS.json`.
The orchestrator reads the latest report on startup to preload `proposed_tasks` into the research queue.

## Disabling

Set `modules.dream.enabled: false` in `config.yaml` or remove the cron job:

```bash
openclaw cron remove fch-dream
```
