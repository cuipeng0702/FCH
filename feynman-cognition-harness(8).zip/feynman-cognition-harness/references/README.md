# references/ 导航

> **按需加载目录**。首次加载技能时，先读 `../SKILL.md` 和 `README.md`；需要深入时再按需加载本目录文件。

---

## 三子目录

### `design/` — 设计决策文档 [DESIGN]

何时加载：修改架构、debug 深层设计问题、新增 loop 阶段时。

| 文件 | 一句话用途 |
|------|-----------|
| `design/PHILOSOPHY.md` | 设计哲学：Illusion of Understanding、核心洞见、Ralph Loop 架构演进 |
| `design/AUTO_DEEPENING.md` | Auto-Deepening 内部机制：Ming Wu 检查、Novelty Monitoring、Auto-Search |
| `design/BDD_ESSENCE_AND_FUSION.md` | BDD 本质提取与 FCH 融合设计 |
| `design/BDD_INTEGRATION_DESIGN.md` | BDD 集成到 Ralph Loop 的路由与适配方案 |
| `design/CASCADE_DREAM_DESIGN.md` | Cascade 级联 + DREAM 夜间全局扫描机制设计 |
| `design/HARNESS_DESIGN.md` | harness/ 执行层总体架构设计（原 `design/HARNESS_DESIGN.md`） |
| `design/METACOGNITION_ANALYSIS.md` | 元认知层分析：情绪、注意力、自我监控的建模 |
| `design/METACOGNITION_FRAMEWORK.md` | 元认知框架设计：状态机、触发器、反馈回路 |
| `design/PERSONA_INTEGRATION.md` | Persona（8 岁 / 初中生 / 大学生 / 专家）集成设计 |
| `design/PRD.md` | 产品需求文档：功能规格与验收标准 |
| `design/RELATION_TYPOLOGY_v2.md` | 概念间关系类型学 v2：依赖、类比、矛盾、泛化等 |
| `design/SELF_HEURISTIC_SIGNAL_FRAMEWORK.md` | 自我启发式信号框架：置信度、情绪、收敛的联合推断 |
| `design/STRUCTURAL_EMERGENCE.md` | 结构涌现设计：gap 的自发发现与拓扑演化规则 |
| `design/TENSION_FIELD_MODEL.md` | 张力场模型：跨层矛盾的力学隐喻与解析策略 |

### `audit/` — 审计报告 [AUDIT]

何时加载：排查历史问题、执行新一轮审计前参考既有结论。

| 文件 | 一句话用途 |
|------|-----------|
| `audit/ALIGNMENT_AUDIT.md` | 人类认知拓扑 vs 当前实现对齐审计 |
| `audit/ARCHITECTURE_AUDIT.md` | 架构一致性审计：模块职责、接口契约、数据流 |
| `audit/AUDIT_FINAL.md` | 最终审计结论摘要 |
| `audit/FCMS_TEST_SUMMARY.md` | FCMS 测试总结与 FCH 调优报告 |
| `audit/OPTIMIZATION_PLAN.md` | 已规划优化路线图（部分已完成） |
| `audit/OPTIMIZATION_REPORT.md` | 已完成优化项的详细报告 |

### `ops/` — 运维配置参考 [REFERENCE]

何时加载：配置 cron、排查运行时故障、查阅 UCC 格式。

| 文件 | 一句话用途 |
|------|-----------|
| `ops/DREAM_CRON_SETUP.md` | DREAM 夜间全局扫描的 cron 配置说明 |

---

## 根级参考文件

| 文件 | 一句话用途 |
|------|-----------|
| `cognitive-science.md` | 学习科学基础：IOED、元认知、双系统理论 |
| `feynman-technique.md` | 费曼学习法深度解析：各阶段原理与常见误用 |
| `harness-engineering.md` | 系统设计原则：容错、降级、状态隔离、原子写 |

---

> 提示：首次加载技能时，先读 `../SKILL.md` 和 `README.md`，需要深入时再按需加载本目录文件。
