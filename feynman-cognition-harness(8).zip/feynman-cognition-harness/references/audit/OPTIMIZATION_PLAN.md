---
tag: [AUDIT]
load_when: "审计报告与质量评估"
---

# Feynman Cognition Harness — 全局修复计划
## 基于 graphify 结构化分析 (267 nodes, 586 edges, 11 communities)

---

## 一、graphify 诊断结论

### 社区结构问题
| 社区 | 凝聚力 | 问题 |
|------|--------|------|
| Community 0-7 | 0.06-0.13 | 凝聚力极低，模块间耦合松散 |
| Community 8 (Orchestrator) | 0.23 | 主控制器只有5个节点，过于单薄 |
| Community 9-10 | 0.33-0.50 | 实际上是示例数据，不是代码结构 |

### 关键发现
1. **70个孤立节点** — 大量方法/函数未被显式引用
2. **LatticeManager 76条边中57条是INFERRED** — 模块接口不清晰
3. **AuditEngine + IndependentAuditor 并存但无明确分工** — 功能重叠
4. **TeachEngine 有prompt但无实际LLM调用** — 核心功能缺失

---

## 二、修复优先级

### Phase 1: 核心功能补全 (阻塞主流程)
- [ ] 1.1 修复 TeachEngine — 添加实际 LLM 调用能力
- [ ] 1.2 修复 Orchestrator API 不匹配
- [ ] 1.3 统一 AuditEngine ↔ IndependentAuditor 分工
- [ ] 1.4 添加 scripts/__init__.py

### Phase 2: 审计深度增强
- [ ] 2.1 完成 D2-D4 语义级审计
- [ ] 2.2 实现子agent审计 (sessions_spawn)
- [ ] 2.3 修复 ConfidenceCalculator coverage_completeness

### Phase 3: 架构进化
- [ ] 3.1 添加 CognitiveClassifier (认知策略分类)
- [ ] 3.2 添加 MetacognitiveMemory (元认知记忆)
- [ ] 3.3 集成 Export/Visualize 到主流程

### Phase 4: 对齐与验证
- [ ] 4.1 更新 SKILL.md 反映实际实现
- [ ] 4.2 端到端测试验证
- [ ] 4.3 检查所有新增组件在主流程中被正确引用

---

## 三、执行顺序

1. 先读所有文件确认当前状态 ✓
2. 修复 TeachEngine (核心阻塞)
3. 修复 Orchestrator 调用链
4. 统一审计层
5. 增强审计深度
6. 添加新架构组件
7. 文档更新
8. 端到端测试
