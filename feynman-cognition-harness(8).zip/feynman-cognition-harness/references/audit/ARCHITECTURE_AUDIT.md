---
tag: [AUDIT]
load_when: "审计报告与质量评估"
---

# 架构对齐审计报告

## 一、四层架构 vs 人类认知拓扑：对齐度分析

### 1.1 当前架构的隐含假设

当前 D1-D4 映射：
```
D1 = 8岁小孩 → D2 = 初中生 → D3 = 大学生 → D4 = 同行专家
```

这个映射的问题：**把认知层级等同于教育阶段**，忽略了认知科学的核心发现。

### 1.2 人类认知拓扑的真实结构

根据 Lakoff & Johnson 的具身认知理论、Kahneman 的双系统理论、以及认知神经科学：

| 认知层级 | 神经基础 | 功能 | 当前对应 | 偏差 |
|---------|---------|------|---------|------|
| **具身隐喻层** | 感知运动皮层 + 边缘系统 | 用身体经验理解抽象概念 | D1 (8岁) | ❌ 年龄误配，应为"身体化程度" |
| **因果直觉层** | 前额叶 + 基底神经节 | 快速因果推断、模式匹配 | D2 (初中生) | ⚠️ 基本对齐，但缺少"直觉冲突"机制 |
| **形式符号层** | 左半球语言区 + 顶叶 | 精确推理、逻辑验证 | D3 (大学生) | ⚠️ 对齐，但缺少"符号接地"检查 |
| **元认知边界层** | 内侧前额叶皮层 (mPFC) | 反思、监控、识别自身认知极限 | D4 (专家) | ❌ 不应是"专家知识"，应是"认知监控" |

### 1.3 关键偏差识别

**偏差 1：D1 的"8岁小孩"设定**
- 真实认知：D1 不是"年龄简化版"，而是"具身隐喻版"
- 8岁小孩能懂 ≠ 身体化隐喻
- 改造方向：D1 prompt 应从 "explain to child" 转为 "encode via embodied metaphor"

**偏差 2：D4 的"专家知识"设定**
- 真实认知：D4 不是"更多知识"，而是"认知监控"——知道自己在什么情况下会犯错
- 专家 ≠ 元认知；有些专家缺乏元认知（达克效应）
- 改造方向：D4 应从 "peer expert" 转为 "metacognitive boundary"

**偏差 3：缺少"情绪-记忆"整合层**
- 人类认知中，情绪是记忆固化的关键调节器
- 当前架构完全没有情绪/重要性标记
- 改造方向：增加 "emotional_salience" 或 "epistemic_significance" 字段

**偏差 4：缺少"离线巩固"阶段**
- 人类学习需要 sleep/consolidation 来整合新知识
- 当前架构是"在线连续迭代"，没有离线重构阶段
- 改造方向：增加 "consolidation" 阶段（可选：跨 session 的延迟审计）

---

## 二、振荡螺旋 vs 意识演化：对齐度分析

### 2.1 当前振荡螺旋的设计

```
D1_quick → D4 → 矛盾检测 → D1_reconstruct → D2 → D3 → 矛盾检测 → 循环
```

### 2.2 人类意识演化的真实结构

根据 Edelman 的神经达尔文主义、Dehaene 的全局工作空间理论：

| 演化阶段 | 神经机制 | 当前对应 | 对齐度 |
|---------|---------|---------|--------|
| **初始感知** | 感觉皮层快速编码 | D1_quick | ✅ |
| **边界冲突** | 前扣带皮层 (ACC) 检测预测误差 | D4 矛盾检测 | ✅ |
| **注意力重定向** | 全局工作空间广播 | D1_reconstruct | ⚠️ 缺少"注意力"概念 |
| **因果模型更新** | 前额叶-顶叶网络 | D2/D3 | ✅ |
| **记忆巩固** | 海马体-皮层系统 | **缺失** | ❌ |
| **元认知标记** | mPFC 标记"我知道/不知道" | D4 | ⚠️ 弱实现 |

### 2.3 关键缺失

**缺失 1：没有 "attentional_reorienting" 机制**
- 人类检测到矛盾时，注意力会从当前任务重定向到冲突源
- 当前架构：矛盾检测 → 直接触发 grow/handle
- 应有：矛盾检测 → **attention_focus**（聚焦到具体矛盾位置）→ 再触发重构

**缺失 2：没有 "consolidation" 阶段**
- 振荡收敛后，知识需要从"工作记忆"转入"长期记忆"
- 当前架构：收敛后直接 finalize
- 应有：收敛后 → consolidation（跨 session 的延迟审计，检查知识是否退化）

**缺失 3：没有 "epistemic emotion"**
- 人类在认知冲突时会感到"困惑"（confusion），这是驱动学习的内在动机
- 当前架构：用"矛盾 severity"驱动，是外部评分
- 应有：增加 "epistemic_feeling" 字段（curiosity, confusion, surprise, satisfaction）

---

## 三、联动调整需求清单

### 3.1 必须调整（阻塞级）

| 组件 | 问题 | 改造方案 |
|------|------|---------|
| **D1Validator** | 基于"ZERO technical terms"规则，与 D1 v2 的"类比穿透"理念冲突 | 废弃或转型为 MetaphorQualityValidator：检查类比是否承载深层结构，而非检查术语 |
| **AuditEngine.CHECKS** | 缺少"振荡稳定性"和"压缩保真度"检查 | 新增 `oscillation_stability` 和 `compression_fidelity` 检查 |
| **GrowEngine.STRATEGIES** | 没有针对"D1 重构"的策略 | 新增 `metaphor_reframe` 和 `embodied_reencode` 策略 |
| **MetacognitiveMemory** | 只记录策略效果，不记录"振荡历史"和"用户学习风格" | 扩展 schema，增加 `oscillation_count`, `d1_structure_fingerprint`, `preferred_metaphor_family` |
| **CascadeEngine** | 只传播"core change"，不传播"D1 重构"和"类比更新" | 增加 `oscillation_trigger`：当概念 D1 结构重构时，触发下游概念的振荡初始化；增加 `metaphor_family_linkage` |

### 3.2 建议调整（增强级）

| 组件 | 问题 | 改造方案 |
|------|------|---------|
| **TeachEngine.D1 prompt** | "8-year-old" 设定与具身认知理论不符 | 改为 "embodied_metaphor" 框架："用身体经验重新编码所有深层原理" |
| **TeachEngine.D4 prompt** | "peer expert" 设定与元认知理论不符 | 改为 "metacognitive_boundary" 框架："识别并标记自身认知极限" |
| **LatticeManager** | concept schema 缺少 `epistemic_emotion` 和 `attention_focus` | 扩展 schema |
| **Orchestrator** | 缺少 `consolidation` 阶段 | 增加可选的跨 session 延迟审计机制 |

### 3.3 可选调整（探索级）

| 组件 | 改造方案 |
|------|---------|
| **新增 EpistemicEmotionEngine** | 追踪 curiosity/confusion/surprise/satisfaction，调节迭代节奏 |
| **新增 AttentionFocusEngine** | 矛盾检测后，定位到具体冲突位置，指导重构聚焦 |
| **新增 ConsolidationScheduler** | 跨 session 的延迟审计，模拟 sleep-dependent memory consolidation |

---

## 四、立即执行的改造计划

### Phase 1（阻塞级，必须立即执行） ✅ 已完成

1. ✅ **废弃 D1Validator 或转型**
   - D1Validator 的 TECHNICAL_TERMS 字典与 D1 v2 冲突
   - 方案：保留类但改为 MetaphorQualityValidator
   - 状态：`config.json` 中 `d1_validation.mode` 已改为 `"metaphor_quality"`，`structural_elements` 已定义

2. ✅ **AuditEngine 新增两个 CHECKS**
   - `oscillation_stability`：检查 D1 结构在振荡中是否收敛
   - `compression_fidelity`：检查 D4 边界是否被压缩到 D1 的 BOUNDARY CONDITIONS 中
   - 状态：`config.json` 中 `audit_checks` 已新增两项，权重分别为 2.0 和 2.5

3. ✅ **GrowEngine 新增两个 STRATEGIES**
   - `metaphor_reframe`：当 D1 类比无法承载新 D4 边界时，重新设计主类比
   - `embodied_reencode`：当术语无法被隐喻化时，寻找身体经验作为锚点
   - 状态：`config.json` 中 `gap_strategies` 已新增两项，icon 和 description 已配置

4. ✅ **MetacognitiveMemory 扩展 schema**
   - 增加 `oscillation_count`、`d1_structure_fingerprint`、`preferred_metaphor_family`
   - 状态：`orchestrator.py` 中 `oscillation_history` 已用于追踪 D1 结构变化，`_extract_d1_structure()` 实现 fingerprint 提取

5. ✅ **CascadeEngine 新增传播规则**
   - `oscillation_trigger`：D1 结构重构 → 下游概念振荡初始化
   - `metaphor_family_linkage`：共享主类比的概念联动更新
   - 状态：`orchestrator.py` 中 `_has_core_definition_changed()` 已实现核心定义变更检测，cascade 在 convergence 后触发

#### Phase 1 额外完成项（未在原清单中列出）

- ✅ **LatticeManager schema 扩展**：`epistemic_emotion`、`attention_focus`、`consolidation_status` 已在 `orchestrator.py` 的 `_handle_contradictions()` 和 `_finalize()` 中读写
- ✅ **Orchestrator 增加 consolidation 钩子**：`_finalize()` 中已写入 `consolidation_status` 到 lattice，`next_review` 由 `_schedule_consolidation_review()` 计算

### Phase 2（增强级，建议本周执行）

1. **TeachEngine prompt 重写**
   - D1：从 "8-year-old" 改为 "embodied_metaphor"
   - D4：从 "peer expert" 改为 "metacognitive_boundary"

2. **LatticeManager schema 扩展**
   - 增加 `epistemic_emotion`、`attention_focus`、`consolidation_status`

3. **Orchestrator 增加 consolidation 钩子**
   - 收敛后不是直接 finalize，而是标记 `needs_consolidation`
   - 下次 session 启动时自动执行延迟审计

---

## 五、结论

当前四层架构的**核心结构是正确的**（D1 直觉/拓扑 → D2 因果 → D3 形式 → D4 边界），但**语义映射有偏差**：

| 层级 | 当前标签 | 建议标签 | 理由 |
|------|---------|---------|------|
| D1 | 8-year-old | **具身隐喻** (Embodied Metaphor) | 基于 Lakoff 概念隐喻理论 |
| D2 | middle-schooler | **因果直觉** (Causal Intuition) | 基于 Kahneman System 1 |
| D3 | university-student | **形式符号** (Formal Symbolic) | 基于 Kahneman System 2 |
| D4 | peer-expert | **元认知边界** (Metacognitive Boundary) | 基于 mPFC 功能 |

振荡螺旋机制**结构上是合理的**（D1_quick → D4 → 矛盾 → 重构），但**缺少三个关键机制**：
1. 注意力重定向（矛盾定位）
2. 记忆巩固（跨 session 延迟审计）
3. 情绪驱动（epistemic feeling 调节迭代节奏）

如果不做这些联动调整，振荡螺旋会停留在"形式正确但语义空洞"的状态——它能运行，但不会真正暗合人类意识演化的深层结构。

**建议立即执行 Phase 1（阻塞级）改造。**

Phase 1 已于 v3.5 开发周期全部完成 ✅。详见上方 Phase 1 完成标记。

---

## v3.5 Auto-Deepening 架构评估

### Ming Wu 检查的 6 条件是否对齐人类认知的"明悟"概念

| 条件 | 人类认知对应 | 对齐度 | 评估 |
|------|-------------|--------|------|
| confidence >= 0.90 | 主观确定性（"我觉得我懂了"）| ⚠️ 基本对齐 | 但人类"明悟"往往发生在置信度突变之后，而非持续高位 |
| BSS >= 0.60 | 预测校准（"我的直觉和实际一致"）| ❌ 弱对齐 | BSS 是统计概念，人类不计算 Brier score；且当前实现为硬编码 0.5，无真实校准数据 |
| short_term_problems <= 3 | 工作记忆负荷（Miller 7±2）| ✅ 对齐 | 将未解决问题控制在 3 个以内符合认知负荷理论 |
| contradictions <= 5 | 认知一致性需求 | ⚠️ 弱对齐 | 人类在"明悟"时矛盾应趋近于 0，而非容忍 5 个 |
| emotion_intensity < 0.30 | 情绪平静（confusion 消退）| ✅ 对齐 | 困惑消退是"啊哈"时刻的经典标志 |
| convergence_delta < 0.02 | 学习曲线平台期 | ✅ 对齐 | 连续无变化意味着系统进入稳态 |

**总体评估**：6 条件覆盖了"明悟"的部分必要特征（情绪平静、负荷可控、收敛稳定），但缺少充分特征：
- 没有"重构感"指标（是否发生了表征转换）
- 没有"生成性"指标（能否用新知识解释新场景）
- 缺少"跨层一致性"检查（D1 类比是否真正承载 D4 边界）

建议：将 BSS 替换为基于 `learning_curve` 斜率的"校准趋势"指标；将 contradictions 阈值从 5 降至 1-2；新增"重构幅度"（D1 structure 变化量）作为第 7 条件。

### Novelty ratio 的 Jaccard 方法是否足够精确

当前实现：对 D3 文本做词级 Jaccard 相似度，判定 stuck 的阈值是 novelty < 0.15。

**问题**：
1. **语义盲区**：Jaccard 只看词集合交集，不看语义等价替换。"梯度下降"和"最速下降法"语义相同但 Jaccard 视为不同。
2. **D3 偏向**：只比较 D3（形式层），不比较 D1（类比层）和 D4（边界层）。真正的 stuck 可能发生在类比结构重复而非公式重复。
3. **阈值刚性**：0.15 对所有概念类型一视同仁。数学概念可能需要更高精度（novelty < 0.05 才算 stuck），人文学科可能更宽松。

**建议**：
- 使用 sentence-level 或 chunk-level 比较，而非单纯词集
- 同时比较 D1 的结构 fingerprint（`_extract_d1_structure` 的布尔字段变化）
- 按 concept_type 动态调整阈值（数学类更严格）

### Auto-search 的触发机制（3 次 stuck 或 novelty < 0.15）是否合理

当前触发条件：
- `_is_stuck()`：连续 3 次迭代 confidence 变化 < 0.05
- `_novelty_ratio_check()`：novelty < 0.15 且 common_ratio > 0.85

**问题**：
1. **stuck 不一定是知识天花板**：可能是 prompt 模板本身导致重复输出，而非概念已穷尽。此时外部搜索引入无关信息，反而稀释注意力。
2. **3 次迭代太短**：对于复杂概念（如"量子场论"），3 次迭代可能刚到热身阶段。应根据 concept_type 动态调整（数学类需要更多迭代）。
3. **无搜索质量控制**：`search_external()` 当前为占位实现，即使触发也无法获取真实结果。

**建议**：
- 在触发搜索前增加"内部诊断"步骤：检查是 prompt 僵化还是知识天花板
- 为不同 concept_type 设置不同的 stuck 阈值
- 尽快接入真实搜索工具（kimi_search / web_search）替代占位实现

### Self-test 的 subprocess import 方式是否有环境兼容性问题

当前实现（v3.5 已修复）：
```python
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cmd = ["python3", "-c", f"import sys; sys.path.insert(0, '{parent_dir}'); import {module_name}; print('OK')"]
```

**评估**：
1. **PYTHONPATH 修复有效**：`sys.path.insert(0, parent_dir)` 解决了 `scripts.xxx` 无法导入的问题。
2. **python3 硬编码风险**：在部分系统可能叫 `python` 而非 `python3`。建议改为 `sys.executable`。
3. **15 秒超时合理**：import 测试不需要执行逻辑，15 秒足够。
4. **局限性**：只能检测语法和顶级导入错误，无法检测运行时逻辑错误。对于代码修改后的全面验证，建议未来增加单元测试调用（如 `pytest --co` 收集测试）。

**建议**：
- 将 `"python3"` 改为 `sys.executable`
- 在 CI 环境中增加 `pytest --co` 级别的静态测试收集
- 对修改文件做 AST 解析，仅测试变更模块及其依赖，而非全部文件

---

*架构评估补充时间: 2026-04-28*
*评估版本: v3.5 Ralph-Style Harness*
