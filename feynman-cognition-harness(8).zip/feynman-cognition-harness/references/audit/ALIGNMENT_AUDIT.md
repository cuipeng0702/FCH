---
tag: [AUDIT]
load_when: "审计报告与质量评估"
---

# FCH v3.5 JSON Schema 对齐检查报告

> 生成时间: 2026-05-03
> 检查范围: Teach/Audit/Grow/Consolidate/Cascade/Orchestrator 数据流
> 方法: 逐字段对比模板定义与实际消费点

---

## 总体结果

| 检查项 | 状态 | 说明 |
|--------|------|------|
| 1. Teach 输出 → Audit 输入 | **PASS** | 字段消费对齐，audit 通过 `teach_output_path` 加载完整 teach_output.json |
| 2. Audit 输出 → Grow 输入 | **PASS** | 字段消费对齐，grow 通过 `audit_output_path` 加载完整 audit_output.json |
| 3. Grow 输出 → Teach 输入 | **FAIL** | 字段名与结构多处不匹配 |
| 4. Cascade 输出 → Orchestrator 输入 | **PASS** | `cascade_gaps` 字段名完全一致 |
| 5. Consolidate 输出 → 下一轮 Teach | **FAIL** | `resolved_by_new_node` 字段缺失 |

**FAIL 数: 2 / 5**

---

## 详细检查

### 1. Teach 输出 → Audit 输入 [PASS]

**Teach 输出字段 (teach_output.json)**
```
concept_id, iteration, timestamp, d1, d2, d3, d4, dependency_chain, metadata
metadata 子字段: strategy_used, confidence_estimate, analogy_id, analogy_domain,
  analogy_selection_reason, analogy_confidence, reframe_triggered, update_reason,
  new_dependencies
```

**Audit 输入引用**
- `teach_output_path` — 加载 teach_output.json ✓
- D1 检查: `d1` 长度/类比/术语/触觉可视化 ✓
- D2 检查: `d2` 步数/可执行性/成功标准 ✓
- D3 检查: `d3` 术语/公式/置信度 ✓
- D4 检查: `d4` boundaries/反例/失效机制 ✓
- Cross-layer: D1-D4 一致性 ✓
- v3.5 条件检查: `metadata.analogy_id`, `metadata.reframe_triggered`, `metadata.confidence_estimate` ✓

**结论**: Audit 消费了 Teach 输出的所有必要字段，无字段名不匹配。

---

### 2. Audit 输出 → Grow 输入 [PASS]

**Audit 输出字段 (audit_output.json)**
```
iteration, timestamp, valid, issues[], summary, metadata
metadata 子字段: issues_by_layer{d1,d2,d3,d4}, critical_count, major_count, minor_count
```

**Grow 输入引用**
- `audit_output_path` — 加载 audit_output.json ✓
- Step 1: 遍历 `issues` 映射到 gaps ✓
- `valid` / `metadata` 用于优先级判断 ✓
- `issues[].layer`, `issues[].severity`, `issues[].description` 全部消费 ✓

**结论**: Grow 消费了 Audit 输出的所有字段，无字段名不匹配。

---

### 3. Grow 输出 → Teach 输入 [FAIL]

**Grow 输出字段 (grow_output.json)**
```json
{
  "gaps": [
    {
      "id": "string",           // ❌ 应为 "gap_id"
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "external_knowledge_required": true,
      "query": "string",
      "search_summary": "string"
    }
  ],
  "strategy": "string",
  "teach_candidates": [...],
  "intra_node_fixes": [
    {
      "gap_id": "string",       // ✅ 与 Teach 期望一致
      "layer": "d1|d2|d3|d4",
      "fix_description": "string",
      "applicable_in_current_node": true
    }
  ],
  "metadata": { ... }
}
```

**Teach 输入字段 (previous_gaps)**
```json
{
  "previous_gaps": [
    {
      "gap_id": "string",       // ❌ Grow 用 "id"
      "layer": "d1|d2|d3|d4",
      "description": "string",
      "strategy": "string",     // ❌ Grow 的 gaps 没有这个字段
      "resolved_by_new_node": "string|null"  // ❌ Grow 的 gaps 没有这个字段
    }
  ]
}
```

**发现的不匹配:**

| 问题 | 严重性 | 说明 |
|------|--------|------|
| A. `id` vs `gap_id` | **major** | Grow 的 gaps 用 `id`，Teach 的 previous_gaps 期望 `gap_id`。Consolidate 模板的 `active_gaps` 也用 `gap_id`。字段名不统一导致数据链断裂。 |
| B. `strategy` 字段位置 | **major** | Grow 中 `strategy` 是顶层字段（全局学习策略），但 Teach 的 previous_gaps 期望每个 gap 有 `strategy` 字段。Consolidate 模板的 `active_gaps` 定义包含 `strategy`，但 Grow 的 gaps 定义不包含。 |
| C. `resolved_by_new_node` 缺失 | **critical** | Teach 的 `gap_driven` 模式依赖此字段决定 dependency_chain 更新。Grow 的 gaps 和 Consolidate 的 active_gaps 均未定义此字段，导致 gap_driven 修复逻辑无法执行。 |
| D. `external_knowledge_required` / `query` / `search_summary` | **minor** | 这些字段在 Consolidate 转换到 active_gaps 时丢失，但 Teach 不需要它们，属于信息损耗而非断裂。 |

**修复建议:**

1. **统一字段名**: 将 Grow 模板中 `gaps[].id` 改为 `gaps[].gap_id`，与 intra_node_fixes 和 Teach 输入保持一致。
2. **增加 per-gap strategy**: 在 Grow 模板的 `gaps` 定义中增加 `strategy` 字段（可从顶层 strategy 继承或根据 gap 类型生成）。
3. **增加 resolved_by_new_node**: 
   - 在 Grow 模板的 `gaps` 定义中增加 `resolved_by_new_node: string|null`
   - 当根因分析为 `new_node_required` 时，将该 teach_candidate 的 concept 填入对应 gap 的 `resolved_by_new_node`
4. **Consolidate 字段映射**: 在 Consolidate 模板中明确说明 `active_gaps` 从 grow_output 转换时的字段映射规则（`id`→`gap_id`，丢弃 `external_knowledge_required`/`query`/`search_summary`）。

---

### 4. Cascade 输出 → Orchestrator 输入 [PASS]

**Cascade 输出字段 (cascade_engine.py)**
```python
cascade_gaps = [
    {
        "id": "...",
        "target_concept": "...",
        "source_concept": "...",
        "impact_direction": "downstream|upstream|indirect",
        "gap_description": "...",
        "affected_layers": ["d1", "d2"],
        "trigger_reason": "dependency_drift|indirect_impact|upstream_knowledge_update|shared_dependency_drift",
        "depth": 1,
        "priority": 0.9,
    }
]
```

**Orchestrator 消费点 (orchestrator.py)**
```python
next_gap = pool[0]
target_concept = next_gap["target_concept"]          # ✅
state["cascade_context"] = {
    "source_concept": next_gap["source_concept"]      # ✅
    "gap_description": next_gap["gap_description"]    # ✅
    "affected_layers": next_gap.get("affected_layers") # ✅
    ...
}
```

**结论**: 要求检查的7个字段名（`id`, `target_concept`, `source_concept`, `impact_direction`, `affected_layers`, `trigger_reason`, `priority`）全部在 cascade_engine.py 输出中存在，且 orchestrator.py 消费的字段名完全一致。

- `depth` 和 `impact_direction` 未被 orchestrator 消费，但属于有效附加信息，不影响对齐。

---

### 5. Consolidate 输出 → 下一轮 Teach [FAIL]

**Consolidate 输出字段 (consolidate_output.json)**
```json
{
  "active_gaps": [
    {
      "gap_id": "string",      // ✅ 与 Teach 对齐
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "strategy": "string",    // ✅ 与 Teach 对齐
      "source": "string"
    }
  ]
}
```

**Teach 输入字段 (previous_gaps)**
```json
{
  "previous_gaps": [
    {
      "gap_id": "string",
      "layer": "d1|d2|d3|d4",
      "description": "string",
      "strategy": "string",
      "resolved_by_new_node": "string|null"  // ❌ Consolidate 未输出
    }
  ]
}
```

**发现的不匹配:**

| 问题 | 严重性 | 说明 |
|------|--------|------|
| A. `resolved_by_new_node` 缺失 | **critical** | Teach 的 `gap_driven` 模式: "若 gap 的 `resolved_by_new_node` 非空，将该节点加入 dependency_chain"。Consolidate 的 `active_gaps` 无此字段，导致该逻辑无法触发。 |
| B. `source` 额外字段 | **info** | Consolidate 输出 `source` 但 Teach 不消费，无负面影响。 |

**修复建议:**

1. **在 Consolidate 模板中增加 `resolved_by_new_node`**:
   - 从 grow_output 的 `teach_candidates` 中提取 `trigger_gap_id`，反向映射到对应 gap
   - 若 gap 有 teach_candidate 解决，则 `resolved_by_new_node = teach_candidate.concept`
   - 否则为 `null`
2. **或在 Orchestrator 中做转换**: 在 `_ingest_worker_output` 的 consolidate 分支中，把 `active_gaps` 传给 `previous_gaps` 之前，根据 `state["teach_candidates"]` 补充 `resolved_by_new_node`。

---

## 修复优先级汇总

| 优先级 | 问题 | 影响文件 | 影响范围 |
|--------|------|----------|----------|
| 🔴 P0 | `resolved_by_new_node` 全链路缺失 | grow_task_template.md, consolidate_task_template.md, teach_task_template.md | gap_driven 模式核心逻辑无法执行 |
| 🔴 P0 | `gaps[].id` 应为 `gaps[].gap_id` | grow_task_template.md | 字段名不一致导致数据链断裂 |
| 🟡 P1 | `gaps[].strategy` 缺失 | grow_task_template.md | Teach 期望 per-gap strategy |
| 🟡 P1 | Consolidate 字段映射未文档化 | consolidate_task_template.md | grow→consolidate→teach 转换规则模糊 |

---

## 附录: 字段名对照表

| 语义 | Grow (gaps) | Grow (intra_node_fixes) | Consolidate (active_gaps) | Teach (previous_gaps) |
|------|------------|------------------------|--------------------------|----------------------|
| 唯一标识 | `id` ❌ | `gap_id` ✅ | `gap_id` ✅ | `gap_id` ✅ |
| 描述 | `description` ✅ | `fix_description` | `description` ✅ | `description` ✅ |
| 层级 | `layer` ✅ | `layer` ✅ | `layer` ✅ | `layer` ✅ |
| 策略 | — ❌ | — | `strategy` ✅ | `strategy` ✅ |
| 由新节点解决 | — ❌ | — | — ❌ | `resolved_by_new_node` |

---

*报告结束。*
