---
tag: [AUDIT]
load_when: "审计报告与质量评估"
---

# FCMS 测试总结报告与 FCH 技能调优建议

## 一、认知过程总结

通过本次 FCMS Phase 6 闭环测试（3 轮完整迭代 + 评分算法修复 + 自动化集成），我对以下问题有了深入理解：

### 1.1 元认知系统的本质
元认知不是"监控知识的系统"，而是**"监控知识生产过程本身的系统"**。FCMS 的核心价值不在于它发现了多少 gaps，而在于它能**自动识别"为什么 gaps 反复出现"**并驱动系统自我修正。

### 1.2 评分算法的敏感性陷阱
测试中最关键的发现：breadth 评分算法只看 gap 数量而不看 severity 和 resolved 数量，导致系统在"大部分问题已解决"时仍报 critical。这揭示了**指标设计的根本原则**：任何评分算法必须考虑"净改善"而非"绝对数量"。

### 1.3 自动化集成的边界
FCMS 的 L1-L4 自动化集成虽然实现，但存在三个隐性边界：
- **子 agent 质量不可控**：Audit3 subagent 返回空输出，说明子 agent 可靠性仍是系统瓶颈
- **信号构造依赖人工**：L1 信号的 gap_produced/gap_closed 等需要手工构造，非真正自动化捕获
- **调控动作粒度粗**：L4 只能调整 budget/threshold/routing，无法直接修复内容质量

### 1.4 DREAM 的重新定位
从最初"夜间批处理任务"重新定位为 L3 反思层的**深度批量模式**。日常反思运行在小时级，DREAM 在夜间做全量扫描。这个正交设计避免了时间尺度错配。

---

## 二、FCMS + Subagent 明镜 客观评价

### 2.1 FCMS 实际效果

| 维度 | 评分 | 说明 |
|------|------|------|
| **诊断准确性** | ⭐⭐⭐⭐☆ (4/5) | 能正确识别 breadth/efficiency 异常，但初始算法过于敏感，修复后准确 |
| **调控有效性** | ⭐⭐⭐☆☆ (3/5) | 能触发 budget 分配，但调控粒度粗（只能调参数，不能直接修内容）|
| **自动化程度** | ⭐⭐⭐⭐☆ (4/5) | L1-L4 流程自动化完成，但信号构造仍需人工介入 |
| **安全边界** | ⭐⭐⭐⭐⭐ (5/5) | 连续 3 轮 safety=PASS，reserve 始终 >20% |
| **闭环完整性** | ⭐⭐⭐⭐☆ (4/5) | 监控→评估→反思→调控闭环完整，但反思→调控的触发条件偏保守 |

**总体评价**：FCMS 作为**诊断和预警系统**非常有效，作为**自动修复系统**能力有限。它的核心价值是"让问题可见"而非"自动解决问题"。

### 2.2 Subagent 明镜实际效果

| 维度 | 评分 | 说明 |
|------|------|------|
| **审计深度** | ⭐⭐⭐⭐☆ (4/5) | Audit2 全量评估产出详细，bridge concept 评估到位 |
| **输出稳定性** | ⭐⭐☆☆☆ (2/5) | Audit3 subagent 返回空输出，说明存在可靠性问题 |
| **修复执行** | ⭐⭐⭐⭐☆ (4/5) | Teach3 的 10 个 intra-node fixes 全部执行到位 |
| **自主性** | ⭐⭐⭐⭐☆ (4/5) | 能自主完成研究任务，但需明确指令约束 |
| **元认知反思** | ⭐⭐☆☆☆ (2/5) | 明镜模板的自指评估未在本次测试中实际运行（stub 状态）|

**总体评价**：subagent 在**内容生成和修复执行**上表现良好，但在**输出稳定性和元认知自指**上存在明显短板。Audit3 的空输出说明需要增加输出验证机制。

### 2.3 协同效果

FCMS + subagent 的协同模式：
- **FCMS 发现问题** → **subagent 修复问题** → **FCMS 验证修复**
- 这个循环在 Iteration 1→2 中有效运转，但 Iteration 2→3 的边际收益递减（0.90→0.91）
- **瓶颈**：subagent 的修复能力上限决定了 FCMS 的调控效果上限

---

## 三、测试中发现的 FCH 技能问题

### 3.1 高优先级问题

| # | 问题 | 影响 | 根因 |
|---|------|------|------|
| 1 | **Audit subagent 输出不稳定** | Audit3 返回空输出，需人工补全 | subagent 未正确处理大文件输入或超时 |
| 2 | **FCMS 信号构造依赖人工** | L1 信号非真正自动化捕获 | 缺乏工具调用/任务完成的自动信号钩子 |
| 3 | **Stability 评分逻辑偏差** | 新增 teach 节点被解读为"不稳定" | 算法将"结构扩展"等同于"结构不稳定" |
| 4 | **Efficiency 评分偏低** | 低消耗率被持续扣分 | 算法未区分"高效"和"低效" |
| 5 | **DREAM 未实际运行** | L3 批量反思仅存在于设计文档 | 缺乏夜间 cron 触发机制 |

### 3.2 中优先级问题

| # | 问题 | 影响 |
|---|------|------|
| 6 | **Bridge concept 信息密度偏高** | 3 个 bridge 概念累计内容量可能超出学习者负荷 |
| 7 | **Cross-layer 术语一致性** | 不同概念对"涌现"的定义语境不同，虽有注释但仍需读者自行对齐 |
| 8 | **Consolidate 纯归档约束过严** | intra-node fixes 在当前节点修复，但历史版本内容未更新，造成版本混乱 |
| 9 | **Cascade 触发条件偏保守** | Iteration 2-3 均未触发 cascade，可能遗漏跨概念依赖 |
| 10 | **Self-Awareness Coach stub** | `_run_self_awareness_check` 返回 None，未实际 spawn 明镜 subagent |

---

## 四、FCH 技能调优建议

### 4.1 立即执行（高优先级）

#### 修复 1：Audit subagent 输出验证机制
**问题**：Audit3 返回空输出。
**方案**：在 `_spawn_auditor` 或 audit task template 中增加输出验证约束：
```markdown
## 输出验证规则
- 输出必须为有效 JSON，顶层必须包含 "primary_concept" 和 "system_comparison" 字段
- 如无法完成评估，输出 {"_error": "原因", "partial": true} 而非空输出
- 评估时间超过 2 分钟时，先输出部分结果再补充
```

#### 修复 2：FCMS L1 信号自动捕获
**问题**：信号依赖手工构造。
**方案**：在 `_spawn_worker` 和 `_spawn_auditor` 中增加自动信号写入：
```python
def _spawn_worker(self, task_name, input_path, output_path):
    # ... 现有逻辑 ...
    # 自动记录任务启动信号
    self.sm.fcms_save_signal({
        "type": "task_started",
        "task": task_name,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }, iteration, mode="realtime")
    return str(out_path)
```

#### 修复 3：Stability 评分逻辑修正
**问题**：新增 teach 节点被解读为不稳定。
**方案**：区分"破坏性变更"和"扩展性变更"：
```python
def _assess_stability(self, signals):
    # 修复后：检查是否有任务失败/异常，而非只看任务数量
    failed_tasks = [s for s in signals if s.get("type") == "task_failed"]
    if failed_tasks:
        return max(0.3, 1.0 - len(failed_tasks) * 0.2)
    # 新增任务（如 bridge concepts）不降低稳定性
    return 1.0
```

### 4.2 近期执行（中优先级）

#### 修复 4：Self-Awareness Coach 实际化
**问题**：`_run_self_awareness_check` 是 stub。
**方案**：替换为实际 `sessions_spawn` 调用：
```python
def _run_self_awareness_check(self, iteration, state, progress, budget):
    coach_input = self._build_coach_input(iteration, state, progress, budget)
    coach_input_path = self._iter_dir(iteration) / "coach_input.json"
    self._atomic_write(coach_input_path, coach_input)
    coach_output_path = self._iter_dir(iteration) / "coach_output.json"
    
    # 实际 spawn
    sessions_spawn(
        task=f"Run self-awareness coach with input={coach_input_path}",
        runtime="subagent",
        mode="run",
    )
    # 等待结果并读取 coach_output.json
    return self._load_json_safe(coach_output_path, {})
```

#### 修复 5：DREAM 定时触发机制
**问题**：DREAM 仅存在于设计文档。
**方案**：在 `config.yaml` 中添加 DREAM cron 配置，并创建触发脚本：
```yaml
dream:
  enabled: true
  schedule: "0 2 * * *"  # 每天凌晨 2 点
  min_iterations_before_run: 3
  max_history_lookback_days: 7
```

#### 修复 6：Consolidate 版本管理
**问题**：intra-node fixes 在当前节点修复，历史版本未更新。
**方案**：Consolidate 输出增加 "version_delta" 字段，记录每次迭代的内容变更摘要，方便追溯：
```json
{
  "archived_nodes": [...],
  "version_delta": {
    "iter_002": "Added 3 bridge concepts, 22 intra-node fixes",
    "iter_003": "Applied 10 intra-node fixes: compression, pacing hints, transition buffers"
  }
}
```

### 4.3 长期优化（低优先级）

#### 修复 7：Bridge Concept 动态加载
**问题**：3 个 bridge 概念全部加载可能认知负荷过高。
**方案**：添加 "lazy_load" 模式，bridge concept 默认折叠，读者点击展开：
```json
{
  "bridge_concepts": [
    {
      "concept_id": "bridge-0",
      "lazy_load": true,
      "summary": "自发组织直觉锚点（点击展开）",
      "priority": 1
    }
  ]
}
```

#### 修复 8：Cross-Concept 术语统一层
**问题**：不同概念对"涌现"定义不一致。
**方案**：在 Consolidate 阶段添加 "terminology_unification" 检查：
```python
def _unify_terminology(self, nodes):
    # 扫描所有节点中相同术语的不同定义
    # 生成对齐注释
    pass
```

---

## 五、测试结论

### 5.1 FCMS 价值确认
- ✅ **诊断能力**：能有效识别系统健康异常（breadth/efficiency/depth）
- ✅ **调控能力**：能自动触发 budget 分配驱动修复
- ⚠️ **自动化程度**：信号捕获仍半人工，需增强工具钩子
- ⚠️ **子 agent 稳定性**：Audit3 空输出说明输出验证机制缺失

### 5.2 FCH v3.5 状态
- 核心机制（Teach/Audit/Grow/Consolidate/Cascade）功能完整
- FCMS 四层架构（L1-L4）验证通过
- 评分算法修复后准确反映系统健康
- **待完善**：Self-Awareness Coach 实际化、DREAM 定时触发、Audit 输出验证

### 5.3 下一步建议
1. **立即**：实施 Audit 输出验证 + FCMS 信号自动捕获 + Stability 评分修正
2. **近期**：Self-Awareness Coach 实际化 + DREAM cron 触发
3. **长期**：Bridge concept lazy load + 术语统一层

---

*报告生成时间: 2026-05-03*
*测试基础: 3 轮完整迭代（Iteration 1-3）*
*FCMS 版本: v3.5 + Phase 1-5 + 评分算法修复*
