---
tag: [REFERENCE]
load_when: "Harness 工程方法论"
---

# Harness Engineering 设计模式

## 定义与定位

Harness Engineering是围绕AI Agent构建的**约束、反馈与质量门控体系**，覆盖Agent系统全生命周期。

**与相关工程的区别：**

| 维度 | Prompt Engineering | Context Engineering | Harness Engineering |
|------|-------------------|-------------------|-------------------|
| 作用域 | 单次交互 | 单次上下文窗口 | 完整任务生命周期 |
| 控制对象 | 指令措辞 | Token选择、排序 | 工具编排、状态持久化 |
| 失败模式 | 指令不清 | 信息缺失 | 错误、死循环、漂移 |
| 时间边界 | 一轮 | 一个上下文窗口 | 多窗口、完整生命周期 |

## 核心理念：约束即引导

好的Harness不是限制Agent，而是：
1. **缩小解空间** — 减少噪音
2. **提高收敛速度** — 加速正确路径
3. **结构化反馈** — 错误成为输入而非终点

## 主流架构模式

### PEV (Plan-Execute-Verify)

三阶段门控架构：

```
[Plan] → 显式分解 + 验收标准
  ↓
[Execute] → 受计划约束，每次调用触发门控
  ↓
[Verify] → 执行前 + 运行时 + 执行后 + 计划对齐
  ↓
[Feedback] → 带上下文的错误消息循环回推理
```

### Coordinator-Implementor-Verifier

多Agent协作模式：
- **Coordinator**：分析、起草"活规格"，委派任务
- **Implementor**：并行执行
- **Verifier**：检查实现，验证依赖

**关键设计**：Verifier的拒绝成为重试循环的**结构化上下文**，而非被静默丢弃。

### ACP (Agent Control Plane)

计算与存储解耦：
- 独立演进存储层（记忆、知识、状态）
- 独立扩展计算层（推理、工具调用）
- 跨会话状态持久化

## 递归自改进机制

### Gödel Agent框架

1. **自我意识**：运行时内存检查
2. **自我改进**：动态代码修改
3. **环境交互**：任务接口评估性能
4. **递归评估**：每轮决定是否进入下一轮

### autocontext多Agent循环

```
competitor → analyst → coach → architect → curator
   ↑_________________________________________↓
```

- **competitor**：提出策略或产物
- **analyst**：解释发生了什么及原因
- **coach**：将分析转化为剧本更新
- **architect**：提出Harness改进
- **curator**：门控哪些知识可以持久化

### Meta-Harness

端到端优化：
1. 提出Harness改进假设
2. 在基准上评估
3. 从失败中学习（因果推理）
4. 组合成功的改进
5. 跨运行转移知识

## 认知反馈循环设计

### 分层认知缓存

- **预取**：检索过去洞察
- **轮级提升**：单轮内积累的经验
- **运行级智慧**：跨运行的可复用经验

### 知识持久化原则

1. 验证过的知识跨运行积累
2. 失败不丢弃，成为重试输入
3. 活规格（Living Spec）持续更新

## 与本技能的融合

费曼认知Harness将Harness Engineering应用于**知识获取场景**：

| Harness组件 | 本技能对应 |
|------------|----------|
| 约束层 | D1-D4难度约束、术语禁用 |
| 反馈层 | 审计引擎的缺口报告 |
| 门控层 | 置信度阈值、迭代终止条件 |
| 状态持久化 | 概念晶格存储 |
| 递归循环 | Teach→Audit→Grow迭代 |
| 多Agent协作 | Explainer-Critic-Researcher-Refiner |

## 参考来源

- Augment Code - Harness Engineering for AI Coding Agents (2026)
- arXiv 2410.04444 - Self-Referential Framework for Recursive Self-Improvement
- Greyhaven AI - autocontext
- arXiv 2603.28052 - Meta-Harness: End-to-End Optimization
