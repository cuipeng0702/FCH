---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# FCH 元认知架构分析

> 分析时间: 2026-05-03
> 基于代码版本: v3.5 (orchestrator.py / termination_checker.py / state_manager.py)

---

## 1. 当前元认知状态

### 1.1 主循环结构

当前 Ralph Loop 的流程 (orchestrator.py `run()` 方法):

```
1. LOAD STATE     ← state_manager.load_state()
2. CHECK BUDGET   ← budget.get("remaining", 0) <= 0
3. PICK NEXT TASK ← state_manager.get_next_task(progress)
4. SPAWN WORKER   ← _spawn_worker(task_name, ...)
5. SPAWN AUDITOR  ← _spawn_auditor(output_path, ...)
6. UPDATE PROGRESS← state_manager.mark_task_done()
7. CHECK CONVERGENCE ← _is_converged(state, iteration)
8. SAVE STATE     ← _save_all(state, progress, budget)
9. LOOP or EXIT
```

附加条件检查 (v3.5 模块化、默认 inactive):
- teach 后: persona_audit (可选)
- verify 后: route_gaps → BDD/FCH 分流 (可选)
- consolidate 后: cascade_check (可选)
- 全局: termination_check (可选)

### 1.2 "思考自己是怎么思考的" 在哪？

**当前没有显式的元认知层。**

元认知职责被分散到以下组件中隐式承担:

| 组件 | 隐式元认知功能 | 局限性 |
|------|-------------|--------|
| `_analyze_failure_pattern` | 分析同一任务连续失败3+次的模式，决定 escalate/abort/continue | 只关注单个任务的失败，不关注全局循环健康度 |
| `_is_converged` | 判断 Ming Wu + Novelty + Stuck 检测 | 只判断当前迭代是否满足收敛条件，不判断"是否值得继续" |
| `TerminationEvaluator` | 4条件终止判断（信心衰减、循环边界、累积风险、深度预算） | 仅关注 BDD/FCH 框架的信心和边界状态，不评估循环本身的运行效率 |
| `_run_cascade_check` | 检测上游概念变更对下游的影响 | 被动检测，不主动学习历史模式 |

**结论**: 当前是一个 "无自省能力的执行引擎" —— 它能判断"任务是否完成"、"预算是否耗尽"、"信心是否衰减"，但它不能回答:
- "这个循环现在运行得健康吗？"
- "同样的gap为什么在3个迭代里反复出现？"
- "把预算花在 teach 还是 audit 上更有效？"
- "当前的路由策略是否有效？"

---

## 2. 需要吗？

### 2.1 元认知对 FCH 的价值

1. **防止盲目循环**: 当前循环可以因 "budget > 0" 而持续运行，但 budget 只是资源约束，不是认知约束。元认知可以在资源耗尽之前判断"继续运行不会增加认知价值"。

2. **从失败中学习**: 当前 `_analyze_failure_pattern` 只能检测连续失败并 escalate/abort，但无法回答"为什么这个任务总是失败"、"失败根因是什么"。

3. **优化资源分配**: 当前 budget 是统一扣减（每次 spawn 扣 1），但 teach-agent 和 audit-agent 的认知价值密度不同。元认知可以评估"当前最值得投资哪个环节"。

4. **识别高阶模式**: 当前 history.jsonl 记录了每次迭代的任务输出，但没有人去阅读它、提炼模式。元认知可以定期扫描历史，发现诸如"每次 teach 后都会产生 3 个同类 gaps"之类的模式。

5. **自适应阈值调整**: 当前 thresholds.json 有冷启动默认值（audit_aggregate 0.85），但从不根据历史表现更新。元认知可以基于历史数据调整审计严格度。

### 2.2 没有元认知会出现的问题

- **Zeno-effect 换皮**: 循环可能在同一个概念上反复震荡，每次产生看似不同但本质相同的 gaps，直到 budget 耗尽。
- **修复疲劳**: `_run_single_task` 的 fix loop 最多 3 次，但 3 次是硬编码，没有根据历史修复成功率调整。
- **路由盲飞**: hybrid_routing 的 BDD/FCH 分流决策一旦做出就不再回顾其有效性。
- **级联爆炸**: cascade_engine 可以检测依赖漂移，但没有机制判断"是否值得"触发级联（可能引发无限级联链）。
- **终止后无沉淀**: 终止时 MetaCognitiveSummary 生成一份摘要，但这份摘要只是"报告"，不是"学习"—— 它不会反过来改进下一轮循环。

### 2.3 当前哪些组件隐式承担了元认知功能

- `TerminationEvaluator` 是最接近元认知的组件，但它的 scope 限定在 BDD 框架的信心/边界判断。
- `_analyze_failure_pattern` 有局部元认知能力（任务级失败分析），但无全局视角。
- `MetaCognitiveSummary` 在终止时生成 triage 报告，但这是一个**被动输出**，不是**主动干预**。

---

## 3. 循环终止机制

### 3.1 当前终止条件

**硬停止条件** (orchestrator.py):
1. Budget 耗尽 (`budget.remaining <= 0`)
2. Max fix attempts 耗尽 (`fix_attempt >= 3`)
3. 任务被 Rejected (`action == "rejected"`)

**收敛条件** (`_is_converged`):
A. Ming Wu passed (`mingwu_result.json`)
B. Novelty ACCEPT (`novelty_result.json`)
C. 非 stuck 状态（连续 <3 次未通过 Ming Wu）
D. v3.5 termination-aware (若 termination 模块启用且 `termination_triggered`)

**终止评估条件** (termination_checker.py, 4条件):
1. **DiminishingReturnsCondition**: 新框架信心 < 旧框架信心 × alpha (默认 0.90)
2. **CyclicBoundaryCondition**: 新边界与历史边界集合相似度 ≥ 0.85
3. **CumulativeRiskCondition**: 连续 3 次 🟡 (VALID_WITH_ENHANCEMENTS) 判断
4. **DepthBudgetCondition**: 用户定义的 max_depth

### 3.2 终止决策是否充分？

**不充分。**

当前终止条件的盲区:

| 盲区 | 说明 | 后果 |
|------|------|------|
| 无全局质量趋势判断 | 没有比较"当前迭代的整体质量 vs 上一迭代" | 质量持续下滑但不被检测 |
| 无重复工作检测 | 同一个 gap 在不同迭代中反复出现，只是措辞不同 | 循环在做无用功 |
| 无资源效率评估 | 不知道 teach 产出/AUDIT 产出/预算消耗的比值 | 资源可能被浪费在低价值任务 |
| 无路由策略回顾 | BDD/FCH 分流决策从未被验证是否有效 | 可能一直在错误的轨道上 |
| 无级联深度评估 | cascade 可以无限触发下游重审 | 级联链可能失控 |
| 终止后无反馈学习 | 终止原因和 meta_summary 不更新任何配置 | 同样的终止模式会重复出现 |

### 3.3 需要增加的条件

**建议新增第 5 个终止条件: `MetaCognitiveHealthCondition`**

这个条件关注"循环本身的健康度"而非"框架的信心度":

```python
class MetaCognitiveHealthCondition(TerminationCondition):
    """Condition 5: Overall loop health deterioration."""
    
    def check(self, state, history):
        # 1. 重复 gap 率: 最近 3 个迭代中 >50% 的 gaps 与历史 gaps 重复
        # 2. 修复成功率: 最近 5 次 fix 尝试中成功率 < 20%
        # 3. 资源效率: budget 消耗 / concept 产出 比值持续上升
        # 4. 审计通过率趋势: 最近 3 次审计通过率 < 30%
        # 5. 级联深度: 当前级联链深度 > max_downstream_depth × 2
```

**同时，将元认知评估嵌入循环的每一个 iteration**，而非只在终止时触发。

---

## 4. 经验学习机制

### 4.1 当前 version_stack 记录了什么

从 state_manager.py 可见，当前持久化结构:

| 文件 | 内容 | 用途 |
|------|------|------|
| `state.json` | current_concept, concept_history, confidence, pending_fixes, strategy_adjustments | 运行时状态 |
| `progress.json` | current_iteration, completed_steps, next_step | 执行进度 |
| `budget.json` | max_spawn, remaining, used | 预算 |
| `history.jsonl` | 每次迭代的 UCC 记录 (task, iteration, timestamp, concept_id, confidence) | 历史 |
| `thresholds.json` | audit_aggregate, bdd_confidence 的冷启动阈值 | 阈值 |
| `routing_decision_log.jsonl` | 每次路由决策 (gap_id, action, band, internal_ratio) | 路由日志 |
| `cascade_queue.json` | 级联队列 (concept_id, reason, trigger_concept) | 级联 |

### 4.2 从 version_stack 能提取什么学习信号

基于现有数据结构，可以提取:

1. **失败模式信号**: history.jsonl + exceptions.json → 哪些 task 在什么 iteration 经常失败
2. **gap 重复信号**: state["pending_gaps"] 跨迭代对比 → 哪些 gap 反复出现
3. **路由有效性信号**: routing_decision_log.jsonl → BDD_ONLY vs FCH_ONLY 的后续结果
4. **信心趋势信号**: history.jsonl 中的 confidence 字段 → 信心是上升还是下降
5. **修复成功率信号**: pending_fixes + exceptions.json → fix loop 的成功率
6. **级联频率信号**: cascade_queue.json → 哪些概念频繁触发级联

### 4.3 如何设计"元学习"机制

**方案: 新增 `metacognition_engine.py`**

职责: 每次 iteration 结束后，扫描历史数据，生成"循环健康报告"，并给出策略调整建议。

```
metacognition_engine.py
├── LoopHealthAnalyzer
│   ├── compute_redundancy_ratio()      # 重复 gap 率
│   ├── compute_fix_success_rate()    # 修复成功率趋势
│   ├── compute_resource_efficiency()   # budget/产出比
│   ├── compute_audit_pass_rate()     # 审计通过率趋势
│   └── compute_cascade_depth()       # 级联深度
├── PatternExtractor
│   ├── extract_recurring_gaps()      # 反复出现的 gaps
│   ├── extract_failure_clusters()    # 任务-错误聚类
│   ├── extract_routing_effectiveness() # 路由决策有效性
│   └── extract_concept_difficulty()  # 概念难度排名
├── StrategyAdjuster
│   ├── adjust_thresholds()           # 基于历史调整 thresholds
│   ├── suggest_budget_reallocation() # 建议 budget 重分配
│   ├── suggest_task_skip()           # 建议跳过某些任务
│   └── suggest_early_termination()   # 建议提前终止
└── MetaLearningLog
    ├── append_health_report()        # 记录健康报告
    ├── append_strategy_adjustment()  # 记录策略调整
    └── generate_cumulative_insight() # 跨多轮累积洞察
```

**融入现有组件的方案** (不新增文件):

如果不新增 metacognition_engine.py，可以将元认知功能融入现有组件:

1. **融入 orchestrator.py**:
   - 在 `CHECK CONVERGENCE` 之前增加 `CHECK LOOP HEALTH` 步骤
   - 在 `_save_all()` 之前调用 `_update_metacognitive_state()`
   - 在 `_is_converged()` 中增加冗余检测和效率检测

2. **融入 termination_checker.py**:
   - 在 `TerminationEvaluator` 中新增 `MetaCognitiveHealthCondition`
   - 让 `MetaCognitiveSummary` 不仅输出报告，还输出 `recommended_config_changes`

3. **融入 state_manager.py**:
   - 新增 `metacognition_log.jsonl` 持久化
   - 新增 `load_metacognitive_insights()` 方法供 orchestrator 读取

---

## 5. 实施建议

### 5.1 推荐方案: 渐进式增强（不新增文件）

基于当前 v3.5 的模块化设计，推荐将元认知能力融入现有组件:

#### 步骤 1: 增强 `termination_checker.py`

新增 `MetaCognitiveHealthCondition` (第 5 终止条件):

```python
class MetaCognitiveHealthCondition(TerminationCondition):
    """检测循环健康度恶化:
    - 重复 gap 率 > 50%
    - 修复成功率 < 20%
    - 审计通过率连续下降
    - 级联深度超过阈值
    """
    def check(self, state, history):
        # 从 state_manager 读取历史数据计算指标
        # 返回 triggered + metrics
```

修改 `MetaCognitiveSummary.generate()` 增加 `recommended_adjustments` 字段:

```python
"recommended_adjustments": {
    "threshold_changes": [...],
    "budget_reallocation": [...],
    "task_skip_suggestions": [...],
}
```

#### 步骤 2: 增强 `orchestrator.py`

在 `run()` 方法中，每个 iteration 结束后增加元认知检查:

```python
# 7. CHECK METACOGNITION (新增)
if self._module_enabled("metacognition"):
    health = self._check_loop_health(state, iteration)
    if health.get("recommend_terminate"):
        self._finalize_with_meta_summary(state, progress, budget, {
            "terminate": True,
            "reason": health["primary_reason"],
            "meta_cognitive_summary": health,
        })
        break
    if health.get("recommended_adjustments"):
        self._apply_strategy_adjustments(health["recommended_adjustments"], state)
```

新增 `_check_loop_health()` 方法:

```python
def _check_loop_health(self, state, iteration):
    """评估循环健康度，返回建议。"""
    # 1. 加载最近 3 个 iteration 的 gaps
    # 2. 检测重复 gaps
    # 3. 加载 exceptions.json 计算修复成功率
    # 4. 加载 history.jsonl 计算信心趋势
    # 5. 计算 budget 效率
    # 6. 返回健康报告和建议
```

#### 步骤 3: 增强 `state_manager.py`

新增元认知日志持久化:

```python
def append_metacognition_report(self, report: dict) -> None:
    """Atomic append to metacognition_log.jsonl."""
    # 同 history.jsonl 的写入方式

def load_metacognition_insights(self, n: int = 10) -> list[dict]:
    """读取最近 n 次元认知报告。"""
```

#### 步骤 4: 新增 `config.yaml` 配置

```yaml
modules:
  metacognition:
    enabled: true
    check_interval: 1  # 每 iteration 检查
    redundancy_threshold: 0.5  # 重复 gap 率阈值
    fix_success_threshold: 0.2  # 修复成功率阈值
    max_cascade_depth_multiplier: 2  # 级联深度倍数
```

### 5.2 替代方案: 新增独立 `metacognition_engine.py`

如果希望元认知层完全独立，可新增文件:

- `harness/metacognition_engine.py` — 元认知引擎
- `../../harness/agents/self_aware_agent_template.md` — 元认知 agent 的模板

但这会增加架构复杂度。当前 FCH 已经足够复杂，推荐**渐进式融入现有组件**。

### 5.3 关键实施优先级

| 优先级 | 改动 | 影响 | 工作量 |
|--------|------|------|--------|
| P0 | 新增 `MetaCognitiveHealthCondition` | 防止循环健康恶化时不被检测 | 中 |
| P0 | `MetaCognitiveSummary` 输出 `recommended_adjustments` | 终止后沉淀学习 | 小 |
| P1 | orchestrator 增加 `_check_loop_health()` | 每 iteration 主动评估 | 中 |
| P1 | state_manager 增加 `metacognition_log.jsonl` | 持久化元认知报告 | 小 |
| P2 | 基于历史数据自适应调整 `thresholds.json` | 让阈值随历史表现进化 | 中 |
| P2 | 修复成功率动态调整 `max_fix_attempts` | 替代硬编码的 3 次 | 小 |

### 5.4 一句话总结

> 当前 FCH 有"终止检查"但没有"元认知"—— 它能判断"是否该停了"，但不能回答"为什么该停"、"从这次循环中学到了什么"、"下次如何更好"。元认知不是奢侈品，是防止循环在盲目中耗尽预算的最后一道防线。
