---
tag: [DESIGN]
load_when: "了解 FCH 设计哲学和认知理论基础"
---

## Philosophy

Most AI systems suffer from the **Illusion of Understanding** — they can generate plausible-sounding explanations without actually grasping the underlying concept.

This system solves this by enforcing **epistemic rigor** through a recursive teaching-auditing-growing cycle that mimics how humans actually learn. **Ralph Loop v3.5** (Cognitive Scaffold Evaluation & Deepening — Distributed Agent Architecture) evolves the v3.2 monolithic self-driving loop into a stateful coordinator + subagent outsourcing model. The 7-layer CSED-CLIF architecture is preserved in logic but distributed across subagents: Search → Teach → Audit → Grow → Verify → Consolidate → Quality Audit → Termination. Each step is independently testable and replaceable.

**Core insight**: True understanding manifests as the ability to explain at multiple granularities (D1-D4), and the **gaps and contradictions between these granularities reveal what you don't actually know**. v3.5 adds **Ralph Loop**: a distributed agent architecture where the coordinator delegates each cognitive step to specialized subagents. Auto-Deepening (introduced in v3.2) is preserved: the system automatically checks Ming Wu conditions after each iteration, monitors novelty ratios to detect stagnation, and triggers external searches when internal deepening reaches a ceiling — eliminating the need for human "continue" prompts.

**v3.5 Ralph Loop + Auto-Deepening features**:
- **Internal Ming Wu trigger**: 6-condition automatic assessment (confidence, BSS, problems, contradictions, emotion, convergence)
- **Novelty monitoring**: Jaccard-based repetition detection; stuck when novelty < 0.15
- **Auto-search trigger**: External knowledge fetch after 3 stuck iterations or novelty threshold breach
- **Self-test on code change**: Automatic import validation after every file modification
