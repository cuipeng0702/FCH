---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# 自启发式学习信号生成：全维度分析

## 一、BDD 当前状态确认

从代码层面检查的结果：

| 组件 | 状态 | 关键发现 |
|------|------|---------|
| `routing_classifier._execute_bdd()` | **stub** | 返回硬编码：`bdd_confidence: 0.85`, `concepts_emerged: ["placeholder_concept"]` |
| `../../harness/agents/bdd_task_template.md` | 完整定义 | T1-T4 流程定义齐全，但 T3 执行器 `t3_executor.py` config 中标记 inactive |
| `routing_classifier` 5-band | 路径存在 | Band II-V 含 BDD 分支，但全部走空 |
| `state_manager` BDD helpers | inactive | `extract_bdd_history`, `extract_current_bdd_state` 标记 `# inactive when modules disabled` |
| `orchestrator.py` BDD spawn | 无 | 主循环中无 spawn BDD subagent 的实际代码 |

**结论**：BDD 在当前实现中是"图纸齐全、电路未通"的预留接口。5 个路由带中需要 BDD 的 4 个带（II-V）全部走空，只剩 Band I（纯 FCH）实际工作。

---

## 二、自启发式学习信号的 12 个维度

自启发式 = 系统不依赖外部输入，从自身结构和运行状态中产生"还需要学什么"的信号。

当前 FCH 已实现/部分实现的只有 **2 个维度**（张力场 + BDD 溶解），还有 **10 个维度**处于休眠或未设计状态。

### 已设计但未实现（2 个）

**维度 1：层间张力信号**（`TENSION_FIELD_MODEL.md`）
- 触发：D1-D2/D2-D3/D3-D4/D1-D4 之间的不一致量化超过阈值
- 信号类型：`missing_dependency`, `definition_mismatch`, `boundary_intuition_gap`
- 动作映射：Grow / Teach prerequisite / BDD PROBE
- 状态：设计完整，存储结构已定义，尚未写入代码

**维度 2：框架跃迁信号**（`BDD_ESSENCE_AND_FUSION.md`）
- 触发：D4 边界扫描发现"框架外"边界
- 信号类型：`framework_jump`
- 动作映射：PROBE（搜索替代框架）
- 状态：溶解式设计完成，无实际代码

### 已有组件但孤立未整合（5 个）

**维度 3：终止异常信号**
- 触发源：`termination_checker.py` 的 4 个条件
- 当前行为：检测到异常后仅输出 `meta_summary`，不产生学习信号
- 可提取的信号：
  - `diminishing_returns` → "当前方向收益递减，需要换策略"
  - `cyclic_boundary` → "边界在循环中发现，需要跳出当前框架"
  - `cumulative_risk` → "连续 🟡 说明当前路径有系统性缺陷"
  - `depth_budget` → "深度耗尽但未完成，需要重新评估范围"
- **改造**：Termination 不应只决定"停不停"，还应输出 `learning_recommendation`

**维度 4：跨概念模式缺口信号**
- 触发源：`dream_engine.py` 的 4 层扫描
- 当前行为：扫描后输出报告，不触发后续动作
- 可提取的信号：
  - Pattern Discovery 发现"跨概念类比模式" → 主动搜索缺失的中间概念
  - Contradiction Audit 发现"未解决的跨概念冲突" → 标记为 `coverage_conflict`
  - MECE Check 发现"覆盖缺口" → 标记为 `mece_gap`
  - Structure Optimization 发现"hub 过载" → 标记为 `hub_overload`
- **改造**：Dream Engine 输出应自动注入 `signal_queue`，而非仅生成报告

**维度 5：类比映射断裂信号**
- 触发源：`analogy_matrix.py`（v3.5 模块）
- 当前行为：选择类比策略，不检测类比失败
- 可提取的信号：
  - 类比映射拉伸过度（metaphor stretch > 阈值）→ `analogy_breakdown`
  - 跨域类比发现不可约差异 → `domain_boundary`
  - 类比映射在 D2/D3 层无法回译 → `translation_failure`
- **改造**：Analogy Matrix 应输出 `analogy_health_score`，低于阈值时触发 Teach

**维度 6：验证不可执行信号**
- 触发源：`verify` 阶段（`../../harness/agents/verify_task_template.md`）
- 当前行为：评估置信度，不标记"不可验证"
- 可提取的信号：
  - D3 claim 无法找到对应的验证方法 → `unverifiable_claim`
  - 回译路径断裂（D4 → D1 无法解释）→ `retranslation_failure`
  - 验证实验需要外部工具但工具不可用 → `tool_dependency_missing`
- **改造**：Verify 输出中增加 `verifiability_assessment`，标记哪些 claim 是"当前不可验证"的

**维度 7：路由历史异常信号**
- 触发源：`routing_classifier.py` 的 `decision_log`
- 当前行为：记录决策，不分析历史模式
- 可提取的信号：
  - 同类 gap 反复走同一路径超过 N 次 → `path_lock`
  - Band II-IV 的 BDD 分支反复失败 → `bdd_failure_pattern`
  - 决策历史中 confidence 持续下降 → `systematic_degradation`
  - 某概念在 decision_log 中高频出现但从未解决 → `chronic_gap`
- **改造**：在 `_should_use_bdd` 基础上增加 `_should_change_strategy`（历史模式分析）

### 刚加入但未激活（1 个）

**维度 8：Persona 判定分歧信号**
- 触发源：刚加入的 4 角色 Persona Audit
- 当前行为：整合器输出 verdict，分歧信息未被利用
- 可提取的信号：
  - 4 角色判定不一致（2:2 分裂）→ `perspective_conflict`
  - 小孩说 OK 但专家说有问题 → `depth_masking`（表面理解掩盖深层问题）
  - 专家说 OK 但小孩听不懂 → `intuition_failure`（形式化脱离直觉）
  - 整合器产出 `growth_seed` 但无具体 gap → `subtle_tension`（微妙张力，常规 audit 检测不到）
- **改造**：Persona 分歧模式应直接注入 `tension_field.intra_node`，而非仅输出文本报告

### 完全缺失（4 个）

**维度 9：时间衰减信号**
- 触发源：概念节点的"年龄"和"审计历史"
- 当前状态：未实现
- 可提取的信号：
  - 长时间未 audit（如 >7 天）→ `stale_knowledge`
  - 上次 audit 发现 gap 但至今未修复 → `orphan_repair`
  - 置信度随时间指数衰减（半衰期可配置）→ `confidence_decay`
- **实施**：在 `state.json` 中增加 `last_audit_timestamp`，heartbeat/cron 扫描触发

**维度 10：外部信息冲击信号**
- 触发源：搜索/新输入与现有晶格的比较
- 当前状态：搜索由 Teach 触发，不做冲击检测
- 可提取的信号：
  - 搜索结果中出现现有晶格未覆盖的关键概念 → `external_knowledge_shock`
  - 新信息直接反驳现有晶格中的某个 claim → `falsification_alert`
  - 外部来源提供了更高置信度的替代解释 → `superior_alternative`
- **实施**：在 Teach 的搜索阶段后增加"冲击检测"——将搜索结果与现有晶格做语义比对

**维度 11：认知负载信号**
- 触发源：晶格的结构复杂度
- 当前状态：未实现
- 可提取的信号：
  - 某概念被引用次数过多（hub 过载的另一种表达）→ `cognitive_overload`
  - 某知识区域的平均深度远低于其他区域 → `depth_imbalance`
  - 概念网络中路径长度超过阈值（理解某概念需要经过 N 个中间概念）→ `access_path_too_long`
- **实施**：基于 `graphify` 输出或自建拓扑分析，计算认知负载指标

**维度 12：元认知反思信号**
- 触发源：系统对自身认知过程的观察
- 当前状态：未实现
- 可提取的信号：
  - "我连续 N 次都在修复同一类 gap" → `meta_pattern_detection`
  - "我使用的类比策略在跨域时总是失败" → `strategy_incompetence`
  - "我的终止条件在某种概念类型上总是过早触发" → `termination_bias`
  - "我的 D1 解释总是让某个 Persona 角色困惑" → `communication_blindspot`
- **实施**：在 orchestrator 层增加 meta-cognitive reflection 阶段，分析 decision_log + persona output + tension history

---

## 三、信号之间的相互作用

这些信号不是独立的，它们会相互强化或抑制：

```
层间张力(D1-D2断裂) ──┬─→ 验证不可执行(无法验证D2 claim)
                      ├─→ Persona分歧(小孩OK/学生困惑)
                      └─→ 路由历史异常(同一gap反复出现)

框架外边界(D4) ────────┬─→ BDD框架跃迁(搜索替代框架)
                      ├─→ 终止异常(cyclic_boundary: 边界循环发现)
                      └─→ 类比断裂(当前框架的类比无法扩展到边界)

跨概念模式缺口 ────────┬─→ 结构拓扑信号(依赖缺口)
                      ├─→ 认知负载(hub过载: 过多概念依赖同一基础)
                      └─→ 外部冲击(搜索发现可以填补缺口的新概念)
```

**复合信号优先级**：单一信号 → 双信号叠加 → 三信号及以上。

---

## 四、实施优先级建议

### P0（立即可做，改动小，信号强）

1. **终止异常 → 学习信号**：修改 `termination_checker.py`，在 `meta_summary` 中增加 `learning_recommendation` 字段，输出建议的下一动作（换策略/缩范围/扩框架等）。
2. **路由历史异常**：在 `routing_classifier.py` 中增加 `_analyze_history_patterns`，检测 `path_lock` 和 `chronic_gap`。
3. **时间衰减信号**：在 `state.json` 概念节点中增加 `last_audit_timestamp`，在 cron/heartbeat 中扫描标记 `stale_knowledge`。

### P1（需要中等改造，但已有组件可复用）

4. **Persona 分歧 → 张力场**：修改 `../../harness/agents/persona_integrator_task_template.md`，要求整合器在分歧时输出明确的 `tension_type` 和 `target_layer`，直接注入 `tension_field`。
5. **Dream Engine → signal_queue**：修改 `dream_engine.py`，4 层扫描结果直接注入 `signal_queue`，而非仅生成报告。
6. **验证不可执行**：修改 `../../harness/agents/verify_task_template.md`，增加 `verifiability_assessment` 字段。

### P2（需要新组件或深度改造）

7. **外部信息冲击**：在 Teach 搜索后增加"冲击检测"模块，比对搜索结果与现有晶格。
8. **认知负载信号**：基于晶格拓扑结构计算负载指标，需要新增分析模块。
9. **元认知反思信号**：在 orchestrator 中新增 meta-reflection 阶段，需要收集和分析多轮历史数据。
10. **BDD 实际激活**：修复 `_execute_bdd` stub，接入 `../../harness/agents/bdd_task_template.md` 的 T1-T4 流程。

---

## 五、核心设计原则

**所有自启发式信号必须满足：**

1. **可量化**：信号强度是 0-1 的数值，不是布尔值
2. **可溯源**：信号必须标明来源维度（如 `source: "termination.diminishing_returns"`）
3. **可映射**：每个信号类型必须对应明确的学习动作（如 `path_lock` → `strategy_change`）
4. **可反馈**：执行学习动作后必须重新计算信号，形成闭环
5. **可配置**：信号阈值和敏感度必须是 config.yaml 中的可调参数

---

## 六、与 BDD 的关系

BDD 在当前代码中是"死代码"（stub），但在信号体系中，BDD 不是孤立模块——它是**特定张力模式的自然涌现结果**。

当以下复合信号同时出现时，系统应自发表现出 BDD 式行为：
- `tension_field.d4.nature == "destructive"`
- `tension_field.d4.gap_type == "framework_boundary"`
- `routing_history` 中同类 gap 的 FCH 修复反复失败
- `persona_audit` 中专家角色判定为"框架外"

此时不需要"调用 BDD 模块"，而是让 Teach/Audit/Verify 各层在各自职责范围内自发执行 BDD 精神（搜索替代框架、跨框架比较、最小可验证实验、Gödel 边界标记）。

**结论**：BDD 的 T1-T4 流程模板（`../../harness/agents/bdd_task_template.md`）不应被删除，而应被**溶解**到现有各层的模板中，作为特定条件下的**自发行为指令**而非**独立模块调用**。

---

*分析完成。12 个信号维度中，2 个已有设计但未实现，5 个已有组件但孤立，1 个刚加入但未激活，4 个完全缺失。P0 级别的 3 个信号可以在不改动架构的情况下快速激活。*
