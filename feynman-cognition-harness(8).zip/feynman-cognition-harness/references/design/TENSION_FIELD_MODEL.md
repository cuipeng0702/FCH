---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# 张力场驱动的认知涌现：存储架构深度重构方案

## 一、问题重定位：当前模式的根本局限

当前 FCH 的存储逻辑是**内容中心**的：

```json
{
  "concept_id": "transformer",
  "d1": "类比解释...",
  "d2": "操作机制...",
  "d3": "形式化定义...",
  "d4": "边界追问..."
}
```

每个概念存了四段文本，假设它们"应该一致"。不一致时由外部 Audit 检测，再触发 Grow 修复。

**根本问题**：
1. **张力是隐式的**：D1-D4 之间的不一致只有在 Audit 时才能发现，平时不可见
2. **结构张力是离散的**：节点间的关系只在 dependency_chain 中列个名字，没有持续的结构应力感知
3. **涌现是被动的**：系统不会"自己觉得该学习了"，必须等外部触发或定期检查
4. **修复是单向的**：Grow 修复后没有反馈回路告诉系统"张力是否降低"

用户的真正需求：让系统**持续感知自身的不完备性**，并将这种不完备性转化为**自发的学习动力**。

---

## 二、张力的本质：两种认知应力

### 2.1 层间张力（Intra-node Tension）

D1-D4 四层不是"同一解释的不同版本"，而是**同一概念在不同认知深度上的投影**。它们之间必然存在张力——这是认知深度的来源。

| 张力对 | 本质 | 健康状态 |
|--------|------|---------|
| D1-D2 | 类比是否足以支撑操作 | 适度张力 = 类比有解释力但不越界 |
| D2-D3 | 操作能否对应形式化 | 低张力 = 操作与形式一致 |
| D3-D4 | 形式化是否考虑了所有边界 | 适度张力 = 形式化紧凑但边界开放 |
| D1-D4 | 直觉是否能容纳边界发现 | 张力反映认知跨度 |

**关键洞察**：张力不是错误，张力是**认知结构的健康指标**。零张力意味着认知僵化（所有层说一样的话），过高张力意味着认知断裂（层之间无法对话）。

### 2.2 结构张力（Inter-node Tension）

概念网络中的拓扑应力：

| 张力类型 | 本质 | 信号 |
|---------|------|------|
| **依赖缺口** | A 需要 B 但 B 缺失或薄弱 | "这里有个洞" |
| **循环定义** | A↔B 互相依赖 | "需要外部锚点" |
| **覆盖冲突** | A 和 B 都声称解释同一现象但结论不同 | "框架冲突" |
| **孤儿应力** | 某概念无入边也无出边 | "悬空知识" |
| **hub 过载** | 某概念被过多概念依赖 | "理解瓶颈" |

---

## 三、张力场存储模型

### 3.1 核心转变：从"内容存储"到"张力场存储"

不再以"概念内容"为核心存储对象，而是以**概念的认知张力状态**为核心。

D1-D4 仍然存在，但它们不再是"静态解释文本"，而是**张力场的缓解产物**——当某层对的张力升高时，系统会尝试更新对应层的内容以降低张力。

### 3.2 概念节点的新结构

```json
{
  "concept_id": "transformer",
  "content": {
    "d1": "类比解释...",
    "d2": "操作机制...",
    "d3": "形式化定义...",
    "d4": "边界追问..."
  },
  
  "tension_field": {
    "intra_node": {
      "d1_d2": {
        "score": 0.3,
        "nature": "productive",
        "gap_type": "analogy_stretch",
        "last_audit": "2026-05-01T10:00:00Z",
        "audit_history": [
          {"time": "...", "score": 0.5, "action": "grow", "effect": -0.2}
        ]
      },
      "d2_d3": {
        "score": 0.7,
        "nature": "destructive",
        "gap_type": "definition_mismatch",
        "last_audit": "2026-05-01T10:00:00Z",
        "audit_history": [
          {"time": "...", "score": 0.8, "action": "grow", "effect": -0.1}
        ]
      },
      "d3_d4": {
        "score": 0.2,
        "nature": "productive",
        "gap_type": null,
        "last_audit": "2026-05-01T10:00:00Z"
      },
      "d1_d4": {
        "score": 0.4,
        "nature": "productive",
        "gap_type": "boundary_intuition_gap"
      }
    },
    
    "inter_node": {
      "dependencies": [
        {
          "target": "attention_mechanism",
          "direction": "outgoing",
          "status": "resolved",
          "tension": 0.0,
          "resolved_by": "teach_001"
        },
        {
          "target": "positional_encoding",
          "direction": "outgoing",
          "status": "missing",
          "tension": 1.0,
          "detected_by": "decompose_003"
        }
      ],
      "contradictions": [],
      "orphan_score": 0.1,
      "hub_load": 0.3
    },
    
    "composite": {
      "max_tension": 1.0,
      "critical_path": "missing_dependency:positional_encoding",
      "saturation": 0.35,
      "overall_health": "stressed"
    }
  },
  
  "learning_signal": {
    "active": true,
    "signal_type": "missing_dependency",
    "target": "positional_encoding",
    "priority": 0.92,
    "origin": "inter_node.tension",
    "auto_trigger": true,
    "queued_at": "2026-05-01T10:05:00Z"
  }
}
```

### 3.3 全局晶格的新结构

```json
{
  "lattice_meta": {
    "tension_heatmap": {
      "last_updated": "2026-05-01T12:00:00Z",
      "hotspots": [
        {"concept": "transformer", "tension": 1.0, "type": "missing_dependency"},
        {"concept": "quantum_field", "tension": 0.85, "type": "framework_boundary"}
      ],
      "global_health": 0.6
    },
    "signal_queue": [
      {"concept": "transformer", "signal": "missing_dependency", "priority": 0.92, "queued_at": "..."},
      {"concept": "quantum_field", "signal": "framework_boundary", "priority": 0.85, "queued_at": "..."}
    ]
  },
  
  "concepts": {...},
  "relations": {...}
}
```

---

## 四、张力量化机制

### 4.1 层间张力计算公式

```
tension_dX_dY = base_score(audit_result) 
                × decay_factor(time_since_last_audit)
                × amplification_factor(repeated_gaps)

nature = classify_nature(tension_score, gap_pattern):
    if gap_type in ["definition_mismatch", "circular_definition", "contradiction"]:
        return "destructive"
    elif gap_type in ["analogy_stretch", "boundary_intuition_gap", "depth_spread"]:
        return "productive"
    else:
        return "neutral"
```

**创造性张力 vs 破坏性张力的判定**：

| 特征 | Productive（保留） | Destructive（驱动学习） |
|------|-------------------|------------------------|
| 层对 | D1-D4, D1-D2（适度） | D2-D3（映射失败） |
| 表现 | 直觉与边界之间有认知跨度 | 操作解释与形式化矛盾 |
| 修复方式 | 不修复，标记为"认知跨度" | 必须修复，否则认知断裂 |
| 信号生成 | 否 | 是 |

### 4.2 结构张力计算公式

```
tension_inter = Σ(
    missing_dependency × 1.0,
    circular_definition × 0.9,
    coverage_conflict × 0.8,
    orphan_score × 0.5,
    hub_overload × 0.4
) × network_position_factor
```

---

## 五、自发涌现机制：信号生成与处理

### 5.1 信号生成规则

```
for each concept in lattice:
    # 1. 计算综合张力
    total_destructive = sum(
        t.score for t in concept.tension_field.intra_node 
        if t.nature == "destructive"
    ) + sum(
        t.tension for t in concept.tension_field.inter_node.dependencies
        if t.status == "missing"
    )
    
    # 2. 信号阈值检测
    if total_destructive > SIGNAL_THRESHOLD:
        signal = generate_signal(concept, dominant_gap)
        lattice.signal_queue.push(signal)
    
    # 3. 信号去重与合并
    if concept already has active_signal:
        update_priority(signal)
    else:
        create_new_signal(signal)
```

### 5.2 信号类型与学习动作的映射

| 主导张力模式 | 信号类型 | 学习动作 | 预期效果 |
|------------|---------|---------|---------|
| D2-D3 definition_mismatch + 依赖概念存在 | 映射修复 | Grow: definition_reconcile | 降低 D2-D3 张力 |
| D2-D3 definition_mismatch + 依赖概念缺失 | 先修缺失 | Teach: prerequisite | 降低结构张力 |
| D4 framework_boundary（框架外） | 框架跃迁 | BDD式: PROBE | 降低 D4 张力 |
| D4 framework_boundary（框架内） | 边界扩展 | Grow: boundary_annotation | 降低 D1-D4 张力 |
| 跨概念 D3 结构相似 | 合成涌现 | CrossCompose | 产生新节点，缓解覆盖缺口 |
| 循环定义 | 锚定突破 | Grow: anchor_breakthrough | 降低结构张力 |
| 孤儿节点 | 连接建立 | Search: find_relations | 降低 orphan_score |
| Hub 过载 | 负载分流 | Decompose: 拆分概念 | 降低 hub_load |

### 5.3 负反馈闭环

```
执行学习动作 → 更新 content (d1-d4) → 重新 Audit → 更新 tension_field
    ↑                                                              ↓
    ←—————————— 若张力降低，signal 标记 resolved，从 queue 移除 ←——
```

**关键**：每次学习动作后必须重新计算张力，否则系统不知道"修好了没有"。这是当前 FCH 缺失的反馈回路。

---

## 六、与现有 FCH 的衔接

### 6.1 兼容性保证

- `content.d1-d4` 完全保留现有格式
- `state.json` 结构扩展而非替换
- 现有 Teach/Audit/Grow/Verify/Consolidate 循环不变
- 新增 `tension_scan` 阶段（可放在 Consolidate 之后或作为 heartbeat/cron）

### 6.2 渐进实施路径

| 阶段 | 内容 | 风险 |
|------|------|------|
| 1 | 在现有概念节点中增加 `tension_field` 骨架（空结构） | 零风险 |
| 2 | Audit 完成后自动写入 `intra_node` 张力数据 | 低风险 |
| 3 | 结构分析（dependency解析）自动写入 `inter_node` 张力数据 | 低风险 |
| 4 | 新增 `tension_scan` 阶段，生成 `learning_signal` | 中等风险 |
| 5 | 新增 `signal_queue`，按优先级排序 | 中等风险 |
| 6 | 系统空闲时自动从 `signal_queue` 取任务执行 | 高风险（需控制频率） |

---

## 七、与 BDD 精神的融合

在此张力场模型中，BDD 不是外部模块，而是**特定张力模式的涌现结果**：

```
当 tension_field 检测到：
  D4 的 nature = "destructive"
  gap_type = "framework_boundary"
  且 framework_boundary 类型 = "external"（框架外）
→ 自动生成的 learning_signal 类型 = "framework_jump"
→ 对应学习动作 = BDD式 PROBE（探测替代框架）
→ 学习结果更新 tension_field：
    - 若找到替代框架 → 新增 perspective，原 perspective 标记 superseded
    - 若标记为 Gödel → D4 张力从 destructive 转为 productive（"已知不可判定"）
```

**BDD 的溶解**：不是"调用 BDD 模块"，而是"张力场在特定配置下自发产生框架跃迁行为"。

---

## 八、本质总结

| 维度 | 旧模式 | 张力场模式 |
|------|--------|-----------|
| 存储核心 | 概念内容（D1-D4 文本） | 认知张力状态（应力场） |
| D1-D4 的角色 | 静态解释 | 张力缓解产物 |
| 不一致的可见性 | Audit 时才能发现 | 持续量化、随时可读 |
| 学习触发 | 外部命令或定期检查 | 张力突破阈值自发涌现 |
| 修复反馈 | 无（Grow 后不知道修好了没） | 有（更新后重算张力，信号清除） |
| BDD 的位置 | 外部模块 | 特定张力模式的自发行为 |

**一句话**：让系统持续"感知自己的不完备性"，并将这种不完备性转化为"自发的学习动力"。

---

*此方案的核心是"张力"而非"内容"。D1-D4 仍然是存储的内容，但系统的运行逻辑围绕张力场展开——张力高的地方自发涌现学习信号，学习完成后张力降低，形成认知的负反馈闭环。*
