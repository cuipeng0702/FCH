---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# FCH v3.4 设计草案：BDD 精神的有机融入

## 目标

将 BDD（Build-Discover-Demonstrate）的理念与精神融入 FCH v3.5 的 Ralph Loop，提升认知的**自发涌现能力**。

**核心洞察**：BDD 不是 FCH 的外部补丁，而是 FCH 在触及边界时的**自然延伸**——当 FCH 的 D4 追问发现当前框架失效时，系统应自发启动 BDD 式验证，而非等待人工干预。

---

## BDD 精神的四要素

| 要素 | 精神 | 融入 FCH 的位置 |
|------|------|----------------|
| **T1 理论构建** | 形式化公理 + 内部一致性检查 | Teach 层的 D3 生成后自动触发 |
| **T2 跨变体比较** | 多种表述方式的等价性验证 | Audit 层的跨层比较升级为"跨变体" |
| **T3 可执行实验** | 关键 claim 设计最小验证实验 | Verify 层引入 T3Executor 实验模板 |
| **T4 Gödel 边界** | 明确标记不可判定区域 | Termination 层新增"全红"终止条件 |

---

## 融入方案：三处关键改造

### 改造 1：Teach 层 — D3 形式化后自动 T1 检查

**当前**：GenesisLayer 生成 D1-D4 后直接输出。
**改造后**：D3 生成后自动执行**形式一致性快速扫描**（ lightweight T1 ）：

```python
# 新增: teach 完成后自动 T1 检查
if d3_output:
    t1_result = lightweight_t1_check(d3_output)
    if t1_result.consistency_score < 0.6:
        # 形式不自洽 → 标记为 🟡 区域，触发下一轮 grow
        teach_output["yellow_zones"].append({
            "layer": "D3",
            "type": "formal_inconsistency",
            "t1_score": t1_result.consistency_score,
            "suggested_action": "PROBE"  # BDD 精神：探测边界
        })
```

**lightweight_t1_check 实现**：
- 提取 D3 中的所有数学断言
- 用符号逻辑做基本一致性检查（非完整证明，是"语法级"检查）
- 输出 consistency_score（0-1）

### 改造 2：Audit 层 — 跨层矛盾升级为"跨变体等价"

**当前**：ContradictionDetector 检测 D1↔D4 直接矛盾。
**改造后**：新增 **Cross-Variant Equivalence Checker**（T2 精神）：

```python
# 新增: 检查 D1-D4 是否真的是同一概念的 4 种表述
variant_check = check_cross_variant_equivalence(d1, d2, d3, d4)
if variant_check.equivalence_score < 0.7:
    # 4 层表述可能不是同一概念 → 标记为 🔴 区域
    audit_result["red_zones"].append({
        "type": "variant_divergence",
        "score": variant_check.equivalence_score,
        "suggested_action": "BDD_ESCALATION"  # 需要 BDD 式深度验证
    })
```

**check_cross_variant_equivalence 实现**：
- 提取 D1-D4 的核心断言集合
- 检查 D1 的类比是否在 D2 有对应因果链
- 检查 D2 的因果链是否在 D3 有对应公式
- 检查 D3 的公式是否在 D4 有对应边界条件
- 输出 equivalence_score + divergence_points

### 改造 3：Verify 层 — 关键 claim 的最小可验证实验

**当前**：VerificationLayer 用 cross-temporal audit + external search。
**改造后**：对高置信度 claim 自动设计**最小可验证实验**（T3 精神）：

```python
# 新增: 对关键 claim 设计最小实验
for claim in extract_critical_claims(d3_output):
    if claim.confidence > 0.8 and claim.testable:
        experiment = design_minimal_experiment(claim)
        if experiment.tier == "T2":
            # 有形式工具可执行
            t3_result = t3_executor.run(experiment)
            claim.empirical_support = t3_result.verdict
        elif experiment.tier == "T1":
            # 思想实验
            t3_result = t3_executor.run_thought_experiment(experiment)
            claim.empirical_support = t3_result.verdict
```

**design_minimal_experiment 规则**：
- 数学 claim → 找反例 / 边界 case
- 物理 claim → 极限测试
- 算法 claim → 小规模实例验证
- 不可测试 claim → 标记为 🔴 Gödel 区域

### 改造 4：Termination 层 — 新增"全红"终止条件

**当前**：max_iterations / stuck / confidence_threshold。
**改造后**：新增 **All-Gödel 终止条件**（T4 精神）：

```python
# 新增: 所有可验证路径均已触及 Gödel 边界
if all_zones_are_red() and no_yellow_zones_remain():
    termination_reason = "ALL_GODEL_REACHED"
    # 输出最终报告时明确标记 🔴 区域
    final_report["godel_boundaries"] = extract_red_zones()
```

---

## 自发涌现机制：BDD 触发器

BDD 精神的真正价值不在于"执行 BDD 流程"，而在于**让 FCH 在运行中自发发现需要 BDD 式验证的时刻**。

### 触发器 1：D4 边界探测发现框架失效

```
当 D4_boundary_scan 发现:
  "当前概念在 X 条件下不自洽"
  且 X 条件不是已知的边界条件（是新发现）
→ 触发 BDD_PROBE:
  1. 标记当前框架可能需要替换
  2. 搜索替代框架（BDD T1 精神）
  3. 将替代框架加入研究队列（涌现新方向）
```

### 触发器 2：Cross-Variant 等价检查失败

```
当 check_cross_variant_equivalence 发现:
  D1 的类比与 D3 的公式不一致
  且 grow 修复后仍不一致
→ 触发 BDD_ESCALATION:
  1. 标记该概念需要跨框架比较
  2. 生成 BDD 子任务（T1-T4 完整流程）
  3. 将 BDD 结果反馈到概念 lattice
```

### 触发器 3：T3 实验持续失败

```
当连续 2 个 T3 实验对同一 claim 返回 FAIL:
  → 触发 PARADIGM_MARKER（BDD T4 精神）
  1. 标记该 claim 处于 Gödel 边界
  2. 将该区域标记为 🔴
  3. 记录为"已知异常"而非"失败"
```

---

## 与 UCC 元框架的对齐

| UCC 阶段 | 融入 BDD 后的 FCH |
|---------|------------------|
| input | TriggerDaemon（不变） |
| detect | AuditEngine + **Cross-Variant Checker**（新增 T2） |
| decide | HybridRouter + **BDD 触发器**（新增 PROBE 路由） |
| operate | GenesisLayer + **lightweight T1**（新增）+ **T3 实验**（新增） |
| output | D1-D4 + **三色标注**（🟢🟡🔴 新增） |
| verify | VerificationLayer + **T3Executor**（接入现有） |
| feedback | ConsolidationLayer + **Gödel 边界记录**（新增） + CascadeEngine（不变） |

---

## 实施优先级

1. **P0（立即）**：改造 2 — Audit 层 Cross-Variant 等价检查。改动最小，影响最大，直接暴露现有矛盾。
2. **P1（本周）**：改造 1 — Teach 层 lightweight T1。让 D3 质量提升。
3. **P2（下周）**：改造 3 — Verify 层 T3 最小实验。复用现有 T3Executor。
4. **P3（后续）**：改造 4 — Termination 层 Gödel 终止。依赖前三项产出。

---

## 与现有 BDD Stub 的关系

- 不恢复 `_execute_bdd()` 的 stub（那个是完整的 BDD 子 agent，太重）
- 而是将 BDD 精神**溶解**到 FCH 各层中，变成轻量级检查点
- 当轻量级检查点发现深层问题时，才触发完整的 BDD 子 agent（ Band V 场景）
- 这样 BDD 不是"备用方案"，而是"涌现机制"

---

*设计草案完成。等待用户确认后按优先级实施。*
