---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# FCH Ralph-Style Execution Harness v1.0

## 设计目标

将 Feynman Cognition Harness v3.2 从 "单体式 orchestrator" 改造为 "协调器 + 专业化子 agent" 架构。主控 agent 只协调不干活，所有执行工作通过文件委托给子 agent。

## 核心文件（Ralph Loop 风格）

```
harness/
├── PRD.md              # 功能需求：FCH 循环的完整规范
├── progress.json       # 执行进度：当前迭代、已完成步骤、待办
├── state.json          # 运行时状态：概念ID、置信度、矛盾、缺口
├── budget.json         # Spawn 预算：剩余 agent 配额、已用计数
├── checklist.md        # 工作步骤清单（本文件）
└── results/            # 各步骤产出物
    ├── iteration_1/
    │   ├── teach_output.json
    │   ├── audit_output.json
    │   ├── grow_output.json
    │   ├── verification_output.json
    │   └── audit_report.json    # 独立审计报告
    ├── iteration_2/
    └── ...
```

## 执行循环（每轮 ONE TASK）

```
┌─────────────────────────────────────────────────────────────┐
│  Ralph Loop: FCH Cycle                                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. LOAD STATE → 读取 state.json + progress.json + budget.json │
│                                                             │
│  2. CHECK BUDGET → spawn_count < max_spawn? 否则停止        │
│                                                             │
│  3. PICK NEXT TASK → 按 checklist 找到下一个未完成步骤       │
│                                                             │
│  4. SPAWN WORKER → 启动专业化 subagent，只传递文件路径       │
│     - worker 读取 input 文件 → 执行 → 写入 output 文件        │
│     - worker 完成后发送 "DONE: /path/to/output"              │
│                                                             │
│  5. SPAWN AUDITOR → 启动独立审计 subagent 检查产出质量       │
│     - auditor 读取 worker output → 输出 audit_report.json   │
│     - 标准：PASS / NEEDS_FIX / REJECT                       │
│                                                             │
│  6. UPDATE PROGRESS → 审计 PASS 则标记完成，更新 state        │
│     - NEEDS_FIX → 通知原 worker 修复（或 spawn 修复 agent）   │
│     - REJECT → 回滚到上一步，尝试新策略                     │
│                                                             │
│  7. CHECK CONVERGENCE → Ming Wu / Novelty / Stuck 检查       │
│     - 未收敛 → 返回步骤 3                                    │
│     - 已收敛 → _finalize()                                   │
│                                                             │
│  8. SAVE STATE → 写回 state.json + progress.json + budget.json│
│                                                             │
│  9. LOOP_COMPLETE? → 是则退出，否则返回步骤 1                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 子 Agent 分工（最小化上下文重叠 + 最小化能力冲突）

| Agent | 职责 | 输入文件 | 输出文件 | 能力要求 |
|-------|------|----------|----------|----------|
| **teach-agent** | 生成 D1-D4 解释 | state.json (concept) | `results/iter{N}/teach_output.json` | 教学/概念分解 |
| **audit-agent** | 独立审计解释质量 | teach_output.json | `results/iter{N}/audit_output.json` | 批判性思维/逻辑检查 |
| **grow-agent** | 识别缺口并生成学习策略 | audit_output.json + state.json | `results/iter{N}/grow_output.json` | 学习策略/问题生成 |
| **verify-agent** | 多维度验证（交叉时间+独立+外部） | grow_output.json + state.json | `results/iter{N}/verification_output.json` | 事实核查/验证方法论 |
| **confidence-agent** | 计算多维度置信度 | verification_output.json | `results/iter{N}/confidence_result.json` | 概率评估/置信度计算 |
| **contradiction-agent** | 检测跨层级矛盾 | teach_output.json + audit_output.json | `results/iter{N}/contradictions.json` | 矛盾检测/逻辑分析 |
| **mingwu-agent** | 评估 Ming Wu 6 条件 | state.json + confidence_result.json | `results/iter{N}/mingwu_result.json` | 条件评估/决策 |
| **novelty-agent** | 计算 Jaccard 新颖度 | 当前 teach_output + 历史 teach_output | `results/iter{N}/novelty_result.json` | 文本相似度/新颖度 |
| **search-agent** | 外部知识搜索 | state.json (stuck 时的概念+问题) | `results/iter{N}/search_results.json` | 搜索/信息检索 |
| **consolidate-agent** | 整合结果并存入 lattice | 全量 iteration 结果 | lattice update + schedule | 整合/存储 |
| **cascade-agent** | 级联更新下游概念 | lattice 变更 | cascade_tasks.json | 依赖分析/级联触发 |
| **audit-quality-agent** | **独立审计任何 worker 产出** | worker_output.json + PRD.md | `results/iter{N}/audit_report.json` | 质量检查/标准验证 |

## 主控 Orchestrator 的职责（纯协调）

1. **文件系统 I/O**：读取/写入 state.json、progress.json、budget.json
2. **Agent 调度**：按 checklist 顺序 spawn worker → spawn auditor → 处理结果
3. **Budget 管理**：每 spawn 一个 agent，budget.json 中计数 -1
4. **异常处理**：
   - Worker 超时 → 读取 output 文件是否存在，若不存在则标记失败并尝试替代策略
   - Auditor 发现 bug → 通知原 worker 修复（通过 state.json 中写入 `needs_fix: true`）
   - Worker 连续失败 3 次 → 主控审查历史执行文件，分析根因，调整策略
5. **状态恢复**：session 中断后，从 state.json + progress.json 续联

## 完成标准（机器可验证）

| 检查项 | 验证方式 |
|--------|----------|
| teach_output.json 存在且含 D1-D4 键 | `os.path.exists()` + JSON schema |
| audit_output.json 存在且含 `valid: bool` | JSON schema |
| verification_output.json 存在且含 `confidence: float` | JSON schema |
| mingwu_result.json 存在且 `passed: true` | JSON schema |
| novelty_result.json 存在且 `novelty_ratio: float` | JSON schema |
| 所有 JSON 可解析 | `json.loads()` 不抛异常 |
| state.json 已更新 | 时间戳检查 |

## 异常处理机制

### Worker 超时
```
1. 检查 output 文件是否存在
2. 若存在但内容不完整 → 标记 PARTIAL，通知修复 agent
3. 若不存在 → 标记 FAILED，尝试替代策略（换 agent 或简化任务）
4. 更新 budget.json（已用配额 +1）
5. 写异常日志到 results/iteration_N/exceptions.json
```

### Auditor 发现 Bug
```
1. Auditor 输出 audit_report.json 含 `status: NEEDS_FIX` + `issues: [...]`
2. 主控读取 issues，写入 state.json 的 `pending_fixes` 字段
3. Spawn 修复 agent（可以是原 worker 或专门修复 agent）
4. 修复 agent 读取原 output + issues → 输出修正版
5. 重新审计直到 PASS
```

### 连续失败
```
1. 主控读取最近 3 次 iteration 的 exceptions.json
2. 分析失败模式（同类错误？agent 能力不足？输入数据问题？）
3. 调整策略：换 agent、简化任务、增加前置检查
4. 写入 state.json 的 `strategy_adjustments` 字段
```

## PRD.md 内容（FCH 功能规范）

PRD.md 需要包含：
1. FCH 循环的完整 Teach → Audit → Grow → Verify → Consolidate 流程
2. D1-D4 的定义和生成要求
3. Ming Wu 6 条件的详细规格
4. Novelty 计算算法
5. Auto-Search 触发条件
6. 每步的输入/输出 JSON schema

## checklist.md 内容（工作步骤）

见下文 "Checklist" 章节。

## 第一阶段实施计划

由于改造范围大，分阶段实施：

**Phase 1: 基础设施**（创建文件系统 + 主控框架）
- 创建 harness/ 目录结构
- 写 PRD.md
- 写主控 orchestrator（纯协调版，约 300 行）
- 写 state.json / progress.json / budget.json 的读写工具

**Phase 2: Worker Agent 模板**（创建专业化 agent 模板）
- teach-agent 模板
- audit-agent 模板
- grow-agent 模板
- verify-agent 模板

**Phase 3: 审计闭环**（创建 audit-quality-agent + 集成到主控）
- audit-quality-agent 模板
- 主控集成审计逻辑

**Phase 4: 异常处理**（完善错误恢复）
- 超时检测
- 修复循环
- 策略调整

**Phase 5: 集成测试**
- 端到端测试一个完整 FCH 循环
- 验证 state 恢复
- 验证审计闭环

## Checklist

- [ ] Phase 1.1: 创建 harness/ 目录结构
- [ ] Phase 1.2: 编写 PRD.md（FCH 功能规范）
- [ ] Phase 1.3: 编写主控 orchestrator（纯协调版）
- [ ] Phase 1.4: 编写状态管理工具（state/progress/budget I/O）
- [ ] Phase 2.1: 编写 teach-agent 模板
- [ ] Phase 2.2: 编写 audit-agent 模板
- [ ] Phase 2.3: 编写 grow-agent 模板
- [ ] Phase 2.4: 编写 verify-agent 模板
- [ ] Phase 3.1: 编写 audit-quality-agent 模板
- [ ] Phase 3.2: 主控集成审计逻辑（spawn worker → spawn auditor → 判断 PASS/FIX）
- [ ] Phase 4.1: 实现超时检测机制
- [ ] Phase 4.2: 实现修复循环（NEEDS_FIX → 修复 agent → 重新审计）
- [ ] Phase 4.3: 实现策略调整（连续失败分析）
- [ ] Phase 5.1: 端到端测试（一个完整迭代）
- [ ] Phase 5.2: 状态恢复测试（模拟中断后续联）
- [ ] Phase 5.3: 审计闭环测试（故意制造 bug，验证修复循环）

## 分工策略

由于需要大量文件创建和代码编写，使用子 agent 分工：

1. **基础设施 agent**：负责 Phase 1（目录结构 + PRD + 主控框架 + 状态工具）
2. **Worker 模板 agent**：负责 Phase 2（4 个 worker agent 模板）
3. **审计闭环 agent**：负责 Phase 3（audit-quality-agent + 主控集成）
4. **异常处理 agent**：负责 Phase 4（超时/修复/策略调整）
5. **测试 agent**：负责 Phase 5（端到端测试 + 验收）

每个 agent 之间通过文件传递成果，主控维护 checklist。

## 注意事项

1. 主控 agent 不直接写代码，只 spawn 子 agent 并检查进度
2. 子 agent 之间不直接通信，通过文件系统交换数据
3. 每个 worker 完成后必须 spawn 独立 auditor 验收
4. 异常时主控读取历史文件分析根因，不盲目重试
5. Budget 超限时停止循环，汇报用户

## See Also
- `STRUCTURAL_EMERGENCE.md` — 涌现设计: D1-D4 六维层间映射系统、Gap Emergence Rules、结构性残差检测
