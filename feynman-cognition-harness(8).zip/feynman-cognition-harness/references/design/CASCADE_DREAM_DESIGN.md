---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# FCH v3.5 Cascade + Dream 架构设计文档

## 设计目标

将 v2.1 的 cascade 传播机制与全局整合守护进程重新设计为 v3.5 Ralph Loop 模式：
- **Cascade** → 融入自发认知深化循环（Verify 后自动触发）
- **Dream** → 每天深夜自动运行一次的"做梦"机制

## 核心设计原则

1. **不做后台 daemon**：v3.5 是"纯协调器 + 子 agent 外包"模式，所有工作显式触发
2. **文件系统状态驱动**：状态变更通过文件写入，下一个 phase 读取文件决定行动
3. **不引入新 Loop Phase**：Cascade 是 Consolidate 的子步骤，Dream 是独立 cron 任务
4. **继承 SemanticDiff**：保留 Jaccard 距离检测核心定义变更的可靠方法

---

## 一、Cascade Engine（`harness/cascade_engine.py`）

### 触发时机
Ralph Loop 的 Consolidate phase 完成后自动调用。

### 职责

```
输入: concept_id, old_teach_output, new_teach_output, lattice
输出: cascade_report.json

1. SemanticDiff 检测当前概念是否发生核心变更
   - 比较 old 和 new 的 D1-D4 + dependency_chain
   - Jaccard distance > threshold → core_change = true

2. 若 core_change = true:
   a. 遍历该概念的 dependent_chain（下游概念）
   b. 对每个下游概念，检查其 D2/D3 是否引用了当前概念已变更的定义
   c. 标记为 "dependency_drift" → 写入 cascade_queue.json

3. 若 core_change = false 但 confidence 下降:
   a. 标记为 "confidence_decline" → 写入 cascade_queue.json

4. 生成 cascade_report.json:
   {
     "concept_id": "...",
     "core_change": true|false,
     "change_summary": {d1_changed, d3_changed, deps_added, deps_removed},
     "downstream_impact": [
       {"downstream_concept": "...", "impact_type": "dependency_drift|confidence_decline", "severity": "high|medium|low"}
     ],
     "cascade_queue_additions": ["concept_id_1", "concept_id_2"],
     "timestamp": "..."
   }
```

### 接入 Ralph Loop

orchestrator.py 的 `_run_consolidate()` 完成后：
```python
# After consolidate, check cascade
cascade_report = self.cascade_engine.analyze(
    concept_id=concept_id,
    old_output=previous_teach_output,  # from state
    new_output=teach_output,           # current iteration
    lattice=self.state_manager
)
if cascade_report["downstream_impact"]:
    # 将受影响概念加入下一轮研究队列
    self.state_manager.add_to_priority_queue(
        cascade_report["cascade_queue_additions"]
    )
```

### 为什么这样设计

- **暗合人类认知演化**：当一个人对"梯度"的理解深化了（从"斜率"深化到"Hessian 矩阵"），所有依赖"梯度"的概念（如"梯度下降"、"牛顿法"）都会"自发"需要重新审视。这不是外部指令，是知识结构的内在张力。
- **不引入新 phase**：Cascade 是 Consolidate 的自然延伸——巩固了一个概念，自然要检查它是否震动了邻居。

---

## 二、Dream Engine（`harness/dream_engine.py`）

### 触发时机
每天深夜（建议 02:00 Asia/Shanghai）通过 OpenClaw cron 自动运行。

### 职责（四层扫描）

```
输入: 全部 concept-lattice 节点
输出: dream_report.json + 可选的新研究任务

Layer 1: 高阶规律洞察 (High-Order Pattern Discovery)
- 扫描全部概念的 D1 类比，检测跨概念的共同类比模式
  例：3 个不同概念都用"水流"类比 → 可能发现"势能-流动"这一高阶隐喻结构
- 扫描 D3 形式定义，检测跨概念的共同数学结构
  例：多个概念都涉及"优化问题" → 可能提炼出"优化通论"元概念

Layer 2: 全局矛盾审计 (Global Contradiction Audit)
- 检测 cross_concept conflicts 中尚未解决的条目
- 检测隐含矛盾：概念 A 的 D4 边界与概念 B 的 D3 定义冲突
- 生成 "contradiction_report" → 推入优先级队列

Layer 3: MECE 检查 (Mutually Exclusive, Collectively Exhaustive)
- 检查知识图谱的覆盖完整性
  - 给定领域（如"机器学习优化"），所有子概念是否被覆盖
  - 概念间是否有重叠（非 ME）或有遗漏（非 CE）
- 生成 "coverage_gaps" → 推入研究队列

Layer 4: 全局结构优化 (Global Structure Optimization)
- 检测孤儿节点（无依赖、无被依赖）
- 检测 hub 过载（一个概念被过多依赖）
- 检测循环依赖
- 提出重组建议：合并、拆分、重新路由依赖
```

### 输出格式

```json
{
  "dream_id": "dream_20260502_020000",
  "timestamp": "2026-05-02T02:00:00+08:00",
  "concepts_scanned": 15,
  
  "patterns": [
    {
      "type": "analogy_pattern",
      "description": "3 concepts use 'water flow' analogy",
      "concepts": ["gradient_descent", "backpropagation", "momentum"],
      "insight": "Potential meta-concept: potential-flow optimization",
      "confidence": 0.75
    }
  ],
  
  "contradictions": [
    {
      "type": "boundary_violation",
      "concept_a": "gradient_descent",
      "concept_b": "newton_method",
      "description": "Gradient descent D4 excludes non-convex; Newton method assumes convex",
      "severity": "medium"
    }
  ],
  
  "coverage_gaps": [
    {
      "domain": "optimization",
      "missing_concepts": ["conjugate_gradient", "quasi_newton"],
      "suggested_priority": "low"
    }
  ],
  
  "structure_issues": [
    {
      "type": "hub_overload",
      "concept": "gradient",
      "dependent_count": 12,
      "suggestion": "Consider splitting into 'gradient_1d' and 'gradient_nd'"
    }
  ],
  
  "proposed_tasks": [
    {
      "task_type": "teach",
      "concept": "conjugate_gradient",
      "reason": "coverage gap in optimization domain",
      "priority": "low"
    }
  ]
}
```

### 接入方式

1. **独立入口**：`python3 harness/dream_engine.py --scan-all`
2. **cron 配置**：`openclaw cron add dream_engine "0 2 * * *" "python3 /path/to/dream_engine.py --scan-all"`
3. **orchestrator 集成**：orchestrator 启动时读取上一次 dream_report，将 proposed_tasks 加入队列

### 为什么叫"做梦"

- 发生在深夜（低优先级时段）
- 不响应外部请求，只做内部整合
- 连接远距概念（跨域类比），类似人类睡眠中的记忆重组
- 产出是"洞察"而非"任务完成"，需要人类确认

---

## 三、文件结构

```
harness/
├── orchestrator.py          # 修改：在 consolidate 后调用 cascade
├── cascade_engine.py        # 新增：依赖传播检测
├── dream_engine.py          # 新增：全局整合扫描
├── state_manager.py         # 修改：支持 priority_queue、cascade_queue
└── config.yaml              # 修改：添加 cascade 和 dream 配置节
```

---

## 四、状态管理扩展

`state_manager.py` 新增：

```python
class StateManager:
    # ... existing methods ...
    
    def add_to_cascade_queue(self, concept_ids: List[str], reason: str):
        """标记概念因 cascade 需要重新研究。"""
        queue = self._load_json("cascade_queue.json", [])
        for cid in concept_ids:
            queue.append({
                "concept_id": cid,
                "reason": reason,
                "trigger_concept": trigger_cid,
                "added_at": datetime.now().isoformat(),
                "priority": "high" if reason == "dependency_drift" else "medium"
            })
        self._save_json("cascade_queue.json", queue)
    
    def get_cascade_queue(self) -> List[dict]:
        """获取待处理的 cascade 队列。"""
        return self._load_json("cascade_queue.json", [])
    
    def add_dream_tasks(self, tasks: List[dict]):
        """将 dream engine 提出的任务加入研究队列。"""
        queue = self._load_json("dream_queue.json", [])
        queue.extend(tasks)
        self._save_json("dream_queue.json", queue)
```

---

## 五、配置扩展

`harness/config.yaml` 新增：

```yaml
modules:
  # ... existing modules ...
  
  cascade:
    enabled: true
    semantic_diff_threshold: 0.3    # Jaccard distance threshold
    max_downstream_depth: 2           # 最多传播 2 层下游
    auto_trigger: true                # consolidate 后自动触发
    
  dream:
    enabled: true
    cron_schedule: "0 2 * * *"        # 每天 02:00
    min_concepts_for_scan: 5          # 至少 5 个概念才扫描
    layers:                           # 启用哪些扫描层
      pattern_discovery: true
      contradiction_audit: true
      mece_check: true
      structure_optimization: true
    output_path: "dreams/"            # dream report 存储目录
```

---

## 六、Ralph Loop 新流程

```
Search → Teach → Audit → Grow → Verify → Consolidate → Cascade → Quality Audit → Termination
                                                          ^
                                                          |
                                                    新增: 检查下游影响
                                                    若有影响，将下游概念
                                                    加入下一轮优先队列
```

Dream 不在 Ralph Loop 内，是独立的夜间 cron 任务。

---

## 七、实现计划

### Phase 1: Cascade Engine
- 创建 `harness/cascade_engine.py`
- 实现 SemanticDiff（继承 v2.1 逻辑）
- 实现下游依赖扫描
- 修改 `orchestrator.py` 在 consolidate 后调用

### Phase 2: Dream Engine
- 创建 `harness/dream_engine.py`
- 实现四层扫描逻辑
- 配置 OpenClaw cron 定时任务

### Phase 3: 状态管理扩展
- 修改 `state_manager.py` 支持 cascade_queue、dream_queue
- 修改 `config.yaml` 添加配置节

### Phase 4: 测试验证
- 使用现有知识图谱测试 cascade 检测
- 测试 dream engine 扫描输出
- 验证 Ralph Loop 新流程
