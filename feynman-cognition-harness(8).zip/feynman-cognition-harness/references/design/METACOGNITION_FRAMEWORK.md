---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# FCH 元认知体系架构设计 v2.0

> 设计时间: 2026-05-03
> 修正方向: 时间尺度解耦、层级独立、AI 自指

---

## 一、核心修正

### 1.1 前版问题

| 问题 | 根因 | 修正 |
|------|------|------|
| 时间尺度错配 | DREAM 绑死夜间，L3 日常无法运行 | 每层分三种时间模式 |
| 不够系统 | 元认知是 FCH 的附加组件，非独立体系 | 元认知是跨层级独立系统 |
| 无 AI 自指 | 只设计 FCH 元认知，没设计 agent 自身元认知 | 增加 Self-Referential Metacognition |

### 1.2 核心原则

1. **时间解耦**: 层级与时间尺度正交。L1-L4 每层都有实时/近实时/批量三种模式。
2. **系统独立**: 元认知层不依附于 FCH 主循环，是跨实例的独立反思系统。
3. **AI 自指**: agent 必须监控自身行为模式（工具使用、子 agent 分工、上下文管理）。

---

## 二、时间尺度与层级正交矩阵

| 层级 | 实时模式 (秒-分钟) | 近实时模式 (小时) | 批量模式 (天/夜) |
|------|-------------------|------------------|----------------|
| **L1 监控** | 单工具调用信号 | iteration 聚合信号 | 日终汇总 |
| **L2 评估** | 单任务健康快照 | iteration 诊断报告 | 跨迭代趋势诊断 |
| **L3 反思** | 异常触发即时反思 | 一批 iterations 模式挖掘 | **DREAM** 全量扫描 |
| **L4 调控** | 阈值微调、路由切换 | budget/策略重分配 | 全局配置更新 |

**关键**: DREAM 不是 L3 的全部，只是 L3 的**深度批量模式**。L3 日常运行在小时级。

---

## 三、FCH 元认知系统 (FCMS)

### 3.1 架构图

```
┌────────────────────────────────────────────────────────────────┐
│                  FCH 元认知系统 (FCMS)                          │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 跨实例层 (Cross-Session)                                │   │
│  │ • 全局模式库  • 跨概念图谱  • 历史趋势库               │   │
│  └──────────────────────┬──────────────────────────────────┘   │
│                         │ 读取/写入                              │
│  ┌──────────────────────▼──────────────────────────────────┐   │
│  │ 实例层 (Per-Session)                                   │   │
│  │ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │   │
│  │ │  L1 监控 │→│  L2 评估 │→│  L3 反思 │→│  L4 调控 │ │   │
│  │ │  (信号)  │ │ (诊断)   │ │ (洞察)   │ │ (调整)   │ │   │
│  │ └──────────┘ └──────────┘ └──────────┘ └──────────┘ │   │
│  └─────────────────────────────────────────────────────┘   │
│                              ↑↓                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                  FCH 认知层 (FCC)                        │   │
│  │  Search → Teach → Audit → Grow → Verify → Consolidate │   │
│  │                              ↓                          │   │
│  │                         Cascade                         │   │
│  └─────────────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────────────┘
                              ↑↓
┌────────────────────────────────────────────────────────────────┐
│              AI 自指元认知 (Self-Referential)                 │
│  • 工具使用模式    • 子 agent 分工效率  • 上下文管理健康度    │
│  • 用户纠正模式    • 任务分解质量      • 失败根因库          │
└────────────────────────────────────────────────────────────────┘
```

### 3.2 数据流

**实时流** (每次 tool call / task 结束):
```
FCH 认知层 → L1 捕获信号 → 写入 signals/realtime/
```

**近实时流** (每个 iteration / 每小时):
```
signals/realtime/ → L1 聚合 → L2 评估 → 写入 diagnosis/
                   → 若异常: L3 即时反思 → L4 即时调控
```

**批量流** (夜间 / 手动触发):
```
diagnosis/* + history.jsonl + cascade_log/ → L3 DREAM → insights/
                                         → L4 全局调控 → config 更新
```

---

## 四、AI 自指元认知

### 4.1 为什么需要

agent 自身也是系统的一部分。agent 的以下行为会直接影响 FCH 效率：
- 子 agent 分工是否合理（是否过度重叠？是否能力错配？）
- 上下文管理是否健康（是否超长？是否遗漏关键信息？）
- 工具使用模式（是否过度依赖搜索？是否忘记使用已安装技能？）
- 用户纠正模式（是否反复误解同一类需求？）

### 4.2 自指信号

| 信号类型 | 触发时机 | 记录内容 | 文件 |
|---------|---------|---------|------|
| **SpawnAudit** | 每次 spawn 子 agent | 分工理由、上下文重叠度、预估耗时 | `metacognition/self/spawn_log.jsonl` |
| **ToolUseAudit** | 每次工具调用 | 工具名、参数、结果、是否最优选择 | `metacognition/self/tool_log.jsonl` |
| **ContextHealth** | 每次用户消息 | 上下文长度、关键信息保留率 | `metacognition/self/context_log.jsonl` |
| **UserCorrection** | 用户说"不对"/纠正 | 误解类型、纠正内容 | `metacognition/self/correction_log.jsonl` |
| **FailurePattern** | 任务失败/子 agent 失败 | 失败类型、根因、修复方式 | `metacognition/self/failure_log.jsonl` |

### 4.3 自指评估

每次大任务结束后，agent 对自身执行一次 L2 评估：

```json
{
  "self_diagnosis": {
    "task_id": "...",
    "spawn_efficiency": 0.85,
    "tool_optimality": 0.72,
    "context_health": 0.90,
    "user_alignment": 0.95,
    "alerts": [
      {
        "type": "spawn_overlap",
        "message": "3个子 agent 同时分析同类数据，上下文重叠度 40%",
        "recommendation": "使用文件系统隔离上下文，减少并行冗余"
      }
    ]
  }
}
```

---

## 五、各层详细设计

### 5.1 L1 监控层 (Monitoring)

**职责**: 只记录，不判断。

**信号类型**:

| 信号 | 内容 | 模式 |
|------|------|------|
| `task_completed` | 任务名、耗时、产出大小、异常 | 实时 |
| `budget_consumed` | 消耗量、消耗速率 | 实时 |
| `gap_produced` | gap 数量、层分布、重复性 | iteration 后 |
| `gap_closed` | 关闭方式、关闭耗时 | iteration 后 |
| `cascade_triggered` | 触发原因、深度、影响范围 | cascade 后 |
| `audit_score` | D1-D4 各层得分 | audit 后 |

### 5.2 L2 评估层 (Evaluation)

**职责**: 判断"状态如何"。

**评估维度**:

| 维度 | 指标 | 数据源 |
|------|------|--------|
| **稳定性** | 任务成功率、异常频率 | L1 信号 |
| **效率** | budget/产出比、迭代速度 | L1 信号 |
| **深度** | D4 得分趋势、边界清晰度 | audit_score |
| **广度** | 概念覆盖率、盲区数量 | gap_produced |
| **一致性** | 级联频率、依赖漂移率 | cascade_triggered |

**诊断触发规则**:
- 实时: 单任务失败立即标记
- 近实时: 每 3 iterations 或异常时综合评估
- 批量: 日终生成趋势报告

### 5.3 L3 反思层 (Reflection)

**职责**: 回答"为什么"和"还有什么可能"。

**三种模式**:

| 模式 | 触发条件 | 处理内容 | 输出 |
|------|---------|---------|------|
| **即时反思** | L2 检测到异常 | 当前异常根因 | `reflection_immediate_{id}.json` |
| **近反思** | 每 5 iterations | 最近 5 次迭代模式 | `reflection_batch_{id}.json` |
| **DREAM** | 夜间 02:00 | 全量数据深度扫描 | `dream_report_{date}.json` |

**即时反思示例** (循环卡死时):
```json
{
  "reflection_type": "immediate",
  "trigger": "stuck_detected",
  "analysis": {
    "pattern": "同一 gap 在 3 次 iteration 中以不同措辞反复出现",
    "root_cause": "Grow 只描述症状，未指定 teach_candidates 中的具体概念",
    "recommended_action": "修改 grow_task_template.md，强制要求 resolved_by_new_node"
  }
}
```

### 5.4 L4 调控层 (Regulation)

**职责**: 调整系统参数。

**调控对象与安全边界**:

| 对象 | 调控手段 | 安全边界 | 模式 |
|------|---------|---------|------|
| thresholds.json | 动态调整审计严格度 | [0.5, 0.95] | 近实时/批量 |
| budget.json | 任务间重分配 | 保留 20% 应急 | 近实时 |
| routing 策略 | BDD/FCH 分流规则 | 需人工确认默认切换 | 批量 |
| task 顺序 | 优先级重排序 | 不可跳过 Audit | 实时 |
| orchestrator.py | 元认知钩子开关 | — | 批量 |

---

## 六、与 FCH v3.5 的整合

### 6.1 Orchestrator 改造

```python
def run(self):
    for iteration in range(1, max_iterations + 1):
        # === 认知层 ===
        self._run_search()
        self._run_teach()
        self._run_audit()
        self._run_grow()
        self._run_verify()
        self._run_consolidate()
        self._run_cascade()
        
        # === L1: 实时信号捕获 ===
        signals = self._fcms_capture_signals(iteration)
        self._fcms_save_signals(signals, iteration, mode="realtime")
        
        # === L2: 近实时评估 (每 3 次或异常) ===
        if iteration % 3 == 0 or signals.get("anomaly_detected"):
            diagnosis = self._fcms_evaluate(signals, iteration)
            self._fcms_save_diagnosis(diagnosis, iteration)
            
            # === L3: 即时反思 (若异常) ===
            if diagnosis.get("severity") in ["warning", "critical"]:
                reflection = self._fcms_reflect_immediate(diagnosis)
                
                # === L4: 即时调控 ===
                if reflection.get("recommended_adjustments"):
                    self._fcms_regulate(reflection["recommended_adjustments"], mode="immediate")
        
        # === 终止检查 ===
        if self._check_termination(state, iteration):
            break
```

### 6.2 StateManager 扩展

```python
class StateManager:
    # 原有方法...
    
    def fcms_save_signal(self, signal: dict, iteration: int, mode: str) -> None:
        """mode: realtime | hourly | daily"""
        dir_path = self.state_dir / "fcms" / "signals" / mode / f"iter_{iteration:03d}"
        dir_path.mkdir(parents=True, exist_ok=True)
        (dir_path / f"{signal['type']}.json").write_text(json.dumps(signal, indent=2))
    
    def fcms_load_signals(self, n: int = 3, mode: str = "realtime") -> list[dict]:
        """加载最近 n 次迭代的信号"""
        signals = []
        current = self._load_json("progress.json", {}).get("current_iteration", 0)
        for i in range(max(1, current - n + 1), current + 1):
            iter_dir = self.state_dir / "fcms" / "signals" / mode / f"iter_{i:03d}"
            if iter_dir.exists():
                for f in iter_dir.glob("*.json"):
                    signals.append(json.loads(f.read_text()))
        return signals
    
    def fcms_save_diagnosis(self, diagnosis: dict, iteration: int) -> None:
        path = self.state_dir / "fcms" / "diagnosis" / f"d_{iteration:03d}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(diagnosis, indent=2))
    
    def fcms_save_reflection(self, reflection: dict, iteration: int, mode: str) -> None:
        path = self.state_dir / "fcms" / "reflections" / mode / f"r_{iteration:03d}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(reflection, indent=2))
    
    def fcms_save_regulation(self, regulation: dict) -> None:
        log = self.state_dir / "fcms" / "regulation_log.jsonl"
        with open(log, "a") as f:
            f.write(json.dumps(regulation) + "\n")
```

### 6.3 TerminationChecker 重新定位

`TerminationEvaluator` 是 L2 评估层的**出口评估子模块**，负责在循环出口处做最终健康检查。

整合:
```python
class TerminationEvaluator:
    def __init__(self, fcms: FCMSInterface):
        self.fcms = fcms  # 依赖注入
        self.conditions = [
            DiminishingReturnsCondition(),
            CyclicBoundaryCondition(),
            CumulativeRiskCondition(),
            DepthBudgetCondition(),
            MetaCognitiveHealthCondition(fcms),  # 读取 FCMS 诊断
        ]
    
    def evaluate(self, state, history):
        # 条件评估
        results = [c.check(state, history) for c in self.conditions]
        
        # 读取 FCMS 最新诊断
        latest_diagnosis = self.fcms.load_latest_diagnosis()
        
        return {
            "termination_results": results,
            "fcms_diagnosis": latest_diagnosis,
            "recommended_adjustments": self._synthesize(results, latest_diagnosis)
        }
```

---

## 七、DREAM 的精确定位

### 7.1 不是 L3 的全部

DREAM 是 L3 反思层的**深度批量模式**之一。L3 日常有三种运行方式：

| 模式 | 触发条件 | 处理范围 | 深度 |
|------|---------|---------|------|
| 即时反思 | L2 异常警报 | 当前异常 | 浅（根因+建议） |
| 批次反思 | 每 5 iterations | 最近 5 次 | 中（模式识别） |
| **DREAM** | 夜间 02:00 | 全量历史 | **深**（跨概念、高阶规律） |

### 7.2 DREAM 输入输出

**输入**:
```json
{
  "sources": {
    "signals": "fcms/signals/*",
    "diagnoses": "fcms/diagnosis/*",
    "reflections": "fcms/reflections/batch/*",
    "history": "history.jsonl",
    "routing": "routing_decision_log.jsonl",
    "cascade": "cascade_reports/",
    "self": "metacognition/self/"
  }
}
```

**输出**:
```json
{
  "dream_id": "dream_20260503_020000",
  "timestamp": "...",
  "scope": "daily_deep_scan",
  
  "patterns": [...],
  "contradictions": [...],
  "coverage_gaps": [...],
  "structure_issues": [...],
  
  "fcms_insights": [
    {
      "type": "strategy_recommendation",
      "description": "analogy-first 策略在 D3 得分上系统性地低于 formal-first",
      "confidence": 0.82,
      "evidence": ["iter_001", "iter_004", "iter_007"]
    }
  ],
  
  "self_insights": [
    {
      "type": "agent_behavior",
      "description": "子 agent 分工时上下文重叠度过高（平均 35%）",
      "recommendation": "使用文件系统隔离 + 最小化上下文注入"
    }
  ],
  
  "regulation_recommendations": [
    {
      "target": "thresholds.json",
      "change": {"audit_aggregate": "0.85 → 0.80"},
      "reason": "审计通过率持续低于 30%"
    }
  ]
}
```

---

## 八、实施路线图 v2.0

### Phase 1: FCMS 基础设施 (P0)
目标: 建立元认知数据管道，每层都能写入和读取。

| 任务 | 文件 | 工作量 |
|------|------|--------|
| 创建 `fcms/` 目录结构 | state_manager.py | 小 |
| L1 实时信号捕获 | orchestrator.py | 中 |
| 信号持久化 (三模式) | state_manager.py | 中 |
| 统一信号 schema | 新增 `fcms/signal_schema.json` | 小 |

### Phase 2: L2 评估层 (P0-P1)
目标: 让系统能"诊断自己"。

| 任务 | 文件 | 工作量 |
|------|------|--------|
| 实现 CognitiveHealthAssessor | 新增 `fcms/evaluator.py` | 中 |
| 实现 BlindSpotDetector | 新增 | 中 |
| 诊断报告格式 + 持久化 | state_manager.py | 小 |
| TerminationEvaluator 接入 FCMS | termination_checker.py | 小 |

### Phase 3: L3 反思层 (P1)
目标: 即时反思 + DREAM 整合。

| 任务 | 文件 | 工作量 |
|------|------|--------|
| 即时反思触发器 | orchestrator.py | 小 |
| 批次反思 (每 5 iterations) | 新增 `fcms/reflector.py` | 中 |
| DREAM 读取 FCMS 输入 | dream_engine.py | 中 |
| DREAM 输出增加 fcms_insights | dream_engine.py | 小 |

### Phase 4: L4 调控层 (P1-P2)
目标: 让系统能"调整自己"。

| 任务 | 文件 | 工作量 |
|------|------|--------|
| AdaptiveThresholdAdjuster | 新增 `fcms/regulator.py` | 中 |
| BudgetReallocator | orchestrator.py | 小 |
| 调控安全边界检查 | 新增 | 小 |
| 调控记录持久化 | state_manager.py | 小 |

### Phase 5: AI 自指 (P1-P2)
目标: agent 能"反思自己"。

| 任务 | 文件 | 工作量 |
|------|------|--------|
| 自指信号捕获 (Spawn/Tool/Context/Correction/Failure) | 新增 `fcms/self_monitor.py` | 中 |
| 自指评估逻辑 | `fcms/self_monitor.py` | 中 |
| 自指日志持久化 | state_manager.py | 小 |
| 自指洞察整合到 DREAM | dream_engine.py | 小 |

### Phase 6: 闭环测试 (P2)
目标: 验证元认知能真正改善效率。

| 任务 | 说明 |
|------|------|
| 基准测试 | 关闭 FCMS，记录迭代次数、产出质量、budget |
| FCMS 测试 | 开启 FCMS，同概念重复运行，对比指标 |
| 盲区注入测试 | 人为植入盲区，验证检测率 |
| 自指验证 | 故意制造子 agent 重叠，验证自指检测 |

---

## 九、关键设计决策

### 9.1 为什么 FCMS 不直接修改知识图谱

FCMS 的调控只作用于**运行参数**（thresholds、budget、路由、任务顺序）。
知识内容（D1-D4）的修改仍由 Teach agent 执行，需人工确认或满足严格条件。

原因:
1. 安全: 夜间/自动运行直接修改风险太高
2. 追溯: 保持"建议→确认→执行"链路
3. 责任: 知识内容的责任归属必须清晰

### 9.2 元认知层自己的健康度如何保障

**不设无限递归。**
- FCMS 的健康度通过硬指标保证（信号捕获成功率、诊断生成延迟 < 5s）
- 若 FCMS 异常，fallback 到最简单的硬终止条件（budget 耗尽）
- FCMS 的"反思"通过 DREAM 报告的人工审查实现

### 9.3 与 UCC 的关系

UCC 是**认知层**的循环（处理单个概念的 D1-D4）。
FCMS 是**跨 UCC**的观察层（观察多个 UCC 的运行模式）。
两者是并行双环，不是上下级。

---

## 十、一句话总结

> FCMS 让 FCH 从"能学习的系统"进化为"能反思自己如何学习的系统"。四层架构（监控→评估→反思→调控）与时间尺度正交（实时/近实时/批量），DREAM 是反思层的深度批量模式而非全部。AI 自指元认知确保 agent 自身的行为模式也在反思范围内。
