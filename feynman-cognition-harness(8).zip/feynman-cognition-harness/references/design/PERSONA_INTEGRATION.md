---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# Persona Audit — Orchestrator 集成方案

## 目标
在 FCH v3.5 的 Ralph Loop 中，将 Persona-Based Audit 插入 teach→audit 流程。

## 当前流程
```
teach → audit → grow → verify → consolidate
```

## 新流程
```
teach → [persona_audit] → audit → grow → verify → consolidate
                        ↑
                 4 个并行子 agent + 1 个整合 agent
```

## 集成点

### 1. 修改 orchestrator.py 的 `_run_single_task`

在 teach task 完成后，标准 audit 之前，插入 persona audit 阶段。

```python
def _run_persona_audit(self, iteration: int, state: dict, progress: dict) -> dict:
    """Run 4 persona agents in parallel, then integrate their outputs.
    
    Returns: persona_audit_output dict or None if skipped.
    """
    # Check if persona audit is enabled
    if not self._module_enabled("persona_audit"):
        return None
    
    # Read teach output
    teach_path = self._iter_dir(iteration) / "teach_output.json"
    teach_data = self._load_json_safe(teach_path, {})
    if not teach_data:
        return None
    
    # Prepare D1 summary (3 sentences max) for all personas
    d1_text = teach_data.get("d1", "")
    d1_summary = self._summarize_d1(d1_text, max_sentences=3)
    
    # Spawn 4 persona agents in parallel
    persona_results = {}
    persona_tasks = [
        ("child", "persona_child_task_template.md", {"d1": d1_text}),
        ("student", "persona_student_task_template.md", {"d1": d1_text, "d1_summary": d1_summary, "d2": teach_data.get("d2", [])}),
        ("undergrad", "persona_undergrad_task_template.md", {"d1": d1_text, "d1_summary": d1_summary, "d3": teach_data.get("d3", {})}),
        ("expert", "persona_expert_task_template.md", {"d1": d1_text, "d1_summary": d1_summary, "d4": teach_data.get("d4", {})}),
    ]
    
    for role, template, data in persona_tasks:
        input_path = self._iter_dir(iteration) / f"persona_{role}_input.json"
        output_path = self._iter_dir(iteration) / f"persona_{role}_output.json"
        
        # Write input
        input_data = {
            "concept": state.get("concept", ""),
            "concept_id": state.get("concept_id", ""),
            "iteration": iteration,
            **data
        }
        self._atomic_write(input_path, input_data)
        
        # Spawn subagent
        self._spawn_worker(f"persona_{role}", str(input_path), str(output_path))
        persona_results[role] = output_path
    
    # Wait for all 4 to complete (parallel execution)
    for role, output_path in persona_results.items():
        self._wait_for_output(output_path, timeout=120)
    
    # Spawn integrator
    integrator_input = {
        "concept": state.get("concept", ""),
        "concept_id": state.get("concept_id", ""),
        "iteration": iteration,
        "child_output_path": str(persona_results["child"]),
        "student_output_path": str(persona_results["student"]),
        "undergrad_output_path": str(persona_results["undergrad"]),
        "expert_output_path": str(persona_results["expert"]),
        "teach_output_path": str(teach_path),
    }
    integrator_input_path = self._iter_dir(iteration) / "persona_integrator_input.json"
    integrator_output_path = self._iter_dir(iteration) / "persona_integrator_output.json"
    
    self._atomic_write(integrator_input_path, integrator_input)
    self._spawn_worker("persona_integrator", str(integrator_input_path), str(integrator_output_path))
    self._wait_for_output(integrator_output_path, timeout=120)
    
    # Load and return integrator output
    return self._load_json_safe(integrator_output_path, {})
```

### 2. 修改主循环

```python
# After teach completes
if task == "teach" and action == "continue":
    persona_result = self._run_persona_audit(iteration, state, progress)
    if persona_result:
        # Store persona audit result in state for downstream use
        state["persona_audit"] = persona_result
        # If persona found critical issues, inject them into pending_gaps
        grow_queue = persona_result.get("grow_queue", [])
        for item in grow_queue:
            if item.get("severity") == "major":
                state.setdefault("pending_gaps", []).append({
                    "gap_id": f"persona_{item['target_layer']}_{iteration}",
                    "description": item["issue"],
                    "type": "framework内",
                    "layer": item["target_layer"],
                    "source": "persona_audit",
                    "recommended_strategy": item.get("suggested_strategy", "dimensional_reduction")
                })
        # If persona found framework-boundary triggers, store them for FUTURE BDD integration
        # (BDD is NOT yet integrated; these are preserved as flagged seeds only)
        bdd_triggers = persona_result.get("bdd_triggers", [])
        if bdd_triggers:
            state.setdefault("flagged_bdd_seeds", []).extend([
                {
                    "gap_id": f"persona_bdd_{i}_{iteration}",
                    "description": t["question"],
                    "source": "persona_audit",
                    "bdd_confidence": t.get("confidence", 0.5),
                    "status": "pending_bdd_not_yet_integrated"
                }
                for i, t in enumerate(bdd_triggers)
            ])
```

### 3. 修改标准 audit 模板

标准 audit agent（`../../harness/agents/audit_task_template.md`）的输入中增加 `persona_audit_path` 字段：

```json
{
  "teach_output_path": "...",
  "persona_audit_path": "string (optional — path to persona_integrator_output.json)",
  "concept": "...",
  ...
}
```

Audit agent 必须：
- 如果 `persona_audit_path` 存在，读取 persona audit 结果
- 将 persona 发现的 issues 作为额外 audit items
- 不重复 persona 已经标记的问题，除非 persona 的结论有误
- 最终 verdict 必须考虑 persona 的 d1-d4 状态

### 4. config.yaml 新增模块开关

```yaml
modules:
  persona_audit:
    enabled: true
    parallel_timeout: 120
    integrator_timeout: 120
    require_growth_seed: true  # 如果所有 persona 都 pass 但无 growth seed，强制补充
```

### 5. 新增 _module_enabled 检查

在 orchestrator.py 的 `_module_enabled` 方法中增加：

```python
elif module_name == "persona_audit":
    return self.config.get("modules", {}).get("persona_audit", {}).get("enabled", False)
```

## 文件清单

新增文件：
- `../../harness/agents/persona_child_task_template.md`
- `../../harness/agents/persona_student_task_template.md`
- `../../harness/agents/persona_undergrad_task_template.md`
- `../../harness/agents/persona_expert_task_template.md`
- `../../harness/agents/persona_integrator_task_template.md`
- `PERSONA_INTEGRATION.md` (本文档)

修改文件：
- `harness/orchestrator.py` (插入 persona audit 调用)
- `../../harness/agents/audit_task_template.md` (增加 persona_audit_path 输入)
- `harness/config.yaml` (增加 persona_audit 模块开关)

## 风险与缓解

| 风险 | 缓解 |
|------|------|
| 4 个并行 agent 增加 latency | 可配置 timeout，且 persona 是轻量级文本分析 |
| prompt 过长导致成本增加 | 每个 persona 只读对应层，输入精简 |
| 4 个 agent 结论矛盾 | integrator 负责整合，标准 audit 最终裁决 |
| 循环中新增阶段破坏稳定性 | 模块开关控制，默认 enabled=false 直到验证 |

## 渐进实施建议

| 阶段 | 内容 | 验证方式 |
|------|------|---------|
| 1 | 新增 5 个模板文件 | 文件存在 + JSON schema 有效 |
| 2 | config.yaml 增加开关 | 解析无错误 |
| 3 | orchestrator 增加 `_run_persona_audit` stub | 调用不报错 |
| 4 | 完整实现 persona audit 调用链 | 跑一轮 teach→persona→audit，检查输出 |
| 5 | audit 模板增加 persona 输入 | 标准 audit 能读取 persona 结果 |
| 6 | 启用模块，实际测试 | 观察 growth seeds 质量 |

---

*方案完成。等待用户确认后进入实施阶段。*
