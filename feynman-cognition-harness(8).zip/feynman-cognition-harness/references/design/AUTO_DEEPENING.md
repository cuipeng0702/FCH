---
tag: [DESIGN]
load_when: "了解 Auto-Deepening 内部机制和 Ming Wu 检查实现细节"
---

## Auto-Deepening Internals

### Ming Wu Check (明悟检查)

After each iteration, the system evaluates 6 conditions to determine if learning has reached a "clear understanding" state:

| Condition | Threshold | Calculation | Skipped when |
|-----------|-----------|-------------|--------------|
| Confidence | ≥ 0.90 | Overall confidence from VerificationLayer | Never |
| BSS | ≥ 0.60 | Brier Skill Score from `brier_data` | When no brier_data exists |
| Short-term problems | ≤ 3 | Count of open problems not tagged "long-term" | Never |
| Contradictions | ≤ 5 | Count of unresolved cross-level contradictions | Never |
| Emotion intensity | < 0.30 | Current epistemic emotion intensity | Never |
| Convergence delta | < 0.02 | `abs(confidence[i] - confidence[i-1])` across last 2 iterations | Never |

**Behavior**: All applicable conditions must pass. If BSS data is unavailable (no prediction history), the BSS condition is skipped and the remaining 5 conditions must all pass.

### Novelty Monitoring

Measures content repetition between consecutive iterations using word-level Jaccard similarity on D3 (formal) explanations:

```
novelty_ratio = (len(curr_words) - len(common)) / len(prev_words)
common_ratio  = len(common) / len(prev_words)
is_stuck      = novelty_ratio < 0.15 AND common_ratio > 0.85
```

**Trigger**: When `is_stuck` is true, the system automatically calls `search_external()` to fetch new external knowledge on the concept.

### Auto-Search Trigger

External knowledge fetch is triggered when:
1. Novelty monitoring detects stagnation (novelty < 0.15)
2. 3 consecutive iterations show diminishing returns
3. Internal deepening reaches a ceiling (no new gaps generated in 2 iterations)

The search uses configured tools (kimi_search, web_search, kimi_fetch) to acquire fresh perspectives, which are then fed back into the next Teach cycle.
