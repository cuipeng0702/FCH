---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# FCH Ralph-Style Execution Harness — Product Requirements Document (v3.5)

> Version: v3.5 | Last updated: 2026-05-05

## 1. Overview

This document defines the functional specification for the Feynman Cognition Harness (FCH) Ralph-Style execution harness. The harness is a pure-coordinator architecture: the main orchestrator delegates all work to specialized sub-agents and only manages file-system state, budget, and scheduling.

## 2. Execution Cycle: Teach → Audit → Grow → Verify → Consolidate

Each iteration of the harness follows a 5-phase cycle:

| Phase | Agent | Purpose | Input | Output |
|-------|-------|---------|-------|--------|
| **Search** | search-agent | Comprehensive web search on the concept | `state.json` (concept) | `search_results.json` |
| **Teach** | teach-agent | Decompose a concept into D1–D4 explanations | `state.json` (concept ID) + `search_results.json` | `teach_output.json` |
| **Audit** | audit-agent | Critically review the D1–D4 explanations | `teach_output.json` | `audit_output.json` |
| **Grow** | grow-agent | Identify knowledge gaps and propose learning strategies | `audit_output.json` + `state.json` | `grow_output.json` |
| **Verify** | verify-agent | Cross-check, external-validate, and score confidence | `grow_output.json` + `state.json` | `verification_output.json` |
| **Consolidate** | consolidate-agent | Merge verified knowledge into the lattice | All iteration results | Lattice update + next schedule |

After every worker output, an **audit-quality-agent** independently validates the output against this PRD. The cycle only advances on `PASS`.

## 3. D1–D4 Definitions and Generation Requirements

### 3.1 D1 — Intuitive Analogy
- **Definition**: Explain the concept as if to an 8-year-old using a concrete, everyday analogy.
- **Requirements**:
  - One vivid analogy that maps the target concept to a familiar experience.
  - No jargon. No abstractions. Every noun must be tactile or visual.

### 3.2 D2 — Step-by-Step Procedure
- **Definition**: A reproducible, ordered list of actions that demonstrates or applies the concept.
- **Requirements**:
  - Numbered steps (≥3, ≤10).
  - Each step must be executable by a human without external clarification.
  - Include a "success criteria" sentence at the end.

### 3.3 D3 — Formal Definition
- **Definition**: The precise, academic/technical formulation of the concept, including notation or taxonomy.
- **Requirements**:
  - Cite domain-standard terminology.
  - If mathematical: include core equation or formal statement.
  - If non-mathematical: include definitional sentence + boundary conditions.
  - Mark confidence level (`high` / `medium` / `low`) for each formal claim.

### 3.4 D4 — Boundary & Counter-Example Map
- **Definition**: A crisp delineation of where the concept applies and where it breaks, including concrete counter-examples.
- **Requirements**:
  - List ≥3 boundary conditions.
  - For each boundary, provide a concrete counter-example showing failure.
  - Explain *why* the failure occurs at the boundary (mechanism, not just symptom).

## 4. Ming Wu 6 Conditions (Detailed Specification)

A concept node is considered "deeply understood" (Ming Wu) only when all six conditions are met simultaneously.

| # | Condition | Machine-Verifiable Test | Threshold |
|---|-----------|------------------------|-----------|
| 1 | **D1 Completeness** | `teach_output.json` contains a non-empty `d1` string of ≥20 words. | `true` |
| 2 | **D2 Actionability** | `teach_output.json` contains a `d2` array with length ≥3. | `true` |
| 3 | **D3 Formal Soundness** | `teach_output.json` contains a non-empty `d3` string with at least one defined term. | `true` |
| 4 | **D4 Boundary Clarity** | `teach_output.json` contains a `d4` object with `boundaries` array length ≥3 and each item has a `counter_example`. | `true` |
| 5 | **Cross-Layer Consistency** | `audit_output.json` `cross_depth_audits` (from audit-agent) — all entries have `valid: true` and `contradictions` array is empty or all marked resolved. | `valid: true` for all |
| 6 | **Confidence ≥ 0.90** | `confidence_result.json` contains `overall >= 0.90`. | `overall >= 0.90` |

**Note**: Brier Skill Score (BSS) threshold is 0.60 when `brier_data` exists. If no prediction history exists, BSS condition is skipped (N/A).

**Ming Wu Result Format**:
```json
{
  "passed": true,
  "conditions": {
    "d1_complete": true,
    "d2_actionable": true,
    "d3_sound": true,
    "d4_clear": true,
    "cross_layer_consistent": true,
    "confidence_high": true
  },
  "timestamp": "2026-04-28T11:43:00+08:00"
}
```

## 5. Novelty Calculation Algorithm

**Purpose**: Prevent repetitive explanations by measuring how much the current `teach_output.json` diverges from all historical `teach_output.json` files.

**Algorithm**:
1. Extract the union of all unique tokens (words, normalized) from current `d1 + d3`.
2. For each historical iteration `i`, extract the same token union.
3. Compute Jaccard similarity: `J(i) = |current ∩ hist_i| / |current ∪ hist_i|`.
4. Novelty ratio = `1 - max(J(i))` over all historical iterations.
5. If no history exists, novelty ratio = `1.0`.

**Thresholds**:
- `novelty_ratio >= 0.15`: ACCEPT (sufficiently new)
- `novelty_ratio < 0.15`: STALE (trigger regrow or search)

**Output Format**:
```json
{
  "novelty_ratio": 0.42,
  "decision": "ACCEPT",
  "max_similar_iteration": 2,
  "timestamp": "2026-04-28T11:43:00+08:00"
}
```

## 6. Search Prerequisites

Search is a **mandatory prerequisite** for every Teach phase.

- **search-agent** runs **before** teach-agent in every iteration.
- Search results (`search_results.json`) are passed as input to teach-agent.
- The orchestrator spawns search-agent unconditionally at the start of each iteration.
- **Additional searches** may be triggered by grow-agent when gaps require external knowledge (this is the only conditional search).

## 7. JSON Schema for Each Step

### 7.1 search_results.json
```json
{
  "concept_id": "string",
  "queries": ["string"],
  "results": [
    {
      "source": "string",
      "url": "string",
      "snippet": "string",
      "relevance": "number (0-1)"
    }
  ],
  "synthesis": "string (comprehensive synthesis of search findings)",
  "timestamp": "ISO-8601"
}
```

### 7.2 teach_output.json

**Input**: `state.json` (concept ID) + `search_results.json` (mandatory prerequisite from search-agent)

```json
{
  "concept_id": "string",
  "iteration": 1,
  "teach_mode": "fresh | cascade_update | gap_driven",
  "d1": "string (analogy — prioritize clarity and completeness)",
  "d2": ["string (step 1)", "string (step 2)", "..."],
  "d3": {
    "definition": "string",
    "notation": "string (optional)",
    "confidence": "high|medium|low — qualitative confidence label for the formal definition"
  },
  "d4": {
    "boundaries": [
      {
        "condition": "string (where it breaks)",
        "counter_example": "string",
        "failure_mechanism": "string"
      }
    ]
  },
  "dependency_chain": ["string — concept IDs that this concept directly depends on"],
  "bridge_concepts": [
    {
      "concept_id": "string",
      "relationship": "prerequisite|builds-upon|analogous-to|contrasts-with",
      "strength": "float (0.0 to 1.0)",
      "locations": ["d1|d2|d3|d4"]
    }
  ],
  "cross_depth_mappings": [
    {
      "from_layer": "d1|d2|d3",
      "to_layer": "d2|d3|d4",
      "correspondences": [
        {
          "from_element": "string — element in source layer",
          "to_element": "string — corresponding element in target layer",
          "mapping_type": "literal|metaphorical|structural|operational"
        }
      ],
      "unmapped_elements": ["string — elements flagged as [UNMAPPED] or [UNMANIPULATED]"]
    }
  ],
  "gaps_identified": [
    {
      "layer": "d1|d2|d3|d4",
      "description": "string — honest description of what could not be fully explained",
      "severity": "minor|moderate|major|critical",
      "reason": "string — why this gap exists (knowledge limit, ambiguity, contradiction, etc.)"
    }
  ],
  "metadata": {
    "strategy_used": "string",
    "confidence_estimate": 0.85,
    "_confidence_note": "confidence_estimate (quantitative 0-1) = overall iteration confidence; d3.confidence (qualitative high/medium/low) = formal definition layer confidence only",
    "analogy_id": "string (optional)",
    "analogy_domain": "string (optional)",
    "analogy_selection_reason": "string (optional)",
    "analogy_confidence": "float (optional)",
    "reframe_triggered": "boolean (optional)",
    "update_reason": "string (optional — cascade_from: {source} | gap_driven: {gap_id})",
    "new_dependencies": ["string (optional)"]
  },
  "timestamp": "ISO-8601"
}
```

### 7.3 audit_output.json
> Note: This schema was unified with `audit_subagent_prompt.md` in v3.5. The detailed `depth_checks` structure replaces the earlier simplified `issues` array.

```json
{
  "concept": "string",
  "iteration": 1,
  "audit_version": "v3.5.0",
  "depth_checks": {
    "d1": {
      "exists": true,
      "has_analogy": true,
      "analogy_quality": 0.85,
      "word_count": 142,
      "word_count_valid": true,
      "issues": ["string — specific issues found"]
    },
    "d2": {
      "exists": true,
      "has_steps": true,
      "step_count": 3,
      "has_success_criteria": true,
      "issues": ["string"]
    },
    "d3": {
      "exists": true,
      "has_definitions": true,
      "formal_rigor": 0.70,
      "issues": ["string"]
    },
    "d4": {
      "exists": true,
      "boundary_count": 3,
      "counter_example_count": 1,
      "issues": ["string"]
    }
  },
  "cross_depth_audits": [
    {
      "from": "string",
      "to": "string",
      "valid": true,
      "issue": "string — if invalid, explain why"
    }
  ],
  "contradictions": [
    {
      "severity": "minor|moderate|critical",
      "between": ["string — which depths contradict"],
      "description": "string — the contradiction"
    }
  ],
  "pseudo_mappings": [
    {
      "mapping": "string — the mapping text",
      "reason": "string — why it is pseudo"
    }
  ],
  "gap_assessment": {
    "gaps_count": 0,
    "honest": true,
    "critical_gaps": ["string — gap_ids that must be addressed"],
    "suggested_new_gaps": [
      {
        "gap_id": "string",
        "description": "string",
        "depth": "string",
        "severity": "string",
        "rationale": "string — why this gap was not identified by teach agent"
      }
    ]
  },
  "confidence_assessment": {
    "reported": 0.85,
    "estimated": 0.75,
    "variance": 0.10,
    "calibrated": true
  },
  "pass": true,
  "pass_threshold": 0.80,
  "recommendation": "PASS|NEEDS_REVISION|REJECT|ESCALATE",
  "revision_notes": "string — specific instructions for teach agent if revision needed",
  "timestamp": "ISO-8601"
}
```

> Legacy compatibility: `valid` (boolean) is replaced by `pass` (boolean). `issues` array is replaced by per-depth `depth_checks.*.issues` arrays. Orchestrator code should consume `pass` and `depth_checks` directly.


### 7.4 grow_output.json
```json
{
  "iteration": 1,
  "timestamp": "ISO-8601 string",
  "gaps": [
    {
      "gap_id": "string",
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "external_knowledge_required": true,
      "query": "string (search query if external)",
      "search_summary": "string — 搜索结果摘要（如执行了搜索）",
      "resolved_by_new_node": "string|null — 若根因为概念缺失，填写 teach_candidates 中的 concept"
    }
  ],
  "strategy": "string (how to close gaps)",
  "teach_candidates": [
    {
      "concept": "string — 新节点名称",
      "reason": "string — 为什么需要教这个节点",
      "trigger_concept": "string — 哪个概念的 gap 触发了这个候选",
      "trigger_gap_id": "string",
      "relation_to_trigger": "depends_on | is_component_of | analogy_of | prerequisite_for",
      "requires_prerequisite": "bool — true if this candidate must wait for another candidate to complete first",
      "prerequisite_concept": "string|null — the concept_id that must be taught before this one",
      "search_results_summary": "string — 搜索关键发现摘要"
    }
  ],
  "intra_node_fixes": [
    {
      "gap_id": "string",
      "layer": "d1|d2|d3|d4",
      "fix_description": "string — 在现有节点内如何修复",
      "applicable_in_current_node": true
    }
  ],
  "dependency_updates": [
    {
      "source_concept_id": "string — 当前概念",
      "target_concept_id": "string — 候选概念",
      "relation_type": "depends_on | is_component_of | analogy_of | prerequisite_for",
      "confidence": "float 0.0-1.0",
      "bidirectional": "bool",
      "rationale": "string — 为什么建立这个关系"
    }
  ],
  "metadata": {
    "gap_count": 0,
    "external_knowledge_count": 0,
    "priority_layer": "d1|d2|d3|d4|null",
    "search_performed": true,
    "search_sources": ["kimi_search"],
    "teach_candidates_count": 0,
    "intra_node_fixes_count": 0,
    "dependency_updates_count": 0
  }
}
```

### 7.5 verification_output.json
```json
{
  "iteration": 1,
  "cross_time_consistent": true,
  "independent_reproduction": true,
  "external_sources": ["url1", "url2"],
  "confidence": {
    "overall": 0.85,
    "d1": 0.9,
    "d2": 0.8,
    "d3": 0.85,
    "d4": 0.8
  },
  "timestamp": "ISO-8601"
}
```

### 7.6 audit_report.json (audit-quality-agent)
```json
{
  "iteration": 1,
  "worker_type": "teach-agent|audit-agent|...",
  "status": "PASS|NEEDS_FIX|REJECT",
  "issues": [
    {
      "rule_violated": "string (PRD section ref)",
      "detail": "string"
    }
  ],
  "timestamp": "ISO-8601"
}
```

### 7.7 consolidate_output.json
```json
{
  "concept_id": "string",
  "version_stack": ["string (version history)"],
  "open_problems": [
    {
      "id": "string",
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "priority": "high|medium|low"
    }
  ],
  "learning_curve": {
    "difficulty": "high|medium|low",
    "iterations_to_ming_wu": "number",
    "confidence_trend": "improving|stable|declining"
  },
  "epistemic_emotion": {
    "primary": "string (e.g., curiosity, confusion, clarity)",
    "intensity": "number (0.0–1.0)",
    "trigger": "string (what caused the emotion)"
  },
  "attention_focus": {
    "current_layer": "d1|d2|d3|d4",
    "target_gap": "string (gap id or description)",
    "next_action": "string"
  },
  "consolidation_status": {
    "lattice_updated": true,
    "nodes_added": "number",
    "edges_added": "number",
    "merge_conflicts": "number"
  },
  "review_schedule": {
    "next_review": "ISO-8601",
    "interval_days": "number",
    "reason": "string"
  },
  "timestamp": "ISO-8601"
}
```

## 8. Machine-Verifiable Completion Criteria

| Check | Method | Pass Condition |
|-------|--------|--------------|
| File exists | `os.path.exists(path)` | `true` |
| Valid JSON | `json.loads(content)` | No exception |
| Required keys present | Key-in-dict check | All mandatory keys present |
| Schema types correct | Type check per key | Match schema |
| Ming Wu passed | `mingwu_result.json["passed"]` | `true` |
| Novelty acceptable | `novelty_result.json["decision"]` | `"ACCEPT"` |
| State updated | `state.json["last_updated"]` | Timestamp >= iteration start |
| Budget not exceeded | `budget.json["remaining"]` | `>= 0` |
| No unhandled exceptions | `exceptions.json` | Empty or all resolved |

## 9. Orchestrator Behavior Contract

1. **Pure Coordination**: The orchestrator never performs concept analysis, writing, or reasoning itself.
2. **One Task Per Loop**: Each Ralph loop iteration spawns exactly one worker agent (and one auditor).
3. **File-System Memory**: All state persists in JSON files; no in-memory caching for durability.
4. **Budget Enforced**: `max_spawn` is a hard ceiling. Exceeding it terminates the loop with a report.
5. **Atomic Writes**: All JSON writes use temp-file-then-rename to prevent corruption.
6. **Resume Capability**: On startup, the orchestrator reads existing `state.json`, `progress.json`, and `budget.json` and continues from the last uncompleted task.
7. **Startup Self-Test**: On initialization, the orchestrator runs a one-time health check (module imports, config validation, path writability). This is NOT part of the iteration loop.
