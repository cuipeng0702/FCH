---
tag: [DESIGN]
load_when: "设计文档与架构决策"
---

# 认知关系类型学扩展：超越 FCH 与 BDD

## 一、当前格局回顾

### FCH 层间张力 → 纵向递归还原关系

| 关系 | 示例 | 涌现机制 |
|------|------|---------|
| 依赖/组成 | transformer → 注意力机制 | DECOMPOSE：层间张力暴露缺失子结构 |
| 前提/先修 | 梯度下降 → 导数 | dimensional_reduction：降维到更基础概念 |
| 精化/具体化 | 群 → 对称群 | D1 类比具象化 |

**本质**：在一个框架内，从上往下拆，直到拆不动（直觉与公理）。

### BDD 边界触发 → 框架级替换关系

| 关系 | 示例 | 涌现机制 |
|------|------|---------|
| 框架替换 | 经典力学 → 量子力学 | PROBE：边界探测发现框架失效 |
| 对偶 | 极限 ↔ 余极限 | REVERSE：约束反转产生自洽新框架 |
| 极限退化 | 相对论 → 经典力学 (v/c→0) | LIMIT_TEST：参数推向极限 |
| 嵌入包含 | 实数 → 复数 | ZOOM_OUT：更大上下文保留原约束 |

**本质**：当前框架触及边界，需要替换或扩展基础假设。

---

## 二、尚未覆盖的三类核心关系

### 关系类型 3：合成/涌现关系（Synthesis）

**定义**：两个（或多个）概念放在一起，产生一个**不可约简的新概念**。不是 A 分解出 B，也不是 A 替换为 B，而是 A + B = C，且 C 的性质不能从 A 和 B 单独推导。

**示例**：
- 量子力学 + 信息论 = **量子信息**（量子纠缠作为通信资源）
- 拓扑学 + 代数 = **代数拓扑**（同调群）
- 神经网络 + 概率图模型 = **图神经网络**
- 类型论 + 同伦论 = **同伦类型论（HoTT）**

**与 FCH/BDD 的区别**：
- FCH：transformer → 注意力机制（拆出来的部件）
- BDD：经典力学 → 量子力学（替换框架）
- **合成**：量子 + 信息 → 量子信息（**全新的东西**）

**涌现机制：CROSS_COMPOSE（交叉合成）**

```
CROSS_COMPOSE(concept_A, concept_B):
    # 1. 提取 A 和 B 的核心机制（不是定义，是"能做什么"）
    mechanism_A = extract_core_mechanism(concept_A)  # 如：量子叠加
    mechanism_B = extract_core_mechanism(concept_B)  # 如：信息编码
    
    # 2. 尝试组合机制
    composite = combine(mechanism_A, mechanism_B)
    
    # 3. 检查是否产生不可约性质
    emergent_properties = detect_emergent_properties(composite)
    
    # 4. 若不可约性质存在 → 新概念 C
    if emergent_properties:
        return new Concept_C(
            mechanisms=[mechanism_A, mechanism_B],
            emergent=emergent_properties,
            reducible_to_parents=False  # 关键标记
        )
```

**判定标准**：
-  reducible_to_parents = False：C 的关键性质不能从 A 或 B 单独解释
-  例如：量子纠缠的"非定域性"不能从"量子"或"信息"单独解释

**与 CROSS_CHECK 的区别**：
- CROSS_CHECK：检测 A 和 B 是否互相依赖（张量积关系）
- CROSS_COMPOSE：检测 A 和 B 组合后是否产生新东西

---

### 关系类型 4：形变/演化关系（Morph）

**定义**：概念 A 随参数/条件**连续变形**成为概念 B。不是替换（BDD），不是合成（CROSS_COMPOSE），而是 A 和 B 之间有一条**连续路径**。

**示例**：
- 欧氏几何 → （曲率从 0 增加到正）→ 球面几何 → （曲率继续增加）→ ...
- 经典比特 → （量子相干度从 0 到 1）→ 量子比特
- 线性回归 → （添加正则化项）→ Ridge → Lasso → ...
- 群 G → （形变参数 t）→ 量子群

**与 LIMIT_TEST 的区别**：
- LIMIT_TEST：参数推向**极限点**（v/c → 0），是**离散跳跃**
- MORPH：追踪参数的**连续谱**，标记**临界点**（相变点）

**涌现机制：MORPH（形变追踪）**

```
MORPH(concept_A, parameter_space):
    # 1. 识别 A 中的可调参数
    params = identify_parameters(concept_A)
    
    # 2. 沿参数空间扫描
    for param_value in parameter_space:
        B = deform(concept_A, param_value)
        
        # 3. 检测相变点（性质的突变）
        if detect_phase_transition(A, B, param_value):
            # 相变点 = 新概念的候选
            candidate_concept = B
            mark_critical_point(param_value)
            
        # 4. 检测等价类（不同参数值产生"相同"概念）
        equivalence_classes = cluster_by_isomorphism(results)
    
    # 5. 输出：参数-概念映射图
    return MorphMap(
        parameter_space=parameter_space,
        concepts=extracted_concepts,
        critical_points=phase_transitions,
        equivalence_classes=equivalence_classes
    )
```

**关键产出**：
- **相变点**：概念性质发生质变的参数值
- **等价类**：不同参数值但本质相同的概念族
- **MorphMap**：概念如何随参数演化的完整图景

---

### 关系类型 5：竞争/互补关系（Duality/Complementarity）

**定义**：两个概念不是互相替换（BDD），也不是合成（CROSS_COMPOSE），而是**必须共存**才能完整描述一个现象。单独使用任何一个都会遗漏本质。

**示例**：
- **波粒二象性**：光子不能只用"波"或"粒子"描述，必须同时使用两种语言
- **位置-动量**：海森堡不确定性，越精确知道位置，越不精确知道动量
- **时域-频域**：傅里叶对偶，信号不能在时域和频域同时局部化
- **拉格朗日描述-哈密顿描述**：同一力学系统的两种等价但互补的视角
- **K-理论 vs 上同调**：代数拓扑中的两种互补不变量

**与 REVERSE（对偶）的区别**：
- REVERSE：反转约束得到**等价**的新框架（极限 ↔ 余极限，结构相同只是方向相反）
- COMPLEMENTARY：两个框架**不等价**，各自描述同一现象的不同侧面，必须同时使用

**涌现机制：COEXIST（共存验证）**

```
COEXIST(concept_A, concept_B, target_phenomenon):
    # 1. 单独用 A 解释现象
    explanation_A = explain(target_phenomenon, using=concept_A)
    completeness_A = measure_completeness(explanation_A)
    
    # 2. 单独用 B 解释现象
    explanation_B = explain(target_phenomenon, using=concept_B)
    completeness_B = measure_completeness(explanation_B)
    
    # 3. 同时使用 A 和 B
    explanation_AB = explain(target_phenomenon, using=[concept_A, concept_B])
    completeness_AB = measure_completeness(explanation_AB)
    
    # 4. 判定关系类型
    if completeness_A < 1.0 and completeness_B < 1.0 and completeness_AB >= 1.0:
        # 单独都不完整，同时才完整 → 互补关系
        return {
            "relation_type": "complementary",
            "irreducibility_score": min(completeness_A, completeness_B),
            "joint_completeness": completeness_AB,
            "tradeoff": measure_tradeoff(concept_A, concept_B)  # 如不确定性关系
        }
    elif completeness_A >= 1.0 and completeness_B >= 1.0:
        # 单独都完整 → 可能是替换关系（走 BDD）或等价关系（走 REVERSE）
        return {"relation_type": "redundant", "route_to": "BDD or REVERSE"}
    else:
        return {"relation_type": "independent"}
```

**关键产出**：
- **tradeoff**：两个概念之间的权衡关系（如 Δx·Δp ≥ ℏ/2）
- **joint_completeness**：同时使用时的解释力
- **irreducibility_score**：单独使用时的不完整度

---

## 三、五维关系类型总览

| 维度 | 关系类型 | 涌现机制 | 典型示例 | 与 FCH/BDD 的衔接 |
|------|---------|---------|---------|------------------|
| **1. 纵向** | 依赖/组成/前提 | DECOMPOSE / FCH 层间张力 | transformer → 注意力机制 | FCH 主循环 |
| **2. 框架** | 替换/对偶/极限/包含 | PROBE / REVERSE / LIMIT_TEST / ZOOM_OUT | 经典力学 → 量子力学 | BDD 边界触发 |
| **3. 合成** | 涌现/不可约组合 | **CROSS_COMPOSE** | 量子 + 信息 = 量子信息 | Audit 后发现跨域融合 |
| **4. 形变** | 连续演化/相变 | **MORPH** | 欧氏 → 球面 → 双曲几何 | D4 边界扫描的连续版本 |
| **5. 互补** | 竞争/必须共存 | **COEXIST** | 波粒二象性 | D3 对偶检测的深化 |

**关系涌现的触发条件**：

| 触发条件 | 涌现的关系类型 | 检测位置 |
|---------|--------------|---------|
| FCH D3 需要子结构但不存在 | 纵向依赖 | GenesisLayer |
| FCH D4 发现框架边界 | 框架替换/对偶/极限/包含 | AuditEngine |
| Audit 发现两个概念的层间张力互补 | 合成关系 | **新增 CrossComposeChecker** |
| D4 边界扫描发现参数连续谱 | 形变关系 | **新增 MorphTracker** |
| D3 对偶检测发现不等价的"双解释" | 互补关系 | **新增 CoexistenceChecker** |

---

## 四、认知晶格网络存储架构优化

### 当前架构的局限

当前 `knowledge-lattice` 存储是**概念中心**的：
```
concept_node = {
    id: "transformer",
    d1: "...", d2: "...", d3: "...", d4: "...",
    dependency_chain: ["attention", "feed_forward", "positional_encoding"],
    confidence: 0.85
}
```

**问题**：
1. 关系边是隐式的（只在 dependency_chain 中列出名字），没有类型标记
2. 不知道关系是怎么涌现的（是 DECOMPOSE 拆出来的，还是 PROBE 探测到的？）
3. 不支持合成关系（谁是父概念？子概念怎么标记不可约性？）
4. 不支持形变关系（没有参数空间存储）
5. 不支持互补关系（没有 tradeoff 存储）

### 优化方案：关系显式化 + UCC 实例中心

#### 方案 A：关系边显式化（最小改动）

在现有概念节点基础上，增加 `relations` 集合：

```json
{
  "id": "transformer",
  "d1": "...",
  "relations": [
    {
      "target": "attention_mechanism",
      "type": "dependency",
      "emergence_mechanism": "DECOMPOSE",
      "trigger": "fch_d3_layer_tension",
      "verified": true,
      "t3_experiment": null
    },
    {
      "target": "quantum_mechanics",
      "type": "framework_replacement",
      "emergence_mechanism": "PROBE",
      "trigger": "bdd_t4_boundary",
      "verified": true,
      "t3_experiment": "thought_experiment_001"
    },
    {
      "target": "quantum_information",
      "type": "synthesis",
      "emergence_mechanism": "CROSS_COMPOSE",
      "trigger": "cross_domain_fusion",
      "parents": ["quantum_mechanics", "information_theory"],
      "emergent_properties": ["non_locality", "superdense_coding"],
      "reducible_to_parents": false,
      "verified": false
    },
    {
      "target": "spherical_geometry",
      "type": "morph",
      "emergence_mechanism": "MORPH",
      "trigger": "d4_parameter_sweep",
      "parameter": {"name": "curvature", "from": 0, "to": 1},
      "critical_points": [{"value": 0, "transition": "euclidean_to_spherical"}],
      "verified": true
    },
    {
      "target": "wave_description",
      "type": "complementary",
      "emergence_mechanism": "COEXIST",
      "trigger": "d3_dual_inequivalent",
      "tradeoff": "uncertainty_relation",
      "joint_completeness": 1.0,
      "individual_completeness": 0.6,
      "verified": true
    }
  ]
}
```

**优点**：兼容现有存储，改动小。
**缺点**：仍是概念中心，无法做"关系路径查询"。

#### 方案 B：UCC 实例中心（推荐）

按照 `../../harness/ucc.md` 的设计，转向 **UCC_Instance 中心**：

```json
{
  "ucc_db": {
    "instances": [
      {
        "id": "ucc_001",
        "input": {"concept_id": "transformer", "trigger_source": "user_request"},
        "detection": {"detected_gaps": [...], "saturation_level": 0.7},
        "decision": {"routing": "fch"},
        "operation": {"cognitive_actions": ["DECOMPOSE"], "transformations": ["projection"]},
        "output": {"new_concept": "attention_mechanism", "d1_d4": {...}, "tricolor": {"green": [...], "yellow": [...], "red": []}},
        "verification": {"confidence": 0.85, "novelty_score": 0.6},
        "feedback": {"next_ucc_triggered": ["ucc_002"], "relation_created": {"type": "dependency", "from": "transformer", "to": "attention_mechanism"}}
      }
    ],
    
    "concepts": {
      "transformer": {
        "latest_ucc": "ucc_001",
        "ucc_history": ["ucc_001", "ucc_003"],
        "current_tricolor": {"green": [...], "yellow": [...], "red": []}
      }
    },
    
    "relations": {
      "rel_001": {
        "type": "dependency",
        "from": "transformer",
        "to": "attention_mechanism",
        "created_by_ucc": "ucc_001",
        "emergence_mechanism": "DECOMPOSE",
        "verified": true
      }
    },
    
    "meta_learning": {
      "action_effectiveness": [
        {"action_type": "DECOMPOSE", "context": {"domain": "cs", "concept_type": "architecture"}, "success_rate": 0.9}
      ]
    }
  }
}
```

**优点**：
- 支持"概念 A 到概念 B 的认知路径查询"（沿着 causal_edges 追溯）
- 支持"最常用认知动作序列分析"
- 支持"关系涌现机制统计"
- 天然支持 UCC 元框架

**缺点**：需要迁移现有数据。

#### 推荐策略：渐进式迁移

1. **Phase 1**：先在现有 `state.json` 中增加 `relations` 字段（方案 A），立即获得关系类型标记能力。
2. **Phase 2**：新增 `history.jsonl` 写入完整 UCC_Instance 结构（方案 B），逐步积累。
3. **Phase 3**：当 UCC_Instance 数量足够时，将查询中心从 concept 切换到 ucc_instance。

---

## 五、实施建议

### 优先级

| 优先级 | 任务 | 影响 |
|-------|------|------|
| **P0** | 新增 CROSS_COMPOSE 机制 | 最高 — 这是目前完全缺失的维度 |
| **P1** | 关系边显式化（方案 A） | 高 — 让现有存储支持 5 种关系类型 |
| **P2** | 新增 MORPH 机制 | 中 — 连续演化是重要补充 |
| **P3** | 新增 COEXIST 机制 | 中 — 互补关系深化对偶检测 |
| **P4** | UCC 实例中心迁移（方案 B） | 低 — 长期架构优化 |

### CROSS_COMPOSE 的具体实现思路

```python
# 新增模块: harness/cross_compose_engine.py

class CrossComposeEngine:
    """
    检测两个概念的核心机制组合后是否产生不可约的新性质。
    触发条件：Audit 发现两个不同领域的概念在 D1 使用了相似的类比结构，
    或 D3 中出现了共同的数学框架。
    """
    
    def check_fusion_potential(self, concept_a, concept_b):
        # 1. 提取核心机制（从 D3 的"能做什么"描述）
        mechanism_a = self._extract_mechanism(concept_a.d3)
        mechanism_b = self._extract_mechanism(concept_b.d3)
        
        # 2. 检查机制兼容性（是否有冲突的核心假设）
        compatibility = self._check_compatibility(mechanism_a, mechanism_b)
        
        # 3. 模拟组合
        composite = self._simulate_composition(mechanism_a, mechanism_b)
        
        # 4. 检测涌现性质
        emergent = self._detect_emergent_properties(composite, mechanism_a, mechanism_b)
        
        if emergent:
            return {
                "fusion_recommended": True,
                "new_concept_name": self._suggest_name(concept_a, concept_b),
                "emergent_properties": emergent,
                "parents": [concept_a.id, concept_b.id],
                "confidence": self._score_fusion(composite, compatibility)
            }
```

**触发场景**：
- DreamEngine 的 Pattern Discovery 发现两个概念用同一类比
- AuditEngine 发现两个概念的 D3 共享数学结构但领域不同
- 用户主动要求"看看 A 和 B 能否结合"

---

## 六、关系类型学的完整性验证

当前 5 维关系类型是否**完备**？

基于数学/物理/CS 中的基本构造操作：
- 投影（DECOMPOSE）✅
- 替换（PROBE）✅
- 对偶（REVERSE）✅
- 极限（LIMIT_TEST）✅
- 包含（ZOOM_OUT）✅
- 合成（CROSS_COMPOSE）✅ **新增**
- 形变（MORPH）✅ **新增**
- 互补（COEXIST）✅ **新增**

**遗漏检查**：
- **商/等价类**（Quotient）：是否被 DECOMPOSE 覆盖？需要验证。
- **覆盖/提升**（Covering/Lifting）：拓扑概念，在 CS 中对应抽象/实现分离。可能被 ZOOM_OUT 覆盖。
- **过滤/分层**（Filtration）：时序/层级结构。可能需要新增 **FILTER** 机制。

初步判断：5 维覆盖了 90% 以上的认知关系场景。剩余的商、覆盖、过滤可以通过扩展现有机制处理，不需要新增维度。

---

## 七、总结

| 问题 | 回答 |
|------|------|
| FCH 产生的关系 | 纵向递归还原（依赖/组成/前提） |
| BDD 产生的关系 | 框架级替换（替换/对偶/极限/包含） |
| **新增关系类型 3** | **合成/涌现** — A + B = C，不可约。涌现机制：CROSS_COMPOSE |
| **新增关系类型 4** | **形变/演化** — A 随参数连续变形成 B。涌现机制：MORPH |
| **新增关系类型 5** | **互补/共存** — A 和 B 必须同时使用。涌现机制：COEXIST |
| 存储架构优化 | 关系边显式化（立即）+ UCC 实例中心（长期） |
| 实施优先级 | CROSS_COMPOSE > 关系边显式化 > MORPH > COEXIST |

---

*设计完成。等待用户确认或调整方向。*
