---
tag: [CRITICAL]
load_when: "技能入口与快速导航"
---

# Feynman Cognition Harness v3.5.0

> **Auto-evolving knowledge system based on the Feynman Technique with Ralph Loop v3.5 Auto-Deepening Architecture.**

---

## Quick Start

### v3.5 Ralph Loop — 完整循环（推荐）

```python
from harness.orchestrator import FeynmanOrchestrator

orch = FeynmanOrchestrator(
    concept="quantum entanglement",
    storage_path="~/.openclaw/workspace/knowledge-lattice/",
)
state = orch.run_v3()   # 阻塞直到收敛或达到 max_iterations

print(state["current_concept"])
print(state["iterations"])
```

### 单步 / Agentic 模式

```python
from harness.orchestrator import FeynmanOrchestrator
from harness.state_manager import StateManager

sm = StateManager(storage_path="~/.openclaw/workspace/knowledge-lattice/")
orch = FeynmanOrchestrator(state_manager=sm)

step_result = orch.run_step()
# action in: search / teach / audit / grow / verify / consolidate / converged / terminated

# 外部 agent 执行后回灌结果
orch.ingest_result(external_result)
```

### v2.1 兼容模式（简要）

```python
from scripts.orchestrator import FeynmanOrchestrator
orch = FeynmanOrchestrator()
result = orch.run("concept", max_iterations=3)
```

`scripts/` 已降级为 legacy library，仅用于单次操作，不参与迭代深化循环。

---

## D1–D4 四层深度

| 深度 | 受众 | 认知模态 | 核心约束 |
|------|------|----------|----------|
| **D1** | 8 岁小孩 | 具身直觉 | 比喻编码深层原理，非简化；每个 D2-D4 原则须有 D1 映射 |
| **D2** | 初中生 | 因果操作 | 基本术语（首次定义），必须有具体例子，展示因果链 |
| **D3** | 大学生 | 形式符号 | 数学形式化，推导允许，标准记号，边界条件 |
| **D4** | 同行专家 | 元反思 | 标注争议、适用边界、开放问题、最新进展 |

**三角测量原则**：若 D1-D4 互一致，概念大概率已真正理解。**层间矛盾是最有价值的学习信号。**

---

## Ralph Loop v3.5 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│  Ralph Loop v3.5 — Trigger-Driven Pipeline                  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐    ┌─────────────────┐                   │
│  │ User Input  │───→│ TriggerDaemon   │                   │
│  │ Time Due    │    │ (standardize)   │                   │
│  └─────────────┘    └────────┬────────┘                   │
│                              ↓                             │
│                    ┌──────────────────┐                    │
│                    │ Metacognitive +  │                    │
│                    │ Classifier       │                    │
│                    │ Deepen? Solidify?│                    │
│                    └────────┬─────────┘                    │
│                             ↓                              │
│                    ┌──────────────────┐                    │
│                    │ GenesisLayer     │                    │
│                    │ D2 → D3 → D1 → D4                   │
│                    └────────┬─────────┘                    │
│                             ↓                              │
│                    ┌──────────────────┐                    │
│                    │ VerificationLayer  │                    │
│                    │ cross-temporal    │                    │
│                    │ accept / revise   │                    │
│                    └────────┬─────────┘                    │
│                             ↓                              │
│                    ┌──────────────────┐                    │
│                    │ ConsolidationLayer │                    │
│                    │ store + schedule   │                    │
│                    └────────┬─────────┘                    │
│                             ↓                              │
│                    ┌──────────────────┐                    │
│                    │ CascadeEngine      │                    │
│                    │ propagate to deps  │                    │
│                    └──────────────────┘                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│  FeynmanOrchestrator (Unified Entry)                        │
│  run_v3() — 7-layer pipeline │ run() — v2.1 compatible     │
└─────────────────────────────────────────────────────────────┘
```

---

## 核心模块速查（harness/）

| 模块 | 职责 | 何时需要读 docstring |
|------|------|---------------------|
| `orchestrator.py` | 状态机调度器。Ralph Loop 主循环：加载状态 → 检查预算 → 挑选任务 → 派生子 agent → 更新进度 → 检查收敛 → 保存状态。 | 修改调度逻辑或新增 loop 阶段时 |
| `routing_classifier.py` | 5-band 路由。3 维 gap 评分 → internal_ratio ∈ [0,1] → Band I-V → FCH-first-then-BDD fallback。 | 调整路由阈值或新增 hybrid 策略时 |
| `calibration_engine.py` | 自适应阈值校准。基于历史 UCC 记录做统计回归（isotonic / logistic），替代硬编码阈值。 | 冷启动策略或阈值漂移 debug 时 |
| `analogy_selector.py` | 多域类比矩阵。按学习者画像、概念亲和度、断裂回避、时效性选择最优比喻；检测迁移失败触发重构协议。 | 修改 D1 生成策略或比喻质量评估时 |
| `t3_executor.py` | T3 可执行化。Tier 1 结构化思想实验 + Tier 2 形式化工具适配器（Agda/Coq/Lean），优雅降级。 | 接入新的形式化验证工具时 |
| `termination_checker.py` | 5 条件终止判断：收益递减、循环边界、累积风险、深度预算耗尽、元认知停滞。输出结构化元认知摘要。 | 调整停止条件或需要「优雅停机」逻辑时 |
| `state_manager.py` | 运行时状态 I/O。state.json / progress.json / budget.json 的原子读写（temp + rename）。 | 新增持久化字段或调试状态丢失时 |
| `cascade_engine.py` | 级联引擎。Consolidate 后自动触发 SemanticDiff（Jaccard 阈值 0.3）检测核心变更，向下游概念传播。 | 修改依赖传播逻辑或语义差异算法时 |
| `dream_engine.py` | 夜间全局扫描。对整个知识图谱执行四层扫描：模式发现、全局矛盾审计、MECE 检查、结构优化。 | 修改「做梦」机制或全局洞察生成时 |

---

## Configuration

`config.json` 关键字段（精简）：

```json
{
  "version": "3.5.0",
  "max_iterations": 5,
  "gap_threshold": 0.1,
  "confidence_threshold": 0.7,
  "cascade_depth_limit": 3,
  "storage_path": "~/.openclaw/workspace/knowledge-lattice/",
  "orchestrator": {
    "auto_cascade": true,
    "stuck_detection_iterations": 3,
    "search_tools": { "kimi_search": true, "web_search": true, "kimi_fetch": true }
  },
  "auto_cycle": {
    "enabled": true,
    "ming_wu_threshold": {
      "confidence": 0.90, "bss": 0.60,
      "short_term_problems": 3, "contradictions": 5,
      "emotion_intensity": 0.30, "convergence_delta": 0.02
    },
    "novelty_threshold": 0.15,
    "max_auto_iterations": 10
  }
}
```

完整配置含 `levels`、`gap_strategies`、`audit_checks`、`confidence_weights`、`d1_validation` 等。详见 `config.json` 本体。

---

## Ming Wu 检查条件速查

每次迭代后自动评估 6 个条件，全部通过视为「明悟」：

| 条件 | 阈值 | 说明 |
|------|------|------|
| Confidence | ≥ 0.90 | 整体置信度（VerificationLayer） |
| BSS | ≥ 0.60 | Brier Skill Score（无历史数据时跳过） |
| 短期问题数 | ≤ 3 | 未标记 "long-term" 的开放问题 |
| 矛盾数 | ≤ 5 | 未解决的跨层矛盾 |
| 情绪强度 | < 0.30 | 当前认知情绪强度 |
| 收敛差 | < 0.02 | 最近 2 次迭代置信度变化绝对值 |

**触发行为**：任一条件未通过 → 继续 GROW 阶段；novelty < 0.15 或连续 3 次 stuck → 自动触发外部搜索。

---

## 导航指引

| 需要深入了解 | 目标位置 |
|-------------|----------|
| 设计原理与决策依据 | → `references/design/` |
| 历史审计报告与 gap list | → `references/audit/` |
| 运维配置（cron / UCC / 测试指南） | → `references/ops/` |
| 子 Agent 模板接口定义 | → `harness/agents/*.md` |

---

> Version history: `archive/Log.md`.
> License: MIT.
