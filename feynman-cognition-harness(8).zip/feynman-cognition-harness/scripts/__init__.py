# scripts/ is NOT a Python package. All modules are imported via sys.path.
# Do NOT add __init__.py — v3.5 orchestrator lives in harness/, not scripts/.
