# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
# DEPRECATED: v3.5 起由 harness/agents/audit_task_template.md 替代。保留作为 legacy 库。
"""
Confidence Calculator — Multi-dimensional confidence assessment for concepts.

Usage:
    python confidence_calculator.py <concept_id> [--lattice-path PATH]
    
Example:
    python confidence_calculator.py "transformer_attention"
"""

import argparse
import json
import sys
import os
from typing import Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.lattice_manager import LatticeManager


class ConfidenceCalculator:
    """
    Calculates multi-dimensional confidence score for a concept.
    
    Confidence dimensions:
    1. Internal consistency (25%): D1-D4 logical consistency
    2. External validation (25%): Search-verified claims proportion
    3. Coverage complete度 (20%): Concept dimension coverage
    4. Iteration convergence (15%): Gap reduction rate across iterations
    5. Expression quality (15%): D1 readability and constraint compliance
    """
    
    DIMENSION_WEIGHTS = {
        "internal_consistency": 0.25,
        "external_validation": 0.25,
        "coverage_completeness": 0.20,
        "iteration_convergence": 0.15,
        "expression_quality": 0.15
    }
    
    def __init__(self, lattice_path: str = None):
        self.lattice = LatticeManager(lattice_path)
        self.history = []
    
    def calculate(self, concept_id: str, audit_report: Dict = None,
                  explanations: Dict = None, iteration_history: List[Dict] = None) -> Dict:
        """
        Calculate comprehensive confidence score.
        
        Args:
            concept_id: Concept identifier
            audit_report: Pre-computed audit report (optional)
            explanations: D1-D4 explanations (optional)
            iteration_history: Previous iteration states (optional)
            
        Returns:
            Confidence breakdown with overall score and per-dimension scores
        """
        # Load concept if needed
        concept = self.lattice.read(concept_id)
        
        # Calculate each dimension
        dimensions = {}
        
        # 1. Internal consistency (from audit or compute)
        if audit_report:
            dimensions["internal_consistency"] = self._calc_internal_consistency(audit_report)
        else:
            dimensions["internal_consistency"] = 0.5  # Default if no audit
        
        # 2. External validation (from concept metadata or search)
        dimensions["external_validation"] = self._calc_external_validation(concept)
        
        # 3. Coverage completeness
        dimensions["coverage_completeness"] = self._calc_coverage_completeness(
            concept, explanations
        )
        
        # 4. Iteration convergence
        if iteration_history:
            dimensions["iteration_convergence"] = self._calc_convergence(iteration_history)
        else:
            dimensions["iteration_convergence"] = 0.5  # Default
        
        # 5. Expression quality
        dimensions["expression_quality"] = self._calc_expression_quality(
            concept, explanations
        )
        
        # Calculate weighted overall score
        overall = sum(
            dimensions[dim] * weight
            for dim, weight in self.DIMENSION_WEIGHTS.items()
        )
        
        # Determine level
        level = self._determine_level(overall)
        
        result = {
            "concept_id": concept_id,
            "overall_confidence": round(overall, 3),
            "level": level,
            "dimensions": {k: round(v, 3) for k, v in dimensions.items()},
            "weights": self.DIMENSION_WEIGHTS,
            "calculation_method": "weighted_multidimensional",
            "timestamp": self._timestamp(),
            "recommendations": self._generate_recommendations(dimensions)
        }
        
        self.history.append(result)
        return result
    
    def _calc_internal_consistency(self, audit_report: Dict) -> float:
        """Calculate internal consistency from audit results."""
        score = audit_report.get("score", 0)
        
        # Adjust based on gaps and contradictions
        gaps = audit_report.get("gaps", [])
        contradictions = audit_report.get("contradictions", [])
        
        # Penalize for gaps
        gap_penalty = min(0.3, len(gaps) * 0.05)
        
        # Severe penalty for contradictions
        contradiction_penalty = min(0.5, len(contradictions) * 0.15)
        
        adjusted = max(0, score - gap_penalty - contradiction_penalty)
        return adjusted
    
    def _calc_external_validation(self, concept: Optional[Dict]) -> float:
        """Calculate external validation score."""
        if not concept:
            return 0.0
        
        # Check if concept has verified claims
        version_stack = concept.get("version_stack", [])
        
        if not version_stack:
            return 0.0
        
        # Count versions with external verification
        verified_count = 0
        total_claims = 0
        
        for version in version_stack:
            metadata = version.get("metadata", {})
            verified = metadata.get("verified_claims", [])
            total = metadata.get("total_claims", 0)
            
            if total > 0:
                verified_count += len(verified)
                total_claims += total
        
        if total_claims == 0:
            return 0.5  # Neutral if no claims tracked
        
        return verified_count / total_claims
    
    def _calc_coverage_completeness(self, concept: Optional[Dict],
                                     explanations: Optional[Dict]) -> float:
        """Calculate coverage of concept dimensions."""
        # Required dimensions
        required_dimensions = [
            "history", "mechanism", "examples", "boundaries",
            "controversies", "applications", "relationships"
        ]
        
        covered = set()
        
        # Check concept metadata
        if concept:
            open_problems = concept.get("open_problems", [])
            contradictions = concept.get("contradictions", [])
            
            # If we have open problems, we know boundaries
            if open_problems:
                covered.add("boundaries")
            
            # If we have contradictions, we know controversies
            if contradictions:
                covered.add("controversies")
        
        # Check explanations
        if explanations:
            d4 = explanations.get("D4", {})
            d4_text = d4.get("explanation", "") if isinstance(d4, dict) else ""
            
            if "history" in d4_text.lower() or "origin" in d4_text.lower():
                covered.add("history")
            if "controvers" in d4_text.lower() or "debate" in d4_text.lower():
                covered.add("controversies")
            if "application" in d4_text.lower() or "use case" in d4_text.lower():
                covered.add("applications")
            
            d2 = explanations.get("D2", {})
            d2_text = d2.get("explanation", "") if isinstance(d2, dict) else ""
            
            if "example" in d2_text.lower():
                covered.add("examples")
            
            d3 = explanations.get("D3", {})
            d3_text = d3.get("explanation", "") if isinstance(d3, dict) else ""
            
            if "mechanism" in d3_text.lower() or "how it works" in d3_text.lower():
                covered.add("mechanism")
        
        coverage = len(covered) / len(required_dimensions)
        return coverage
    
    def _calc_convergence(self, iteration_history: List[Dict]) -> float:
        """Calculate iteration convergence rate."""
        if len(iteration_history) < 2:
            return 0.5  # Not enough data
        
        # Get confidence trajectory
        confidences = [h.get("confidence", 0) for h in iteration_history]
        
        # Calculate improvement rate
        improvements = []
        for i in range(1, len(confidences)):
            delta = confidences[i] - confidences[i-1]
            improvements.append(delta)
        
        # Average improvement
        avg_improvement = sum(improvements) / len(improvements)
        
        # Convergence is good if we're making consistent progress
        if avg_improvement > 0.05:
            return min(1.0, 0.5 + avg_improvement * 5)
        elif avg_improvement > 0:
            return 0.5 + avg_improvement * 5
        else:
            # Negative or zero improvement
            return max(0, 0.5 + avg_improvement * 5)
    
    def _calc_expression_quality(self, concept: Optional[Dict],
                                    explanations: Optional[Dict]) -> float:
        """Calculate D1 expression quality."""
        if not explanations:
            return 0.5
        
        d1 = explanations.get("D1", {})
        if not d1:
            return 0.0
        
        d1_text = d1.get("explanation", "") if isinstance(d1, dict) else ""
        
        if not d1_text:
            return 0.0
        
        scores = []
        
        # Check for visual metaphor
        if any(emoji in d1_text for emoji in ['🌈', '⭐', '🎈', '🎨', '🎭', '🎪', '💡']):
            scores.append(1.0)
        else:
            scores.append(0.3)
        
        # Check sentence length (shorter is better for D1)
        sentences = d1_text.split('.')
        avg_length = sum(len(s.split()) for s in sentences) / max(1, len(sentences))
        if avg_length <= 10:
            scores.append(1.0)
        elif avg_length <= 15:
            scores.append(0.7)
        else:
            scores.append(0.3)
        
        # Check total length
        word_count = len(d1_text.split())
        if word_count <= 50:
            scores.append(1.0)
        elif word_count <= 100:
            scores.append(0.7)
        else:
            scores.append(0.4)
        
        # Check for assumed knowledge list
        if "assumed knowledge" in d1_text.lower() or "assumed_knowledge" in str(d1):
            scores.append(1.0)
        else:
            scores.append(0.5)
        
        return sum(scores) / len(scores)
    
    def _determine_level(self, confidence: float) -> str:
        """Determine confidence level."""
        if confidence >= 0.9:
            return "expert"
        elif confidence >= 0.7:
            return "working"
        elif confidence >= 0.5:
            return "surface"
        else:
            return "ignorance"
    
    def _generate_recommendations(self, dimensions: Dict[str, float]) -> List[str]:
        """Generate improvement recommendations."""
        recommendations = []
        
        for dim, score in dimensions.items():
            if score < 0.5:
                if dim == "internal_consistency":
                    recommendations.append("Fix logical contradictions between D1-D4")
                elif dim == "external_validation":
                    recommendations.append("Verify claims with external sources")
                elif dim == "coverage_completeness":
                    recommendations.append("Add missing dimensions: history, examples, boundaries")
                elif dim == "iteration_convergence":
                    recommendations.append("Learning is stuck - try different approach")
                elif dim == "expression_quality":
                    recommendations.append("Improve D1: add metaphor, shorten sentences")
        
        return recommendations
    
    def _timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().isoformat()

    def compare_iterations(self, concept_id: str) -> Dict:
        """Compare confidence across iterations."""
        concept = self.lattice.read(concept_id)
        if not concept:
            return {"error": "Concept not found"}
        
        learning_curve = concept.get("learning_curve", [])
        
        if len(learning_curve) < 2:
            return {"message": "Not enough iterations for comparison"}
        
        # Calculate trends
        confidences = [p["new_confidence"] for p in learning_curve]
        
        trend = "improving" if confidences[-1] > confidences[0] else "declining"
        
        return {
            "trend": trend,
            "initial": confidences[0],
            "current": confidences[-1],
            "delta": confidences[-1] - confidences[0],
            "iterations": len(learning_curve),
            "learning_curve": learning_curve
        }

    # ==================== v3.0: Confidence Trend Calculation ====================

    def get_confidence_trend(self, concept_id: str, window: int = 5) -> Dict:
        """
        Calculate confidence trend for a concept over recent versions.
        
        v3.0 extension: Returns trend direction, slope, and volatility
        for metacognitive decision-making.
        
        Args:
            concept_id: Concept to analyze
            window: Number of recent versions to consider (default 5)
            
        Returns:
            Dict with trend, slope, volatility, and recommendation
        """
        concept = self.lattice.read(concept_id)
        if not concept:
            return {"error": "Concept not found"}
        
        learning_curve = concept.get("learning_curve", [])
        if len(learning_curve) < 2:
            return {
                "trend": "insufficient_data",
                "slope": 0.0,
                "volatility": 0.0,
                "window": window,
                "data_points": len(learning_curve)
            }
        
        # Get recent window
        recent = learning_curve[-window:] if len(learning_curve) >= window else learning_curve
        confidences = [entry.get("confidence", 0.0) for entry in recent]
        
        # Calculate slope (simple linear regression)
        n = len(confidences)
        if n < 2:
            return {"trend": "stable", "slope": 0.0, "volatility": 0.0}
        
        x = list(range(n))
        mean_x = sum(x) / n
        mean_y = sum(confidences) / n
        
        numerator = sum((x[i] - mean_x) * (confidences[i] - mean_y) for i in range(n))
        denominator = sum((x[i] - mean_x) ** 2 for i in range(n))
        
        slope = numerator / denominator if denominator != 0 else 0.0
        
        # Calculate volatility (standard deviation)
        variance = sum((c - mean_y) ** 2 for c in confidences) / n
        volatility = variance ** 0.5
        
        # Determine trend
        if slope > 0.05:
            trend = "improving"
        elif slope < -0.05:
            trend = "declining"
        else:
            trend = "stable"
        
        # Generate recommendation
        recommendation = ""
        if trend == "declining" and volatility > 0.15:
            recommendation = "Confidence is declining with high volatility — trigger deepening"
        elif trend == "declining":
            recommendation = "Confidence is declining — consider re-audit"
        elif trend == "improving" and volatility < 0.1:
            recommendation = "Confidence improving steadily — schedule consolidation"
        elif trend == "stable" and mean_y > 0.8:
            recommendation = "High stable confidence — extend review interval"
        else:
            recommendation = "Monitor for changes"
        
        return {
            "trend": trend,
            "slope": round(slope, 4),
            "volatility": round(volatility, 4),
            "mean_confidence": round(mean_y, 3),
            "window": window,
            "data_points": n,
            "recommendation": recommendation
        }

    def batch_trend_report(self, concept_ids: List[str], window: int = 5) -> Dict:
        """
        Calculate confidence trends for multiple concepts.
        
        Returns summary statistics across all concepts.
        """
        trends = {}
        improving = 0
        declining = 0
        stable = 0
        
        for cid in concept_ids:
            trend = self.get_confidence_trend(cid, window)
            trends[cid] = trend
            
            if trend.get("trend") == "improving":
                improving += 1
            elif trend.get("trend") == "declining":
                declining += 1
            else:
                stable += 1
        
        total = len(concept_ids)
        return {
            "concepts_analyzed": total,
            "improving": improving,
            "declining": declining,
            "stable": stable,
            "improving_pct": round(improving / total, 3) if total > 0 else 0,
            "declining_pct": round(declining / total, 3) if total > 0 else 0,
            "stable_pct": round(stable / total, 3) if total > 0 else 0,
            "per_concept": trends
        }

    # ==================== End v3.0 Extensions ====================


def main():
    parser = argparse.ArgumentParser(
        description="Confidence Calculator — Multi-dimensional confidence assessment"
    )
    parser.add_argument("concept_id", help="Concept to assess")
    parser.add_argument("--lattice-path", help="Path to Concept Lattice")
    parser.add_argument("--audit-report", help="Pre-computed audit report JSON")
    parser.add_argument("--explanations", help="Explanations JSON")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # Load optional inputs
    audit_report = None
    if args.audit_report:
        with open(args.audit_report, 'r') as f:
            audit_report = json.load(f)
    
    explanations = None
    if args.explanations:
        with open(args.explanations, 'r') as f:
            explanations = json.load(f)
    
    # Calculate
    calculator = ConfidenceCalculator(lattice_path=args.lattice_path)
    result = calculator.calculate(
        args.concept_id,
        audit_report=audit_report,
        explanations=explanations
    )
    
    # Output
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"Confidence Assessment: {result['concept_id']}")
        print(f"Overall: {result['overall_confidence']:.3f} ({result['level']})")
        print("\nDimensions:")
        for dim, score in result['dimensions'].items():
            bar = "█" * int(score * 20) + "░" * (20 - int(score * 20))
            print(f"  {dim:25s} {bar} {score:.3f}")
        
        if result['recommendations']:
            print("\nRecommendations:")
            for r in result['recommendations']:
                print(f"  → {r}")


if __name__ == "__main__":
    main()
