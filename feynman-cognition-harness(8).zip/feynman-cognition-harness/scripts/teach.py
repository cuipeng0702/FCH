# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
# DEPRECATED: v3.5 起由 harness/agents/audit_task_template.md 替代。保留作为 legacy 库。
"""
Teach Engine — Generate D1-D4 explanations for any concept.

Usage:
    python teach.py <concept> [--d1] [--d2] [--d3] [--d4] [--all]
    
Example:
    python teach.py "transformer attention" --all
"""

import argparse
import json
import sys
import os
from typing import Dict, List, Optional

# Add parent to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Try to import LLM Bridge for default model calling
try:
    from scripts.llm_bridge import create_model_caller, LLMBridge
    HAS_LLM_BRIDGE = True
except ImportError:
    HAS_LLM_BRIDGE = False


class TeachEngine:
    """Generates multi-granularity explanations (D1-D4) for concepts."""
    
    LEVELS = {
        "D1": {
            "name": "8-year-old-penetrating",
            "constraints": [
                "NOT simplification — analogy-encoded deep principles",
                "Every D2-D4 core principle must have a D1 analog",
                "Metaphors are cognitive scaffolds, not decorations",
                "Terms allowed if first introduced via analogy",
                "Honest about analogy limits: mark what cannot be fully analogized"
            ],
            "prompt_template": """You are a master who can explain any deep principle using language an 8-year-old understands. Your task is NOT to simplify or water down — it is to use analogy and metaphor to thoroughly encode ALL core principles of '{concept}' at the deepest level.

=== ULTRA-THINKING STAGE (do this BEFORE writing the answer) ===

Step 1 — Over-simplification audit:
What is the most common "over-simplified" explanation of {concept} that sounds right but actually misleads? How does it fail to capture the true mechanism? Write this down explicitly.

Step 2 — Core principle inventory:
List the 3-5 most critical principles from the D2-D4 explanations below. For each, ask: "If the reader doesn't pre-load this insight at D1, will they be blindsided later?"

{D2_D3_D4_summary}

Step 3 — Scaffold design:
Design ONE master analogy that can simultaneously carry multiple core principles. The analogy must have:
- A clear structural correspondence to the real mechanism (not just surface resemblance)
- The ability to represent cause-and-effect chains
- The ability to represent boundary conditions / failure modes

=== OUTPUT ===

1. MASTER ANALOGY (1 paragraph)
   The single analogy that carries the whole concept. Explain why this analogy was chosen and what structural properties it shares with the real system.

2. PRINCIPLE MAP (3-5 items)
   For each core principle from D2-D4:
   a. The principle (in one sentence)
   b. The D1 analog (how the master analogy expresses this)
   c. Correspondence: Which D2-D4 content does this analog map to?

3. BOUNDARY CONDITIONS (1 paragraph)
   Use the analogy to explain: "When does this stop working?" This must capture the D4-level boundary/failure modes.

4. PRE-LOAD INVENTORY
   After reading this D1, the reader should already intuitively grasp these D2-D4 insights:
   - [list each pre-loaded insight]

5. HONESTY GAPS
   Parts where even the best analogy cannot fully capture the mechanism. These require D2-D4 for precise understanding:
   - [list each gap with brief explanation]

6. Confidence (0-1): How thoroughly does this D1 pre-load all D2-D4 core principles?"""
        },
        "D2": {
            "name": "middle-schooler",
            "constraints": [
                "Basic terms allowed (define on first use)",
                "Must include concrete example or experiment",
                "Show cause-and-effect relationships",
                "Avoid mathematical notation"
            ],
            "prompt_template": """Explain "{concept}" to a middle school student.

Rules:
- Basic technical terms allowed, but define each on first use.
- Include at least one concrete example, experiment, or real-world application.
- Show clear cause-and-effect relationships.
- No mathematical notation or formulas.
- If a concept relies on another concept you haven't explained, mark it as a dependency.

Output format:
1. Explanation (with defined terms)
2. Example/Experiment: Concrete demonstration
3. Assumed Knowledge List: Prerequisites the student needs
4. Dependencies: Other concepts this explanation relies on
5. Confidence (0-1): How complete is this explanation?"""
        },
        "D3": {
            "name": "university-student",
            "constraints": [
                "Mathematical formalization required",
                "Derivations allowed and encouraged",
                "Use standard notation",
                "Show edge cases and assumptions"
            ],
            "prompt_template": """Explain "{concept}" to a university student in the relevant field.

Rules:
- Use mathematical formalization where applicable.
- Include derivations or proofs for key results.
- Use standard academic notation.
- Explicitly state assumptions, edge cases, and limitations.
- Reference foundational theorems or principles this builds on.

Output format:
1. Formal Definition (mathematical where possible)
2. Derivation/Proof of key results
3. Assumptions and Preconditions
4. Edge Cases and Limitations
5. Connections to foundational concepts
6. Confidence (0-1): How rigorous is this formalization?"""
        },
        "D4": {
            "name": "peer-expert",
            "constraints": [
                "NOT a boundary list — problematization of D3 certainties",
                "Transform each D3 conclusion into an open question",
                "Generate experimental hypotheses, not just list known limits",
                "Identify premises that, if false, would invalidate conclusions"
            ],
            "prompt_template": """Problematize "{concept}" at the expert level.

Your task is NOT to list boundaries or counterexamples. Your task is to
"open" the D3 formalization — to transform every certainty into a question.

Step 1 — Premise excavation:
For each key conclusion in the D3 formalization, identify:
- What premise must be true for this conclusion to hold?
- Is this premise empirical, mathematical, or methodological?
- What would happen if this premise were false?

Step 2 — Question generation:
For each identified premise, generate:
- An OPEN PROBLEM: "We don't know whether..."
- An EXPERIMENTAL HYPOTHESIS: A minimal test that could resolve it
- A META-QUESTION: "What kind of evidence would convince us?"

Step 3 — Constructive skepticism:
Ask: "If I had to design a research program to challenge the standard
understanding of {concept}, what would I investigate first?"

Output format:
1. OPENED PROBLEMS (for each D3 certainty)
   - Certainty: [D3 conclusion]
   - Premise: [Hidden assumption]
   - Open Question: [What we don't know]
   - If False: [Consequence of premise failure]

2. EXPERIMENTAL HYPOTHESES
   - Hypothesis: [Testable minimum claim]
   - Minimal Experiment: [What to measure]
   - Expected Result if Challenge Succeeds: [What would surprise us]

3. META-QUESTIONS
   - What evidence structure would change our minds?
   - What methodological limitation might bias our current understanding?
   - What alternative formalization could explain the same phenomena?

4. Confidence (0-1): How thoroughly have we problematized D3?"""
        }
    }
    
    def __init__(self, model_caller=None):
        """
        Initialize TeachEngine.
        
        Args:
            model_caller: Function to call LLM (concept, level_prompt) -> explanation
                         If None, uses LLM Bridge (Kimi-Claw proxy) if available,
                         otherwise falls back to placeholder.
        """
        if model_caller:
            self.model_caller = model_caller
        elif HAS_LLM_BRIDGE:
            self.model_caller = create_model_caller()
        else:
            self.model_caller = self._default_caller
        self.history = []
    
    def _default_caller(self, concept: str, prompt: str) -> dict:
        """Placeholder for LLM call. In production, this calls kimi-claw or similar."""
        return {
            "concept": concept,
            "level": "placeholder",
            "explanation": f"[Placeholder explanation for {concept}]",
            "assumed_knowledge": [],
            "confidence": 0.5,
            "raw_prompt": prompt
        }
    
    def teach(self, concept: str, level: str = None) -> dict:
        """
        Generate explanation for a concept at specified level(s).
        
        D1 is generated LAST, based on D2-D4 results, to ensure it thoroughly
        encodes all deep principles via analogy (not simplification).
        
        Args:
            concept: The concept to explain
            level: "D1", "D2", "D3", "D4", or None for all
            
        Returns:
            dict with explanations, metadata, and knowledge gaps
        """
        levels_to_generate = [level] if level else ["D1", "D2", "D3", "D4"]
        results = {}
        
        # Phase 1: Generate D2-D4 first (they provide the raw material for D1)
        for lvl in ["D2", "D3", "D4"]:
            if lvl not in levels_to_generate:
                continue
            
            config = self.LEVELS[lvl]
            prompt = config["prompt_template"].format(concept=concept)
            
            raw_result = self.model_caller(concept, prompt)
            # Normalize: model_caller may return str or dict
            if isinstance(raw_result, str):
                result = {"explanation": raw_result}
            else:
                result = dict(raw_result)
            result["level"] = lvl
            result["level_name"] = config["name"]
            result["constraints"] = config["constraints"]
            result["has_gap"] = False
            result["gaps"] = []
            
            results[lvl] = result
        
        # Phase 2: Generate D1 last, with D2-D4 summaries injected
        if "D1" in levels_to_generate:
            d2_d3_d4_summary = self._summarize_for_d1(results)
            
            config = self.LEVELS["D1"]
            prompt = config["prompt_template"].format(
                concept=concept,
                D2_D3_D4_summary=d2_d3_d4_summary
            )
            
            raw_result = self.model_caller(concept, prompt)
            # Normalize: model_caller may return str or dict
            if isinstance(raw_result, str):
                result = {"explanation": raw_result}
            else:
                result = dict(raw_result)
            result["level"] = "D1"
            result["level_name"] = config["name"]
            result["constraints"] = config["constraints"]
            
            # Check for honesty gaps
            result["has_gap"] = "HONESTY GAPS" in result.get("explanation", "")
            result["gaps"] = self._extract_honesty_gaps(result.get("explanation", ""))
            
            results["D1"] = result
        
        # Cross-reference assumed knowledge
        if len(levels_to_generate) > 1:
            self._cross_reference_assumptions(results)
        
        self.history.append({
            "concept": concept,
            "results": results,
            "timestamp": self._timestamp()
        })
        
        return results
    
    def _summarize_for_d1(self, results: dict) -> str:
        """Compress D2-D4 results into a summary for D1 prompt injection."""
        parts = []
        
        for lvl in ["D2", "D3", "D4"]:
            if lvl not in results:
                continue
            
            result = results[lvl]
            explanation = result.get("explanation", "")
            
            # Extract key sections
            lines = explanation.split('\n')
            key_lines = []
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                # Keep numbered/list items and section headers
                if line[0].isdigit() or line.startswith('- ') or line.startswith('* '):
                    key_lines.append(line)
                # Keep short substantive lines (not fluff)
                elif len(line) < 200 and len(line) > 20:
                    key_lines.append(line)
                # Stop after we have enough material
                if len(key_lines) >= 15:
                    break
            
            parts.append(f"=== {lvl} ({result.get('level_name', lvl)}) ===")
            parts.extend(key_lines[:15])
            parts.append("")
        
        return "\n".join(parts)
    
    def _extract_honesty_gaps(self, explanation: str) -> list:
        """Extract honesty gaps from D1 explanation (parts where analogy fails)."""
        gaps = []
        lines = explanation.split("\n")
        in_gap_section = False
        
        for line in lines:
            line = line.strip()
            if "HONESTY GAPS" in line or "Honesty Gaps" in line:
                in_gap_section = True
                continue
            if in_gap_section:
                if line.startswith("5.") or line.startswith("6."):
                    break  # Next section
                if line.startswith("-") or line.startswith("*"):
                    gap_text = line.lstrip("- *").strip()
                    if gap_text:
                        gaps.append({
                            "type": "analogy_limit",
                            "description": gap_text,
                            "severity": 5,
                            "strategy": "requires_d2_d4"
                        })
        
        return gaps
    
    def _extract_gaps(self, explanation: str) -> list:
        """Extract knowledge gaps from D1 explanation."""
        gaps = []
        lines = explanation.split("\n")
        for line in lines:
            if "🕳️ KNOWLEDGE GAP" in line:
                # Extract the specific gap
                gap_text = line.split("🕳️ KNOWLEDGE GAP:")[1].strip() if "🕳️ KNOWLEDGE GAP:" in line else line
                gaps.append({
                    "type": "basic",
                    "description": gap_text,
                    "severity": 10,  # D1 gaps are always high severity
                    "strategy": "dimensional_reduction"
                })
        return gaps
    
    def _cross_reference_assumptions(self, results: dict) -> None:
        """Cross-reference assumed knowledge across levels."""
        # Collect all assumptions
        all_assumptions = {}
        for lvl, result in results.items():
            assumptions = result.get("assumed_knowledge", [])
            all_assumptions[lvl] = set(assumptions) if isinstance(assumptions, list) else set()
        
        # Find assumptions that appear in D3/D4 but not in D1/D2
        # These are potential knowledge gaps (terms used without foundation)
        advanced_assumptions = all_assumptions.get("D3", set()) | all_assumptions.get("D4", set())
        basic_assumptions = all_assumptions.get("D1", set()) | all_assumptions.get("D2", set())
        
        untranslated_terms = advanced_assumptions - basic_assumptions
        
        # Add warning to results
        if untranslated_terms:
            for lvl in ["D3", "D4"]:
                if lvl in results:
                    if "warnings" not in results[lvl]:
                        results[lvl]["warnings"] = []
                    results[lvl]["warnings"].append({
                        "type": "untranslated_terms",
                        "message": f"Terms used without D1 equivalent: {untranslated_terms}",
                        "terms": list(untranslated_terms)
                    })
    
    # === Genesis Layer Methods (CSED-CLIF v3.0) ===
    
    def scan_terrain(self, concept: str) -> Dict:
        """
        Layer 1: Metacognitive terrain scanning.
        
        NOT cognitive genesis — just prompt engineering.
        Quick scan of D1 and D4 to gather hints for genesis.
        """
        print(f"\n🗺️  TERRAIN SCAN: Quick survey for '{concept}'")
        
        # Quick D1 scan (pre-training prior)
        raw_d1 = self.model_caller(concept, self.LEVELS["D1"]["prompt_template"].format(
            concept=concept, D2_D3_D4_summary="[Terrain scan: D2-D4 not yet generated]"
        ))
        if isinstance(raw_d1, str):
            d1_quick = {"explanation": raw_d1}
        else:
            d1_quick = dict(raw_d1)
        
        # Quick D4 scan (boundary knowledge)
        raw_d4 = self.model_caller(concept, self.LEVELS["D4"]["prompt_template"].format(
            concept=concept
        ))
        if isinstance(raw_d4, str):
            d4_quick = {"explanation": raw_d4}
        else:
            d4_quick = dict(raw_d4)
        
        # Detect mismatch zones
        terrain = {
            "d1_quick_analogy": self._extract_master_analogy(d1_quick.get("explanation", "")),
            "d4_quick_problems": self._extract_open_problems(d4_quick.get("explanation", "")),
            "mismatch_zones": self._detect_mismatch_zones(
                d1_quick.get("explanation", ""),
                d4_quick.get("explanation", "")
            ),
            "d1_quick_confidence": d1_quick.get("confidence", 0.5),
            "d4_quick_confidence": d4_quick.get("confidence", 0.5)
        }
        
        print(f"   Analogy: {terrain['d1_quick_analogy'][:60]}...")
        print(f"   Mismatch zones: {len(terrain['mismatch_zones'])}")
        
        return terrain
    
    def genesis(self, concept: str, terrain: Dict = None) -> Dict:
        """
        Layer 2: Strict genesis sequence D2→D3→D1→D4.
        
        Each level depends on previous level's output.
        Terrain hints are injected but do not override strict order.
        """
        terrain = terrain or {}
        
        print(f"\n🌱 GENESIS: Strict sequence for '{concept}'")
        
        # D2: Operations (with terrain hints)
        d2 = self._genesis_d2(concept, terrain)
        
        # D3: Formalization (based on D2)
        d3 = self._genesis_d3(concept, d2, terrain)
        
        # D1: Rooted analogy (based on D3, NOT on D1_quick)
        d1 = self._genesis_d1(concept, d3, terrain)
        
        # D4: Problematization (based on D3)
        d4 = self._genesis_d4(concept, d3, terrain)
        
        return {
            "D1": d1,
            "D2": d2,
            "D3": d3,
            "D4": d4,
            "terrain": terrain,
            "generated_at": self._timestamp()
        }
    
    def _genesis_d2(self, concept: str, terrain: Dict) -> Dict:
        """Generate D2 with terrain hints."""
        prompt = self.LEVELS["D2"]["prompt_template"].format(concept=concept)
        
        if terrain.get("mismatch_zones"):
            prompt += f"\n\n[Metacognitive hint: Prior analogy '{terrain.get('d1_quick_analogy', 'N/A')[:50]}...' fails on: {terrain['mismatch_zones'][:2]}. Ensure your example covers these scenarios.]"
        
        raw_result = self.model_caller(concept, prompt)
        if isinstance(raw_result, str):
            result = {"explanation": raw_result}
        else:
            result = dict(raw_result)
        result.update({"level": "D2", "level_name": "operational", "constraints": self.LEVELS["D2"]["constraints"]})
        print(f"   D2: {len(result.get('explanation', ''))} chars")
        return result
    
    def _genesis_d3(self, concept: str, d2: Dict, terrain: Dict) -> Dict:
        """Generate D3 based on D2 output."""
        d2_explanation = d2.get("explanation", "")
        
        prompt = self.LEVELS["D3"]["prompt_template"].format(concept=concept)
        prompt += f"\n\n[Operational foundation from D2]:\n{d2_explanation[:800]}"
        
        if terrain.get("mismatch_zones"):
            prompt += f"\n\n[Attention: The following aspects resist analogy — formalize them rigorously: {terrain['mismatch_zones'][:2]}]"
        
        raw_result = self.model_caller(concept, prompt)
        if isinstance(raw_result, str):
            result = {"explanation": raw_result}
        else:
            result = dict(raw_result)
        result.update({"level": "D3", "level_name": "formal", "constraints": self.LEVELS["D3"]["constraints"]})
        print(f"   D3: {len(result.get('explanation', ''))} chars")
        return result
    
    def _genesis_d1(self, concept: str, d3: Dict, terrain: Dict) -> Dict:
        """
        Generate D1 based on D3 output — NOT based on D1_quick.
        
        This is the key: D1 is rooted in D3 formal principles,
        not a correction of prior intuition.
        """
        d3_explanation = d3.get("explanation", "")
        
        prompt = self.LEVELS["D1"]["prompt_template"].format(
            concept=concept,
            D2_D3_D4_summary=f"=== D3 (FORMAL) ===\n{d3_explanation[:1200]}"
        )
        
        # Add terrain hint about prior analogy (for comparison, not reuse)
        if terrain.get("d1_quick_analogy"):
            prompt += f"\n\n[Metacognitive note: A common prior analogy is '{terrain['d1_quick_analogy'][:80]}...'. If your analogy differs, that's expected — it means you're building from formal principles rather than prior intuition.]"
        
        raw_result = self.model_caller(concept, prompt)
        if isinstance(raw_result, str):
            result = {"explanation": raw_result}
        else:
            result = dict(raw_result)
        result.update({"level": "D1", "level_name": "intuitive", "constraints": self.LEVELS["D1"]["constraints"]})
        
        # Check for honesty gaps
        result["has_gap"] = "HONESTY GAPS" in result.get("explanation", "")
        result["gaps"] = self._extract_honesty_gaps(result.get("explanation", ""))
        
        print(f"   D1: {len(result.get('explanation', ''))} chars")
        return result
    
    def _genesis_d4(self, concept: str, d3: Dict, terrain: Dict) -> Dict:
        """
        Generate D4 as problematization of D3 — not independent boundary scan.
        """
        d3_explanation = d3.get("explanation", "")
        
        prompt = self.LEVELS["D4"]["prompt_template"].format(concept=concept)
        prompt += f"\n\n[Formalization to problematize]:\n{d3_explanation[:1200]}"
        
        if terrain.get("d4_quick_problems"):
            prompt += f"\n\n[Context: Prior problematization identified: {terrain['d4_quick_problems'][:2]}. Build upon or challenge these.]"
        
        raw_result = self.model_caller(concept, prompt)
        if isinstance(raw_result, str):
            result = {"explanation": raw_result}
        else:
            result = dict(raw_result)
        result.update({"level": "D4", "level_name": "problematized", "constraints": self.LEVELS["D4"]["constraints"]})
        print(f"   D4: {len(result.get('explanation', ''))} chars")
        return result
    
    def _extract_master_analogy(self, d1_explanation: str) -> str:
        """Extract master analogy from D1 explanation."""
        lines = d1_explanation.split('\n')
        for i, line in enumerate(lines):
            if "MASTER ANALOGY" in line.upper():
                for j in range(i+1, min(i+5, len(lines))):
                    if lines[j].strip():
                        return lines[j].strip()
        return ""
    
    def _extract_open_problems(self, d4_explanation: str) -> List[str]:
        """Extract open problems from D4 explanation."""
        problems = []
        lines = d4_explanation.split('\n')
        in_problems = False
        for line in lines:
            if "OPEN" in line.upper() and "PROBLEM" in line.upper():
                in_problems = True
                continue
            if in_problems and line.strip().startswith('-'):
                problems.append(line.strip().lstrip('- '))
        return problems
    
    def _detect_mismatch_zones(self, d1_text: str, d4_text: str) -> List[str]:
        """Detect zones where D1 analogy and D4 boundaries mismatch."""
        d1_terms = set(re.findall(r'\b[A-Za-z]{5,}\b', d1_text.lower()))
        d4_terms = set(re.findall(r'\b[A-Za-z]{5,}\b', d4_text.lower()))
        mismatch = d4_terms - d1_terms
        return [t for t in sorted(mismatch)[:5]]

    def _timestamp(self) -> str:
        """Get current ISO timestamp."""
        from datetime import datetime
        return datetime.now().isoformat()
    
    def get_history(self) -> list:
        """Return teaching history."""
        return self.history
    
    def export(self, filepath: str) -> None:
        """Export history to JSON file."""
        with open(filepath, 'w') as f:
            json.dump(self.history, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Teach Engine — Generate D1-D4 explanations")
    parser.add_argument("concept", help="Concept to explain")
    parser.add_argument("--d1", action="store_true", help="Generate D1 only")
    parser.add_argument("--d2", action="store_true", help="Generate D2 only")
    parser.add_argument("--d3", action="store_true", help="Generate D3 only")
    parser.add_argument("--d4", action="store_true", help="Generate D4 only")
    parser.add_argument("--all", action="store_true", help="Generate all levels (default)")
    parser.add_argument("--output", "-o", help="Output JSON file")
    
    args = parser.parse_args()
    
    # Determine levels
    levels = []
    if args.d1: levels.append("D1")
    if args.d2: levels.append("D2")
    if args.d3: levels.append("D3")
    if args.d4: levels.append("D4")
    if not levels or args.all:
        levels = None  # All levels
    
    # Generate
    engine = TeachEngine()
    
    if levels and len(levels) == 1:
        results = engine.teach(args.concept, levels[0])
    else:
        results = engine.teach(args.concept)
    
    # Output
    output = {
        "concept": args.concept,
        "levels": results,
        "generated_at": engine._timestamp()
    }
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(output, f, indent=2)
        print(f"Saved to {args.output}")
    else:
        print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
