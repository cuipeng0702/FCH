# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
D1 Metaphor Quality Validator — Validates analogy-based D1 explanations.

Replaces the old "ZERO technical terms" constraint with a structural quality check
that validates whether the D1 explanation truly encodes deep principles through
embodied metaphor (cognitive scaffolding).

Checks for:
- MASTER ANALOGY: Core metaphor present and explained
- PRINCIPLE MAP: Each D2-D4 principle has a metaphoric mapping
- BOUNDARY CONDITIONS: Failure modes encoded in metaphor
- PRE-LOAD INVENTORY: D2-D4 insights intuitively pre-loaded
- HONESTY GAPS: Explicitly marks where metaphor breaks down
- TERM SCAFFOLDING: Technical terms, if present, are explained via metaphor
"""

import argparse
import json
import re
import sys
import os
from typing import Dict, List, Set, Tuple


class D1Validator:
    """
    Validates D1 explanations for structural analogy quality.
    
    Three-layer validation:
    1. Structural fingerprint check (MASTER ANALOGY, PRINCIPLE MAP, etc.)
    2. Metaphoric term scaffolding (terms explained via analogy)
    3. Metaphor completeness assessment
    """
    
    # Structural elements that must be present in D1 v2
    STRUCTURAL_ELEMENTS = {
        "MASTER ANALOGY": {
            "pattern": r"MASTER ANALOGY|master analogy",
            "name": "核心类比",
            "weight": 3.0,
            "description": "贯穿始终的核心比喻及其选择理由"
        },
        "PRINCIPLE MAP": {
            "pattern": r"PRINCIPLE MAP|principle map",
            "name": "原理映射",
            "weight": 2.5,
            "description": "每个深层原理到类比的映射关系"
        },
        "BOUNDARY CONDITIONS": {
            "pattern": r"BOUNDARY CONDITIONS|boundary conditions",
            "name": "边界条件",
            "weight": 2.5,
            "description": "用类比讲清楚什么时候不适用"
        },
        "PRE-LOAD INVENTORY": {
            "pattern": r"PRE-LOAD INVENTORY|pre-load inventory",
            "name": "预加载清单",
            "weight": 1.5,
            "description": "读者理解D1后已预加载的深层洞察"
        },
        "HONESTY GAPS": {
            "pattern": r"HONESTY GAPS|honesty gaps",
            "name": "诚实缺口",
            "weight": 2.0,
            "description": "诚实标注类比无法还原的部分"
        }
    }
    
    # Technical terms that should be scaffolded (not banned)
    # These are allowed IF they appear near an explanation
    SCAFFOLD_TERMS = {
        "algorithm", "derivative", "gradient", "vector", "matrix", "tensor",
        "scalar", "function", "equation", "formula", "theorem", "proof",
        "optimization", "convergence", "divergence", "integral", "differential",
        "neural network", "deep learning", "machine learning",
        "backpropagation", "gradient descent", "loss function", "activation function",
        "hyperparameter", "epoch", "batch", "layer", "node", "weight", "bias",
        "encoder", "decoder", "transformer", "attention", "embedding", "token",
        "recurrent", "convolutional", "pooling", "dropout", "regularization",
        "overfitting", "underfitting", "generalization", "inference", "training",
        "quantum", "relativity", "entropy", "thermodynamics",
        "hypothesis", "theory", "experiment", "observation", "measurement",
        "variable", "constant", "parameter", "coefficient", "correlation",
        "causation", "statistical", "significant", "p-value",
        "derivative", "option", "future", "hedge", "arbitrage", "liquidity",
        "volatility", "diversification", "portfolio",
    }
    
    def __init__(self, custom_elements: Dict = None, custom_scaffold_terms: Set[str] = None):
        """
        Initialize validator.
        
        Args:
            custom_elements: Additional structural elements to check
            custom_scaffold_terms: Additional terms that require scaffolding
        """
        self.structural_elements = {**self.STRUCTURAL_ELEMENTS, **(custom_elements or {})}
        self.scaffold_terms = self.SCAFFOLD_TERMS | (custom_scaffold_terms or set())
    
    def validate(self, explanation: str, use_llm: bool = False) -> Dict:
        """
        Validate a D1 explanation for metaphor quality.
        
        Args:
            explanation: The D1 explanation text
            use_llm: Whether to use LLM-based assessment
            
        Returns:
            Validation result with structural score, scaffolding checks, and suggestions
        """
        results = {}
        
        # Layer 1: Structural fingerprint check
        structural_result = self._check_structural_elements(explanation)
        results["structural"] = structural_result
        
        # Layer 2: Metaphoric term scaffolding
        scaffold_result = self._check_term_scaffolding(explanation)
        results["scaffolding"] = scaffold_result
        
        # Layer 3: Metaphor completeness
        completeness_result = self._check_metaphor_completeness(explanation)
        results["completeness"] = completeness_result
        
        # Calculate overall score
        structural_score = structural_result["score"]
        scaffold_penalty = scaffold_result["penalty"]
        completeness_score = completeness_result["score"]
        
        # Weighted: structural 40%, scaffolding 30%, completeness 30%
        overall_score = (
            structural_score * 0.4 +
            max(0, 1 - scaffold_penalty) * 0.3 +
            completeness_score * 0.3
        )
        
        passed = overall_score >= 0.7 and structural_score >= 0.6
        
        # Generate suggestions
        suggestions = self._generate_suggestions(results, explanation)
        
        return {
            "passed": passed,
            "overall_score": round(overall_score, 3),
            "structural_score": round(structural_score, 3),
            "scaffold_penalty": round(scaffold_penalty, 3),
            "completeness_score": round(completeness_score, 3),
            "structural_elements": structural_result["elements"],
            "missing_elements": structural_result["missing"],
            "unscaffolded_terms": scaffold_result["unscaffolded_terms"],
            "suggestions": suggestions,
            "details": results
        }
    
    def _check_structural_elements(self, explanation: str) -> Dict:
        """Check for required structural elements in D1."""
        found = {}
        missing = []
        total_weight = 0
        found_weight = 0
        
        for element_id, config in self.structural_elements.items():
            pattern = re.compile(config["pattern"], re.IGNORECASE)
            match = pattern.search(explanation)
            
            total_weight += config["weight"]
            
            if match:
                found_weight += config["weight"]
                found[element_id] = {
                    "name": config["name"],
                    "position": match.start(),
                    "present": True
                }
            else:
                missing.append({
                    "id": element_id,
                    "name": config["name"],
                    "description": config["description"],
                    "weight": config["weight"]
                })
        
        score = found_weight / total_weight if total_weight > 0 else 0
        
        return {
            "score": round(score, 3),
            "elements": found,
            "missing": missing,
            "total_elements": len(self.structural_elements),
            "found_count": len(found)
        }
    
    def _check_term_scaffolding(self, explanation: str) -> Dict:
        """
        Check if technical terms are scaffolded by metaphor.
        
        A term is 'scaffolded' if it appears near an analogy or explanation
        within ~100 characters.
        """
        unscaffolded = []
        
        for term in self.scaffold_terms:
            # Find all occurrences
            pattern = re.compile(r'\b' + re.escape(term) + r'\b', re.IGNORECASE)
            
            for match in pattern.finditer(explanation):
                # Check context for scaffolding
                start = max(0, match.start() - 100)
                end = min(len(explanation), match.end() + 100)
                context = explanation[start:end].lower()
                
                # Scaffolding indicators: analogy words, explanation markers
                scaffold_indicators = [
                    "like", "similar to", "analogy", "metaphor", "imagine",
                    "think of", "picture", "just as", "the way", "is like",
                    "called", "means", "refers to", "basically", "in other words",
                    "simpler terms", "can think of", "way to understand"
                ]
                
                has_scaffold = any(ind in context for ind in scaffold_indicators)
                
                if not has_scaffold:
                    unscaffolded.append({
                        "term": term,
                        "position": match.start(),
                        "context": context[:80],
                        "severity": 5
                    })
        
        # Penalty = proportion of unscaffolded terms (capped at 1.0)
        total_term_occurrences = sum(
            len(list(re.finditer(r'\b' + re.escape(t) + r'\b', explanation, re.IGNORECASE)))
            for t in self.scaffold_terms
        )
        
        penalty = min(1.0, len(unscaffolded) / max(1, total_term_occurrences)) if total_term_occurrences > 0 else 0
        
        return {
            "penalty": round(penalty, 3),
            "unscaffolded_terms": unscaffolded,
            "total_term_occurrences": total_term_occurrences,
            "scaffolded_rate": round(1 - penalty, 3)
        }
    
    def _check_metaphor_completeness(self, explanation: str) -> Dict:
        """
        Check if the metaphor is complete enough to support deep principles.
        
        Indicators:
        - Explanation length (too short = can't be deep)
        - Number of principle mappings
        - Presence of "why" explanations
        """
        # Length check: D1 v2 should be substantial (not just 3 sentences)
        length_score = min(1.0, len(explanation) / 800)  # 800 chars = ~1.0
        
        # Principle mapping check: look for "a.", "b.", numbered items
        principle_count = len(re.findall(r'^[a-z]\.|^\d+\.', explanation, re.MULTILINE))
        principle_score = min(1.0, principle_count / 5)  # 5+ principles = ~1.0
        
        # "Why" explanation check
        why_indicators = ["because", "this is why", "the reason", "why this works",
                         "underlying", "fundamentally", "at its core"]
        why_count = sum(explanation.lower().count(w) for w in why_indicators)
        why_score = min(1.0, why_count / 3)
        
        score = (length_score * 0.3 + principle_score * 0.4 + why_score * 0.3)
        
        return {
            "score": round(score, 3),
            "length_score": round(length_score, 3),
            "principle_score": round(principle_score, 3),
            "why_score": round(why_score, 3),
            "principle_count": principle_count,
            "why_count": why_count
        }
    
    def _generate_suggestions(self, results: Dict, explanation: str) -> List[str]:
        """Generate improvement suggestions based on validation results."""
        suggestions = []
        
        # Structural suggestions
        missing = results.get("structural", {}).get("missing", [])
        for m in missing:
            suggestions.append(
                f"添加 '{m['name']}'：{m['description']}（权重: {m['weight']}）"
            )
        
        # Scaffolding suggestions
        unscaffolded = results.get("scaffolding", {}).get("unscaffolded_terms", [])
        if unscaffolded:
            terms = [u["term"] for u in unscaffolded[:3]]
            suggestions.append(
                f"术语缺少类比脚手架：{', '.join(terms)}... "
                f"请在每个术语出现的位置附近添加类比解释（如 '就像...'、'类似于...'）"
            )
        
        # Completeness suggestions
        completeness = results.get("completeness", {})
        if completeness.get("principle_count", 0) < 3:
            suggestions.append(
                f"原理映射不足（当前 {completeness.get('principle_count', 0)} 个）。"
                f"建议为每个深层原理添加一个类比映射。"
            )
        
        if completeness.get("length_score", 0) < 0.5:
            suggestions.append(
                "解释过于简短。D1 v2 不是简化版，而是'类比穿透版'，需要充分展开类比。"
            )
        
        return suggestions
    
    def batch_validate(self, explanations: List[str]) -> List[Dict]:
        """Validate multiple D1 explanations."""
        return [self.validate(exp) for exp in explanations]
    
    def check_pseudo_mapping(self, d1_explanation: str, d3_explanation: str) -> Dict:
        """
        Detect pseudo-mapping: D1's PRINCIPLE MAP claims to map to D3
        principles, but the mapping is vague or vacuous.
        
        A pseudo-mapping looks like:
        - "This corresponds to the mathematical structure" (vague)
        - "This is like the formula" (empty)
        - "This maps to the theoretical concept" (circular)
        
        A genuine mapping specifies:
        - Exact D3 principle name
        - How the analogy mechanism mirrors the formal mechanism
        - Boundary of the mapping (where analogy breaks)
        
        Args:
            d1_explanation: D1 explanation text containing PRINCIPLE MAP
            d3_explanation: D3 explanation text containing formal principles
            
        Returns:
            Dict with is_pseudo, mapped_principles, unmapped_principles,
            vague_mappings, mapping_quality_score
        """
        principle_map_entries = self._extract_principle_map_entries(d1_explanation)
        d3_principles = self._extract_d3_principles(d3_explanation)
        
        if not principle_map_entries or not d3_principles:
            return {
                "is_pseudo": True,
                "mapped_principles": [],
                "unmapped_principles": d3_principles,
                "vague_mappings": [],
                "mapping_quality_score": 0.0,
                "reason": "No principle map or no D3 principles found"
            }
        
        mapped = []
        unmapped = []
        vague = []
        
        for principle in d3_principles:
            matching_entry = None
            for entry in principle_map_entries:
                if self._principle_matches_entry(principle, entry):
                    matching_entry = entry
                    break
            
            if matching_entry:
                if self._is_vague_mapping(matching_entry):
                    vague.append({"principle": principle, "entry": matching_entry, "reason": "Mapping is vague or empty"})
                else:
                    mapped.append({"principle": principle, "entry": matching_entry})
            else:
                unmapped.append(principle)
        
        total_principles = len(d3_principles)
        genuine_mappings = len(mapped)
        vague_count = len(vague)
        
        score = (genuine_mappings + vague_count * 0.3) / total_principles if total_principles > 0 else 0.0
        is_pseudo = (genuine_mappings / total_principles < 0.5) if total_principles > 0 else True
        
        return {
            "is_pseudo": is_pseudo,
            "mapped_principles": mapped,
            "unmapped_principles": unmapped,
            "vague_mappings": vague,
            "mapping_quality_score": round(score, 3),
            "reason": f"{genuine_mappings}/{total_principles} genuinely mapped, {vague_count} vague, {len(unmapped)} unmapped"
        }
    
    def _extract_principle_map_entries(self, d1_explanation: str) -> List[str]:
        """Extract individual entries from PRINCIPLE MAP section."""
        entries = []
        lines = d1_explanation.split('\n')
        in_map = False
        for line in lines:
            line = line.strip()
            if re.search(r'PRINCIPLE MAP|principle map', line, re.IGNORECASE):
                in_map = True
                continue
            if in_map:
                if re.search(r'^(BOUNDARY|PRE-LOAD|HONESTY|[0-9]+\.)', line, re.IGNORECASE):
                    break
                if line.startswith(('-', '*', 'a.', 'b.', 'c.', 'd.', 'e.')) and len(line) > 10:
                    entries.append(line)
        return entries
    
    def _extract_d3_principles(self, d3_explanation: str) -> List[str]:
        """Extract core principles/terms from D3 explanation."""
        principles = []
        lines = d3_explanation.split('\n')
        for line in lines:
            line = line.strip()
            if any(marker in line for marker in ['Definition:', 'Theorem:', 'Formula:', 'Equation:', '→', '⇒', '≈', '∑', '∫', '∂', '∇']):
                if len(line) > 20 and len(line) < 300:
                    principles.append(line)
            elif line.startswith(('-', '*', '1.', '2.', '3.', '4.', '5.')) and any(
                term in line.lower() for term in ['function', 'equation', 'theorem', 'property', 'condition', 'constraint', 'optimization', 'gradient', 'derivative', 'matrix', 'vector']
            ):
                if len(line) > 20 and len(line) < 300:
                    principles.append(line)
        return principles
    
    def _principle_matches_entry(self, principle: str, entry: str) -> bool:
        """Check if a D3 principle is referenced in a D1 principle map entry."""
        principle_words = set(re.findall(r'\b[A-Za-z]{4,}\b', principle.lower()))
        entry_words = set(re.findall(r'\b[A-Za-z]{4,}\b', entry.lower()))
        overlap = principle_words & entry_words
        return len(overlap) >= 2
    
    def _is_vague_mapping(self, entry: str) -> bool:
        """Detect if a mapping entry is vague or vacuous."""
        vague_patterns = [
            r'this\s+(corresponds|maps|relates)\s+to\s+the\s+(mathematical|theoretical|abstract|formal)\s+(structure|concept|idea|principle)',
            r'this\s+is\s+like\s+the\s+(formula|equation|theorem|definition)',
            r'similar\s+to\s+the\s+(mathematical|theoretical)\s+(model|framework)',
            r'can\s+be\s+thought\s+of\s+as\s+the\s+(abstract|formal)\s+(version|equivalent)',
        ]
        entry_lower = entry.lower()
        for pattern in vague_patterns:
            if re.search(pattern, entry_lower):
                return True
        if len(entry.split()) < 15:
            return True
        mechanism_words = ['because', 'when', 'if', 'then', 'leads to', 'causes', 'results in', 'produces', 'generates']
        if not any(w in entry_lower for w in mechanism_words):
            return True
        return False


# Legacy alias for backward compatibility
class MetaphorQualityValidator(D1Validator):
    """Alias for D1Validator."""
    pass


def main():
    parser = argparse.ArgumentParser(
        description="Validate D1 explanations for metaphor quality (v2)"
    )
    parser.add_argument("explanation", help="D1 explanation text or file path")
    parser.add_argument("--legacy", action="store_true", 
                       help="Use legacy technical-term-based validation")
    parser.add_argument("--output", help="Output JSON file path")
    
    args = parser.parse_args()
    
    # Load explanation
    if os.path.isfile(args.explanation):
        with open(args.explanation, 'r') as f:
            explanation = f.read()
    else:
        explanation = args.explanation
    
    validator = D1Validator()
    result = validator.validate(explanation)
    
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
