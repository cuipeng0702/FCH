# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
Metacognitive Memory — The skill learns how to learn.

Records strategy effectiveness per concept type and learns from each
cognitive cycle to improve future learning.

Usage:
    from scripts.metacognitive_memory import MetacognitiveMemory
    memory = MetacognitiveMemory()
    memory.record_cycle("gradient_descent", "mathematical", "axiom_first", 3, 0.85, [])
    best_strategy = memory.suggest_strategy("neural_network", "mathematical")
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional


class MetacognitiveMemory:
    """
    Tracks what learning strategies work for what concept types.
    
    Core insight: The 100th concept learning should be smarter than the 1st.
    """
    
    def __init__(self, storage_path: str = None):
        self.storage_path = storage_path or os.path.expanduser(
            "~/.openclaw/workspace/knowledge-lattice/metacognitive_memory.json"
        )
        self.records = self._load()
        self._ensure_defaults()
    
    def _load(self) -> List[Dict]:
        """Load historical records."""
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return []
        return []
    
    def _save(self) -> None:
        """Save records to disk."""
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        with open(self.storage_path, 'w') as f:
            json.dump(self.records, f, indent=2)
    
    def _ensure_defaults(self) -> None:
        """Seed with default effectiveness assumptions."""
        if not self.records:
            # Default assumptions based on cognitive science
            defaults = [
                {
                    "concept_id": "_default_mathematical",
                    "concept_type": "mathematical",
                    "strategy": "axiom_first",
                    "iterations": 3,
                    "final_confidence": 0.75,
                    "gap_count": 2,
                    "timestamp": datetime.now().isoformat(),
                    "source": "default_assumption"
                },
                {
                    "concept_id": "_default_empirical",
                    "concept_type": "empirical_science",
                    "strategy": "evidence_first",
                    "iterations": 3,
                    "final_confidence": 0.80,
                    "gap_count": 1,
                    "timestamp": datetime.now().isoformat(),
                    "source": "default_assumption"
                },
                {
                    "concept_id": "_default_engineering",
                    "concept_type": "engineering",
                    "strategy": "problem_first",
                    "iterations": 4,
                    "final_confidence": 0.70,
                    "gap_count": 3,
                    "timestamp": datetime.now().isoformat(),
                    "source": "default_assumption"
                }
            ]
            self.records.extend(defaults)
            self._save()
    
    def record_cycle(self, concept_id: str, concept_type: str, strategy: str,
                     iterations: int, final_confidence: float, gaps: List[Dict],
                     oscillation_count: int = 0,
                     d1_structure_fingerprint: str = None,
                     preferred_metaphor_family: str = None,
                     source: str = "runtime") -> None:
        """
        Record the outcome of a complete cognitive cycle.
        
        Args:
            concept_id: The concept learned
            concept_type: Classification type (mathematical, empirical, etc.)
            strategy: Strategy used (axiom_first, evidence_first, etc.)
            iterations: Number of iterations to convergence
            final_confidence: Final confidence score (0-1)
            gaps: List of remaining gaps (empty = complete success)
            oscillation_count: Number of oscillation cycles performed
            d1_structure_fingerprint: Hash/fingerprint of D1 structure for tracking stability
            preferred_metaphor_family: User's preferred metaphor type (physical, social, biological, etc.)
            source: "runtime" for actual runs, "simulated" for projections
        """
        record = {
            "concept_id": concept_id,
            "concept_type": concept_type,
            "strategy": strategy,
            "iterations": iterations,
            "final_confidence": final_confidence,
            "gap_count": len(gaps),
            "gap_types": [g.get("type", "unknown") for g in gaps],
            "success": final_confidence >= 0.7 and len(gaps) == 0,
            "oscillation_count": oscillation_count,
            "d1_structure_fingerprint": d1_structure_fingerprint,
            "preferred_metaphor_family": preferred_metaphor_family,
            "timestamp": datetime.now().isoformat(),
            "source": source
        }
        
        self.records.append(record)
        self._save()
    
    def get_effectiveness(self, concept_type: str, strategy: str,
                          min_samples: int = 1) -> Dict:
        """
        Calculate strategy effectiveness for a concept type.
        
        Returns:
            Dict with success_rate, avg_iterations, avg_confidence, sample_count
        """
        matches = [
            r for r in self.records
            if r["concept_type"] == concept_type and r["strategy"] == strategy
            and r.get("source") != "default_assumption"
        ]
        
        if len(matches) < min_samples:
            # Fall back to default assumptions + any runtime data
            matches = [
                r for r in self.records
                if r["concept_type"] == concept_type and r["strategy"] == strategy
            ]
        
        if not matches:
            return {
                "success_rate": 0.5,
                "avg_iterations": 4.0,
                "avg_confidence": 0.6,
                "sample_count": 0,
                "recommendation": "insufficient_data"
            }
        
        success_rate = sum(1 for r in matches if r.get("success", False)) / len(matches)
        avg_iterations = sum(r["iterations"] for r in matches) / len(matches)
        avg_confidence = sum(r["final_confidence"] for r in matches) / len(matches)
        
        # Recommendation logic
        if success_rate >= 0.8 and avg_iterations <= 3:
            recommendation = "highly_effective"
        elif success_rate >= 0.6:
            recommendation = "moderately_effective"
        else:
            recommendation = "consider_alternative"
        
        return {
            "success_rate": round(success_rate, 2),
            "avg_iterations": round(avg_iterations, 1),
            "avg_confidence": round(avg_confidence, 2),
            "sample_count": len(matches),
            "recommendation": recommendation
        }
    
    def suggest_strategy(self, concept_id: str, concept_type: str,
                         available_strategies: List[str] = None) -> Dict:
        """
        Suggest the best strategy for a concept based on historical data.
        
        Returns:
            Dict with strategy recommendation and confidence
        """
        if available_strategies is None:
            available_strategies = ["axiom_first", "evidence_first", 
                                    "problem_first", "perspective_first", "step_first"]
        
        # Score each strategy
        scores = {}
        for strategy in available_strategies:
            effectiveness = self.get_effectiveness(concept_type, strategy)
            # Composite score: success_rate * 0.4 + avg_confidence * 0.4 - avg_iterations * 0.05
            score = (effectiveness["success_rate"] * 0.4 + 
                    effectiveness["avg_confidence"] * 0.4 -
                    effectiveness["avg_iterations"] * 0.05)
            scores[strategy] = {
                "score": round(score, 3),
                **effectiveness
            }
        
        # Select best
        best_strategy = max(scores, key=lambda s: scores[s]["score"])
        
        return {
            "recommended_strategy": best_strategy,
            "confidence": scores[best_strategy]["avg_confidence"],
            "rationale": f"Based on {scores[best_strategy]['sample_count']} samples, "
                          f"{best_strategy} has {scores[best_strategy]['success_rate']*100:.0f}% success rate",
            "all_scores": scores
        }
    
    def get_failure_patterns(self, concept_type: str = None) -> List[Dict]:
        """
        Identify common failure patterns from historical data.
        
        Returns:
            List of failure patterns with frequency and recommendations
        """
        failures = [
            r for r in self.records
            if not r.get("success", False) and r.get("source") == "runtime"
        ]
        
        if concept_type:
            failures = [r for r in failures if r["concept_type"] == concept_type]
        
        if not failures:
            return []
        
        # Group by gap types
        from collections import Counter
        gap_type_counts = Counter()
        for f in failures:
            for gt in f.get("gap_types", []):
                gap_type_counts[gt] += 1
        
        patterns = []
        for gap_type, count in gap_type_counts.most_common(5):
            freq = count / len(failures)
            
            recommendations = {
                "missing_foundation": "Teach prerequisite concepts first (dimensional_reduction)",
                "oversimplification": "Add boundary annotations to D1",
                "circular_definition": "Find external anchor concept",
                "theoretical_crisis": "Mark as open problem, reduce scope",
                "incomplete_example": "Add concrete numerical example",
                "missing_formalization": "Add mathematical derivation"
            }
            
            patterns.append({
                "pattern": gap_type,
                "frequency": round(freq, 2),
                "count": count,
                "recommendation": recommendations.get(gap_type, "Investigate root cause")
            })
        
        return patterns
    
    def get_learning_curve(self, concept_type: str = None) -> List[Dict]:
        """
        Get learning curve data for visualization.
        
        Returns:
            List of {timestamp, confidence, iterations} sorted by time
        """
        records = [r for r in self.records if r.get("source") == "runtime"]
        if concept_type:
            records = [r for r in records if r["concept_type"] == concept_type]
        
        return sorted([
            {
                "timestamp": r["timestamp"],
                "confidence": r["final_confidence"],
                "iterations": r["iterations"],
                "concept_id": r["concept_id"]
            }
            for r in records
        ], key=lambda x: x["timestamp"])


class Decision:
    """Enumeration of metacognitive decisions."""
    DEEPEN = "deepen"
    SOLIDIFY = "solidify"


class TriggerEvent:
    """Standardized trigger event from any source."""
    def __init__(self, trigger_type: str, concept_id: str, 
                 priority: str = "medium", data: Dict = None):
        self.type = trigger_type  # time_due | new_info | failure | propagation
        self.concept_id = concept_id
        self.priority = priority  # low | medium | high | maximum
        self.data = data or {}
    
    def to_dict(self) -> Dict:
        return {
            "type": self.type,
            "concept_id": self.concept_id,
            "priority": self.priority,
            "data": self.data
        }


class MetacognitiveLayer:
    """
    Layer 1: Metacognitive Evaluation.
    
    When awakened by a trigger, evaluates the current cognitive state
    and decides whether to DEEPEN or SOLIDIFY.
    """
    
    def __init__(self, lattice_manager=None, config: Dict = None):
        self.lattice = lattice_manager
        self.config = config or {}
        self.confidence_decline_threshold = self.config.get(
            "confidence_decline_threshold", -0.1
        )
        self.version_delta_threshold = self.config.get(
            "version_delta_threshold", 0.3
        )
    
    def evaluate(self, trigger: TriggerEvent) -> str:
        """
        Evaluate whether to DEEPEN or SOLIDIFY.
        
        Dimensions:
        1. Epistemic emotion: satisfied → confused triggers DEEPEN
        2. Confidence trend: declining triggers DEEPEN
        3. Version delta: high external info mismatch triggers DEEPEN
        
        Returns:
            Decision.DEEPEN or Decision.SOLIDIFY
        """
        concept_id = trigger.concept_id
        concept = self.lattice.read(concept_id) if self.lattice else None
        
        if not concept:
            # New concept: always DEEPEN
            return Decision.DEEPEN
        
        scores = []
        reasons = []
        
        # Dimension 1: Emotion assessment
        emotion_score, emotion_reason = self._evaluate_emotion(concept, trigger)
        scores.append(emotion_score)
        if emotion_reason:
            reasons.append(emotion_reason)
        
        # Dimension 2: Confidence trend
        trend_score, trend_reason = self._evaluate_confidence_trend(concept)
        scores.append(trend_score)
        if trend_reason:
            reasons.append(trend_reason)
        
        # Dimension 3: Version delta (external info mismatch)
        delta_score, delta_reason = self._evaluate_version_delta(concept, trigger)
        scores.append(delta_score)
        if delta_reason:
            reasons.append(delta_reason)
        
        # Decision: max score > 0.6 → DEEPEN
        max_score = max(scores) if scores else 0
        if max_score > 0.6:
            return Decision.DEEPEN
        return Decision.SOLIDIFY
    
    def _evaluate_emotion(self, concept: Dict, trigger: TriggerEvent) -> tuple:
        """Evaluate epistemic emotion dimension."""
        emotion = concept.get("epistemic_emotion", {})
        current = emotion.get("current_state", "curious")
        
        # New info trigger on satisfied emotion → confusion
        if trigger.type == "new_info" and current == "satisfied":
            return 0.8, f"New info conflicts with satisfied state"
        
        # Failure trigger → high confusion
        if trigger.type == "failure":
            return 1.0, f"Failure mode triggers deep confusion"
        
        # Already confused → deepen
        if current == "confused":
            return 0.7, f"Already in confused state"
        
        return 0.0, None
    
    def _evaluate_confidence_trend(self, concept: Dict) -> tuple:
        """Evaluate confidence trend dimension."""
        if not self.lattice:
            return 0.0, None
        
        trend = self.lattice.get_confidence_trend(concept.get("core_id"))
        if len(trend) < 2:
            return 0.0, None
        
        # Calculate recent trend (last 3 points)
        recent = trend[-3:]
        if len(recent) >= 2:
            first_conf = recent[0].get("confidence", 0)
            last_conf = recent[-1].get("confidence", 0)
            delta = last_conf - first_conf
            
            if delta < self.confidence_decline_threshold:
                return 0.7, f"Confidence declining: {delta:.3f}"
        
        return 0.0, None
    
    def _evaluate_version_delta(self, concept: Dict, trigger: TriggerEvent) -> tuple:
        """Evaluate external info mismatch dimension."""
        if trigger.type != "new_info":
            return 0.0, None
        
        # Check if trigger contains high-delta external info
        delta = trigger.data.get("version_delta", 0)
        if delta > self.version_delta_threshold:
            return min(delta * 2, 1.0), f"High version delta: {delta:.3f}"
        
        return 0.0, None
    """CLI for testing metacognitive memory."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Metacognitive Memory")
    parser.add_argument("--stats", action="store_true", help="Show statistics")
    parser.add_argument("--concept-type", help="Filter by concept type")
    parser.add_argument("--suggest", help="Suggest strategy for concept type")
    
    args = parser.parse_args()
    
    memory = MetacognitiveMemory()
    
    if args.stats:
        print(f"Total records: {len(memory.records)}")
        print(f"Runtime records: {sum(1 for r in memory.records if r.get('source') == 'runtime')}")
        
        if args.concept_type:
            failures = memory.get_failure_patterns(args.concept_type)
            if failures:
                print(f"\nFailure patterns for {args.concept_type}:")
                for p in failures:
                    print(f"  {p['pattern']}: {p['frequency']*100:.0f}% ({p['count']} cases)")
            
            curve = memory.get_learning_curve(args.concept_type)
            if curve:
                print(f"\nLearning curve ({len(curve)} points):")
                for point in curve[-5:]:
                    print(f"  {point['concept_id']}: conf={point['confidence']:.2f}, iters={point['iterations']}")
    
    if args.suggest:
        suggestion = memory.suggest_strategy("test", args.suggest)
        print(f"\nStrategy suggestion for {args.suggest}:")
        print(f"  Recommended: {suggestion['recommended_strategy']}")
        print(f"  Confidence: {suggestion['confidence']}")
        print(f"  Rationale: {suggestion['rationale']}")


if __name__ == "__main__":
    main()
