#!/usr/bin/env python3
"""
cognitive_classifier_legacy.py — Original v1 logic preserved as fallback.

Extracted from cognitive_classifier.py v1 to maintain backward compatibility
while v2 uses emergent semantic clustering.
"""

from typing import Dict

TYPE_SIGNATURES = {
    "mathematical": {
        "indicators": [
            "theorem", "proof", "lemma", "axiom", "formula", "equation",
            "derivation", "convergence", "divergence", "optimization",
            "gradient", "matrix", "vector", "tensor", "calculus",
            "algebra", "geometry", "topology", "statistics", "probability"
        ],
        "strategy": {
            "name": "axiom_first",
            "d1_approach": "physical_metaphor",
            "audit_focus": ["derivation_gaps", "edge_cases", "counter_examples"],
            "growth_pattern": "bottom_up"
        }
    },
    "empirical_science": {
        "indicators": [
            "experiment", "observation", "hypothesis", "evidence", "data",
            "phenomenon", "measurement", "empirical", "observational",
            "laboratory", "field study", "survey", "clinical trial"
        ],
        "strategy": {
            "name": "evidence_first",
            "d1_approach": "observation_story",
            "audit_focus": ["experimental_design", "causality", "replication"],
            "growth_pattern": "top_down"
        }
    },
    "engineering": {
        "indicators": [
            "system", "design", "architecture", "implementation",
            "protocol", "framework", "platform", "infrastructure",
            "deployment", "scalability", "performance", "reliability",
            "constraint", "tradeoff", "optimization", "efficiency"
        ],
        "strategy": {
            "name": "problem_first",
            "d1_approach": "constraint_narrative",
            "audit_focus": ["tradeoffs", "failure_modes", "scalability"],
            "growth_pattern": "spiral"
        }
    },
    "humanities": {
        "indicators": [
            "interpretation", "context", "perspective", "culture",
            "history", "philosophy", "literature", "art", "society",
            "politics", "economics", "psychology", "language"
        ],
        "strategy": {
            "name": "perspective_first",
            "d1_approach": "experience_transfer",
            "audit_focus": ["cultural_context", "interpretation_bias", "historical_evolution"],
            "growth_pattern": "network"
        }
    },
    "procedural": {
        "indicators": [
            "algorithm", "procedure", "process", "workflow",
            "step", "instruction", "recipe", "method", "technique",
            "operation", "function", "routine", "pipeline"
        ],
        "strategy": {
            "name": "step_first",
            "d1_approach": "recipe_analogy",
            "audit_focus": ["step_completeness", "branch_coverage", "error_handling"],
            "growth_pattern": "linear"
        }
    }
}
