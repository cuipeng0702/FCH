# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
Visualize Concept Lattice using graphify.

Usage:
    python visualize_lattice.py [--input-dir DIR] [--output-dir DIR] [--open]
    
Example:
    python visualize_lattice.py --output-dir ./viz
"""

import argparse
import json
import os
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Dict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.export_to_graphify import LatticeToGraphifyExporter


def run_graphify_pipeline(graph_json_path: str, output_dir: str) -> Dict:
    """
    Run graphify clustering and HTML generation on exported graph.
    
    Requires graphify to be installed: pip install graphifyy
    """
    try:
        import graphify
        from graphify.build import build_from_json
        from graphify.cluster import cluster, score_all
        from graphify.analyze import god_nodes, surprising_connections, suggest_questions
        from graphify.report import generate
        from graphify.export import to_html
        import networkx as nx
        from networkx.readwrite import json_graph
        
        # Load graph
        with open(graph_json_path, 'r') as f:
            data = json.load(f)
        
        G = json_graph.node_link_graph(data, edges='links')
        
        if G.number_of_nodes() == 0:
            return {"status": "error", "message": "Graph is empty"}
        
        # Cluster
        communities = cluster(G)
        cohesion = score_all(G, communities)
        
        # Analyze
        gods = god_nodes(G)
        surprises = surprising_connections(G, communities)
        
        # Generate labels
        labels = {}
        for cid, nodes in communities.items():
            # Label by most common file_type
            types = {}
            for nid in nodes:
                ft = G.nodes[nid].get('file_type', 'unknown')
                types[ft] = types.get(ft, 0) + 1
            dominant = max(types, key=types.get) if types else 'mixed'
            labels[cid] = f"{dominant.title()} Community"
        
        # Generate report
        detection = {
            'total_files': len([n for n in G.nodes()]),
            'total_words': 99999,
            'needs_graph': True,
            'warning': None,
            'files': {'code': [], 'document': [], 'paper': []}
        }
        tokens = {'input': 0, 'output': 0}
        
        report = generate(
            G, communities, cohesion, labels, gods, surprises,
            detection, tokens, os.path.dirname(graph_json_path)
        )
        
        report_path = os.path.join(output_dir, "GRAPH_REPORT.md")
        with open(report_path, 'w') as f:
            f.write(report)
        
        # Generate HTML
        html_path = os.path.join(output_dir, "graph.html")
        if G.number_of_nodes() <= 5000:
            to_html(G, communities, html_path, community_labels=labels)
            html_generated = True
            
            # Step 3: Inject JS to override graphify's community colors with semantic encoding
            _inject_visual_override_js(html_path, G)
        else:
            html_generated = False
        
        return {
            "status": "success",
            "nodes": G.number_of_nodes(),
            "edges": G.number_of_edges(),
            "communities": len(communities),
            "report_path": report_path,
            "html_path": html_path if html_generated else None,
            "html_generated": html_generated,
            "god_nodes": gods[:5] if gods else [],
            "surprises": surprises[:3] if surprises else []
        }
        
    except ImportError:
        return {
            "status": "error",
            "message": "graphify not installed. Run: pip install graphifyy"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }


def _inject_visual_override_js(html_path: str, G) -> None:
    """
    Inject JavaScript into HTML to override graphify's community colors
    with our semantic encoding after page load.
    
    This avoids complex server-side regex manipulation of minified JSON.
    """
    import re
    
    # Build color/shape map
    override_map = {}
    for nid, data in G.nodes(data=True):
        node_type = data.get('file_type', 'concept')
        conf = data.get('confidence', 0)
        
        if node_type == 'concept':
            if conf == 0:
                color = "#74c0fc"
            elif conf < 0.5:
                color = "#ffd43b"
            elif conf < 0.8:
                color = "#ff6b6b"
            elif conf < 0.95:
                color = "#51cf66"
            else:
                color = "#339af0"
            shape = "dot"
        elif node_type == 'gap':
            color = "#ffa94d"
            shape = "triangle"
        elif node_type == 'contradiction':
            color = "#ff8787"
            shape = "diamond"
        elif node_type == 'cascade':
            color = "#da77f2"
            shape = "star"
        else:
            color = data.get('color', '#74c0fc')
            shape = "dot"
        
        override_map[nid] = {"color": color, "shape": shape}
    
    # Read HTML
    with open(html_path, 'r') as f:
        html = f.read()
    
    # Inject JS before closing </script> of the main script block
    js_code = f"""
// --- Feynman Harness Visual Override ---
(function() {{
  const OVERRIDES = {json.dumps(override_map)};
  
  function applyOverrides() {{
    if (typeof nodesDS === 'undefined') return;
    const updates = [];
    for (const [id, props] of Object.entries(OVERRIDES)) {{
      if (nodesDS.get(id)) {{
        updates.push({{
          id: id,
          color: {{
            background: props.color,
            border: props.color,
            highlight: {{ background: '#ffffff', border: props.color }}
          }},
          shape: props.shape
        }});
      }}
    }}
    if (updates.length > 0) {{
      nodesDS.update(updates);
      console.log('Feynman Harness: Applied visual overrides to ' + updates.length + ' nodes');
    }}
  }}
  
  // Apply after stabilization
  if (typeof network !== 'undefined') {{
    network.once('stabilizationIterationsDone', applyOverrides);
    // Also apply immediately in case stabilization already happened
    setTimeout(applyOverrides, 500);
  }} else {{
    setTimeout(applyOverrides, 1000);
  }}
}})();
// --- End Feynman Harness Visual Override ---
"""
    
    # Find the last </script> before </body> and insert before it
    # Or append to the main script block
    last_script_end = html.rfind('</script>')
    if last_script_end > 0:
        html = html[:last_script_end] + js_code + html[last_script_end:]
    
    # Also update vis-network options to remove default shape
    html = html.replace(
        "nodes: { shape: 'dot', borderWidth: 1.5 }",
        "nodes: { borderWidth: 1.5 }"
    )
    
    with open(html_path, 'w') as f:
        f.write(html)
    
    print(f"  Injected visual override JS for {len(override_map)} nodes")


def main():
    parser = argparse.ArgumentParser(description="Visualize Concept Lattice")
    parser.add_argument("--input-dir", default="~/.openclaw/workspace/knowledge-lattice/",
                       help="Concept lattice directory")
    parser.add_argument("--output-dir", default="./graphify-out",
                       help="Output directory")
    parser.add_argument("--open", action="store_true",
                       help="Open HTML in browser after generation")
    
    args = parser.parse_args()
    
    output_dir = os.path.expanduser(args.output_dir)
    os.makedirs(output_dir, exist_ok=True)
    
    # Step 1: Export to graphify format
    print("Step 1: Exporting concept lattice to graphify format...")
    exporter = LatticeToGraphifyExporter(os.path.expanduser(args.input_dir))
    export_result = exporter.export(output_dir)
    
    if export_result["status"] != "success":
        print(json.dumps(export_result, indent=2))
        sys.exit(1)
    
    print(f"  Exported: {export_result['nodes']} nodes, {export_result['edges']} edges")
    
    # Step 2: Run graphify pipeline
    print("\nStep 2: Running graphify clustering and visualization...")
    graph_json_path = export_result["graph_path"]
    viz_result = run_graphify_pipeline(graph_json_path, output_dir)
    
    print(json.dumps(viz_result, indent=2))
    
    # Step 3: Open browser if requested
    if args.open and viz_result.get("html_path"):
        html_path = viz_result["html_path"]
        if os.path.exists(html_path):
            print(f"\nOpening {html_path} in browser...")
            webbrowser.open(f"file://{os.path.abspath(html_path)}")


if __name__ == "__main__":
    main()
