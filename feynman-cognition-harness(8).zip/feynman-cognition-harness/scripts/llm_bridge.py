# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
LLM Bridge — Kimi-Claw proxy integration for the Feynman Cognition Harness.

Uses the local Kimi-Claw proxy (localhost:18790) to generate explanations.
This allows the skill to call LLM capabilities directly without external API keys.
"""

import json
import os
import sys
from typing import Dict, Optional

try:
    import openai
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    import urllib.request
    import urllib.error
    HAS_URLLIB = True
except ImportError:
    HAS_URLLIB = False


class LLMBridge:
    """
    Bridge to Kimi-Claw proxy for LLM generation.
    
    The proxy runs at localhost:18790 and exposes an OpenAI-compatible API.
    """
    
    DEFAULT_BASE_URL = "http://localhost:18790/v1"
    DEFAULT_MODEL = "k2p5-6-code-preview"
    DEFAULT_TIMEOUT = 120
    
    def __init__(self, base_url: str = None, model: str = None, api_key: str = "dummy"):
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.model = model or self.DEFAULT_MODEL
        self.api_key = api_key
        self._client = None
        
        if HAS_OPENAI:
            self._client = openai.OpenAI(
                base_url=self.base_url,
                api_key=self.api_key,
                timeout=self.DEFAULT_TIMEOUT
            )
    
    def generate(self, prompt: str, system_prompt: str = None, 
                 temperature: float = 1.0, max_tokens: int = 4000) -> Dict:
        """
        Generate text using the Kimi-Claw proxy.
        
        Args:
            prompt: The user prompt
            system_prompt: Optional system instructions
            temperature: Sampling temperature (k2p5 only supports 1.0)
            max_tokens: Max tokens to generate
            
        Returns:
            Dict with "content", "model", "usage", "raw_response"
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        try:
            if self._client:
                response = self._client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens
                )
                return {
                    "content": response.choices[0].message.content,
                    "model": response.model,
                    "usage": {
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens
                    },
                    "raw_response": response,
                    "status": "success"
                }
            else:
                # Fallback to urllib
                return self._generate_urllib(messages, temperature, max_tokens)
        except Exception as e:
            return {
                "content": f"[LLM Error: {str(e)}]",
                "model": self.model,
                "usage": {},
                "raw_response": None,
                "status": "error",
                "error": str(e)
            }
    
    def _generate_urllib(self, messages: list, temperature: float, 
                         max_tokens: int) -> Dict:
        """Fallback generation using urllib (no openai package)."""
        url = f"{self.base_url}/chat/completions"
        data = json.dumps({
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }).encode('utf-8')
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            },
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=self.DEFAULT_TIMEOUT) as resp:
            result = json.loads(resp.read().decode('utf-8'))
            return {
                "content": result["choices"][0]["message"]["content"],
                "model": result.get("model", self.model),
                "usage": result.get("usage", {}),
                "raw_response": result,
                "status": "success"
            }
    
    def health_check(self) -> Dict:
        """Check if the proxy is available."""
        try:
            if HAS_OPENAI and self._client:
                models = self._client.models.list()
                return {
                    "status": "healthy",
                    "models": [m.id for m in models.data],
                    "base_url": self.base_url
                }
            else:
                req = urllib.request.Request(
                    f"{self.base_url}/models",
                    headers={"Authorization": f"Bearer {self.api_key}"}
                )
                with urllib.request.urlopen(req, timeout=5) as resp:
                    result = json.loads(resp.read().decode('utf-8'))
                    return {
                        "status": "healthy",
                        "models": [m["id"] for m in result.get("data", [])],
                        "base_url": self.base_url
                    }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "base_url": self.base_url
            }


def create_model_caller(bridge: LLMBridge = None):
    """
    Create a model_caller function compatible with TeachEngine and GrowEngine.
    
    Returns:
        Function: (concept, prompt) -> dict with explanation, confidence, etc.
    """
    bridge = bridge or LLMBridge()
    
    def model_caller(concept: str, prompt: str) -> Dict:
        """Call LLM and parse result into expected format."""
        result = bridge.generate(prompt)
        
        if result["status"] != "success":
            return {
                "concept": concept,
                "explanation": f"[Generation failed: {result.get('error', 'unknown')}]",
                "assumed_knowledge": [],
                "confidence": 0.0,
                "error": result.get("error")
            }
        
        content = result["content"]
        
        # Extract confidence from content (look for "Confidence: X.X" or similar)
        confidence = 0.7  # Default
        import re
        confidence_match = re.search(r'[Cc]onfidence[:\s]+([0-9.]+)', content)
        if confidence_match:
            confidence = float(confidence_match.group(1))
            confidence = max(0.0, min(1.0, confidence))
        
        # Extract assumed knowledge (look for "Assumed Knowledge" section)
        assumed_knowledge = []
        ak_match = re.search(r'[Aa]ssumed [Kk]nowledge[^:]*:?\s*\n?((?:\n?\s*[-•*].+)*)', content)
        if ak_match:
            ak_text = ak_match.group(1)
            assumed_knowledge = [line.strip('-•* ').strip() for line in ak_text.split('\n') if line.strip()]
        
        return {
            "concept": concept,
            "explanation": content,
            "assumed_knowledge": assumed_knowledge,
            "confidence": confidence,
            "raw_llm_response": result
        }
    
    return model_caller


def main():
    """CLI for testing LLM Bridge."""
    bridge = LLMBridge()
    
    # Health check
    health = bridge.health_check()
    print(f"Health: {health['status']}")
    if health['status'] == 'healthy':
        print(f"Available models: {health['models']}")
    else:
        print(f"Error: {health.get('error')}")
        return
    
    # Test generation
    prompt = "Explain 'gravity' to an 8-year-old child in 3 sentences. Use a visual metaphor."
    print(f"\nTest prompt: {prompt}")
    result = bridge.generate(prompt)
    print(f"Status: {result['status']}")
    print(f"Content: {result['content'][:200]}...")


if __name__ == "__main__":
    main()
