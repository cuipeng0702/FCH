# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
CognitiveClassifier v2 - Semantic Clustering with Synonym Expansion

Philosophy:
  Cross-disciplinary concepts cannot be exhaustively enumerated.
  We use synonym expansion + emergent clustering to discover latent connections.
  "AHA moments" surface when a concept bridges previously disconnected clusters.

Usage:
    from scripts.cognitive_classifier import CognitiveClassifier
    classifier = CognitiveClassifier()
    result = classifier.classify("gradient_descent", "optimization algorithm")
    # result now includes clusters, bridges, and potential aha_moments
"""

import json
import re
from typing import Dict, List, Optional, Set, Tuple
from collections import defaultdict, Counter


class SemanticClusterEngine:
    """
    Emergent concept clustering via co-occurrence + synonym expansion.

    No fixed categories. Clusters form bottom-up from lexical co-occurrence
    in explanation texts. Clusters merge when bridge concepts appear.
    """

    # Seed lexicon: minimal, non-exhaustive. The system grows from here.
    SEED_LEXICON = {
        "math": ["theorem", "proof", "formula", "equation", "gradient", "matrix"],
        "compute": ["neural", "network", "algorithm", "training", "layer", "model"],
        "physics": ["quantum", "mechanics", "particle", "wave", "energy", "field"],
        "biology": ["cell", "neuron", "evolution", "genome", "protein"],
        "social": ["culture", "politics", "economics", "psychology", "society"],
        "engineer": ["system", "design", "architecture", "protocol", "scalability"],
        "proc": ["algorithm", "procedure", "workflow", "step", "method"]
    }

    # Synonym chains: static expansion for common terms.
    SYNONYM_MAP = {
        "network": ["graph", "topology", "web", "system"],
        "neural": ["brain", "cognitive", "neuron", "synapse"],
        "quantum": ["discrete", "atomic", "subatomic"],
        "mechanics": ["dynamics", "motion", "kinematics", "forces"],
        "gradient": ["slope", "derivative", "rate_of_change"],
        "training": ["learning", "fitting", "optimization", "calibration"],
        "model": ["representation", "abstraction", "framework", "paradigm"],
        "algorithm": ["procedure", "method", "heuristic", "rule"],
        "system": ["framework", "architecture", "platform", "infrastructure"],
        "equation": ["formula", "identity", "relation", "law"]
    }

    def __init__(self, external_corpus: Dict[str, str] = None):
        """
        Args:
            external_corpus: Optional pre-loaded concept_id -> explanation_text map.
                             Used to prime co-occurrence before live classification.
        """
        self.co_occurrence = defaultdict(lambda: defaultdict(int))
        self.cluster_map = {}  # concept_id -> cluster_label
        self.bridge_history = []  # [{concept, clusters, explanation}]
        self.corpus = external_corpus or {}
        self._prime_from_corpus()

    def _expand_tokens(self, tokens: Set[str]) -> Set[str]:
        """Expand tokens via synonym chains + derivational variants."""
        expanded = set(tokens)
        for token in list(tokens):
            # Direct synonym expansion
            if token in self.SYNONYM_MAP:
                expanded.update(self.SYNONYM_MAP[token])
            # Simple derivational heuristic (e.g., gradient -> gradients)
            if not token.endswith('s'):
                expanded.add(token + 's')
            # Stem heuristic (e.g., neural -> neuron via overlap)
        return expanded

    def _tokenize(self, text: str) -> Set[str]:
        """Extract clean tokens from text."""
        if not text:
            return set()
        text = text.lower()
        # Keep underscores for snake_case IDs, replace non-alnum with space
        text = re.sub(r'[^a-z0-9_\s]', ' ', text)
        tokens = {t.strip('_') for t in text.split() if len(t.strip('_')) > 2}
        return self._expand_tokens(tokens)

    def _prime_from_corpus(self):
        """Build initial co-occurrence from external corpus."""
        for concept_id, explanation in self.corpus.items():
            tokens = self._tokenize(f"{concept_id} {explanation}")
            for t1 in tokens:
                for t2 in tokens:
                    if t1 < t2:
                        self.co_occurrence[t1][t2] += 1
                        self.co_occurrence[t2][t1] += 1

    def add_to_corpus(self, concept_id: str, explanation: str):
        """Add new concept to live corpus, update co-occurrence."""
        self.corpus[concept_id] = explanation
        tokens = self._tokenize(f"{concept_id} {explanation}")
        for t1 in tokens:
            for t2 in tokens:
                if t1 < t2:
                    self.co_occurrence[t1][t2] += 1
                    self.co_occurrence[t2][t1] += 1

    def _connected_components(self, tokens: Set[str], threshold: int = 1) -> List[Set[str]]:
        """Find connected components in token co-occurrence graph."""
        visited = set()
        components = []
        for token in tokens:
            if token in visited:
                continue
            # BFS/DFS for connected component
            stack = [token]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in visited:
                    continue
                visited.add(cur)
                comp.add(cur)
                # neighbors: co-occurring tokens above threshold
                neighbors = {n for n, cnt in self.co_occurrence[cur].items() if cnt >= threshold}
                stack.extend(neighbors - visited)
            if comp:
                components.append(comp)
        return components

    def detect_aha_moments(self, concept_id: str, explanation: str) -> List[Dict]:
        """
        Detect "AHA moments" - when a concept bridges previously disconnected clusters.

        Two mechanisms:
        1. Domain mix: A single cluster contains tokens from >=2 seed domains
           (cross-disciplinary fusion within one lexical cluster).
        2. Cross-cluster bridge: Concept tokens connect >=2 distinct clusters
           (emergent linkage between previously separate lexical groups).
        """
        tokens = self._tokenize(f"{concept_id} {explanation}")
        components = self._connected_components(tokens, threshold=1)
        ahas = []

        # Mechanism 1: Domain mix within a single cluster
        for comp in components:
            matched_domains = []
            for domain, seeds in self.SEED_LEXICON.items():
                expanded_seeds = self._expand_tokens(set(seeds))
                if comp & expanded_seeds:
                    matched_domains.append(domain)

            if len(matched_domains) >= 2:
                ahas.append({
                    "type": "domain_mix",
                    "concept": concept_id,
                    "tokens": list(comp)[:20],
                    "domains": matched_domains,
                    "explanation": f"'{concept_id}' fuses {', '.join(matched_domains)} within a single lexical cluster - cross-disciplinary AHA."
                })

        # Mechanism 2: Cross-cluster bridge (only if >1 component)
        if len(components) >= 2:
            for i, comp_a in enumerate(components):
                for j, comp_b in enumerate(components):
                    if i >= j:
                        continue
                    concept_tokens = self._tokenize(concept_id)
                    if concept_tokens & comp_a and concept_tokens & comp_b:
                        ahas.append({
                            "type": "cross_cluster_bridge",
                            "concept": concept_id,
                            "cluster_a": list(comp_a)[:10],
                            "cluster_b": list(comp_b)[:10],
                            "explanation": f"'{concept_id}' links previously disconnected lexical clusters - emergent interdisciplinary connection."
                        })

        return ahas

    def get_clusters_for_concept(self, concept_id: str, explanation: str) -> List[Dict]:
        """Return emergent cluster memberships for a concept."""
        tokens = self._tokenize(f"{concept_id} {explanation}")
        components = self._connected_components(tokens, threshold=1)
        clusters = []
        for comp in components:
            # Check domain affiliation
            domain_scores = {}
            for domain, seeds in self.SEED_LEXICON.items():
                expanded = self._expand_tokens(set(seeds))
                overlap = comp & expanded
                if overlap:
                    domain_scores[domain] = len(overlap) / len(expanded)
            best_domain = max(domain_scores, key=domain_scores.get) if domain_scores else "unlabeled"
            clusters.append({
                "label": best_domain,
                "tokens": list(comp)[:15],
                "strength": sum(self.co_occurrence[t][n] for t in comp for n in comp if t < n) / max(len(comp)**2, 1)
            })
        return clusters


class CognitiveClassifier:
    """
    v2: Classifies via emergent semantic clusters, not exhaustive indicator lists.

    Backward-compatible interface. Adds new outputs:
      - clusters: emergent lexical clusters
      - aha_moments: detected cross-domain bridges
      - strategy: chosen from cluster-detected type
    """

    def __init__(self, external_corpus: Dict[str, str] = None):
        self.cluster_engine = SemanticClusterEngine(external_corpus=external_corpus)
        # Legacy fallback: keep TYPE_SIGNATURES for when clusters are too weak
        try:
            from scripts.cognitive_classifier_legacy import TYPE_SIGNATURES as _LEGACY_SIG
            self._legacy = _LEGACY_SIG
        except ImportError:
            # When run directly, scripts/ may not be in path
            import importlib.util, os
            legacy_path = os.path.join(os.path.dirname(__file__), 'cognitive_classifier_legacy.py')
            spec = importlib.util.spec_from_file_location("legacy", legacy_path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            self._legacy = mod.TYPE_SIGNATURES

    def classify(self, concept_id: str, initial_explanation: str = "", explanations: Dict = None) -> str:
        """
        Main classification entry.

        1. Build token set from concept_id + all explanation texts.
        2. Detect emergent clusters.
        3. Detect AHA moments (cross-domain bridges).
        4. Map strongest cluster to a type (for strategy selection).

        Returns:
            Primary type string (for strategy selection) + stores cluster data internally.
        """
        text_parts = [concept_id, initial_explanation]
        if explanations:
            for level_data in explanations.values():
                if isinstance(level_data, dict):
                    text_parts.append(level_data.get("explanation", ""))

        full_text = " ".join(text_parts)
        self.cluster_engine.add_to_corpus(concept_id, full_text)

        # Detect clusters and AHA moments
        self._last_clusters = self.cluster_engine.get_clusters_for_concept(concept_id, full_text)
        self._last_ahas = self.cluster_engine.detect_aha_moments(concept_id, full_text)

        # Map to primary type for strategy selection
        primary_type = self._map_clusters_to_type(self._last_clusters)
        if primary_type == "unknown" and len(self._last_clusters) > 0:
            # Fallback: use legacy keyword matching
            primary_type = self._legacy_classify(concept_id, full_text)

        return primary_type

    def _map_clusters_to_type(self, clusters: List[Dict]) -> str:
        """Map cluster labels to legacy type names for strategy compatibility."""
        label_map = {
            "math": "mathematical",
            "compute": "procedural",  # computational concepts default procedural
            "physics": "empirical_science",
            "biology": "empirical_science",
            "social": "humanities",
            "engineer": "engineering",
            "proc": "procedural"
        }
        if not clusters:
            return "unknown"
        # Pick strongest cluster
        strongest = max(clusters, key=lambda c: c.get("strength", 0))
        label = strongest.get("label", "unknown")
        return label_map.get(label, "unknown")

    def _legacy_classify(self, concept_id: str, text: str) -> str:
        """Fallback to legacy keyword matching."""
        scores = {t: 0.0 for t in self._legacy}
        concept_lower = concept_id.lower().replace("_", " ")
        text_lower = text.lower()
        for ctype, config in self._legacy.items():
            for indicator in config["indicators"]:
                if indicator in concept_lower:
                    scores[ctype] += 2.0
                scores[ctype] += text_lower.count(indicator) * 1.0
        if max(scores.values()) == 0:
            return "unknown"
        return max(scores, key=scores.get)

    def get_strategy(self, concept_type: str) -> Dict:
        """Get strategy — same as legacy."""
        try:
            from scripts.cognitive_classifier_legacy import TYPE_SIGNATURES
        except ImportError:
            import importlib.util, os
            legacy_path = os.path.join(os.path.dirname(__file__), 'cognitive_classifier_legacy.py')
            spec = importlib.util.spec_from_file_location("legacy", legacy_path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            TYPE_SIGNATURES = mod.TYPE_SIGNATURES
        
        if concept_type in TYPE_SIGNATURES:
            return {"type": concept_type, **TYPE_SIGNATURES[concept_type]["strategy"]}
        return {
            "type": "general",
            "name": "layered_buildup",
            "d1_approach": "everyday_analogy",
            "audit_focus": ["consistency", "clarity", "completeness"],
            "growth_pattern": "bottom_up"
        }

    def get_cluster_report(self) -> Dict:
        """Return full cluster + AHA moment data from last classification."""
        return {
            "clusters": getattr(self, '_last_clusters', []),
            "aha_moments": getattr(self, '_last_ahas', []),
            "corpus_size": len(self.cluster_engine.corpus),
            "co_occurrence_density": sum(
                sum(v.values()) for v in self.cluster_engine.co_occurrence.values()
            ) / max(len(self.cluster_engine.co_occurrence)**2, 1)
        }

    def explain_classification(self, concept_id: str, concept_type: str) -> str:
        """Generate explanation including AHA moments."""
        base = f"'{concept_id}' classified as {concept_type}."
        ahas = getattr(self, '_last_ahas', [])
        if ahas:
            aha_texts = [f"AHA: {a.get('explanation', '')}" for a in ahas]
            base += "\n   " + "\n   ".join(aha_texts)
        clusters = getattr(self, '_last_clusters', [])
        if clusters:
            cluster_texts = [f"Cluster '{c.get('label', '?')}': {', '.join(c.get('tokens', [])[:5])}"
                            for c in clusters]
            base += "\n   " + "\n   ".join(cluster_texts)
        return base


def main():
    """CLI for testing v2 classifier."""
    import argparse
    parser = argparse.ArgumentParser(description="Cognitive Classifier v2")
    parser.add_argument("concept", help="Concept to classify")
    parser.add_argument("--text", default="", help="Explanation text")
    args = parser.parse_args()

    classifier = CognitiveClassifier()
    ctype = classifier.classify(args.concept, args.text)
    strategy = classifier.get_strategy(ctype)
    report = classifier.get_cluster_report()

    print(f"\nConcept: {args.concept}")
    print(f"Type: {ctype}")
    print(f"Strategy: {strategy['name']}")
    print(f"\nClusters:")
    for c in report['clusters']:
        print(f"   {c['label']}: {', '.join(c['tokens'][:8])} (strength: {c['strength']:.2f})")
    if report['aha_moments']:
        print(f"\nAHA Moments:")
        for a in report['aha_moments']:
            print(f"   [{a['type']}] {a.get('explanation', '')}")
    else:
        print(f"\nNo AHA moments detected (clusters too unified or too fragmented).")


if __name__ == "__main__":
    main()
