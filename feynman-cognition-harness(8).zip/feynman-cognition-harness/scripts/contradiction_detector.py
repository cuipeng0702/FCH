# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
# DEPRECATED: v3.5 起由 harness/agents/audit_task_template.md 替代。保留作为 legacy 库。
"""
Cross-Level Contradiction Detector — Surface hidden inconsistencies across D1-D4.

Philosophy:
  Deep-level changes (D3/D4) often reveal contradictions with upper-level (D1/D2)
  explanations that weren't visible before. These contradictions are the most
  valuable learning signals — they mark the boundary of current understanding.

  "Insight is not accumulation of facts. It is the resolution of contradictions."
"""

import re
from typing import Dict, List, Set, Tuple, Optional
from collections import defaultdict


class CrossLevelContradictionDetector:
    """
    Detects contradictions between different explanation levels (D1-D4).
    
    Contradiction types:
      - factual_conflict: D1 says X, D4 says not-X (direct negation)
      - scope_mismatch: D1 claims "always", D3 shows edge case
      - mechanism_gap: D2 explains mechanism, D4 reveals missing step
      - assumption_violation: D1 assumes Y, D3 shows Y is false
      - confidence_divergence: confidence decreases with depth (suspicious)
    """

    # Negation patterns for factual conflict detection
    NEGATION_INDICATORS = [
        "not", "never", "always", "only", "must", "cannot",
        "impossible", "guaranteed", "certain", "always true"
    ]

    # Universal quantifiers that edge cases violate
    UNIVERSAL_MARKERS = ["all", "every", "always", "never", "must", "only"]

    def __init__(self, threshold: float = 0.15):
        """
        Args:
            threshold: Minimum contradiction severity to report (0-1 scale)
        """
        self.threshold = threshold

    def _extract_versions(self, concept: Dict) -> Dict[str, str]:
        """Extract D1-D4 content from version_stack."""
        versions = {}
        for v in concept.get("version_stack", []):
            level = v.get("level", "")
            if level in ("D1", "D2", "D3", "D4"):
                versions[level] = v.get("content", "")
        return versions

    def detect(self, concept: Dict) -> List[Dict]:
        """
        Full contradiction scan across all available D-levels.
        
        Returns list of contradictions, each with:
          - type: contradiction category
          - severity: 0-1 score
          - levels_involved: which D-levels conflict
          - description: human-readable explanation
          - resolution_hint: suggested learning direction
        """
        versions = self._extract_versions(concept)
        if len(versions) < 2:
            return []

        contradictions = []

        # 1. Factual conflict: negation between levels
        contradictions.extend(self._check_factual_conflicts(versions))

        # 2. Scope mismatch: universal claims vs edge cases
        contradictions.extend(self._check_scope_mismatch(versions))

        # 3. Mechanism gap: D2 mechanism incomplete in D4
        contradictions.extend(self._check_mechanism_gap(versions))

        # 4. Assumption violation
        contradictions.extend(self._check_assumption_violation(versions))

        # 5. Confidence divergence
        contradictions.extend(self._check_confidence_divergence(concept, versions))

        # v3.0: Push high-severity contradictions to TriggerDaemon
        self._push_contradiction_events(concept, contradictions)

        # Filter by threshold
        return [c for c in contradictions if c.get("severity", 0) >= self.threshold]

    def _push_contradiction_events(self, concept: Dict, contradictions: List[Dict]) -> None:
        """Push contradiction events to TriggerDaemon for high-severity findings."""
        try:
            from scripts.trigger_daemon import TriggerDaemon, TriggerEvent, Priority
            
            concept_id = concept.get("core_id", "unknown")
            high_severity = [c for c in contradictions if c.get("severity", 0) >= 0.7]
            
            if not high_severity:
                return
            
            daemon = TriggerDaemon()
            priority = Priority.HIGH if any(c.get("severity", 0) >= 0.8 for c in high_severity) else Priority.MEDIUM
            
            daemon.push_event(TriggerEvent(
                type=TriggerEvent.from_dict({"type": "failure", "concept_id": concept_id}).type,
                concept_id=concept_id,
                priority=priority,
                failure_reason="cross_level_contradiction",
                metadata={
                    "contradiction_count": len(high_severity),
                    "max_severity": max(c.get("severity", 0) for c in high_severity),
                    "types": list(set(c.get("type", "unknown") for c in high_severity))
                }
            ))
        except Exception:
            # TriggerDaemon is optional — silently skip if unavailable
            pass

    def _check_factual_conflicts(self, versions: Dict[str, str]) -> List[Dict]:
        """Check for direct negation between levels."""
        contradictions = []
        levels = sorted(versions.keys())

        for i, l1 in enumerate(levels):
            for l2 in levels[i+1:]:
                text1 = versions[l1].lower()
                text2 = versions[l2].lower()

                # Look for sentences in l1 that are negated in l2
                sentences1 = [s.strip() for s in text1.split('.') if len(s.strip()) > 15]
                for sent in sentences1:
                    # Simple heuristic: if l2 contains negation + key terms from sent
                    key_terms = self._extract_key_terms(sent)
                    if not key_terms:
                        continue

                    # Check if l2 has "not [term]" or contradicts the claim
                    for term in key_terms:
                        neg_pattern = f"not {term}|{term} is not|never {term}|cannot {term}"
                        if re.search(neg_pattern, text2):
                            contradictions.append({
                                "type": "factual_conflict",
                                "severity": 0.7,
                                "levels_involved": [l1, l2],
                                "description": f"'{l1}' claims '{sent[:50]}...' but '{l2}' negates key term '{term}'",
                                "resolution_hint": f"Reconcile '{l1}' and '{l2}' on the role of '{term}'"
                            })

        return contradictions

    def _check_scope_mismatch(self, versions: Dict[str, str]) -> List[Dict]:
        """Check for universal claims contradicted by deeper levels — across ALL level pairs."""
        contradictions = []
        
        # All ordered level pairs where shallower might overclaim universality
        level_pairs = [("D1", "D2"), ("D1", "D3"), ("D1", "D4"),
                       ("D2", "D3"), ("D2", "D4"), ("D3", "D4")]
        
        edge_patterns = ["except", "unless", "however", "but", "only if", "when", "in some cases",
                        "not always", "not all", "not every", "typically", "usually", "generally"]
        
        for shallow, deep in level_pairs:
            shallow_text = versions.get(shallow, "").lower()
            deep_text = versions.get(deep, "").lower()
            
            if not shallow_text or not deep_text:
                continue
            
            # Find universal quantifiers in the shallower level
            universals_found = []
            for marker in self.UNIVERSAL_MARKERS:
                if marker in shallow_text:
                    idx = shallow_text.find(marker)
                    start = max(0, idx - 30)
                    end = min(len(shallow_text), idx + 50)
                    clause = shallow_text[start:end]
                    universals_found.append((marker, clause))
            
            # Check if deeper level contains edge case / exception language
            deep_has_edge = any(p in deep_text for p in edge_patterns)
            
            if universals_found and deep_has_edge:
                for marker, clause in universals_found:
                    contradictions.append({
                        "type": "scope_mismatch",
                        "severity": 0.6,
                        "levels_involved": [shallow, deep],
                        "description": f"{shallow} uses universal '{marker}' ('{clause[:40]}...'), but {deep} reveals exceptions/edge cases",
                        "resolution_hint": f"Refine {shallow} to acknowledge boundary conditions that {deep} explores"
                    })
        
        return contradictions

    def _check_mechanism_gap(self, versions: Dict[str, str]) -> List[Dict]:
        """Check if deeper levels reveal missing steps in shallower mechanism descriptions — across ALL level pairs."""
        contradictions = []
        
        level_pairs = [("D1", "D2"), ("D1", "D3"), ("D1", "D4"),
                       ("D2", "D3"), ("D2", "D4"), ("D3", "D4")]
        
        step_keywords = ["first", "then", "next", "finally", "step", "stage", "phase"]
        mechanism_terms = ["mechanism", "process", "how", "works", "function", "operation"]
        
        for shallow, deep in level_pairs:
            shallow_text = versions.get(shallow, "").lower()
            deep_text = versions.get(deep, "").lower()
            
            if not shallow_text or not deep_text:
                continue
            
            # Count procedural markers in both levels
            shallow_steps = [w for w in shallow_text.split() if w in step_keywords]
            deep_steps = [w for w in deep_text.split() if w in step_keywords]
            
            # Check if both describe mechanisms
            shallow_mechanism = any(t in shallow_text for t in mechanism_terms)
            deep_mechanism = any(t in deep_text for t in mechanism_terms)
            
            # If deeper level unpacks significantly more steps, the shallower level may have oversimplified
            if shallow_mechanism and deep_mechanism and len(deep_steps) > len(shallow_steps) + 1:
                contradictions.append({
                    "type": "mechanism_gap",
                    "severity": 0.5,
                    "levels_involved": [shallow, deep],
                    "description": f"{shallow} outlines a mechanism, but {deep} reveals more detailed steps ({len(deep_steps)} vs {len(shallow_steps)} procedural markers)",
                    "resolution_hint": f"Update {shallow} mechanism to include steps discovered in {deep}"
                })
        
        return contradictions

    def _check_assumption_violation(self, versions: Dict[str, str]) -> List[Dict]:
        """Check if assumptions in shallower levels are violated by deeper levels — across ALL level pairs."""
        contradictions = []
        
        level_pairs = [("D1", "D2"), ("D1", "D3"), ("D1", "D4"),
                       ("D2", "D3"), ("D2", "D4"), ("D3", "D4")]
        
        # Common implicit assumptions and their violation markers in deeper levels
        assumption_patterns = {
            "infinite": ["finite", "limited", "bounded", "restricted"],
            "perfect": ["imperfect", "error", "noise", "approximation"],
            "ideal": ["real", "practical", "implementation", "constraints"],
            "linear": ["nonlinear", "non-linear", "complex"],
            "discrete": ["continuous", "approximation", "smooth"],
            "deterministic": ["stochastic", "random", "probabilistic"],
            "static": ["dynamic", "changing", "evolving", "adaptive"],
            "isolated": ["interactive", "coupled", "dependent", "contextual"]
        }
        
        for shallow, deep in level_pairs:
            shallow_text = versions.get(shallow, "").lower()
            deep_text = versions.get(deep, "").lower()
            
            if not shallow_text or not deep_text:
                continue
            
            for assumption, violations in assumption_patterns.items():
                if assumption in shallow_text:
                    for viol in violations:
                        if viol in deep_text:
                            contradictions.append({
                                "type": "assumption_violation",
                                "severity": 0.65,
                                "levels_involved": [shallow, deep],
                                "description": f"{shallow} implicitly assumes '{assumption}' conditions, but {deep} deals with '{viol}' reality",
                                "resolution_hint": f"Explicitly state the '{assumption}' assumption in {shallow} and show how {deep} relaxes it"
                            })
                            break  # One violation per assumption is enough
        
        return contradictions

    def _check_confidence_divergence(self, concept: Dict, versions: Dict[str, str]) -> List[Dict]:
        """Check if confidence decreases with depth (suspicious pattern)."""
        version_stack = concept.get("version_stack", [])
        confidences = {}
        for v in version_stack:
            level = v.get("level", "")
            conf = v.get("confidence", 0)
            if level in ("D1", "D2", "D3", "D4"):
                confidences[level] = conf

        if len(confidences) < 2:
            return []

        levels_sorted = ["D1", "D2", "D3", "D4"]
        vals = [confidences.get(l, 0) for l in levels_sorted if l in confidences]

        # If confidence drops significantly from D1 to D4
        if vals[0] - vals[-1] > 0.3:
            return [{
                "type": "confidence_divergence",
                "severity": 0.55,
                "levels_involved": ["D1", levels_sorted[len(vals)-1]],
                "description": f"Confidence drops from {vals[0]:.2f} (D1) to {vals[-1]:.2f} (deepest level) — deeper understanding exposes uncertainty",
                "resolution_hint": "Investigate why deeper levels reduce confidence; may indicate D1 oversimplification"
            }]

        return []

    def _extract_key_terms(self, text: str) -> List[str]:
        """Extract noun-like key terms from a sentence."""
        words = re.findall(r'[a-z]+', text.lower())
        # Filter common stop words
        stops = {"the", "a", "an", "is", "are", "was", "were", "be", "been",
                 "have", "has", "had", "do", "does", "did", "will", "would",
                 "could", "should", "may", "might", "must", "shall", "can",
                 "need", "dare", "ought", "used", "to", "of", "in", "for",
                 "on", "with", "at", "by", "from", "as", "into", "through",
                 "during", "before", "after", "above", "below", "between",
                 "under", "again", "further", "then", "once", "here", "there",
                 "when", "where", "why", "how", "all", "each", "few", "more",
                 "most", "other", "some", "such", "no", "nor", "not", "only",
                 "own", "same", "so", "than", "too", "very", "just", "but"}
        return [w for w in words if w not in stops and len(w) > 3]

    def get_priority_contradiction(self, contradictions: List[Dict]) -> Optional[Dict]:
        """Return the highest-severity contradiction to focus on."""
        if not contradictions:
            return None
        return max(contradictions, key=lambda c: c.get("severity", 0))


class ContradictionDrivenLearning:
    """
    Uses detected contradictions as the seed for the next learning cycle.
    
    Instead of generic "fill gaps", we target the specific contradiction:
      - factual_conflict → 启动事实核查 + 权威来源对比
      - scope_mismatch →  重新划定边界条件
      - mechanism_gap →   补充机制细节
      - assumption_violation → 显式化假设
      - confidence_divergence → 重新评估基础层简化程度
    """

    CONTRADICTION_TO_LEARNING_MAP = {
        "factual_conflict": {
            "action": "fact_reconcile",
            "target_levels": ["D1", "D4"],
            "strategy": "Search external sources to verify which level is correct. If both have partial truth, synthesize a D1.5 intermediate explanation."
        },
        "scope_mismatch": {
            "action": "boundary_reframe",
            "target_levels": ["D1"],
            "strategy": "Rewrite D1 with explicit scope qualifiers. Move universal claims to conditional form."
        },
        "mechanism_gap": {
            "action": "mechanism_deepen",
            "target_levels": ["D2"],
            "strategy": "Integrate D4's revealed steps into D2. Create intermediate D2.5 if granularity jump is too large."
        },
        "assumption_violation": {
            "action": "assumption_surface",
            "target_levels": ["D1", "D3"],
            "strategy": "Make D1 assumptions explicit. Add 'Under the assumption that...' framing. Show D3 as the relaxation."
        },
        "confidence_divergence": {
            "action": "foundation_audit",
            "target_levels": ["D1"],
            "strategy": "Audit D1 for oversimplification. If D1 is an idealization, label it clearly and link to D3 for real-world version."
        }
    }

    def generate_learning_task(self, contradiction: Dict) -> Dict:
        """
        Convert a contradiction into a concrete learning task.
        
        Returns:
            Dict with action, target_levels, strategy, and contradiction context.
        """
        ctype = contradiction.get("type", "unknown")
        mapping = self.CONTRADICTION_TO_LEARNING_MAP.get(ctype, {
            "action": "generic_reconcile",
            "target_levels": ["D1", "D4"],
            "strategy": "Investigate and resolve the contradiction through external validation."
        })

        return {
            "trigger": "contradiction",
            "contradiction_type": ctype,
            "severity": contradiction.get("severity", 0),
            "levels_involved": contradiction.get("levels_involved", []),
            "description": contradiction.get("description", ""),
            "resolution_hint": contradiction.get("resolution_hint", ""),
            **mapping
        }

    def should_trigger_new_cycle(self, contradictions: List[Dict]) -> bool:
        """
        Determine if contradictions are severe enough to warrant a new learning cycle.
        
        Rules:
          - Any factual_conflict (severity >= 0.7) → always
          - 2+ contradictions of any type → yes
          - Any assumption_violation → yes (fundamental restructuring needed)
          - Otherwise → no, log for future
        """
        if not contradictions:
            return False

        if any(c.get("type") == "factual_conflict" for c in contradictions):
            return True
        if len(contradictions) >= 2:
            return True
        if any(c.get("type") == "assumption_violation" for c in contradictions):
            return True

        return False


def main():
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Cross-Level Contradiction Detector")
    parser.add_argument("--concept-file", required=True, help="Concept JSON file to analyze")
    parser.add_argument("--threshold", type=float, default=0.15, help="Severity threshold")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    with open(args.concept_file, 'r') as f:
        concept = json.load(f)

    detector = CrossLevelContradictionDetector(threshold=args.threshold)
    contradictions = detector.detect(concept)

    cdl = ContradictionDrivenLearning()
    learning_tasks = [cdl.generate_learning_task(c) for c in contradictions]
    should_cycle = cdl.should_trigger_new_cycle(contradictions)

    if args.json:
        print(json.dumps({
            "contradictions": contradictions,
            "learning_tasks": learning_tasks,
            "should_trigger_new_cycle": should_cycle,
            "priority_contradiction": detector.get_priority_contradiction(contradictions)
        }, indent=2, ensure_ascii=False))
    else:
        print(f"Contradictions found: {len(contradictions)}")
        for c in contradictions:
            print(f"  [{c['type']}] severity={c['severity']:.2f} levels={c['levels_involved']}")
            print(f"    {c['description'][:80]}...")
            print(f"    → {c['resolution_hint'][:80]}...")
        print(f"\nTrigger new cycle: {should_cycle}")
        if learning_tasks:
            print(f"Learning tasks: {len(learning_tasks)}")
            for t in learning_tasks:
                print(f"  [{t['action']}] target={t['target_levels']} → {t['strategy'][:60]}...")


if __name__ == "__main__":
    main()
