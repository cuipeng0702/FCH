# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
Export Concept Lattice to graphify format.

Usage:
    python export_to_graphify.py [--input-dir DIR] [--output-dir DIR]
    
Example:
    python export_to_graphify.py --input-dir ~/.openclaw/workspace/knowledge-lattice/ --output-dir ./graphify-out
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.lattice_manager import LatticeManager


class LatticeToGraphifyExporter:
    """
    Converts Concept Lattice (JSON) to graphify-compatible graph.json format.
    
    Mapping:
    - Concept Node → graphify Node (with metadata)
    - Dependency Chain → graphify Edge (relation: "depends_on")
    - Version Stack → Node attributes (D1-D4 confidence scores)
    - Contradictions → Edge (relation: "contradicts", confidence: AMBIGUOUS)
    - Open Problems → Node (type: "open_problem", connected to concept)
    """
    
    def __init__(self, lattice_path: str = None):
        self.lattice = LatticeManager(lattice_path)
        self.nodes = []
        self.edges = []
        self.hyperedges = []
    
    def export(self, output_dir: str = "./graphify-out") -> Dict:
        """
        Export entire concept lattice to graphify format.
        
        Returns:
            Export statistics and file paths
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Load all concepts
        all_concepts = self.lattice.list_all()
        
        if not all_concepts:
            return {
                "status": "warning",
                "message": "No concepts found in lattice",
                "nodes": 0,
                "edges": 0
            }
        
        # Process each concept
        for concept_summary in all_concepts:
            concept_id = concept_summary["id"]
            concept = self.lattice.read(concept_id)
            
            if concept:
                self._process_concept(concept)
        
        # Build graphify graph.json
        graph_data = self._build_graphify_graph()
        
        # Save
        graph_path = os.path.join(output_dir, "graph.json")
        with open(graph_path, 'w') as f:
            json.dump(graph_data, f, indent=2)
        
        # Generate GRAPH_REPORT.md
        report_path = os.path.join(output_dir, "GRAPH_REPORT.md")
        report = self._generate_report(all_concepts)
        with open(report_path, 'w') as f:
            f.write(report)
        
        return {
            "status": "success",
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "hyperedges": len(self.hyperedges),
            "concepts": len(all_concepts),
            "graph_path": graph_path,
            "report_path": report_path
        }
    
    def _process_concept(self, concept: Dict) -> None:
        """Process a single concept into graphify nodes and edges."""
        concept_id = concept.get("core_id", "unknown")
        confidence = concept.get("confidence", 0)
        
        # Determine node size based on confidence (10-50 range)
        node_size = 10 + int(confidence * 40)
        
        # Determine color based on state
        if concept.get("cascade_flag", False):
            node_color = "#ff6b6b"  # Red: cascade pending
        elif confidence >= 0.8:
            node_color = "#51cf66"  # Green: high confidence
        elif confidence >= 0.5:
            node_color = "#ffd43b"  # Yellow: medium confidence
        else:
            node_color = "#74c0fc"  # Blue: low confidence
        
        # Build tooltip with version stack
        tooltip = self._build_tooltip(concept)
        
        # Create main concept node
        concept_node = {
            "id": f"concept_{concept_id}",
            "label": concept_id.replace("_", " ").title(),
            "file_type": "concept",
            "source_file": f"concepts/{concept_id}.json",
            "source_location": None,
            "source_url": None,
            "captured_at": concept.get("updated_at", ""),
            "author": None,
            "contributor": None,
            # Visual attributes
            "size": node_size,
            "color": node_color,
            "tooltip": tooltip,
            # Custom attributes for concept lattice
            "confidence": confidence,
            "version_count": len(concept.get("version_stack", [])),
            "gap_count": len(concept.get("open_problems", [])),
            "has_contradictions": len(concept.get("contradictions", [])) > 0,
            "cascade_pending": concept.get("cascade_flag", False)
        }
        self.nodes.append(concept_node)
        
        # Process version stack (D1-D4)
        for version in concept.get("version_stack", []):
            level = version.get("level", "")
            if level:
                # Add version as attribute to main node (not separate node)
                concept_node[f"{level}_confidence"] = version.get("confidence", 0)
                concept_node[f"{level}_preview"] = version.get("content", "")[:100]
        
        # Process dependencies (depends_on edges)
        for dep_id in concept.get("dependencies", []):
            edge = {
                "source": f"concept_{concept_id}",
                "target": f"concept_{dep_id}",
                "relation": "depends_on",
                "confidence": "EXTRACTED",
                "confidence_score": 1.0,
                "source_file": f"concepts/{concept_id}.json",
                "source_location": "dependencies",
                "weight": 1.0
            }
            self.edges.append(edge)
        
        # Process contradictions
        for contradiction in concept.get("contradictions", []):
            # Create contradiction node
            contra_id = f"contradiction_{concept_id}_{len(self.nodes)}"
            severity = contradiction.get("severity", 5)
            contra_node = {
                "id": contra_id,
                "label": f"⚠️ {contradiction.get('description', '')[:50]}",
                "file_type": "contradiction",
                "source_file": f"concepts/{concept_id}.json",
                "source_location": "contradictions",
                "captured_at": contradiction.get("timestamp", ""),
                "author": None,
                "contributor": None,
                # Visual: red diamond shape for contradictions
                "size": 15 + severity,
                "color": "#ff8787",
                "shape": "diamond",
                "tooltip": f"Contradiction (severity: {severity}/10): {contradiction.get('description', '')}",
                "severity": severity
            }
            self.nodes.append(contra_node)
            
            # Edge from concept to contradiction
            edge = {
                "source": f"concept_{concept_id}",
                "target": contra_id,
                "relation": "has_contradiction",
                "confidence": "EXTRACTED",
                "confidence_score": 1.0,
                "source_file": f"concepts/{concept_id}.json",
                "source_location": "contradictions",
                "weight": contradiction.get("severity", 1) / 10.0
            }
            self.edges.append(edge)
        
        # Process open problems (gaps)
        for gap in concept.get("open_problems", []):
            if not isinstance(gap, dict):
                continue  # Skip malformed entries
            gap_id = f"gap_{concept_id}_{len(self.nodes)}"
            severity = gap.get("severity", 5)
            gap_type = gap.get("type", "unknown")
            gap_node = {
                "id": gap_id,
                "label": f"🕳️ {gap.get('description', '')[:50]}",
                "file_type": "gap",
                "source_file": f"concepts/{concept_id}.json",
                "source_location": "open_problems",
                "captured_at": gap.get("timestamp", ""),
                "author": None,
                "contributor": None,
                # Visual: orange triangle for gaps
                "size": 12 + severity,
                "color": "#ffa94d",
                "shape": "triangle",
                "tooltip": f"Gap [{gap_type}] (severity: {severity}/10): {gap.get('description', '')}",
                "severity": severity,
                "gap_type": gap_type
            }
            self.nodes.append(gap_node)
            
            # Edge from concept to gap
            edge = {
                "source": f"concept_{concept_id}",
                "target": gap_id,
                "relation": "has_gap",
                "confidence": "EXTRACTED",
                "confidence_score": 1.0,
                "source_file": f"concepts/{concept_id}.json",
                "source_location": "open_problems",
                "weight": gap.get("severity", 1) / 10.0
            }
            self.edges.append(edge)
        
        # Process audit history
        for audit in concept.get("audit_history", [])[-3:]:  # Last 3 audits
            audit_id = f"audit_{concept_id}_{len(self.nodes)}"
            score = audit.get("score", 0)
            audit_node = {
                "id": audit_id,
                "label": f"📊 {score:.2f}",
                "file_type": "audit",
                "source_file": f"concepts/{concept_id}.json",
                "source_location": "audit_history",
                "captured_at": audit.get("timestamp", ""),
                "author": None,
                "contributor": None,
                # Visual: small gray circle for audits
                "size": 8,
                "color": "#adb5bd",
                "shape": "circle",
                "tooltip": f"Audit score: {score:.2f} | Gaps: {audit.get('total_gaps', 0)} | Contradictions: {audit.get('total_contradictions', 0)}",
                "score": score
            }
            self.nodes.append(audit_node)
            
            edge = {
                "source": f"concept_{concept_id}",
                "target": audit_id,
                "relation": "audited",
                "confidence": "EXTRACTED",
                "confidence_score": 1.0,
                "source_file": f"concepts/{concept_id}.json",
                "source_location": "audit_history",
                "weight": audit.get("score", 0)
            }
            self.edges.append(edge)
    
    def _build_tooltip(self, concept: Dict) -> str:
        """Build rich tooltip showing version stack and key stats."""
        lines = []
        lines.append(f"Concept: {concept.get('core_id', 'unknown')}")
        lines.append(f"Confidence: {concept.get('confidence', 0):.2f}")
        lines.append(f"Gaps: {len(concept.get('open_problems', []))}")
        lines.append(f"Contradictions: {len(concept.get('contradictions', []))}")
        
        # Version stack summary
        versions = concept.get("version_stack", [])
        if versions:
            lines.append("\nVersions:")
            for v in versions:
                level = v.get("level", "?")
                conf = v.get("confidence", 0)
                preview = v.get("content", "")[:60]
                lines.append(f"  {level}: {preview}... (conf: {conf:.2f})")
        
        # Dependencies
        deps = concept.get("dependencies", [])
        if deps:
            lines.append(f"\nDepends on: {', '.join(deps)}")
        
        # Cascade status
        if concept.get("cascade_flag", False):
            lines.append("\n⚠️ CASCADE PENDING: needs re-audit")
        
        return "\n".join(lines)
    
    def _build_graphify_graph(self) -> Dict:
        """Build graphify-compatible graph.json structure."""
        return {
            "directed": True,
            "multigraph": False,
            "graph": {
                "name": "Feynman Concept Lattice",
                "created_at": datetime.now().isoformat(),
                "node_count": len(self.nodes),
                "edge_count": len(self.edges)
            },
            "nodes": self.nodes,
            "links": self.edges  # graphify uses "links" not "edges"
        }
    
    def _generate_report(self, concepts: List[Dict]) -> str:
        """Generate GRAPH_REPORT.md for graphify."""
        report = f"""# Feynman Concept Lattice Report

Generated: {datetime.now().isoformat()}

## Overview

- **Total Concepts**: {len(concepts)}
- **Total Nodes**: {len(self.nodes)} (concepts + gaps + contradictions + audits)
- **Total Edges**: {len(self.edges)}
- **Total Hyperedges**: {len(self.hyperedges)}

## Concept Confidence Distribution

"""
        
        # Confidence distribution
        confidence_buckets = {"0.0-0.2": 0, "0.2-0.4": 0, "0.4-0.6": 0, "0.6-0.8": 0, "0.8-1.0": 0}
        for c in concepts:
            conf = c.get("confidence", 0)
            if conf < 0.2:
                confidence_buckets["0.0-0.2"] += 1
            elif conf < 0.4:
                confidence_buckets["0.2-0.4"] += 1
            elif conf < 0.6:
                confidence_buckets["0.4-0.6"] += 1
            elif conf < 0.8:
                confidence_buckets["0.6-0.8"] += 1
            else:
                confidence_buckets["0.8-1.0"] += 1
        
        for bucket, count in confidence_buckets.items():
            report += f"- {bucket}: {count} concepts\n"
        
        # God Nodes (highest confidence)
        report += "\n## God Nodes (Highest Confidence)\n\n"
        sorted_concepts = sorted(concepts, key=lambda x: x.get("confidence", 0), reverse=True)[:5]
        for c in sorted_concepts:
            report += f"- **{c['id']}**: confidence={c['confidence']:.2f}, gaps={c['gap_count']}, deps={c['dependency_count']}\n"
        
        # Surprising Connections (cross-community)
        report += "\n## Surprising Connections\n\n"
        report += "Concepts with high confidence but many unresolved gaps (potential knowledge traps):\n\n"
        
        # Find concepts with high confidence but gaps
        traps = [c for c in concepts if c.get("confidence", 0) > 0.5 and c.get("gap_count", 0) > 0]
        for c in traps[:5]:
            report += f"- **{c['id']}**: confidence={c['confidence']:.2f} but {c['gap_count']} gaps remain\n"
        
        # Suggested Questions
        report += "\n## Suggested Questions\n\n"
        report += "1. Which concepts have the most dependencies and should be prioritized for deepening?\n"
        report += "2. Are there any circular dependency chains that need resolution?\n"
        report += "3. Which gaps have the highest severity and should be addressed first?\n"
        report += "4. How does confidence distribute across the knowledge graph?\n"
        
        return report


def main():
    parser = argparse.ArgumentParser(description="Export Concept Lattice to graphify format")
    parser.add_argument("--input-dir", default="~/.openclaw/workspace/knowledge-lattice/",
                       help="Concept lattice directory")
    parser.add_argument("--output-dir", default="./graphify-out",
                       help="Output directory for graphify files")
    
    args = parser.parse_args()
    
    exporter = LatticeToGraphifyExporter(os.path.expanduser(args.input_dir))
    result = exporter.export(os.path.expanduser(args.output_dir))
    
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
