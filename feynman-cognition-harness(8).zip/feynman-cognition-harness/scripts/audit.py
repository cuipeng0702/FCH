# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
# DEPRECATED: v3.5 起由 harness/agents/audit_task_template.md 替代。保留作为 legacy 库。
"""
Audit Engine — Consistency Triangulation for concept verification.

Usage:
    python audit.py <concept_id> [--lattice-path PATH]
    
Example:
    python audit.py "transformer_attention" --lattice-path ~/.openclaw/workspace/knowledge-lattice/
"""

import argparse
import json
import sys
import os
import re
from typing import Dict, List, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class AuditEngine:
    """
    Performs consistency triangulation across D1-D4 explanations.
    
    Core algorithm: Check three dimensions for consistency:
        Formal Definition (D3/D4)
              △
             / \
            /   \
           /  ?  \
          /_______\
   Intuitive Analogy (D1) ←——→ Operational Example (D2)
    """
    
    CHECKS = {
        "term_penetration": {
            "name": "术语穿透 (Term Penetration)",
            "description": "D3中的每个术语，能否在D1中找到非术语对应？",
            "weight": 3.0
        },
        "boundary_consistency": {
            "name": "边界一致 (Boundary Consistency)",
            "description": "D1说'总是这样'，D4说'仅在X条件下成立'？",
            "weight": 2.5
        },
        "dependency_closure": {
            "name": "依赖闭环 (Dependency Closure)",
            "description": "解释A依赖B，B的解释又回指A？",
            "weight": 2.0
        },
        "counterexample_compatibility": {
            "name": "反例兼容 (Counterexample Compatibility)",
            "description": "已知反例能否被当前版本容纳？",
            "weight": 2.5
        },
        "oscillation_stability": {
            "name": "振荡稳定 (Oscillation Stability)",
            "description": "D1类比结构在振荡中是否收敛稳定？",
            "weight": 2.0
        },
        "compression_fidelity": {
            "name": "压缩保真 (Compression Fidelity)",
            "description": "D4边界条件是否被正确压缩到D1的类比边界中？",
            "weight": 2.5
        }
    }
    
    def __init__(self, lattice_path: str = None):
        """
        Initialize AuditEngine.
        
        Args:
            lattice_path: Path to Concept Lattice storage
        """
        self.lattice_path = lattice_path or os.path.expanduser(
            "~/.openclaw/workspace/knowledge-lattice/"
        )
        self.history = []
    
    def audit(self, concept_id: str, versions: Dict = None) -> Dict:
        """
        Execute full audit on a concept.
        
        Args:
            concept_id: Unique concept identifier
            versions: Dict with D1-D4 explanations. If None, loads from lattice.
            
        Returns:
            Audit report with gaps, contradictions, and priority queue
        """
        # Load versions if not provided
        if versions is None:
            versions = self._load_concept(concept_id)
        
        if not versions:
            return {
                "concept_id": concept_id,
                "error": "Concept not found in lattice",
                "status": "failed"
            }
        
        # Execute checks
        results = {}
        gaps = []
        contradictions = []
        
        for check_id, check_config in self.CHECKS.items():
            result = self._execute_check(check_id, versions)
            results[check_id] = result
            
            if not result["passed"]:
                gaps.extend(result.get("gaps", []))
                contradictions.extend(result.get("contradictions", []))
        
        # Calculate overall score
        total_weight = sum(c["weight"] for c in self.CHECKS.values())
        passed_weight = sum(
            self.CHECKS[cid]["weight"] 
            for cid, res in results.items() 
            if res["passed"]
        )
        score = passed_weight / total_weight if total_weight > 0 else 0
        
        # Priority queue: sort gaps by severity
        priority_queue = sorted(gaps, key=lambda x: x.get("severity", 0), reverse=True)
        
        # Identify solid nodes (aspects that passed all checks)
        solid_nodes = [
            check_id for check_id, res in results.items() if res["passed"]
        ]
        
        audit_report = {
            "concept_id": concept_id,
            "timestamp": self._timestamp(),
            "score": round(score, 3),
            "status": "passed" if score >= 0.8 else "needs_work" if score >= 0.5 else "failed",
            "solid_nodes": solid_nodes,
            "gaps": gaps,
            "contradictions": contradictions,
            "priority_queue": priority_queue,
            "check_details": results,
            "total_gaps": len(gaps),
            "total_contradictions": len(contradictions)
        }
        
        self.history.append(audit_report)
        return audit_report
    
    def _execute_check(self, check_id: str, versions: Dict) -> Dict:
        """Execute a single audit check."""
        if check_id == "term_penetration":
            return self._check_term_penetration(versions)
        elif check_id == "boundary_consistency":
            return self._check_boundary_consistency(versions)
        elif check_id == "dependency_closure":
            return self._check_dependency_closure(versions)
        elif check_id == "counterexample_compatibility":
            return self._check_counterexample_compatibility(versions)
        elif check_id == "oscillation_stability":
            return self._check_oscillation_stability(versions)
        elif check_id == "compression_fidelity":
            return self._check_compression_fidelity(versions)
        else:
            return {"passed": False, "error": f"Unknown check: {check_id}"}
    
    def _check_term_penetration(self, versions: Dict) -> Dict:
        """
        Check if terms in D2/D3/D4 have non-technical equivalents in D1.
        
        Scans ALL deeper levels (D2, D3, D4) against D1 — not just D3/D4.
        A term found in ANY deeper level but missing in D1 indicates a basic gap.
        """
        # Handle both dict and list formats
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        d1_text = versions.get("D1", {}).get("explanation", "")
        
        # Scan D2, D3, D4 — all deeper levels may introduce terms needing D1 anchoring
        deeper_levels = ["D2", "D3", "D4"]
        all_terms = set()
        level_sources = {}  # term -> which level(s) it came from
        
        def extract_terms(text):
            terms = set()
            terms.update(re.findall(r'"([^"]+)"', text))
            candidates = re.findall(r'\b[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){1,2}\b', text)
            for candidate in candidates:
                if candidate.lower() in ['open problems', 'standard understanding', 'recent advances', 
                                        'known counterexamples', 'boundaries and', 'controversies and',
                                        'current controversies', 'formal definition', 'mathematical formalization']:
                    continue
                if 'British Columbia' in candidate or 'University of' in candidate:
                    continue
                terms.add(candidate)
            return terms
        
        for level in deeper_levels:
            text = versions.get(level, {}).get("explanation", "")
            if text:
                terms = extract_terms(text)
                for term in terms:
                    all_terms.add(term)
                    level_sources.setdefault(term, []).append(level)
        
        # Check if terms appear in D1
        untranslated = []
        for term in all_terms:
            core_term = term.replace("The ", "").replace("A ", "").lower()
            if core_term not in d1_text.lower() and term.lower() not in d1_text.lower():
                untranslated.append({
                    "term": term,
                    "sources": level_sources.get(term, [])
                })
        
        if untranslated:
            terms_list = [t["term"] for t in untranslated]
            source_levels = sorted(set(
                lvl for t in untranslated for lvl in t["sources"]
            ))
            return {
                "passed": False,
                "gaps": [
                    {
                        "type": "term_penetration",
                        "severity": 7,
                        "description": f"Terms without D1 equivalent: {terms_list}",
                        "terms": terms_list,
                        "affected_versions": source_levels,
                        "recommended_strategy": "dimensional_reduction",
                        "message": "术语未真正理解，降级为'待定义'"
                    }
                ],
                "contradictions": []
            }
        
        return {"passed": True, "gaps": [], "contradictions": []}
    
    def _check_boundary_consistency(self, versions: Dict) -> Dict:
        """
        Check for oversimplification (absolute claims vs boundary conditions) across ALL level pairs.
        
        Previously only checked D1 vs D4. Now scans every pair:
        D1↔D2, D1↔D3, D1↔D4, D2↔D3, D2↔D4, D3↔D4.
        
        Any level claiming universality while a deeper level introduces restrictions
        is an oversimplification trap.
        """
        # Handle both dict and list formats
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        absolute_terms = ["always", "never", "all", "every", "only", "must"]
        qualifying_terms = ["usually", "typically", "under", "condition", 
                           "except", "unless", "in most cases", "generally", "when", "if"]
        
        level_pairs = [("D1", "D2"), ("D1", "D3"), ("D1", "D4"),
                       ("D2", "D3"), ("D2", "D4"), ("D3", "D4")]
        
        all_gaps = []
        all_contradictions = []
        
        for shallow, deep in level_pairs:
            shallow_text = versions.get(shallow, {}).get("explanation", "").lower()
            deep_text = versions.get(deep, {}).get("explanation", "").lower()
            
            if not shallow_text or not deep_text:
                continue
            
            # Absolute terms in the shallower level
            shallow_absolutes = []
            for term in absolute_terms:
                if re.search(r'\b' + term + r'\b', shallow_text):
                    shallow_absolutes.append(term)
            
            # Qualifying terms in the deeper level
            deep_qualifiers = [t for t in qualifying_terms if t in deep_text]
            
            if shallow_absolutes and deep_qualifiers:
                all_gaps.append({
                    "type": "oversimplification",
                    "severity": 6,
                    "description": f"{shallow} uses absolutes ({shallow_absolutes}) while {deep} qualifies ({deep_qualifiers})",
                    f"{shallow}_absolutes": shallow_absolutes,
                    f"{deep}_qualifiers": deep_qualifiers,
                    "affected_versions": [shallow, deep],
                    "recommended_strategy": "boundary_annotation",
                    "message": "⚠️ 过度简化陷阱"
                })
                all_contradictions.append({
                    "type": "boundary_mismatch",
                    "description": f"{shallow} claims universality but {deep} limits applicability"
                })
        
        if all_gaps:
            return {
                "passed": False,
                "gaps": all_gaps,
                "contradictions": all_contradictions
            }
        
        return {"passed": True, "gaps": [], "contradictions": []}
    
    def _check_dependency_closure(self, versions: Dict) -> Dict:
        """
        Check for circular definitions in dependency chains.
        """
        # Handle both dict and list formats
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        # Extract dependencies from each version
        deps = {}
        for level in ["D1", "D2", "D3", "D4"]:
            version = versions.get(level, {})
            dependencies = version.get("dependencies", [])
            if dependencies:
                deps[level] = dependencies
        
        # Check for circularity (simplified)
        # In production, this would traverse the full dependency graph
        circular = []
        concept_name = versions.get("D1", {}).get("concept", "unknown")
        
        for level, dependencies in deps.items():
            for dep in dependencies:
                if concept_name.lower() in dep.lower():
                    circular.append({
                        "level": level,
                        "dependency": dep,
                        "type": "self_reference"
                    })
        
        if circular:
            return {
                "passed": False,
                "gaps": [
                    {
                        "type": "circular_definition",
                        "severity": 8,
                        "description": f"Circular dependencies found: {circular}",
                        "circular_refs": circular,
                        "affected_versions": [c["level"] for c in circular],
                        "recommended_strategy": "anchor_breakthrough",
                        "message": "🌀 循环定义，强制打破"
                    }
                ],
                "contradictions": []
            }
        
        return {"passed": True, "gaps": [], "contradictions": []}
    
    def _check_counterexample_compatibility(self, versions: Dict) -> Dict:
        """
        Check if counterexamples/exceptions from deeper levels are accommodated by shallower levels.
        
        Scans ALL deeper levels (D2, D3, D4) for counterexamples, exceptions, edge cases,
        and verifies that ALL shallower levels acknowledge them — not just D1/D2 vs D4.
        """
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        # Scan all levels for counterexample signals
        counterexample_markers = ["counterexample", "exception", "edge case", "not applicable",
                                   "fails when", "breaks if", "limitation", "boundary condition",
                                   "does not work", "invalid when"]
        
        level_pairs = [("D1", "D2"), ("D1", "D3"), ("D1", "D4"),
                       ("D2", "D3"), ("D2", "D4"),
                       ("D3", "D4")]
        
        # Severity mapping: surface↔deep = high (9), deep↔deep = medium (6)
        # D3↔D4 tension is productive research frontier, not necessarily crisis
        severity_map = {
            ("D1", "D2"): 8, ("D1", "D3"): 9, ("D1", "D4"): 9,
            ("D2", "D3"): 7, ("D2", "D4"): 8,
            ("D3", "D4"): 6
        }
        
        all_gaps = []
        all_contradictions = []
        
        for shallow, deep in level_pairs:
            shallow_text = versions.get(shallow, {}).get("explanation", "").lower()
            deep_text = versions.get(deep, {}).get("explanation", "").lower()
            
            if not shallow_text or not deep_text:
                continue
            
            # Extract counterexample signals from deep level
            deep_signals = []
            for marker in counterexample_markers:
                if marker in deep_text:
                    deep_signals.append(marker)
            
            # Check if shallow level acknowledges these signals
            acknowledged = [m for m in deep_signals if m in shallow_text]
            unacknowledged = [m for m in deep_signals if m not in shallow_text]
            
            if unacknowledged:
                severity = severity_map.get((shallow, deep), 7)
                all_gaps.append({
                    "type": "theoretical_crisis",
                    "severity": severity,
                    "description": f"{deep} acknowledges exceptions ({unacknowledged}) but {shallow} presents as universal",
                    "unacknowledged_signals": unacknowledged,
                    "acknowledged_signals": acknowledged,
                    "affected_versions": [shallow, deep],
                    "recommended_strategy": "paradigm_marker",
                    "message": "💥 理论危机" if severity >= 8 else "⚠️ 边界张力"
                })
                all_contradictions.append({
                    "type": "counterexample_mismatch",
                    "description": f"{deep} reveals boundaries but {shallow} lacks corresponding qualifiers"
                })
        
        if all_gaps:
            return {
                "passed": False,
                "gaps": all_gaps,
                "contradictions": all_contradictions
            }
        
        return {"passed": True, "gaps": [], "contradictions": []}
    
    def _check_oscillation_stability(self, versions: Dict) -> Dict:
        """
        Check if D1 analogy structure is stable across oscillations.
        
        A stable D1 structure should:
        - Have MASTER ANALOGY present and consistent
        - PRINCIPLE MAP should reference actual D2-D4 principles
        - BOUNDARY CONDITIONS should capture real failure modes from D4
        """
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        d1_text = versions.get("D1", {}).get("explanation", "")
        
        # Check structural stability
        has_master_analogy = "MASTER ANALOGY" in d1_text or "master analogy" in d1_text.lower()
        has_principle_map = "PRINCIPLE MAP" in d1_text or "principle map" in d1_text.lower()
        has_boundary_conditions = "BOUNDARY CONDITIONS" in d1_text or "boundary conditions" in d1_text.lower()
        
        # Count principle mappings
        principle_count = len(re.findall(r'^[a-z]\.|^\d+\.', d1_text, re.MULTILINE))
        
        # Oscillation stability score
        stability_score = 0
        if has_master_analogy:
            stability_score += 0.3
        if has_principle_map:
            stability_score += 0.2
        if has_boundary_conditions:
            stability_score += 0.2
        if principle_count >= 3:
            stability_score += 0.2
        if principle_count >= 5:
            stability_score += 0.1
        
        if stability_score >= 0.7:
            return {"passed": True, "gaps": [], "contradictions": []}
        
        gaps = []
        if not has_master_analogy:
            gaps.append({
                "type": "oscillation_stability",
                "severity": 7,
                "description": "D1缺少MASTER ANALOGY——振荡收敛需要稳定的认知锚点",
                "affected_versions": ["D1"],
                "recommended_strategy": "metaphor_reframe"
            })
        if not has_principle_map:
            gaps.append({
                "type": "oscillation_stability",
                "severity": 6,
                "description": "D1缺少PRINCIPLE MAP——无法验证类比是否承载深层结构",
                "affected_versions": ["D1"],
                "recommended_strategy": "metaphor_reframe"
            })
        if not has_boundary_conditions:
            gaps.append({
                "type": "oscillation_stability",
                "severity": 6,
                "description": "D1缺少BOUNDARY CONDITIONS——类比可能过度泛化",
                "affected_versions": ["D1", "D4"],
                "recommended_strategy": "boundary_annotation"
            })
        
        return {
            "passed": False,
            "gaps": gaps,
            "contradictions": [],
            "stability_score": round(stability_score, 3)
        }
    
    def _check_compression_fidelity(self, versions: Dict) -> Dict:
        """
        Check if deeper-level boundary conditions are correctly compressed into shallower levels.
        
        Scans ALL level pairs: D2→D1, D3→D1, D3→D2, D4→D1, D4→D2, D4→D3.
        
        Key question: Does the shallower level's explanation actually capture
        the failure modes, constraints, and boundaries described in the deeper level?
        """
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        failure_indicators = [
            "fails", "breaks", "invalid", "not applicable", "limitation",
            "constraint", "boundary", "exception", "counterexample",
            "when", "if", "unless", "except", "only when", "edge case",
            "not work", "does not apply", "restricted", "bounded"
        ]
        
        level_pairs = [("D1", "D2"), ("D1", "D3"), ("D1", "D4"),
                       ("D2", "D3"), ("D2", "D4"),
                       ("D3", "D4")]
        
        # Severity mapping: D1 must compress ALL deep boundaries (severity 7-8)
        # D3↔D4 tension is productive research frontier, lower severity (5)
        severity_map = {
            ("D1", "D2"): 6, ("D1", "D3"): 7, ("D1", "D4"): 8,
            ("D2", "D3"): 6, ("D2", "D4"): 7,
            ("D3", "D4"): 5
        }
        
        all_gaps = []
        
        for shallow, deep in level_pairs:
            shallow_text = versions.get(shallow, {}).get("explanation", "").lower()
            deep_text = versions.get(deep, {}).get("explanation", "").lower()
            
            if not shallow_text or not deep_text:
                continue
            
            # Extract failure modes from deep level
            deep_failures = []
            for indicator in failure_indicators:
                if indicator in deep_text:
                    deep_failures.append(indicator)
            
            # Check if shallow level captures these
            captured = [f for f in deep_failures if f in shallow_text]
            missing = [f for f in deep_failures if f not in shallow_text]
            
            total = len(deep_failures)
            if total == 0:
                fidelity_score = 0.5  # No clear boundaries in deep level, ambiguous
            else:
                fidelity_score = len(captured) / total
            
            if fidelity_score < 0.6:
                severity = severity_map.get((shallow, deep), 7)
                all_gaps.append({
                    "type": "compression_fidelity",
                    "severity": severity,
                    "description": f"{shallow}未充分压缩{deep}的边界信息（捕获率: {fidelity_score:.1%}）",
                    "captured": captured,
                    "missing": missing,
                    "affected_versions": [shallow, deep],
                    "recommended_strategy": "boundary_annotation"
                })
        
        if all_gaps:
            return {
                "passed": False,
                "gaps": all_gaps,
                "contradictions": [],
                "fidelity_scores": {g["affected_versions"][0] + "<-" + g["affected_versions"][1]: 
                                    len(g["captured"]) / max(len(g["captured"]) + len(g["missing"]), 1) 
                                    for g in all_gaps}
            }
        
        return {"passed": True, "gaps": [], "contradictions": []}

    # ==================== v3.0: Cross-Temporal Audit Extensions ====================

    def audit_for_verification(self, concept_id: str, new_versions: Dict, old_versions: Dict = None) -> Dict:
        """
        Audit interface for VerificationLayer (v3.0 cross-temporal audit).
        
        Combines standard audit with mapping consistency and pseudo-mapping checks.
        
        Args:
            concept_id: Concept being verified
            new_versions: Current D1-D4 versions
            old_versions: Previous versions for comparison (optional)
            
        Returns:
            Audit report compatible with VerificationLayer expectations
        """
        # Standard audit on new versions
        standard_report = self.audit(concept_id, new_versions)
        
        # v3.0 checks
        mapping_check = self._check_mapping_consistency(new_versions)
        pseudo_check = self._check_pseudo_mapping(new_versions)
        
        # Merge into report
        standard_report["mapping_consistency"] = mapping_check
        standard_report["pseudo_mapping"] = pseudo_check
        standard_report["cross_temporal_ready"] = True
        
        # If any v3.0 check fails, adjust status
        if not mapping_check["passed"] or pseudo_check.get("is_pseudo", False):
            standard_report["status"] = "needs_work"
            standard_report["gaps"].extend(mapping_check.get("gaps", []))
        
        return standard_report

    def _check_mapping_consistency(self, versions: Dict) -> Dict:
        """
        Check structural mapping consistency between D1 PRINCIPLE MAP and D3 formalization.
        
        Ensures every principle in D3 has a corresponding entry in D1 PRINCIPLE MAP,
        and the mapping is not just empty/generic references.
        """
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        d1_text = versions.get("D1", {}).get("explanation", "")
        d3_text = versions.get("D3", {}).get("explanation", "")
        
        if not d1_text or not d3_text:
            return {"passed": False, "gaps": [{"type": "mapping_consistency", "severity": 5, "description": "D1 or D3 missing"}]}
        
        # Extract PRINCIPLE MAP entries from D1
        principle_map = []
        in_map = False
        for line in d1_text.split('\n'):
            if "PRINCIPLE MAP" in line.upper():
                in_map = True
                continue
            if in_map and line.strip() and not line.startswith('#'):
                principle_map.append(line.strip())
            if in_map and line.strip().startswith('#') and "PRINCIPLE MAP" not in line.upper():
                break
        
        # Extract formal principles from D3 (numbered/bulleted items, equations)
        d3_principles = re.findall(r'^[\s]*(?:\d+\.|[a-z]\.)\s*(.+)', d3_text, re.MULTILINE)
        if not d3_principles:
            # Fallback: extract sentences with formal terms
            d3_principles = [s.strip() for s in d3_text.split('.') if any(t in s for t in ['=', '→', '∀', '∃', '⇒', 'function', 'theorem', 'lemma'])]
        
        # Check coverage
        mapped_count = 0
        unmapped = []
        for principle in d3_principles:
            principle_core = principle.lower()[:30]
            found_in_map = any(principle_core in m.lower() for m in principle_map)
            if found_in_map:
                mapped_count += 1
            else:
                unmapped.append(principle[:60])
        
        coverage = mapped_count / max(len(d3_principles), 1)
        
        if coverage >= 0.8:
            return {"passed": True, "coverage": round(coverage, 2), "gaps": []}
        
        return {
            "passed": False,
            "coverage": round(coverage, 2),
            "gaps": [{
                "type": "mapping_consistency",
                "severity": 6,
                "description": f"D1 PRINCIPLE MAP覆盖率仅{coverage:.0%}，{len(unmapped)}个D3原理未映射",
                "unmapped_principles": unmapped[:5],
                "affected_versions": ["D1", "D3"],
                "recommended_strategy": "principle_mapping"
            }]
        }

    def _check_pseudo_mapping(self, versions: Dict) -> Dict:
        """
        Detect pseudo-mapping: D1 PRINCIPLE MAP that appears to map D3 principles
        but actually contains only empty/generic descriptions.
        
        Uses D1Validator if available, otherwise falls back to heuristics.
        """
        if isinstance(versions, list):
            versions = {v.get("level", f"D{i+1}"): v for i, v in enumerate(versions)}
        
        d1_text = versions.get("D1", {}).get("explanation", "")
        d3_text = versions.get("D3", {}).get("explanation", "")
        
        if not d1_text or not d3_text:
            return {"is_pseudo": False, "reason": "Missing D1 or D3"}
        
        # Try to use D1Validator for structural check
        try:
            from scripts.d1_validator import D1Validator
            validator = D1Validator()
            validation = validator.validate(d1_text)
            
            # Check if PRINCIPLE MAP entries are vague
            vague_indicators = ["对应", "相关", "类似", "映射到", "相当于", "is related to", "corresponds to", "maps to"]
            principle_map_section = re.search(r'PRINCIPLE MAP.*?(?=\n\n|\Z)', d1_text, re.DOTALL | re.IGNORECASE)
            
            if principle_map_section:
                map_text = principle_map_section.group(0)
                vague_count = sum(1 for indicator in vague_indicators if indicator in map_text.lower())
                total_entries = len([l for l in map_text.split('\n') if l.strip().startswith(('-', '*', '•', 'a.', 'b.', '1.', '2.'))])
                
                if total_entries > 0 and vague_count / total_entries > 0.5:
                    return {
                        "is_pseudo": True,
                        "vague_ratio": round(vague_count / total_entries, 2),
                        "reason": "PRINCIPLE MAP contains mostly generic/vague mappings",
                        "recommendation": "Replace generic mappings with specific structural correspondences"
                    }
        except Exception:
            pass
        
        # Fallback heuristic: check if D1 has specific structural elements
        has_specific_mapping = bool(re.search(r'\b(because|since|as|results in|leads to|causes)\b', d1_text.lower()))
        
        if not has_specific_mapping:
            return {
                "is_pseudo": True,
                "reason": "D1 lacks causal/structural specificity in PRINCIPLE MAP",
                "recommendation": "Add specific causal chains and structural correspondences"
            }
        
        return {"is_pseudo": False, "reason": "Mapping appears structurally grounded"}

    # ==================== End v3.0 Extensions ====================

    def _load_concept(self, concept_id: str) -> Dict:
        """Load concept from lattice storage."""
        filepath = os.path.join(self.lattice_path, "concepts", f"{concept_id}.json")
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                data = json.load(f)
                return data.get("version_stack", {})
        return {}
    
    def _timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().isoformat()
    
    def get_gap_summary(self, audit_report: Dict) -> Dict:
        """Generate human-readable gap summary."""
        gaps = audit_report.get("gaps", [])
        
        by_type = {}
        for gap in gaps:
            gap_type = gap.get("type", "unknown")
            if gap_type not in by_type:
                by_type[gap_type] = []
            by_type[gap_type].append(gap)
        
        return {
            "total_gaps": len(gaps),
            "by_type": {k: len(v) for k, v in by_type.items()},
            "highest_severity": max((g.get("severity", 0) for g in gaps), default=0),
            "requires_action": len(gaps) > 0,
            "top_priority": gaps[0] if gaps else None
        }


def main():
    parser = argparse.ArgumentParser(description="Audit Engine — Consistency Triangulation")
    parser.add_argument("concept_id", help="Concept ID to audit")
    parser.add_argument("--lattice-path", help="Path to Concept Lattice")
    parser.add_argument("--output", "-o", help="Output JSON file")
    
    args = parser.parse_args()
    
    engine = AuditEngine(lattice_path=args.lattice_path)
    report = engine.audit(args.concept_id)
    
    # Add summary
    report["summary"] = engine.get_gap_summary(report)
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(report, f, indent=2)
        print(f"Audit report saved to {args.output}")
    else:
        print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

    def check_confirmation_bias_risk(self, technical_confidence: float, social_persuasiveness: float) -> dict:
        """
        HIVE finding: explanations create trust even for wrong predictions (60-67% rate)
        Detect when SocialListener produces high persuasiveness but TechnicalListener low confidence
        """
        risk_score = 0.0
        flagged = False
        
        if technical_confidence < 0.5 and social_persuasiveness > 0.7:
            risk_score = (social_persuasiveness - 0.7) + (0.5 - technical_confidence)
            flagged = True
        elif technical_confidence < 0.7 and social_persuasiveness > 0.85:
            risk_score = (social_persuasiveness - 0.85) * 0.5
            flagged = True
        
        mitigation = None
        if flagged:
            if technical_confidence < 0.3:
                mitigation = "BLOCK: technical confidence critically low, override with uncertainty framing"
            else:
                mitigation = "WARN: add explicit uncertainty hedges, reduce social weight by 20%"
        
        return {
            "flagged": flagged,
            "risk_score": round(min(risk_score, 1.0), 3),
            "mitigation": mitigation,
            "technical_confidence": technical_confidence,
            "social_persuasiveness": social_persuasiveness
        }

