#!/usr/bin/env python3
"""
GlobalIntegrationDaemon — Layer 6: Cross-concept coherence + inspiration trigger.

Unlike the per-concept learning loop (Layers 0–5), this daemon operates
on the ENTIRE lattice as a knowledge graph. It is the AI's "dreaming"
mechanism: not review, but global structure scan + cross-concept insight.

Responsibilities:
  1. Cross-concept contradiction detection — two individually-audited
     concepts that conflict when placed together.
  2. Bridge discovery — concept A's D4 boundary mentions concept B
     (or vice versa), but no explicit dependency exists.
  3. Concept cluster coherence — detect orphan clusters or
     over-centralized hub concepts.
  4. Inspiration event generation — package findings as TriggerEvent
     and push to TriggerDaemon queue.

Usage:
    gid = GlobalIntegrationDaemon(lattice_manager, trigger_daemon)
    gid.scan()  # returns list of findings
    gid.generate_events(findings)  # pushes to trigger queue
"""

import json
import re
from typing import Dict, List, Optional, Tuple


class GlobalIntegrationDaemon:
    """
    Layer 6: Global knowledge-graph integrator.
    """

    def __init__(
        self,
        lattice,
        trigger_daemon=None,
        min_content_length: int = 50,
        contradiction_keywords: List[str] = None,
        bridge_keywords: List[str] = None,
    ):
        self.lattice = lattice
        self.trigger_daemon = trigger_daemon
        self.min_content_length = min_content_length

        # Default keyword sets for cross-concept contradiction detection
        self.contradiction_keywords = contradiction_keywords or [
            "cannot", "impossible", "never", "always", "only", "must not",
            "violate", "break", "contradict", "incompatible", "mutually exclusive",
        ]

        # Default keywords for bridge discovery
        self.bridge_keywords = bridge_keywords or [
            "requires", "depends on", "builds upon", "derived from",
            "is a special case of", "generalizes", "extends", "is equivalent to",
            "similar to", "analogous to", "inspired by",
        ]

    # ==================== Public API ====================

    def scan(self) -> List[Dict]:
        """
        Full lattice scan. Returns list of findings.
        Each finding is a dict with 'type' and details.
        """
        concepts = self._load_all_concepts()
        if len(concepts) < 2:
            return [{"type": "insufficient_data", "message": f"Only {len(concepts)} concepts, need ≥2 for cross-concept analysis"}]

        findings = []

        # 1. Cross-concept contradictions
        findings.extend(self._detect_cross_concept_contradictions(concepts))

        # 2. Bridge discovery
        findings.extend(self._discover_bridges(concepts))

        # 3. Orphan detection
        findings.extend(self._detect_orphans(concepts))

        # 4. Hub overload detection
        findings.extend(self._detect_hub_overload(concepts))

        return findings

    def generate_events(self, findings: List[Dict]) -> List[Dict]:
        """
        Convert findings into TriggerEvent payloads and push to queue.
        Returns list of events (pushed or not, depending on trigger_daemon availability).
        """
        events = []
        for f in findings:
            event = self._finding_to_trigger_event(f)
            if event and self.trigger_daemon:
                try:
                    self.trigger_daemon.add_event(event)
                except Exception:
                    pass  # Push failed, but event still valid
            if event:
                events.append(event)

        return events

    # ==================== Internal: Load Concepts ====================

    def _load_all_concepts(self) -> List[Dict]:
        """Load all concepts from lattice with their latest D-level content."""
        concepts = []
        # Try to list via lattice manager
        try:
            index = self.lattice.list_all()
        except Exception:
            index = None

        if index:
            for entry in index:
                # list_all() may return a list of dicts or a list of cids
                if isinstance(entry, dict):
                    cid = entry.get("concept_id", entry.get("core_id"))
                else:
                    cid = entry
                if not cid:
                    continue
                c = self.lattice.read(cid)
                if c:
                    concepts.append(self._enrich_concept(c, cid))
        else:
            # Fallback: scan filesystem
            import os
            base = getattr(self.lattice, "base_path", "")
            concepts_dir = os.path.join(base, "concepts")
            if os.path.exists(concepts_dir):
                for fn in os.listdir(concepts_dir):
                    if fn.endswith(".json") and fn != "index.json":
                        cid = fn.replace(".json", "")
                        c = self.lattice.read(cid)
                        if c:
                            concepts.append(self._enrich_concept(c, cid))

        return concepts

    def _enrich_concept(self, raw: Dict, cid: str) -> Dict:
        """Extract latest D-level explanations from a concept node."""
        result = {
            "concept_id": cid,
            "core_id": raw.get("core_id", cid),
            "status": raw.get("status", "unknown"),
            "dependencies": raw.get("dependencies", raw.get("dependency_chain", [])),
            "downstream": raw.get("downstream_concepts", raw.get("dependent_chain", [])),
            "confidence": raw.get("confidence", 0.0),
            "contradictions": raw.get("contradictions", []),
            "open_problems": raw.get("open_problems", []),
        }

        # Extract latest D-level content
        stack = raw.get("version_stack", [])
        d_levels = {"D1": "", "D2": "", "D3": "", "D4": ""}

        if stack:
            # v3.2 format: iteration-based
            latest = stack[-1]
            if "versions" in latest:
                for level in ["D1", "D2", "D3", "D4"]:
                    v = latest.get("versions", {}).get(level, {})
                    d_levels[level] = v.get("explanation", "") if isinstance(v, dict) else str(v)
            else:
                # v2.1 fallback: single-level entries
                for entry in stack:
                    lvl = entry.get("level")
                    if lvl in d_levels:
                        d_levels[lvl] = entry.get("content", "")

        result["d1"] = d_levels["D1"]
        result["d2"] = d_levels["D2"]
        result["d3"] = d_levels["D3"]
        result["d4"] = d_levels["D4"]
        result["has_content"] = any(len(v) >= self.min_content_length for v in d_levels.values())

        return result

    # ==================== Analysis 1: Cross-concept contradictions ====================

    def _detect_cross_concept_contradictions(self, concepts: List[Dict]) -> List[Dict]:
        """
        Detect contradictions between two concepts when viewed together.
        Strategy: scan D4 (boundaries/limitations) of concept A for
        statements that conflict with D2 (core definition) of concept B.
        """
        findings = []
        n = len(concepts)

        for i in range(n):
            for j in range(i + 1, n):
                a, b = concepts[i], concepts[j]
                if not a["has_content"] or not b["has_content"]:
                    continue

                contradictions = self._check_pair_contradiction(a, b)
                for c in contradictions:
                    findings.append({
                        "type": "cross_concept_contradiction",
                        "severity": c.get("severity", 5),
                        "concept_a": a["concept_id"],
                        "concept_b": b["concept_id"],
                        "description": c["description"],
                        "trigger_reason": f"D4 of {a['concept_id']} conflicts with D2 of {b['concept_id']}",
                    })

        return findings

    def _check_pair_contradiction(self, a: Dict, b: Dict) -> List[Dict]:
        """Check if concept A's D4 contradicts concept B's D2."""
        findings = []
        d4_a = a.get("d4", "").lower()
        d2_b = b.get("d2", "").lower()
        d3_b = b.get("d3", "").lower()

        if not d4_a or (not d2_b and not d3_b):
            return findings

        # Strategy: look for negation patterns in D4 that might conflict
        # with positive claims in D2/D3
        negation_indicators = ["cannot", "impossible", "never", "only", "must not",
                               "violate", "break", "incompatible", "not possible"]
        
        # Extract "claims" from D2/D3 of B (sentences)
        b_claims = self._extract_claims(b.get("d2", "") + " " + b.get("d3", ""))
        
        for claim in b_claims:
            claim_lower = claim.lower()
            for neg in negation_indicators:
                # Check if D4 contains a negation related to this claim
                if neg in d4_a:
                    # Simple semantic overlap: claim keywords appear near negation
                    claim_keywords = set(claim_lower.split()) - {"the", "a", "an", "is", "are", "to", "of", "in", "and", "or"}
                    d4_context = self._get_context_around(d4_a, neg, window=20)
                    overlap = claim_keywords & set(d4_context.split())
                    if len(overlap) >= 2:
                        findings.append({
                            "severity": 6,
                            "description": f"D4 of '{a['concept_id']}' states '{neg}' near concepts also in D2/D3 of '{b['concept_id']}' (keywords: {overlap}). Possible cross-concept contradiction.",
                        })

        return findings

    # ==================== Analysis 2: Bridge discovery ====================

    def _discover_bridges(self, concepts: List[Dict]) -> List[Dict]:
        """
        Discover implicit connections between concepts.
        If concept A's D4 mentions concept B by name, but no explicit
        dependency exists, that's a missing bridge.
        """
        findings = []
        all_ids = {c["concept_id"].lower() for c in concepts}

        for a in concepts:
            if not a["has_content"]:
                continue

            # Scan D4 for mentions of other concepts
            d4_text = (a.get("d4", "") + " " + a.get("d3", "")).lower()
            explicit_deps = set(d.lower() for d in a.get("dependencies", []))

            for b in concepts:
                if b["concept_id"] == a["concept_id"]:
                    continue
                b_id = b["concept_id"].lower()

                # Check if B is mentioned in A's content
                if b_id.replace("_", " ") in d4_text or b_id in d4_text:
                    if b_id not in explicit_deps:
                        findings.append({
                            "type": "missing_bridge",
                            "severity": 4,
                            "from": a["concept_id"],
                            "to": b["concept_id"],
                            "description": f"'{b['concept_id']}' is mentioned in D3/D4 of '{a['concept_id']}' but not in dependency list.",
                            "trigger_reason": f"cross_concept_bridge_detected",
                        })

        return findings

    # ==================== Analysis 3: Orphan detection ====================

    def _detect_orphans(self, concepts: List[Dict]) -> List[Dict]:
        """Detect concepts with no dependencies and no downstream."""
        findings = []
        for c in concepts:
            if not c.get("dependencies") and not c.get("downstream"):
                if c.get("status") == "active":
                    findings.append({
                        "type": "orphan_concept",
                        "severity": 3,
                        "concept_id": c["concept_id"],
                        "description": f"'{c['concept_id']}' has no dependencies and no downstream concepts. Consider linking it to related concepts.",
                    })
        return findings

    # ==================== Analysis 4: Hub overload ====================

    def _detect_hub_overload(self, concepts: List[Dict]) -> List[Dict]:
        """Detect concepts that are overly central (too many downstream)."""
        findings = []
        for c in concepts:
            downstream = c.get("downstream", [])
            if len(downstream) >= 3:
                findings.append({
                    "type": "hub_overload",
                    "severity": 3,
                    "concept_id": c["concept_id"],
                    "description": f"'{c['concept_id']}' is a hub with {len(downstream)} downstream concepts. Its changes will cascade heavily.",
                    "downstream_count": len(downstream),
                })
        return findings

    # ==================== Event generation ====================

    def _finding_to_trigger_event(self, finding: Dict) -> Optional[Dict]:
        """Convert a finding into a TriggerEvent payload."""
        ftype = finding.get("type")

        if ftype == "cross_concept_contradiction":
            return {
                "type": "cross_concept_contradiction",
                "priority": finding.get("severity", 5),
                "payload": {
                    "concept_a": finding.get("concept_a"),
                    "concept_b": finding.get("concept_b"),
                    "description": finding.get("description"),
                },
                "reason": finding.get("trigger_reason", ""),
            }

        elif ftype == "missing_bridge":
            return {
                "type": "inspiration",
                "priority": finding.get("severity", 4),
                "payload": {
                    "from": finding.get("from"),
                    "to": finding.get("to"),
                    "description": finding.get("description"),
                },
                "reason": "cross_concept_bridge_detected",
            }

        elif ftype == "orphan_concept":
            return {
                "type": "info",
                "priority": finding.get("severity", 3),
                "payload": {
                    "concept_id": finding.get("concept_id"),
                    "description": finding.get("description"),
                },
                "reason": "orphan_detected",
            }

        elif ftype == "hub_overload":
            return {
                "type": "info",
                "priority": finding.get("severity", 3),
                "payload": {
                    "concept_id": finding.get("concept_id"),
                    "description": finding.get("description"),
                    "downstream_count": finding.get("downstream_count"),
                },
                "reason": "hub_overload",
            }

        return None

    # ==================== Helpers ====================

    def _extract_claims(self, text: str) -> List[str]:
        """Extract sentences/claims from text."""
        if not text:
            return []
        sentences = re.split(r'[.!?\n]+', text)
        return [s.strip() for s in sentences if len(s.strip()) > 20]

    def _get_context_around(self, text: str, keyword: str, window: int = 20) -> str:
        """Get text around a keyword with a word window."""
        words = text.split()
        for i, w in enumerate(words):
            if keyword in w:
                start = max(0, i - window)
                end = min(len(words), i + window + 1)
                return " ".join(words[start:end])
        return ""

    # ==================== Convenience methods ====================

    def scan_and_push(self) -> List[Dict]:
        """One-shot: scan + generate events + push to queue."""
        findings = self.scan()
        if findings and self.trigger_daemon:
            self.generate_events(findings)
        return findings
