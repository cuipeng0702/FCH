#!/usr/bin/env python3
"""
Feynman Orchestrator v3.2 — Auto-Deepening: Self-regulating Teach → Audit → Grow cycle.

Usage:
    python orchestrator.py <concept> [--max-iterations N] [--confidence-threshold F]

Example:
    python orchestrator.py "transformer attention" --max-iterations 5
"""

import argparse
import json
import sys
import os
import subprocess
from typing import Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.teach import TeachEngine
from scripts.audit import AuditEngine
from scripts.grow import GrowEngine
from scripts.cascade import CascadeEngine
from scripts.lattice_manager import LatticeManager
from scripts.independent_auditor import IndependentAuditor
from scripts.confidence_calculator import ConfidenceCalculator
from scripts.d1_validator import D1Validator
from scripts.cognitive_classifier import CognitiveClassifier
from scripts.metacognitive_memory import MetacognitiveMemory

try:
    from scripts.llm_bridge import create_model_caller, LLMBridge
    HAS_LLM_BRIDGE = True
except ImportError:
    HAS_LLM_BRIDGE = False


class FeynmanOrchestrator:
    """
    Main loop controller for the Feynman Cognition Harness.

    Implements the Teach → Audit → Grow cycle with:
    - Automatic iteration control
    - Termination condition checking
    - Cascade update triggering
    - Metacognitive monitoring
    - Search tool integration (kimi_search, web_search)
    """

    DEFAULT_CONFIG = {
        "max_iterations": 5,
        "confidence_threshold": 0.7,
        "gap_threshold": 0.1,  # Min severity to trigger Grow
        "cascade_depth_limit": 3,
        "audit_schedule": "weekly",
        "storage_path": "~/.openclaw/workspace/knowledge-lattice/",
        "graphify_output_path": "./graphify-out",
        "search_tools": {
            "kimi_search": True,
            "web_search": True,
            "kimi_fetch": True
        },
        "auto_cycle": {
            "enabled": True,
            "ming_wu_threshold": {
                "confidence": 0.90,
                "bss": 0.60,
                "short_term_problems": 3,
                "contradictions": 5,
                "emotion_intensity": 0.30,
                "convergence_delta": 0.02
            },
            "novelty_threshold": 0.15,
            "search_trigger_after_stuck_iterations": 3,
            "max_auto_iterations": 10,
            "self_test_enabled": True
        }
    }

    def __init__(self, config: Dict = None, model_caller=None):
        """
        Initialize Orchestrator.

        Args:
            config: Override default configuration
            model_caller: Function to call LLM (concept, prompt) -> explanation
        """
        self.config = {**self.DEFAULT_CONFIG, **(config or {})}

        # Setup model caller (LLM Bridge if available)
        if model_caller:
            self.model_caller = model_caller
        elif HAS_LLM_BRIDGE:
            self.model_caller = create_model_caller()
        else:
            self.model_caller = None

        # Initialize engines
        self.teach = TeachEngine(model_caller=model_caller)
        self.audit = AuditEngine(lattice_path=self.config["storage_path"])
        self.grow = GrowEngine(
            lattice_path=self.config["storage_path"],
            model_caller=model_caller
        )
        self.cascade = CascadeEngine(
            lattice_path=self.config["storage_path"],
            max_depth=self.config["cascade_depth_limit"]
        )
        self.lattice = LatticeManager(base_path=self.config["storage_path"])
        self.confidence_calc = ConfidenceCalculator(
            lattice_path=self.config["storage_path"]
        )
        self.d1_validator = D1Validator()
        self.independent_auditor = IndependentAuditor(
            lattice_path=self.config["storage_path"]
        )

        # Initialize cognitive architecture
        self.cognitive_classifier = CognitiveClassifier()
        self.metacognitive_memory = MetacognitiveMemory(
            storage_path=os.path.expanduser(
                "~/.openclaw/workspace/knowledge-lattice/metacognitive_memory.json"
            )
        )

        # v3.0: Initialize CSED-CLIF layers
        self._init_v3_layers(config)

        # Metacognitive state
        self.iteration_count = 0
        self.state_history = []
        self.current_concept = None
        self.current_concept_type = None
        self.current_strategy = None

    def _init_v3_layers(self, config: Dict):
        """Initialize CSED-CLIF v3.2 layers."""
        self.v3_config = config or {}

        # Layer 0: TriggerDaemon
        try:
            from scripts.trigger_daemon import TriggerDaemon
            self.trigger_daemon = TriggerDaemon(self.lattice, self.v3_config.get("trigger_daemon", {}))
        except ImportError:
            self.trigger_daemon = None

        # Layer 1: Metacognitive evaluation (reuses metacognitive_memory but adds decision logic)
        try:
            from scripts.metacognitive_memory import MetacognitiveMemory
            self.metacognitive_layer = MetacognitiveMemory(
                storage_path=os.path.expanduser(
                    "~/.openclaw/workspace/knowledge-lattice/metacognitive_memory.json"
                )
            )
        except ImportError:
            self.metacognitive_layer = None

        # Layer 3: VerificationLayer
        try:
            from scripts.verification_layer import VerificationLayer
            self.verification_layer = VerificationLayer(self.lattice, self.v3_config.get("verification", {}))
        except ImportError:
            self.verification_layer = None

        # Layer 4: ConsolidationLayer
        try:
            from scripts.consolidation_layer import ConsolidationLayer
            self.consolidation_layer = ConsolidationLayer(self.lattice, self.v3_config.get("consolidation", {}))
        except ImportError:
            self.consolidation_layer = None

        # Layer 6: GlobalIntegrationDaemon (optional — cross-concept coherence + inspiration)
        try:
            from scripts.global_integration_daemon import GlobalIntegrationDaemon
            self.global_daemon = GlobalIntegrationDaemon(
                lattice=self.lattice,
                trigger_daemon=self.trigger_daemon
            )
        except ImportError:
            self.global_daemon = None

        # Check if v3 mode is available
        self.v3_mode = all([
            self.trigger_daemon is not None,
            self.verification_layer is not None,
            self.consolidation_layer is not None
        ])

    def search_external(self, query: str, tool: str = "kimi_search") -> List[Dict]:
        """
        Use installed search tools to validate claims externally.
        v3.2: Now uses mcporter exa.web_search_exa as primary backend.
        Falls back to empty results if search tools are unavailable.

        Args:
            query: Search query
            tool: Tool to use (kimi_search, web_search, kimi_fetch)

        Returns:
            List of search results
        """
        results = []
        try:
            # v3.2: Use mcporter exa search (available in OpenClaw environment)
            safe_query = query.replace('"', ' ').replace("'", " ")
            result = subprocess.run(
                ["mcporter", "call", f'exa.web_search_exa(query: "{safe_query}", numResults: 3)'],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                results = self._parse_mcporter_output(result.stdout)
            else:
                print(f"   ⚠️ mcporter error: {result.stderr[:200]}")

        except Exception as e:
            print(f"   ⚠️ Search failed: {e}")

        if not results:
            print(f"   ⚠️ No search results for: {query[:50]}...")

        return results

    def _parse_mcporter_output(self, raw: str) -> List[Dict]:
        """
        Parse mcporter's text output into structured search results.
        """
        entries = []
        for block in raw.split("\n\n---\n\n"):
            entry = {}
            lines = block.strip().split("\n")
            i = 0
            while i < len(lines):
                line = lines[i].strip()
                if line.startswith("Title:"):
                    entry["title"] = line[6:].strip()
                elif line.startswith("URL:"):
                    entry["url"] = line[4:].strip()
                elif line.startswith("Published:"):
                    entry["published"] = line[10:].strip()
                elif line.startswith("Author:"):
                    entry["author"] = line[7:].strip()
                elif line.startswith("Highlights:"):
                    entry["highlights"] = []
                    i += 1
                    while i < len(lines) and not lines[i].startswith("Title:"):
                        hl = lines[i].strip()
                        if hl and not hl.startswith("[...]"):
                            entry["highlights"].append(hl)
                        i += 1
                    continue
                i += 1
            if entry.get("title") and entry.get("url"):
                entries.append(entry)
        return entries

    def validate_with_search(self, claims: List[str]) -> Dict[str, bool]:
        """
        Validate claims using external search.

        Args:
            claims: List of factual claims to validate

        Returns:
            Dict mapping claim to validation result
        """
        results = {}
        for claim in claims:
            search_results = self.search_external(claim)
            # Simple heuristic: if we got results, claim is likely valid
            results[claim] = len(search_results) > 0
        return results

    def run(self, concept: str, max_iterations: int = None,
            confidence_threshold: float = None) -> Dict:
        """
        Execute oscillation spiral: D1_quick → D4 → D1_reconstruct → D2 → D3 → oscillate.

        The oscillation mechanism mirrors consciousness evolution:
        - D1 establishes initial cognitive topology (intuition map)
        - D4 provides boundary calibration (where intuition fails)
        - D1↔D4 contradiction drives reconstruction (compression-decompression cycle)
        - D2/D3 fill causal and formal structure between topology and boundary
        - Convergence = D1 analogy structure stabilizes across oscillations
        """
        max_iter = max_iterations or self.config["max_iterations"]
        threshold = confidence_threshold or self.config["confidence_threshold"]

        self.current_concept = concept
        self.iteration_count = 0
        self.oscillation_history = []  # Track D1 structure across oscillations

        print(f"🎯 Starting Feynman cycle for: {concept}")
        print(f"   Max iterations: {max_iter}")
        print(f"   Confidence threshold: {threshold}")

        concept_id = self._sanitize_id(concept)

        # === PHASE 0: OSCILLATION INITIALIZATION ===
        # D1_quick → D4 → contradiction → D1_reconstruct
        # This establishes the "consciousness evolution" foundation
        oscillation_result = self._oscillation_initialize(concept_id, concept)
        if oscillation_result.get("status") == "converged":
            # D1 already stable after oscillation initialization
            print(f"\n✅ OSCILLATION CONVERGED: D1 structure stable after initialization")
            return self._finalize(
                concept_id, "oscillation_converged",
                oscillation_result.get("confidence", 0.7),
                []
            )

        # === COGNITIVE CLASSIFICATION ===
        print("\n🧠 COGNITIVE: Classifying concept type...")
        self.current_concept_type = self.cognitive_classifier.classify(concept_id)
        strategy = self.cognitive_classifier.get_strategy(self.current_concept_type)
        self.current_strategy = strategy

        print(f"   Type: {self.current_concept_type}")
        print(f"   Strategy: {strategy['name']} ({strategy['d1_approach']})")

        cluster_report = self.cognitive_classifier.get_cluster_report()
        if cluster_report.get('clusters'):
            print(f"   Emergent clusters:")
            for c in cluster_report['clusters']:
                print(f"      '{c.get('label', '?')}': {', '.join(c.get('tokens', [])[:6])} (strength: {c.get('strength', 0):.2f})")
        if cluster_report.get('aha_moments'):
            print(f"   ⚡ AHA moments detected:")
            for a in cluster_report['aha_moments']:
                print(f"      [{a.get('type')}] {a.get('explanation', '')[:80]}...")

        # Main loop (Teach → Audit → Grow with contradiction priority)
        for iteration in range(1, max_iter + 1):
            self.iteration_count = iteration
            print(f"\n{'='*60}")
            print(f"🔄 Iteration {iteration}/{max_iter}")
            print(f"{'='*60}")

            # === TEACH ===
            print("\n🎙️  TEACH: Generating D1-D4 explanations...")
            # D1 is generated LAST (D2→D3→D4→D1 order), with D2-D4 summaries injected
            explanations = self.teach.teach(concept)
            self._store_explanations(concept_id, explanations)

            # Track D1 structure for oscillation convergence
            d1_structure = self._extract_d1_structure(explanations.get("D1", {}))
            self.oscillation_history.append(d1_structure)

            # === INDEPENDENT AUDIT ===
            print("\n🕵️  INDEPENDENT AUDIT: Spawning subagent for unbiased evaluation...")
            audit_report = self.independent_auditor.audit_concept(concept_id, explanations)

            # === EXTERNAL VALIDATION ===
            print("\n🔍 EXTERNAL: Validating claims with search...")
            claims = self._extract_claims(explanations)
            validated = self.validate_with_search(claims)
            valid_count = sum(1 for v in validated.values() if v)
            print(f"   Validated {valid_count}/{len(claims)} claims")

            # === CONFIDENCE CALCULATION ===
            print("\n📊 CONFIDENCE: Multi-dimensional calculation...")
            confidence_result = self.confidence_calc.calculate(concept_id)
            confidence = confidence_result["overall_confidence"]

            self._display_audit(audit_report)
            self._display_confidence(confidence_result)

            gaps = audit_report.get("gaps", [])
            print(f"\n📊 Current confidence: {confidence:.3f} (target: {threshold})")
            print(f"   Gaps found: {len(gaps)}")

            self.state_history.append({
                "iteration": iteration,
                "confidence": confidence,
                "gaps_count": len(gaps),
                "status": audit_report.get("status", "unknown")
            })

            # === v3.2 AUTO-CYCLE CHECKS ===
            auto_results = self._run_auto_cycle_checks(
                concept_id, confidence, gaps, [], explanations, iteration
            )
            if auto_results["ming_wu"].get("passed"):
                return self._finalize(concept_id, "ming_wu_converged", confidence, gaps)

            # === OSCILLATION CONVERGENCE CHECK ===
            # D1 structure stable for 2 consecutive iterations = convergence
            if len(self.oscillation_history) >= 3:
                if self._is_d1_structure_stable():
                    print(f"\n🌀 OSCILLATION CONVERGED: D1 analogy structure stable")
                    hidden = self._detect_contradictions(concept_id)
                    if hidden:
                        print(f"   ⚡ But {len(hidden)} contradictions remain")
                        return self._finalize(
                            concept_id, "oscillation_converged_with_contradictions",
                            confidence, gaps, contradictions=hidden
                        )
                    return self._finalize(concept_id, "oscillation_converged", confidence, gaps)

            # === TERMINATION / CONTRADICTION / GROW ===
            if confidence >= threshold and len(gaps) == 0:
                hidden = self._detect_contradictions(concept_id)
                if hidden:
                    print(f"\n⚡ CONTRADICTIONS despite convergence: {len(hidden)}")
                    self._handle_contradictions(concept_id, hidden)
                    continue
                print(f"\n✅ CONVERGED: Confidence {confidence:.3f}, no gaps, no contradictions")
                return self._finalize(concept_id, "converged", confidence, gaps)

            if iteration == max_iter:
                final_contradictions = self._detect_contradictions(concept_id)
                if final_contradictions:
                    print(f"\n⏹️  MAX ITERATIONS - {len(final_contradictions)} contradictions unresolved")
                    return self._finalize(
                        concept_id, "max_iterations_with_contradictions",
                        confidence, gaps, contradictions=final_contradictions
                    )
                print(f"\n⏹️  MAX ITERATIONS REACHED")
                return self._finalize(concept_id, "max_iterations", confidence, gaps)

            if self._is_stuck():
                print(f"\n⚠️  STUCK: No progress for 3 iterations")
                stuck_contradictions = self._detect_contradictions(concept_id)
                if stuck_contradictions:
                    print(f"   Using contradictions as escape hatch...")
                    self._handle_contradictions(concept_id, stuck_contradictions)
                    continue
                return self._finalize(concept_id, "stuck", confidence, gaps)

            # Priority: contradictions > gaps
            contradictions = self._detect_contradictions(concept_id)
            if contradictions:
                print(f"\n⚡ CONTRADICTION-DRIVEN LEARNING: {len(contradictions)} found")
                self._handle_contradictions(concept_id, contradictions)
                continue

            if gaps:
                significant_gaps = [
                    g for g in gaps
                    if g.get("severity", 0) >= self.config["gap_threshold"] * 10
                ]
                if significant_gaps:
                    print(f"\n🌱 GROW: Filling {len(significant_gaps)} significant gaps...")
                    for gap in significant_gaps[:3]:
                        print(f"   → {gap.get('type', 'unknown')}: {gap.get('description', '')[:60]}...")
                        growth_result = self.grow.grow(gap)
                        if growth_result.get("status") == "success":
                            print(f"     ✅ Gap filled")
                        else:
                            print(f"     ⚠️  Partial fill: {growth_result.get('error', 'unknown error')}")

        return self._finalize(concept_id, "unknown", 0, [])

    def _oscillation_initialize(self, concept_id: str, concept: str) -> Dict:
        """
        Phase 0: Oscillation spiral initialization.

        Mirrors consciousness evolution:
        1. D1_quick: Establish initial cognitive topology (intuition map)
        2. D4: Scan boundaries (where does the intuition fail?)
        3. Detect D1↔D4 contradictions (the productive tension zone)
        4. D1_reconstruct: Rebuild D1 using D4's boundary knowledge
           (compression: D4's precise limits → D1's intuitive boundaries)
        5. Check convergence: D1 structure stable?

        Returns:
            Dict with status, d1_versions, contradictions, confidence
        """
        print(f"\n{'='*60}")
        print(f"🌀 PHASE 0: OSCILLATION INITIALIZATION")
        print(f"   Mapping: D1_quick → D4 → D1_reconstruct")
        print(f"{'='*60}")

        # Step 1: D1_quick - fast, rough, topology-only
        print("\n📍 Step 1: D1_quick - Establish cognitive topology...")
        d1_quick = self.teach.teach(concept, level="D1")
        d1_quick_exp = d1_quick.get("D1", {}).get("explanation", "")
        print(f"   D1_quick length: {len(d1_quick_exp)} chars")

        # Store D1_quick in lattice (as version 0)
        self._store_explanations(concept_id, {"D1": d1_quick.get("D1")})

        # Step 2: D4 - boundary scan
        print("\n🔬 Step 2: D4 - Scan boundaries and failure modes...")
        d4_result = self.teach.teach(concept, level="D4")
        d4_exp = d4_result.get("D4", {}).get("explanation", "")
        print(f"   D4 length: {len(d4_exp)} chars")

        # Store D4
        self._store_explanations(concept_id, {"D4": d4_result.get("D4")})

        # Step 3: Detect D1↔D4 contradictions
        print("\n⚡ Step 3: Detect D1↔D4 contradictions...")
        concept_state = self.lattice.read(concept_id)
        contradictions = self._detect_contradictions(concept_id)

        if not contradictions:
            print("   No contradictions - D1_quick already aligns with D4 boundaries")
            print("   (Rare: concept is well-understood or D1_quick was lucky)")
            return {
                "status": "converged",
                "d1_versions": [d1_quick_exp],
                "contradictions": [],
                "confidence": 0.7
            }

        print(f"   {len(contradictions)} contradictions detected:")
        for c in contradictions:
            print(f"      [{c['type']}] sev={c['severity']:.2f} {c['levels_involved']}")

        # Step 4: D1_reconstruct - rebuild D1 with D4 knowledge
        print("\n🔄 Step 4: D1_reconstruct - Rebuild D1 using D4 boundary knowledge...")
        print("   (This is compression: D4's precise limits → D1's intuitive boundaries)")

        # Generate D2 and D3 to give D1_reconstruct full context
        print("   Generating D2-D3 for reconstruction context...")
        d2_result = self.teach.teach(concept, level="D2")
        d3_result = self.teach.teach(concept, level="D3")
        self._store_explanations(concept_id, {
            "D2": d2_result.get("D2"),
            "D3": d3_result.get("D3")
        })

        # Now generate D1 again - with D2-D4 summaries injected (TeachEngine v2 behavior)
        d1_reconstruct = self.teach.teach(concept, level="D1")
        d1_reconstruct_exp = d1_reconstruct.get("D1", {}).get("explanation", "")
        print(f"   D1_reconstruct length: {len(d1_reconstruct_exp)} chars")

        # Store reconstructed D1 as new version
        self._store_explanations(concept_id, {"D1": d1_reconstruct.get("D1")})

        # Step 5: Check oscillation convergence
        print("\n🎯 Step 5: Oscillation convergence check...")
        contradictions_after = self._detect_contradictions(concept_id)
        print(f"   Contradictions after reconstruction: {len(contradictions_after)}")

        # Compare D1_quick vs D1_reconstruct structure
        d1_quick_struct = self._extract_d1_structure(d1_quick.get("D1", {}))
        d1_reconstruct_struct = self._extract_d1_structure(d1_reconstruct.get("D1", {}))
        structure_similarity = self._compare_d1_structures(d1_quick_struct, d1_reconstruct_struct)

        print(f"   D1 structure similarity: {structure_similarity:.2f}")
        print(f"   (Low = significant reconstruction; High = minor refinement)")

        # Track in oscillation history
        self.oscillation_history = [d1_quick_struct, d1_reconstruct_struct]

        if len(contradictions_after) == 0 and structure_similarity < 0.8:
            # D1 was significantly reconstructed and now aligns with D4
            print("\n✅ OSCILLATION INITIALIZATION CONVERGED")
            print("   D1 reconstructed to align with D4 boundaries")
            return {
                "status": "converged",
                "d1_versions": [d1_quick_exp, d1_reconstruct_exp],
                "contradictions": [],
                "confidence": 0.75
            }

        print("\n⏩ OSCILLATION INITIALIZATION COMPLETE - entering main cycle")
        return {
            "status": "needs_main_cycle",
            "d1_versions": [d1_quick_exp, d1_reconstruct_exp],
            "contradictions": contradictions_after,
            "confidence": 0.6
        }

    def _extract_d1_structure(self, d1_result: Dict) -> Dict:
        """Extract structural fingerprints from D1 for oscillation tracking."""
        exp = d1_result.get("explanation", "")
        return {
            "has_master_analogy": "MASTER ANALOGY" in exp or "master analogy" in exp.lower(),
            "has_principle_map": "PRINCIPLE MAP" in exp or "principle map" in exp.lower(),
            "has_boundary_conditions": "BOUNDARY" in exp or "boundary" in exp.lower(),
            "has_preload_inventory": "PRE-LOAD" in exp or "pre-load" in exp.lower(),
            "has_honesty_gaps": "HONESTY GAPS" in exp or "honesty gaps" in exp.lower(),
            "principle_count": len([l for l in exp.split("\n") if l.strip().startswith("a.") or l.strip().startswith("b.")]),
            "explanation_length": len(exp),
            "confidence": d1_result.get("confidence", 0.5)
        }

    def _compare_d1_structures(self, struct_a: Dict, struct_b: Dict) -> float:
        """Compare two D1 structures, return similarity (0-1)."""
        # Check structural field presence
        fields = ["has_master_analogy", "has_principle_map", "has_boundary_conditions",
                  "has_preload_inventory", "has_honesty_gaps"]
        field_matches = sum(1 for f in fields if struct_a.get(f) == struct_b.get(f))
        field_sim = field_matches / len(fields)

        # Check principle count similarity
        count_a = struct_a.get("principle_count", 0)
        count_b = struct_b.get("principle_count", 0)
        if max(count_a, count_b) == 0:
            count_sim = 1.0
        else:
            count_sim = 1 - abs(count_a - count_b) / max(count_a, count_b)

        # Weighted average
        return field_sim * 0.6 + count_sim * 0.4

    def _is_d1_structure_stable(self) -> bool:
        """Check if D1 structure has stabilized across last 3 iterations."""
        if len(self.oscillation_history) < 3:
            return False

        # Compare last 3 D1 structures
        recent = self.oscillation_history[-3:]
        similarities = []
        for i in range(len(recent) - 1):
            sim = self._compare_d1_structures(recent[i], recent[i+1])
            similarities.append(sim)

        avg_similarity = sum(similarities) / len(similarities)
        print(f"   D1 structure stability (last 3): {avg_similarity:.2f}")

        # Stable = high similarity AND presence of key structural elements
        last = recent[-1]
        has_key_elements = (
            last.get("has_master_analogy") and
            last.get("has_principle_map") and
            last.get("has_boundary_conditions")
        )

        return avg_similarity >= 0.85 and has_key_elements

    def _store_explanations(self, concept_id: str, explanations: Dict) -> None:
        """Store explanations in lattice."""
        # Ensure concept exists
        existing = self.lattice.read(concept_id)
        if not existing:
            self.lattice.create(concept_id)

        # Add each level as a version
        for level, explanation in explanations.items():
            content = explanation.get("explanation", "")
            confidence = explanation.get("confidence", 0.5)

            self.lattice.add_version(
                concept_id, level, content, confidence,
                metadata={
                    "assumed_knowledge": explanation.get("assumed_knowledge", []),
                    "dependencies": explanation.get("dependencies", []),
                    "gaps": explanation.get("gaps", [])
                }
            )

    def _extract_claims(self, explanations: Dict) -> List[str]:
        """Extract factual claims from explanations for external validation."""
        claims = []
        for level, explanation in explanations.items():
            content = explanation.get("explanation", "")
            # Simple extraction: sentences that look like factual claims
            sentences = content.split('.')
            for sentence in sentences:
                sentence = sentence.strip()
                if len(sentence) > 20 and not sentence.endswith('?'):
                    claims.append(sentence)
        return claims[:5]  # Limit to top 5 claims for efficiency

    def _display_confidence(self, confidence_result: Dict) -> None:
        """Display confidence calculation results."""
        overall = confidence_result.get("overall_confidence", 0)
        level = confidence_result.get("level", "unknown")
        dimensions = confidence_result.get("dimensions", {})

        print(f"\n   📈 Confidence: {overall:.3f} ({level})")
        print(f"   Dimensions:")
        for dim, score in dimensions.items():
            bar = "█" * int(score * 10) + "░" * (10 - int(score * 10))
            print(f"      {dim:20s} {bar} {score:.2f}")

        recommendations = confidence_result.get("recommendations", [])
        if recommendations:
            print(f"   Recommendations:")
            for rec in recommendations[:3]:
                print(f"      → {rec}")

    def _extract_claims(self, explanations: Dict) -> List[str]:
        """Extract factual claims from explanations for external validation."""
        claims = []
        for level, explanation in explanations.items():
            content = explanation.get("explanation", "")
            # Simple extraction: sentences that look like factual claims
            sentences = content.split('.')
            for sentence in sentences:
                sentence = sentence.strip()
                if len(sentence) > 20 and not sentence.endswith('?'):
                    claims.append(sentence)
        return claims[:5]  # Limit to top 5 claims for efficiency

    def _display_confidence(self, confidence_result: Dict) -> None:
        """Display confidence calculation results."""
        overall = confidence_result.get("overall_confidence", 0)
        level = confidence_result.get("level", "unknown")
        dimensions = confidence_result.get("dimensions", {})

        print(f"\n   📈 Confidence: {overall:.3f} ({level})")
        print(f"   Dimensions:")
        for dim, score in dimensions.items():
            bar = "█" * int(score * 10) + "░" * (10 - int(score * 10))
            print(f"      {dim:20s} {bar} {score:.2f}")

        recommendations = confidence_result.get("recommendations", [])
        if recommendations:
            print(f"   Recommendations:")
            for rec in recommendations[:3]:
                print(f"      → {rec}")

    def _display_audit(self, audit_report: Dict) -> None:
        """Display independent audit results."""
        status = audit_report.get("status", "unknown")
        method = audit_report.get("method", "unknown")
        gaps = audit_report.get("gaps", [])
        contradictions = audit_report.get("contradictions", [])
        confidence = audit_report.get("confidence", {})

        # Status emoji
        emoji = "✅" if status == "completed" else "❌"
        print(f"   {emoji} Independent audit: {status} (method: {method})")

        if gaps:
            print(f"   🕳️  Gaps ({len(gaps)}):")
            for gap in gaps[:5]:  # Show top 5
                severity = gap.get("severity", 0)
                gap_type = gap.get("type", "unknown")
                desc = gap.get("description", "")[:50]
                print(f"      [{severity}/10] {gap_type}: {desc}...")

        if contradictions:
            print(f"   ⚡ Contradictions ({len(contradictions)}):")
            for c in contradictions[:3]:
                print(f"      → {c.get('description', '')[:60]}...")

        if confidence:
            overall = confidence.get("overall", 0)
            print(f"   📊 Confidence: {overall:.3f}")
            dims = confidence.get("dimensions", {})
            for dim, score in dims.items():
                print(f"      {dim}: {score:.2f}")

    def _is_stuck(self) -> bool:
        """Check if learning is stuck (no progress for 3 iterations)."""
        if len(self.state_history) < 3:
            return False

        recent = self.state_history[-3:]
        confidences = [s["confidence"] for s in recent]

        # Check if confidence is essentially unchanged
        return max(confidences) - min(confidences) < 0.05

    def _has_core_definition_changed(self, concept_id: str, new_explanations: Dict) -> bool:
        """Check if core definition has changed significantly."""
        existing = self.lattice.read(concept_id)
        if not existing:
            return False

        # Compare D1 explanations
        old_versions = existing.get("version_stack", [])
        old_d1 = next((v for v in old_versions if v.get("level") == "D1"), None)
        new_d1 = new_explanations.get("D1", {})

        if not old_d1 or not new_d1:
            return True  # Changed if either is missing

        # Simple comparison: if content is different
        old_content = old_d1.get("content", "")
        new_content = new_d1.get("explanation", "")

        return old_content != new_content


    # === v3.2 Auto-Deepening: Self-Regulating Cycle Control ===

    def _ming_wu_check(self, concept_id: str, confidence: float, gaps: List[Dict],
                       contradictions: List[Dict], emotion: Dict) -> Dict:
        """
        Automatic Ming Wu condition checker.
        
        Evaluates 6 conditions to determine if learning has reached
        "明悟" (clear understanding) state.
        
        Returns: {"passed": bool, "score": int, "total": int, "blocking": [...]}
        """
        cfg = self.config.get("auto_cycle", {}).get("ming_wu_threshold", {})
        
        # Count short-term problems (non-long-term open problems)
        concept = self.lattice.read(concept_id) or {}
        open_problems = concept.get("open_problems", [])
        short_term = [p for p in open_problems if "long-term" not in str(p).lower()]
        
        # Calculate convergence delta from state history
        convergence_delta = 0.05
        if len(self.state_history) >= 2:
            prev = self.state_history[-2]["confidence"]
            curr = self.state_history[-1]["confidence"]
            convergence_delta = abs(curr - prev)
        
        # Approximate BSS (Brier Skill Score) from lattice
        # v3.2: If no brier_data exists, condition is not applicable (skip)
        brier_data = concept.get("brier_data", {})
        if brier_data:
            bss = brier_data.get("bss", 0.5)
        else:
            bss = None  # Not available yet
        
        conditions = [
            ("confidence", confidence >= cfg.get("confidence", 0.90)),
            ("bss", bss >= cfg.get("bss", 0.60) if bss is not None else True),
            ("short_term_problems", len(short_term) <= cfg.get("short_term_problems", 3)),
            ("contradictions", len(contradictions) <= cfg.get("contradictions", 5)),
            ("emotion", emotion.get("intensity", 0.5) < cfg.get("emotion_intensity", 0.30)),
            ("convergence", convergence_delta < cfg.get("convergence_delta", 0.02)),
        ]
        
        passed = sum(1 for _, ok in conditions if ok)
        blocking = [name for name, ok in conditions if not ok]
        
        return {
            "passed": passed >= 6,  # All must pass
            "score": passed,
            "total": 6,
            "blocking": blocking,
            "details": {name: ok for name, ok in conditions},
            "bss_approx": bss,
            "short_term_count": len(short_term),
            "convergence_delta": convergence_delta
        }

    def _run_auto_cycle_checks(self, concept_id: str, confidence: float,
                               gaps: List[Dict], contradictions: List[Dict],
                               explanations_or_versions: Dict, iteration) -> Dict:
        """
        Unified auto-cycle checks: Ming Wu + Novelty + Stuck.
        Returns dict with check results for both run() and run_v3().
        """
        results = {
            "ming_wu": {},
            "novelty": {},
            "stuck": False,
        }

        if not self.config.get("auto_cycle", {}).get("enabled", False):
            return results

        # Read concept state from lattice (handles run() where concept may be string)
        concept_state = self.lattice.read(concept_id) or {}

        # 1. Ming Wu check
        emotion = concept_state.get("epistemic_emotion", {})
        mw = self._ming_wu_check(concept_id, confidence, gaps, contradictions, emotion)
        results["ming_wu"] = mw
        print(f"\n🎯 Ming Wu check: {mw['score']}/{mw['total']} conditions")
        if mw["passed"]:
            print(f"   ✅ MING WU ACHIEVED — auto-converging")
        else:
            print(f"   Blocking: {', '.join(mw['blocking'])}")

        # 2. Novelty check
        novelty = self._novelty_ratio_check(concept_id, explanations_or_versions)
        results["novelty"] = novelty
        print(f"   Novelty ratio: {novelty['novelty_ratio']:.2f} (threshold: {novelty['threshold']})")
        if novelty["is_stuck"]:
            print(f"   ⚠️ NOVELTY STUCK detected — auto-triggering external search")
            self._auto_search_trigger(concept_id, reason="novelty_stuck")

        # 3. Stuck iteration check → auto search
        if isinstance(iteration, list) and len(iteration) >= 3:
            recent = iteration[-3:]
            confidences = [it.get("confidence", 0.0) for it in recent]
            max_c = max(confidences)
            min_c = min(confidences)
            all_rejected = all(it.get("status") == "revise" for it in recent)
            is_stuck = (max_c - min_c < 0.05) and all_rejected
        else:
            is_stuck = self._is_stuck()

        if is_stuck:
            print(f"   ⚠️ STUCK for 3+ iterations — auto-triggering external search")
            self._auto_search_trigger(concept_id, reason="stuck_iterations")
            results["stuck"] = True

        return results

    def _novelty_ratio_check(self, concept_id: str, current_explanations: Dict) -> Dict:
        """
        Calculate novelty ratio between current and previous iteration.
        
        Uses simple text comparison on D3 (formal) content.
        Novelty ratio < 0.15 = content is mostly repetition = stuck.
        
        Returns: {"novelty_ratio": float, "is_stuck": bool, "common_ratio": float}
        """
        concept = self.lattice.read(concept_id) or {}
        versions = concept.get("version_stack", [])
        
        threshold = self.config.get("auto_cycle", {}).get("novelty_threshold", 0.15)
        
        if len(versions) < 2:
            return {"novelty_ratio": 1.0, "is_stuck": False, "common_ratio": 0.0, "threshold": threshold}
        
        prev_d3 = versions[-2].get("versions", {}).get("D3", {}).get("explanation", "")
        curr_d3 = current_explanations.get("D3", {}).get("explanation", "")
        
        if not prev_d3 or not curr_d3:
            return {"novelty_ratio": 1.0, "is_stuck": False, "common_ratio": 0.0, "threshold": threshold}
        
        # Simple word-level Jaccard similarity
        prev_words = set(prev_d3.lower().split())
        curr_words = set(curr_d3.lower().split())
        
        if not prev_words:
            return {"novelty_ratio": 1.0, "is_stuck": False, "common_ratio": 0.0, "threshold": threshold}
        
        common = prev_words & curr_words
        novelty = (len(curr_words) - len(common)) / len(prev_words)
        common_ratio = len(common) / len(prev_words)
        
        threshold = self.config.get("auto_cycle", {}).get("novelty_threshold", 0.15)
        is_stuck = novelty < threshold and common_ratio > 0.85
        
        return {
            "novelty_ratio": round(novelty, 3),
            "common_ratio": round(common_ratio, 3),
            "is_stuck": is_stuck,
            "threshold": threshold
        }

    def _auto_search_trigger(self, concept_id: str, reason: str = "stuck") -> List[Dict]:
        """
        Trigger external search when internal deepening reaches ceiling.
        
        Called automatically after 3 stuck iterations or when novelty < threshold.
        
        Returns: Search results list
        """
        concept = self.lattice.read(concept_id) or {}
        concept_name = concept.get("name", concept_id)
        
        print(f"\n🔍 AUTO-SEARCH TRIGGERED: {reason}")
        print(f"   Searching for external knowledge on: {concept_name}")
        
        # Build search queries based on open problems
        open_problems = concept.get("open_problems", [])
        queries = [f"{concept_name} advanced research latest developments"]
        for p in open_problems[:2]:
            queries.append(f"{concept_name} {str(p)[:50]}")
        
        results = []
        for query in queries[:2]:  # Limit to 2 queries
            try:
                search_res = self.search_external(query)
                if search_res:
                    results.extend(search_res[:3])
            except Exception as e:
                print(f"   ⚠️ Search error for '{query}': {e}")
        
        # Store search results in lattice for next iteration
        if results:
            self.lattice.update(concept_id, {
                "auto_search_results": {
                    "timestamp": self._timestamp(),
                    "reason": reason,
                    "query_count": len(queries),
                    "results": results[:5]
                }
            })
            print(f"   ✅ Found {len(results)} external sources")
        else:
            print(f"   ⚠️ No external results found")
        
        return results

    def _self_test_after_code_change(self, files_changed: List[str]) -> Dict:
        """
        Auto-run import tests after code modifications.
        
        v3.2: Every file edit triggers automatic import validation
        to catch insertion-position or syntax errors immediately.
        
        Returns: {"all_passed": bool, "results": [{file, passed, error}]}
        """
        if not self.config.get("auto_cycle", {}).get("self_test_enabled", True):
            return {"all_passed": True, "results": [], "skipped": True}
        
        import subprocess
        
        test_results = []
        all_passed = True
        
        for filepath in files_changed:
            try:
                # Try importing the module
                module_name = filepath.replace("/", ".").replace(".py", "")
                # Need to add parent dir to path for scripts.X imports
                parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                cmd = ["python3", "-c", f"import sys; sys.path.insert(0, '{parent_dir}'); import {module_name}; print('OK')"]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
                
                passed = result.returncode == 0 and "OK" in result.stdout
                test_results.append({
                    "file": filepath,
                    "passed": passed,
                    "error": result.stderr if not passed else None
                })
                
                if not passed:
                    all_passed = False
                    print(f"   ❌ Self-test FAILED: {filepath}")
                    print(f"      {result.stderr[:200]}")
                else:
                    print(f"   ✅ Self-test passed: {filepath}")
                    
            except Exception as e:
                test_results.append({
                    "file": filepath,
                    "passed": False,
                    "error": str(e)
                })
                all_passed = False
        
        return {
            "all_passed": all_passed,
            "results": test_results,
            "timestamp": self._timestamp()
        }

    def _finalize(self, concept_id: str, status: str,
                  confidence: float, gaps: List[Dict],
                  contradictions: List[Dict] = None) -> Dict:
        """Finalize cycle and return results."""
        contradictions = contradictions or []

        # Update concept confidence
        self.lattice.update_confidence(
            concept_id, confidence,
            reason=f"Feynman cycle completed: {status}"
        )

        # === CONSOLIDATION PHASE ===
        # Mark for delayed consolidation (simulates sleep-dependent memory consolidation)
        if status in ["converged", "oscillation_converged"]:
            consolidation_stage = "pending"
            next_review = self._schedule_consolidation_review()
            print(f"\n💤 CONSOLIDATION: Marked for delayed review at {next_review}")
        else:
            consolidation_stage = "incomplete"
            next_review = None

        self.lattice.update(concept_id, {
            "consolidation_status": {
                "stage": consolidation_stage,
                "last_consolidated": self._timestamp() if consolidation_stage == "pending" else None,
                "next_review_scheduled": next_review,
                "degradation_detected": False
            }
        })

        # === EPISTEMIC EMOTION UPDATE ===
        # Record emotional state at cycle end (drives future iteration pacing)
        if contradictions:
            emotion_state = "confused"
            emotion_intensity = min(1.0, max(0.3, len(contradictions) / 5))
        elif gaps:
            emotion_state = "curious"
            emotion_intensity = min(1.0, max(0.3, len(gaps) / 5))
        elif status.startswith("oscillation_converged"):
            emotion_state = "satisfied"
            emotion_intensity = 0.8
        else:
            emotion_state = "satisfied"
            emotion_intensity = 0.6

        concept = self.lattice.read(concept_id) or {}
        emotion_history = concept.get("epistemic_emotion", {}).get("history", [])
        emotion_history.append({
            "state": emotion_state,
            "intensity": emotion_intensity,
            "trigger": status,
            "timestamp": self._timestamp()
        })

        self.lattice.update(concept_id, {
            "epistemic_emotion": {
                "current_state": emotion_state,
                "intensity": emotion_intensity,
                "history": emotion_history
            }
        })

        result = {
            "concept_id": concept_id,
            "concept": self.current_concept,
            "status": status,
            "iterations": self.iteration_count,
            "final_confidence": confidence,
            "remaining_gaps": len(gaps),
            "gap_summary": self._summarize_gaps(gaps),
            "contradictions_detected": len(contradictions),
            "contradiction_summary": self._summarize_contradictions(contradictions) if contradictions else {},
            "consolidation_status": consolidation_stage,
            "next_review": next_review,
            "epistemic_emotion": emotion_state,
            "state_history": self.state_history,
            "timestamp": self._timestamp()
        }

        print(f"\n{'='*60}")
        print(f"🏁 FEYNMAN CYCLE COMPLETE")
        print(f"{'='*60}")
        print(f"   Status: {status}")
        print(f"   Iterations: {self.iteration_count}")
        print(f"   Final confidence: {confidence:.3f}")
        print(f"   Remaining gaps: {len(gaps)}")
        if contradictions:
            print(f"   ⚡ Unresolved contradictions: {len(contradictions)}")
        print(f"   💭 Epistemic emotion: {emotion_state} ({emotion_intensity:.2f})")

        return result

    def _schedule_consolidation_review(self, hours_ahead: int = 24) -> str:
        """Schedule a delayed consolidation review (simulates offline memory consolidation)."""
        from datetime import datetime, timedelta
        review_time = datetime.now() + timedelta(hours=hours_ahead)
        return review_time.isoformat()

    def _summarize_gaps(self, gaps: List[Dict]) -> Dict:
        """Summarize gaps by type."""
        by_type = {}
        for gap in gaps:
            gap_type = gap.get("type", "unknown")
            by_type[gap_type] = by_type.get(gap_type, 0) + 1

        return {
            "total": len(gaps),
            "by_type": by_type,
            "highest_severity": max((g.get("severity", 0) for g in gaps), default=0)
        }

    def _summarize_contradictions(self, contradictions: List[Dict]) -> Dict:
        """Summarize contradictions by type."""
        by_type = {}
        for c in contradictions:
            ctype = c.get("type", "unknown")
            by_type[ctype] = by_type.get(ctype, 0) + 1

        return {
            "total": len(contradictions),
            "by_type": by_type,
            "highest_severity": max((c.get("severity", 0) for c in contradictions), default=0),
            "levels_affected": list(set(
                lvl for c in contradictions for lvl in c.get("levels_involved", [])
            ))
        }

    def _detect_contradictions(self, concept_id: str) -> List[Dict]:
        """
        Detect cross-level contradictions in the current concept state.

        Returns list of contradictions, or empty list if none.
        """
        try:
            from scripts.contradiction_detector import CrossLevelContradictionDetector
            detector = CrossLevelContradictionDetector(threshold=0.15)
            concept = self.lattice.read(concept_id)
            if not concept:
                return []
            return detector.detect(concept)
        except Exception as e:
            print(f"   ⚠️  Contradiction detection failed: {e}")
            return []

    def _handle_contradictions(self, concept_id: str, contradictions: List[Dict]) -> None:
        """
        Handle detected contradictions by spawning targeted learning tasks.

        Uses ContradictionDrivenLearning to convert contradictions into
        concrete actions, then stores them as open problems in the lattice.

        Also updates attention_focus and epistemic_emotion to reflect
        the cognitive state shift caused by contradiction detection.
        """
        try:
            from scripts.contradiction_detector import ContradictionDrivenLearning
            cdl = ContradictionDrivenLearning()

            # Get priority contradiction
            priority = None
            for c in contradictions:
                if c.get("type") == "factual_conflict":
                    priority = c
                    break
            if not priority:
                priority = max(contradictions, key=lambda c: c.get("severity", 0))

            task = cdl.generate_learning_task(priority)

            print(f"   Priority contradiction: [{priority.get('type')}] severity={priority.get('severity', 0):.2f}")
            print(f"   Levels involved: {priority.get('levels_involved', [])}")
            print(f"   → Action: {task['action']} targeting {task['target_levels']}")
            print(f"   → Strategy: {task['strategy'][:100]}...")

            # === ATTENTION FOCUS UPDATE ===
            # Redirect attention to the specific contradiction location
            # (simulates ACC-mediated attention reorienting in human cognition)
            self.lattice.update(concept_id, {
                "attention_focus": {
                    "target_contradiction": {
                        "type": priority.get("type"),
                        "levels_involved": priority.get("levels_involved", []),
                        "severity": priority.get("severity", 0),
                        "description": priority.get("description", "")[:100]
                    },
                    "target_gap": None,
                    "focus_level": min(1.0, priority.get("severity", 0) + 0.3)
                }
            })

            # === EPISTEMIC EMOTION UPDATE ===
            # Detecting a contradiction triggers "confusion" which drives learning
            concept = self.lattice.read(concept_id) or {}
            emotion_history = concept.get("epistemic_emotion", {}).get("history", [])
            emotion_history.append({
                "state": "confused",
                "intensity": min(1.0, max(0.5, priority.get("severity", 0))),
                "trigger": f"contradiction_detected:{priority.get('type')}",
                "timestamp": self._timestamp()
            })
            self.lattice.update(concept_id, {
                "epistemic_emotion": {
                    "current_state": "confused",
                    "intensity": min(1.0, max(0.5, priority.get("severity", 0))),
                    "history": emotion_history
                }
            })

            # Store contradiction as open problem in lattice
            problem = {
                "type": "contradiction",
                "description": priority.get("description", ""),
                "severity": priority.get("severity", 0),
                "levels_involved": priority.get("levels_involved", []),
                "resolution_hint": priority.get("resolution_hint", ""),
                "learning_action": task["action"],
                "target_levels": task["target_levels"],
                "created_at": self._timestamp()
            }

            concept = self.lattice.read(concept_id) or {}
            if "open_problems" not in concept:
                concept["open_problems"] = []
            concept["open_problems"].append(problem)
            self.lattice.update(concept_id, {"open_problems": concept["open_problems"]})

            # Update metacognitive memory
            self.metacognitive_memory.record_event(
                concept_id, "contradiction_detected",
                {
                    "contradiction_type": priority.get("type"),
                    "severity": priority.get("severity", 0),
                    "levels": priority.get("levels_involved", [])
                }
            )

            # Print contradiction-driven insight
            print(f"\n   💡 CONTRADICTION INSIGHT:")
            print(f"      '{priority.get('description', '')[:120]}...'")
            print(f"      Resolution direction: {priority.get('resolution_hint', '')[:100]}...")

        except Exception as e:
            print(f"   ⚠️  Contradiction handling failed: {e}")

    def _sanitize_id(self, concept: str) -> str:
        """Convert concept name to safe ID."""
        return "".join(c if c.isalnum() or c in "_-" else "_" for c in concept.lower())

    def _timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().isoformat()

    # ==================== CSED-CLIF v3.2 Fusion Methods ====================

    def run_v3(self, concept: str, trigger_type: str = "user_input",
               external_info: List[Dict] = None,
               failure_reason: str = None,
               max_iterations: int = None) -> Dict:
        """
        CSED-CLIF v3.2 unified entry point - fused TEACH → AUDIT → GROW cycle.

        Fusion architecture:
        Layer 0:   Trigger standardization
        Layer 0.5: Oscillation Initialization (v2.1 PHASE 0)
        Layer 1:   Metacognitive evaluation + Cognitive Classification (v3.0 + v2.1)
        Layer 2:   Genesis generation (D2→D3→D1→D4)
        Layer 3:   Multi-dimensional Verification (cross-temporal + independent + external)
        Layer 3.5: Contradiction Detection & Resolution (v2.1)
        Layer 3.6: GROW - targeted gap filling (v2.1)
        Layer 4:   Consolidation with exponential backoff scheduling
        Layer 5:   CASCADE - downstream re-audit trigger

        Iteration priority: contradictions > gaps > revise-retry
        Backward compatible: old run() calls route here automatically.
        """
        if not self.v3_mode:
            print("⚠️ v3.2 layers not fully initialized - falling back to v2.1 mode")
            return self.run(concept, max_iterations=max_iterations)

        print(f"\n{'='*60}")
        print(f"🎯 CSED-CLIF v3.2: '{concept}'")
        print(f"{'='*60}")

        concept_id = self._sanitize_id(concept)
        max_iter = max_iterations or self.config.get("max_iterations", 5)
        confidence_threshold = self.config.get("confidence_threshold", 0.7)

        # === LAYER 0.5: OSCILLATION INITIALIZATION ===
        concept_exists = self.lattice.read(concept_id) is not None
        if not concept_exists or trigger_type == "oscillation":
            print(f"\n{'='*60}")
            print(f"🌀 Layer 0.5: Oscillation Initialization")
            print(f"   Mapping: D1_quick → D4 → D1_reconstruct")
            print(f"{'='*60}")
            osc_result = self._oscillation_initialize(concept_id, concept)
            if osc_result.get("status") == "converged":
                print(f"\n✅ OSCILLATION CONVERGED: D1 structure stable after initialization")
                return {
                    "concept": concept,
                    "concept_id": concept_id,
                    "trigger_type": trigger_type,
                    "concept_type": None,
                    "decision": "deepen",
                    "iterations": [],
                    "iteration_count": 0,
                    "new_versions": osc_result.get("d1_versions"),
                    "verification": {"recommendation": "accept", "reason": "oscillation_converged"},
                    "consolidation": {"status": "consolidated", "interval_days": 1},
                    "v3_mode": True,
                    "status": "oscillation_converged"
                }

        # Layer 0: Standardize initial trigger
        trigger = self._standardize_trigger(concept_id, trigger_type, external_info, failure_reason)
        print(f"🔔 Layer 0: Trigger standardized ({trigger_type})")

        # === COGNITIVE CLASSIFICATION (runs once, used by all iterations) ===
        print("\n🧠 Cognitive Classification...")
        concept_type = self.cognitive_classifier.classify(concept_id)
        strategy = self.cognitive_classifier.get_strategy(concept_type)
        print(f"   Type: {concept_type} | Strategy: {strategy.get('name', 'default')}")

        iterations = []
        current_versions = None
        final_verification = None
        final_consolidation = None

        # === ITERATIVE TEACH → AUDIT → GROW LOOP ===
        for iteration in range(1, max_iter + 1):
            print(f"\n{'='*60}")
            print(f"🔄 Iteration {iteration}/{max_iter}")
            print(f"{'='*60}")

            # Layer 1: Metacognitive + Cognitive Classification
            decision = self._evaluate_metacognitive(trigger, concept_type)
            print(f"🧠 Layer 1: Decision = {decision} (type={concept_type})")

            if decision == "solidify":
                solidify_result = self._solidify_only(concept_id, trigger)
                solidify_result["iterations"] = iterations
                solidify_result["v3_mode"] = True
                solidify_result["concept_type"] = concept_type
                return solidify_result

            # Layer 2: Genesis generation
            print(f"\n🎙️ Layer 2: Genesis generation...")
            new_versions = self._genesis_generate(concept, concept_id)
            current_versions = new_versions
            self._store_v3_versions(concept_id, new_versions, iteration)

            # === LAYER 3: MULTI-DIMENSIONAL VERIFICATION ===
            print(f"\n🔍 Layer 3: Multi-dimensional verification...")

            # 3a: Cross-temporal audit (v3.0)
            print("   🕰️  Cross-temporal audit...")
            all_history = self._get_all_versions(concept_id)
            cross_temporal = self._verify_versions(concept_id, new_versions, all_history)
            print(f"      Result: {cross_temporal.get('recommendation', 'unknown')}")

            # 3b: Independent audit (v2.1)
            print("   🕵️  Independent audit...")
            independent = self.independent_auditor.audit_concept(concept_id, new_versions)
            ind_status = independent.get("status", "unknown")
            ind_gaps = independent.get("gaps", [])
            print(f"      Status: {ind_status} | Gaps: {len(ind_gaps)}")

            # 3c: External validation (v2.1)
            print("   🔍 External validation...")
            claims = self._extract_claims(new_versions)
            external_validated = self.validate_with_search(claims)
            valid_count = sum(1 for v in external_validated.values() if v)
            total_claims = len(claims)
            print(f"      Validated {valid_count}/{total_claims} claims")

            # 3d: Confidence calculation (v2.1)
            print("   📊 Confidence calculation...")
            confidence_result = self.confidence_calc.calculate(concept_id)
            confidence = confidence_result.get("overall_confidence", 0.0)
            print(f"      Confidence: {confidence:.3f} (target: {confidence_threshold})")

            # Aggregate all dimensions
            verification = self._aggregate_verification(
                cross_temporal, independent, external_validated, confidence_result
            )
            rec = verification.get("recommendation", "unknown")

            # Calculate v3 confidence metric
            v3_confidence = self._calculate_v3_confidence(concept_id, new_versions, verification)

            iteration_result = {
                "iteration": iteration,
                "decision": decision,
                "verification": {
                    "recommendation": rec,
                    "depth_delta": verification.get("depth_delta", 0.0),
                    "analogy_stability": verification.get("analogy_stability", 0.0),
                    "mapping_consistency": verification.get("mapping_consistency", 0.0),
                    "external_valid_ratio": verification.get("external_valid_ratio", 0.0),
                    "independent_status": independent.get("status", "unknown"),
                    "reason": verification.get("reason", "")[:200]
                },
                "confidence": v3_confidence,
                "status": rec
            }
            iterations.append(iteration_result)

            # === PERSIST CONFIDENCE TO LATTICE ===
            # v3.2 fix: confidence must be written to learning_curve so
            # MetacognitiveLayer can read it on next iteration's evaluation
            self.lattice.update_confidence(
                concept_id, v3_confidence,
                reason=f"v3.2 iteration {iteration} | {rec} | ext={verification.get('external_valid_ratio', 0):.2f}"
            )

            # === LAYER 3.5: CONTRADICTION DETECTION & RESOLUTION ===
            print(f"\n⚡ Layer 3.5: Contradiction detection...")
            contradictions = self._detect_contradictions(concept_id)
            if contradictions:
                print(f"   {len(contradictions)} contradictions found - priority resolution")
                self._handle_contradictions(concept_id, contradictions)
                # Update emotion and prepare re-trigger
                self.lattice.update(concept_id, {
                    "epistemic_emotion": {
                        "current_state": "confused",
                        "intensity": 0.8,
                        "history": [{"state": "confused", "intensity": 0.8, "trigger": "contradiction_found", "timestamp": self._timestamp()}]
                    }
                })
                trigger = self._standardize_trigger(
                    concept_id, "failure",
                    external_info=[{"reason": f"contradiction_iter_{iteration}", "detail": f"{len(contradictions)} contradictions resolved"}],
                    failure_reason=f"Contradictions resolved at iteration {iteration}: {len(contradictions)} found"
                )
                continue

            # === LAYER 3.6: GROW (targeted gap filling) ===
            print(f"\n🌱 Layer 3.6: Gap analysis & GROW...")
            if ind_gaps and confidence < confidence_threshold:
                gap_threshold = self.config.get("gap_threshold", 0.1)
                significant_gaps = [
                    g for g in ind_gaps
                    if g.get("severity", 0) >= gap_threshold * 10
                ]
                if significant_gaps:
                    print(f"   {len(significant_gaps)} significant gaps - targeted GROW")
                    for gap in significant_gaps[:3]:
                        print(f"   → {gap.get('type', 'unknown')}: {gap.get('description', '')[:60]}...")
                        growth_result = self.grow.grow(gap)
                        if growth_result.get("status") == "success":
                            print(f"     ✅ Gap filled")
                        else:
                            print(f"     ⚠️  Partial fill: {growth_result.get('error', 'unknown')}")
                    # Prepare re-trigger after growth
                    trigger = self._standardize_trigger(
                        concept_id, "propagation",
                        external_info=[{"reason": "gap_filled", "gaps_count": len(significant_gaps)}],
                        failure_reason=None
                    )
                    continue
                else:
                    print(f"   Gaps below threshold - skip GROW")
            else:
                print(f"   No significant gaps - skip GROW")

            # === v3.2 AUTO-CYCLE CHECKS (run_v3) ===
            contradictions = self._detect_contradictions(concept_id)
            auto_results = self._run_auto_cycle_checks(
                concept_id, v3_confidence, ind_gaps or [], contradictions,
                new_versions or {}, iterations
            )
            if auto_results["ming_wu"].get("passed"):
                rec = "accept"

            # === CONVERGENCE CHECKS ===

            # 1. Verification accepted → consolidate and exit
            if rec == "accept":
                print(f"\n📦 Layer 4: Consolidation...")
                consolidation = self._consolidate_result(concept_id, new_versions, verification)
                final_verification = verification
                final_consolidation = consolidation
                print(f"   Status: consolidated")
                print(f"   Next review: {consolidation.get('interval_days', 0)} days")

                # Layer 5: CASCADE - check if core definition changed
                print(f"\n🔗 Layer 5: Cascade check...")
                if self._has_core_definition_changed(concept_id, new_versions):
                    print(f"   Core definition changed - triggering cascade")
                    cascade_result = self.cascade.cascade(concept_id, reason="core_definition_changed")
                    affected = cascade_result.get("total_affected", 0)
                    print(f"   Cascade: {affected} downstream concepts flagged for re-audit")
                else:
                    print(f"   No core change - cascade skipped")

                print(f"\n✅ Iteration {iteration}: Verification ACCEPTED - cycle converged")
                break

            # 2. Stuck detection (no progress for 3 iterations)
            if self._is_v3_stuck(iterations):
                print(f"\n⚠️  STUCK: No progress for 3 iterations - exiting loop")
                break

            # 3. Rejection → prepare next iteration with failure trigger
            print(f"\n⚡ Verification REJECTED - preparing next iteration...")
            v_reason = verification.get("reason", "unknown")

            # Update epistemic emotion to confused
            self.lattice.update(concept_id, {
                "epistemic_emotion": {
                    "current_state": "confused",
                    "intensity": 0.75,
                    "history": [{"state": "confused", "intensity": 0.75, "trigger": "verification_rejected", "timestamp": self._timestamp()}]
                }
            })

            trigger = self._standardize_trigger(
                concept_id,
                "failure",
                external_info=[{
                    "reason": f"verification_rejected_iter_{iteration}",
                    "detail": v_reason[:200]
                }],
                failure_reason=f"Verification rejected at iteration {iteration}: {v_reason[:100]}"
            )

        else:
            # Loop completed without break (max iterations reached)
            print(f"\n⏹️  MAX ITERATIONS REACHED ({max_iter})")

        # === FINALIZE ===
        status = "completed" if (final_verification and final_verification.get("recommendation") == "accept") else "max_iterations"

        return {
            "concept": concept,
            "concept_id": concept_id,
            "trigger_type": trigger_type,
            "concept_type": concept_type,
            "decision": "deepen",
            "iterations": iterations,
            "iteration_count": len(iterations),
            "new_versions": current_versions,
            "verification": final_verification or verification,
            "consolidation": final_consolidation or {"status": "incomplete"},
            "v3_mode": True,
            "status": status
        }

    def _standardize_trigger(self, concept_id: str, trigger_type: str,
                            external_info: List[Dict], failure_reason: str) -> Dict:
        """Layer 0: Standardize any trigger into canonical TriggerEvent format."""
        return {
            "concept_id": concept_id,
            "type": trigger_type,
            "external_info": external_info or [],
            "failure_reason": failure_reason,
            "timestamp": self._timestamp()
        }

    def _evaluate_metacognitive(self, trigger: Dict, concept_type: str = None) -> str:
        """Layer 1: Evaluate whether to deepen or solidify.

        v3.2 enhancement: incorporates cognitive classification to adjust threshold.
        """
        concept_id = trigger["concept_id"]

        # Read current concept state
        concept = self.lattice.read(concept_id)
        if not concept:
            # New concept - always deepen
            return "deepen"

        # Determine adaptive threshold based on concept type
        base_threshold = self.config.get("confidence_threshold", 0.7)
        if concept_type:
            type_adjustments = {
                "mathematical": 0.15,    # Higher bar: math needs rigor
                "formal_system": 0.15,
                "empirical": -0.05,      # Lower bar: empirical tolerates approximation
                "biological": -0.05,
                "abstract": 0.0,         # Standard: abstract needs careful boundary work
                "engineering": 0.0,
                "default": 0.0
            }
            adjustment = type_adjustments.get(concept_type, 0.0)
            effective_threshold = min(0.95, base_threshold + adjustment)
        else:
            effective_threshold = base_threshold

        # Dimension 1: Epistemic emotion assessment
        emotion = concept.get("epistemic_emotion", {})
        current_state = emotion.get("current_state", "curious")
        intensity = emotion.get("intensity", 0.5)

        # High confusion or curiosity = deepen
        if current_state in ["confused", "curious"] and intensity > 0.6:
            return "deepen"

        # Dimension 2: Confidence trend vs adaptive threshold
        learning_curve = concept.get("learning_curve", [])
        if len(learning_curve) >= 2:
            recent = learning_curve[-3:]
            c1 = recent[-1].get("confidence", 0.0) if isinstance(recent[-1], dict) else 0.0
            c0 = recent[0].get("confidence", 0.0) if isinstance(recent[0], dict) else 0.0
            trend = c1 - c0
            if trend < -0.1:  # Declining confidence
                return "deepen"
            if c1 >= effective_threshold and current_state == "satisfied":
                return "solidify"

        # Dimension 3: Failure trigger
        if trigger.get("failure_reason"):
            return "deepen"

        # Dimension 4: External info available
        if trigger.get("external_info"):
            return "deepen"

        # Default: solidify if confidence is stable above threshold, else deepen
        last_conf = learning_curve[-1].get("confidence", 0.0) if learning_curve and isinstance(learning_curve[-1], dict) else 0.0
        if last_conf >= effective_threshold:
            return "solidify"
        return "deepen"

    def _solidify_only(self, concept_id: str, trigger: Dict) -> Dict:
        """Layer 1 alternative: Only solidify, no deepening."""
        concept = self.lattice.read(concept_id)
        if not concept:
            return {"status": "error", "message": "Concept not found"}

        # Update consolidation status
        consolidation_status = concept.get("consolidation_status", {})
        consolidation_status["stage"] = "solidified"
        consolidation_status["last_consolidated"] = self._timestamp()

        # Schedule next review
        if self.consolidation_layer:
            summary = self.consolidation_layer.get_consolidation_summary(concept_id)
            next_review = summary.get("next_review") if summary else None
        else:
            next_review = None

        self.lattice.update(concept_id, {"consolidation_status": consolidation_status})

        return {
            "concept_id": concept_id,
            "decision": "solidify",
            "status": "solidified",
            "next_review": next_review,
            "message": "Concept marked for solidification - no deepening needed"
        }

    def _genesis_generate(self, concept: str, concept_id: str) -> Dict:
        """Layer 2: Generate explanations using genesis order (D2→D3→D1→D4)."""
        # Use existing teach engine but force genesis order
        # Store genesis config temporarily
        old_config = getattr(self.teach, 'config', {})

        try:
            # Force genesis mode
            if hasattr(self.teach, 'config'):
                self.teach.config["genesis"] = {
                    "terrain_scan_enabled": True,
                    "strict_order": ["D2", "D3", "D1", "D4"],
                    "d1_based_on_d3": True,
                    "d4_problematize": True
                }

            # Generate using existing teach engine
            explanations = self.teach.teach(concept)

            # Normalize to standard version format
            versions = {}
            for level in ["D1", "D2", "D3", "D4"]:
                if level in explanations:
                    versions[level] = {
                        "explanation": explanations[level].get("explanation", ""),
                        "confidence": explanations[level].get("confidence", 0.0)
                    }

            return versions
        finally:
            # Restore original config
            if hasattr(self.teach, 'config') and old_config:
                self.teach.config = old_config

    def _get_all_versions(self, concept_id: str) -> Optional[List[Dict]]:
        """Get all historical versions from version_stack as a list."""
        concept = self.lattice.read(concept_id)
        if not concept:
            return None

        version_stack = concept.get("version_stack", [])
        if not version_stack:
            return None

        # Return all versions except the most recent (current iteration stores after generation)
        # Actually, we want all prior versions for cross-temporal audit
        all_versions = []
        for entry in version_stack:
            versions = entry.get("versions")
            if versions:
                all_versions.append(versions)
        return all_versions if all_versions else None

    def _aggregate_verification(self, cross_temporal: Dict, independent: Dict,
                                 external_validated: Dict, confidence_result: Dict) -> Dict:
        """
        Aggregate multi-dimensional verification results into unified verdict.

        Logic:
        - External validation < 50% → force 'revise' (grounding failure)
        - Independent audit failed + gaps present → 'revise'
        - Cross-temporal + independent + external all pass → 'accept'
        - Mixed results → weighted decision based on severity
        """
        ct_rec = cross_temporal.get("recommendation", "unknown")
        ind_status = independent.get("status", "unknown")
        ind_gaps = independent.get("gaps", [])
        ext_total = len(external_validated)
        ext_valid = sum(1 for v in external_validated.values() if v) if external_validated else 0
        ext_ratio = ext_valid / ext_total if ext_total > 0 else 1.0
        conf = confidence_result.get("overall_confidence", 0.0)

        reasons = []

        # Rule 1: External grounding failure is fatal
        if ext_total > 0 and ext_ratio < 0.5:
            reasons.append(f"External validation failed: {ext_valid}/{ext_total} claims verified")
            return {
                "recommendation": "revise",
                "depth_delta": cross_temporal.get("depth_delta", 0.0),
                "analogy_stability": cross_temporal.get("analogy_stability", 0.0),
                "mapping_consistency": cross_temporal.get("mapping_consistency", 0.0),
                "external_valid_ratio": ext_ratio,
                "independent_status": ind_status,
                "confidence": conf,
                "reason": "; ".join(reasons)
            }

        # Rule 2: Independent audit failure with gaps
        if ind_status != "passed" and len(ind_gaps) > 0:
            reasons.append(f"Independent audit found {len(ind_gaps)} gaps")

        # Rule 3: Cross-temporal rejection
        if ct_rec == "revise":
            reasons.append(cross_temporal.get("reason", "Cross-temporal audit rejected"))

        # Decision
        if not reasons and ct_rec == "accept":
            rec = "accept"
        else:
            rec = "revise"
            if not reasons:
                reasons.append("Cross-temporal audit pending or inconclusive")

        return {
            "recommendation": rec,
            "depth_delta": cross_temporal.get("depth_delta", 0.0),
            "analogy_stability": cross_temporal.get("analogy_stability", 0.0),
            "mapping_consistency": cross_temporal.get("mapping_consistency", 0.0),
            "external_valid_ratio": ext_ratio,
            "independent_status": ind_status,
            "confidence": conf,
            "reason": "; ".join(reasons) if reasons else "All dimensions passed"
        }

    def _store_v3_versions(self, concept_id: str, versions: Dict, iteration: int = None) -> None:
        """Store generated versions into lattice version_stack for next iteration's history."""
        concept = self.lattice.read(concept_id)

        if not concept:
            # Concept doesn't exist — create it first
            self.lattice.create(concept_id, {
                "version_stack": [],
                "learning_curve": []
            })
            concept = self.lattice.read(concept_id)

        version_stack = concept.get("version_stack", [])

        version_entry = {
            "timestamp": self._timestamp(),
            "versions": versions,
            "iteration": iteration
        }
        version_stack.append(version_entry)

        # Store full history (not just latest)
        self.lattice.update(concept_id, {"version_stack": version_stack})

    def _calculate_v3_confidence(self, concept_id: str, versions: Dict, verification: Dict) -> float:
        """Calculate confidence for this iteration based on verification metrics."""
        # Base confidence from verification scores
        depth_delta = verification.get("depth_delta", 0.0)
        analogy_stability = verification.get("analogy_stability", 0.0)
        mapping_consistency = verification.get("mapping_consistency", 0.0)

        if verification.get("recommendation") == "accept":
            base = 0.85
        elif verification.get("recommendation") == "revise":
            base = 0.50
        else:
            base = 0.30

        # Adjust by metrics
        adjusted = base + (depth_delta * 0.1) + (analogy_stability * 0.05) + (mapping_consistency * 0.05)
        return round(max(0.0, min(1.0, adjusted)), 3)

    def _is_v3_stuck(self, iterations: List[Dict]) -> bool:
        """Check if learning is stuck (no progress for 3 iterations)."""
        if len(iterations) < 3:
            return False

        recent = iterations[-3:]
        confidences = [it.get("confidence", 0.0) for it in recent]

        # Stuck = confidence essentially unchanged and all rejected
        max_c = max(confidences)
        min_c = min(confidences)
        all_rejected = all(it.get("status") == "revise" for it in recent)

        return (max_c - min_c < 0.05) and all_rejected

    def _verify_versions(self, concept_id: str, new_versions: Dict,
                         history: Optional[List[Dict]]) -> Dict:
        """Layer 3: Cross-temporal verification with fallback to standard audit."""
        if not self.verification_layer:
            # Fallback to standard audit — return metrics compatible with _aggregate_verification
            audit_report = self.audit.audit(concept_id, new_versions)
            status = audit_report.get("status", "unknown")
            gaps = audit_report.get("gaps", [])
            contradictions = audit_report.get("contradictions", [])

            # Estimate depth_delta: more gaps/contradictions = lower depth (regression)
            penalty = len(gaps) * 0.05 + len(contradictions) * 0.1
            depth_delta = max(0.0, 1.0 - penalty)

            # Estimate analogy_stability: passed = 0.7, otherwise degrade
            analogy_stability = 0.7 if status == "passed" else max(0.3, 0.7 - penalty)

            # Estimate mapping_consistency: passed = 1.0, otherwise degrade
            mapping_consistency = 1.0 if status == "passed" else max(0.3, 1.0 - penalty)

            rec = "accept" if status == "passed" else "revise"
            reason = audit_report.get("reason", f"Standard audit {status}")

            return {
                "recommendation": rec,
                "depth_delta": depth_delta,
                "analogy_stability": analogy_stability,
                "mapping_consistency": mapping_consistency,
                "reason": reason,
                "audit_report": audit_report
            }

        # Build history list for cross-temporal audit
        audit_history = []
        if history:
            audit_history.extend(history)

        return self.verification_layer.cross_temporal_audit(concept_id, new_versions, audit_history)

    def _consolidate_result(self, concept_id: str, new_versions: Dict,
                          verification: Dict) -> Dict:
        """Layer 4: Consolidation with exponential backoff scheduling."""
        if not self.consolidation_layer:
            # Fallback: basic lattice update
            self.lattice.update(concept_id, {
                "version_stack": [{"timestamp": self._timestamp(), "versions": new_versions}]
            })
            return {"status": "consolidated", "interval_days": 1}

        return self.consolidation_layer.consolidate(
            concept_id, new_versions, verification
        ).to_dict()

    # ==================== End CSED-CLIF v3.2 ====================


def main():
    parser = argparse.ArgumentParser(
        description="Feynman Orchestrator - Teach → Audit → Grow cycle"
    )
    parser.add_argument("concept", help="Concept to learn/audit")
    parser.add_argument("--max-iterations", type=int, default=5,
                       help="Maximum iterations (default: 5)")
    parser.add_argument("--confidence-threshold", type=float, default=0.7,
                       help="Confidence threshold to converge (default: 0.7)")
    parser.add_argument("--config", help="Config JSON file")
    parser.add_argument("--output", "-o", help="Output JSON file")

    parser.add_argument("--json", "-j", action="store_true",
                       help="Output as JSON")

    args = parser.parse_args()

    # Load config if provided
    config = None
    if args.config:
        with open(args.config, 'r') as f:
            config = json.load(f)

    # Run orchestrator
    orchestrator = FeynmanOrchestrator(config=config)
    result = orchestrator.run(
        args.concept,
        max_iterations=args.max_iterations,
        confidence_threshold=args.confidence_threshold
    )

    # Output
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    elif args.output:
        with open(args.output, 'w') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"\n💾 Result saved to {args.output}")
    else:
        print(f"\n📊 Final result:")
        print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

    def _tarski_stratification_check(self, concept_id: str, versions: dict) -> dict:
        """
        Tarski L1: Verify no self-reference at L0, no meta-meta at L1.
        Returns {"passed": bool, "violations": [...], "layer_map": {...}}
        """
        violations = []
        layer_map = {}
        
        # L0 = concept language (D1, D3 content) — must not reference own truth predicate
        l0_text = (versions.get("D1", {}).get("explanation", "") + 
                   versions.get("D3", {}).get("explanation", ""))
        if "I know that I know" in l0_text or "this statement is true" in l0_text:
            violations.append({"layer": "L0", "issue": "self_reference_in_object_language"})
        layer_map["L0"] = {"text_length": len(l0_text), "self_refs": l0_text.lower().count("i know")}
        
        # L1 = meta-language (D2, audit) — can reference L0 but not own truth
        l1_text = versions.get("D2", {}).get("explanation", "")
        if "this audit is correct" in l1_text or "I verify myself" in l1_text:
            violations.append({"layer": "L1", "issue": "self_reference_in_meta_language"})
        layer_map["L1"] = {"text_length": len(l1_text)}
        
        # L2 = meta-meta-language (D4 boundaries) — allowed to reference L1
        l2_text = versions.get("D4", {}).get("explanation", "")
        layer_map["L2"] = {"text_length": len(l2_text)}
        
        passed = len(violations) == 0
        return {"passed": passed, "violations": violations, "layer_map": layer_map}

