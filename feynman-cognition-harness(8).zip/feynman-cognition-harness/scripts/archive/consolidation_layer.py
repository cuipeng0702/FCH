#!/usr/bin/env python3
"""
Consolidation Layer — Layer 4 of CSED-CLIF v3.0

Stores verified versions, schedules next review with exponential backoff,
and triggers cascade propagation when concept deepening succeeds.

Usage:
    from scripts.consolidation_layer import ConsolidationLayer
    consolidator = ConsolidationLayer(lattice_manager)
    result = consolidator.consolidate("gradient_descent", new_versions, verification_result)
"""

import json
import os
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional


class ConsolidationResult:
    """Result of a consolidation operation."""
    
    def __init__(self, success: bool, concept_id: str, next_review: datetime,
                 interval_days: int, message: str):
        self.success = success
        self.concept_id = concept_id
        self.next_review = next_review
        self.interval_days = interval_days
        self.message = message
    
    def to_dict(self) -> Dict:
        return {
            "success": self.success,
            "concept_id": self.concept_id,
            "next_review": self.next_review.isoformat(),
            "interval_days": self.interval_days,
            "message": self.message
        }


class ConsolidationLayer:
    """
    Layer 4: Consolidation and Scheduling.
    
    Responsibilities:
    1. Store new verified versions to version_stack
    2. Update consolidation_status with timestamps
    3. Schedule next review with exponential backoff
    4. Trigger cascade propagation if deepening succeeded
    5. Update learning_curve with confidence trajectory
    """
    
    def __init__(self, lattice_manager=None, config: Dict = None):
        self.lattice = lattice_manager
        self.config = config or {}
        self.base_interval = self.config.get("base_interval_days", 1)
        self.max_interval = self.config.get("max_interval_days", 30)
        self.success_multiplier = self.config.get("success_multiplier", 2.0)
    
    def consolidate(self, concept_id: str, new_versions: Dict,
                    verification_result: Dict) -> ConsolidationResult:
        """
        Consolidate a verified deepening cycle.
        
        Args:
            concept_id: The concept being consolidated
            new_versions: Dict with D1-D4 explanations
            verification_result: Output from VerificationLayer
            
        Returns:
            ConsolidationResult with scheduling info
        """
        print(f"\n📦 CONSOLIDATION: '{concept_id}'")
        
        if not self.lattice:
            return ConsolidationResult(
                success=False,
                concept_id=concept_id,
                next_review=datetime.now(),
                interval_days=0,
                message="No lattice manager available"
            )
        
        # Read current concept state
        concept = self.lattice.read(concept_id)
        if not concept:
            return ConsolidationResult(
                success=False,
                concept_id=concept_id,
                next_review=datetime.now(),
                interval_days=0,
                message=f"Concept '{concept_id}' not found"
            )
        
        # Determine if verification passed
        verified = verification_result.get("recommendation", "reject") == "accept"
        
        # 1. Store new version to version_stack
        version_entry = {
            "timestamp": datetime.now().isoformat(),
            "versions": new_versions,
            "verification": verification_result,
            "verified": verified
        }
        
        version_stack = concept.get("version_stack", [])
        version_stack.append(version_entry)
        
        # 2. Update learning_curve
        current_confidence = self._extract_confidence(new_versions)
        learning_curve = concept.get("learning_curve", [])
        learning_curve.append({
            "timestamp": datetime.now().isoformat(),
            "confidence": current_confidence,
            "verified": verified
        })
        
        # 3. Calculate next review interval with exponential backoff
        success_count = self._count_successes(version_stack)
        interval_days = self._calculate_interval(verified, success_count)
        next_review = datetime.now() + timedelta(days=interval_days)
        
        # 4. Update consolidation_status
        consolidation_status = {
            "stage": "consolidated" if verified else "needs_revision",
            "last_consolidated": datetime.now().isoformat(),
            "next_review_scheduled": next_review.isoformat(),
            "degradation_detected": not verified,
            "success_count": success_count,
            "failure_count": self._count_failures(version_stack)
        }
        
        # 5. Update epistemic_emotion based on result
        emotion = concept.get("epistemic_emotion", {})
        if verified:
            emotion["current_state"] = "confident"
            emotion["intensity"] = min(1.0, emotion.get("intensity", 0.5) + 0.1)
        else:
            emotion["current_state"] = "confused"
            emotion["intensity"] = min(1.0, emotion.get("intensity", 0.5) + 0.15)
        emotion["history"].append({
            "timestamp": datetime.now().isoformat(),
            "state": emotion["current_state"],
            "trigger": "consolidation"
        })
        
        # 6. Apply all updates
        updates = {
            "version_stack": [version_entry],
            "learning_curve": [{
                "timestamp": datetime.now().isoformat(),
                "confidence": current_confidence,
                "verified": verified
            }],
            "consolidation_status": consolidation_status,
            "epistemic_emotion": emotion
        }
        
        self.lattice.update(concept_id, updates)
        
        # 7. If verified, trigger cascade for downstream concepts
        cascade_triggered = False
        if verified:
            cascade_triggered = self._trigger_cascade(concept_id, new_versions)
        
        message = f"Consolidated (verified={verified}, next_review={interval_days}d)"
        if cascade_triggered:
            message += " + cascade triggered"
        
        print(f"   {message}")
        
        return ConsolidationResult(
            success=True,
            concept_id=concept_id,
            next_review=next_review,
            interval_days=interval_days,
            message=message
        )
    
    def _extract_confidence(self, versions: Dict) -> float:
        """Extract overall confidence from version data."""
        confidences = []
        for level in ["D1", "D2", "D3", "D4"]:
            level_data = versions.get(level, {})
            if isinstance(level_data, dict):
                conf = level_data.get("confidence", 0.0)
                if isinstance(conf, (int, float)):
                    confidences.append(conf)
        
        return sum(confidences) / len(confidences) if confidences else 0.0
    
    def _count_successes(self, version_stack: List[Dict]) -> int:
        """Count verified versions in stack."""
        return sum(1 for v in version_stack if v.get("verified", False))
    
    def _count_failures(self, version_stack: List[Dict]) -> int:
        """Count non-verified versions in stack."""
        return sum(1 for v in version_stack if not v.get("verified", False))
    
    def _calculate_interval(self, verified: bool, success_count: int) -> int:
        """
        Calculate next review interval with exponential backoff.
        
        Success: interval doubles (up to max)
        Failure: reset to base interval
        """
        if not verified:
            return self.base_interval
        
        interval = self.base_interval * (self.success_multiplier ** success_count)
        return min(int(interval), self.max_interval)
    
    def _trigger_cascade(self, concept_id: str, new_versions: Dict) -> bool:
        """
        Trigger cascade propagation to downstream concepts.
        
        Returns True if cascade was triggered.
        """
        try:
            # Try to import and use CascadeEngine
            from scripts.cascade import CascadeEngine
            cascade = CascadeEngine(self.lattice)
            
            # Push propagation event to trigger daemon if available
            try:
                from scripts.trigger_daemon import TriggerDaemon
                daemon = TriggerDaemon()
                dependents = cascade.get_dependents(concept_id)
                for dependent in dependents:
                    daemon.push_event({
                        "type": "propagation",
                        "concept_id": dependent,
                        "source_concept": concept_id,
                        "priority": "medium",
                        "timestamp": datetime.now().isoformat()
                    })
                return len(dependents) > 0
            except ImportError:
                # Fallback: just update downstream directly
                cascade.propagate(concept_id, new_versions)
                return True
                
        except ImportError:
            print(f"   Warning: CascadeEngine not available")
            return False
    
    def get_due_reviews(self) -> List[Dict]:
        """
        Get all concepts with due reviews.
        
        Returns:
            List of concept records with due next_review_scheduled
        """
        if not self.lattice:
            return []
        
        due_concepts = []
        now = datetime.now()
        
        # Try to get all concepts from lattice
        try:
            all_concepts = self.lattice.list_all()
            for concept in all_concepts:
                status = concept.get("consolidation_status", {})
                next_review_str = status.get("next_review_scheduled")
                if next_review_str:
                    next_review = datetime.fromisoformat(next_review_str)
                    if next_review <= now:
                        due_concepts.append({
                            "concept_id": concept.get("core_id"),
                            "next_review": next_review_str,
                            "stage": status.get("stage"),
                            "success_count": status.get("success_count", 0)
                        })
        except AttributeError:
            # lattice.list_all() not available
            pass
        
        return due_concepts
    
    def get_consolidation_summary(self, concept_id: str) -> Optional[Dict]:
        """Get consolidation summary for a concept."""
        if not self.lattice:
            return None
        
        concept = self.lattice.read(concept_id)
        if not concept:
            return None
        
        status = concept.get("consolidation_status", {})
        version_stack = concept.get("version_stack", [])
        learning_curve = concept.get("learning_curve", [])
        
        return {
            "concept_id": concept_id,
            "stage": status.get("stage", "unknown"),
            "last_consolidated": status.get("last_consolidated"),
            "next_review": status.get("next_review_scheduled"),
            "version_count": len(version_stack),
            "verified_count": self._count_successes(version_stack),
            "latest_confidence": learning_curve[-1].get("confidence", 0.0) if learning_curve else 0.0,
            "confidence_trend": self._calculate_trend(learning_curve)
        }
    
    def _calculate_trend(self, learning_curve: List[Dict]) -> str:
        """Calculate confidence trend from learning curve."""
        if len(learning_curve) < 2:
            return "stable"
        
        recent = learning_curve[-5:] if len(learning_curve) >= 5 else learning_curve
        values = [entry.get("confidence", 0.0) for entry in recent]
        
        if len(values) < 2:
            return "stable"
        
        # Simple linear trend
        delta = values[-1] - values[0]
        if delta > 0.1:
            return "improving"
        elif delta < -0.1:
            return "declining"
        else:
            return "stable"


# CLI
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Consolidation Layer")
    parser.add_argument("command", choices=["summary", "due"])
    parser.add_argument("--concept-id", help="Concept ID for summary")
    parser.add_argument("--lattice-path", default="~/.openclaw/workspace/knowledge-lattice/")
    
    args = parser.parse_args()
    
    from scripts.lattice_manager import LatticeManager
    lattice = LatticeManager(args.lattice_path)
    consolidator = ConsolidationLayer(lattice)
    
    if args.command == "summary" and args.concept_id:
        summary = consolidator.get_consolidation_summary(args.concept_id)
        print(json.dumps(summary, indent=2, ensure_ascii=False))
    elif args.command == "due":
        due = consolidator.get_due_reviews()
        print(json.dumps(due, indent=2, ensure_ascii=False))

    def dream_cycle_v3(self, memory_buffer: list, batch_size: int = 7) -> dict:
        """
        Tripartite sleep-inspired consolidation (Robinson et al. 2022 + DreamNet Ni & Liu 2024)
        Phase 1: NREM — veridical replay of salient memories
        Phase 2: REM — generative reconstruction via frozen encoder
        Phase 3: Synaptic downscaling — prune weak associations (p=0.75)
        """
        import random
        
        # Phase 1: NREM veridical replay
        salient = sorted(memory_buffer, key=lambda m: m.get("salience", 0), reverse=True)[:batch_size]
        replayed = [dict(m) for m in salient]
        
        # Phase 2: REM generative replay (simplified: feature recombination)
        dreams = []
        if len(replayed) >= 2:
            for i in range(len(replayed)):
                # Recombine features from two memories
                other = replayed[(i + 1) % len(replayed)]
                dream = {
                    "source_a": replayed[i].get("concept_id", "unknown"),
                    "source_b": other.get("concept_id", "unknown"),
                    "recombined_features": list(set(
                        replayed[i].get("features", []) + other.get("features", [])
                    )),
                    "dream_stage": random.randint(1, 3),
                    "is_generative": True
                }
                dreams.append(dream)
        
        # Phase 3: Synaptic downscaling (prune low-salience memories)
        threshold = sorted([m.get("salience", 0) for m in memory_buffer])[int(len(memory_buffer) * 0.25)]
        pruned = [m for m in memory_buffer if m.get("salience", 0) >= threshold]
        
        # Dream quality: measure via reconstruction coherence
        coherence = len(dreams) / max(len(replayed), 1) if replayed else 0.0
        
        return {
            "nrem_replayed": len(replayed),
            "rem_dreams": len(dreams),
            "pruned_count": len(memory_buffer) - len(pruned),
            "retained_count": len(pruned),
            "dream_coherence": round(coherence, 3),
            "pruning_threshold": round(threshold, 3)
        }

