#!/usr/bin/env python3
"""
Independent Auditor — Uses subagent for unbiased evaluation.

This module spawns a fresh subagent to perform audit and confidence
calculation, ensuring the evaluator is not contaminated by the main
agent's prior assumptions or reasoning patterns.

Usage:
    from scripts.independent_auditor import IndependentAuditor
    auditor = IndependentAuditor()
    result = auditor.audit_concept("transformer_attention")
"""

import json
import os
import sys
import subprocess
from typing import Dict, List, Optional

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.lattice_manager import LatticeManager


class IndependentAuditor:
    """
    Spawns a fresh subagent to perform unbiased audit.
    
    Key principle: The auditor must NOT share the main agent's
    context or reasoning traces. It receives only:
    - The concept's current explanations (D1-D4)
    - The raw lattice data
    - A structured audit prompt
    
    The subagent returns:
    - Gap analysis (what's missing or wrong)
    - Confidence assessment
    - Contradiction detection
    - Recommendations
    """
    
    def __init__(self, lattice_path: str = None):
        self.lattice = LatticeManager(base_path=lattice_path)
    
    def audit_concept(self, concept_id: str, 
                      explanations: Dict = None) -> Dict:
        """
        Perform independent audit using a subagent.
        
        Args:
            concept_id: Concept to audit
            explanations: Current D1-D4 explanations (optional)
            
        Returns:
            Audit report with gaps, confidence, contradictions
        """
        # Get concept data if not provided
        if not explanations:
            concept_data = self.lattice.read(concept_id)
            if not concept_data:
                return {
                    "status": "error",
                    "error": f"Concept {concept_id} not found",
                    "gaps": [],
                    "confidence": 0,
                    "contradictions": []
                }
            explanations = self._extract_explanations(concept_data)
        
        # Build audit prompt for subagent
        audit_prompt = self._build_audit_prompt(concept_id, explanations)
        
        # Spawn subagent for independent evaluation
        # In production, this calls sessions_spawn
        # For now, we simulate with a local heuristic
        result = self._local_heuristic_audit(concept_id, explanations)
        
        return result
    
    def _extract_explanations(self, concept_data: Dict) -> Dict:
        """Extract D1-D4 explanations from lattice data."""
        versions = concept_data.get("version_stack", [])
        explanations = {}
        
        for v in versions:
            level = v.get("level", "unknown")
            content = v.get("content", "")
            confidence = v.get("confidence", 0.5)
            
            explanations[level] = {
                "explanation": content,
                "confidence": confidence,
                "assumed_knowledge": v.get("metadata", {}).get("assumed_knowledge", []),
                "dependencies": v.get("metadata", {}).get("dependencies", [])
            }
        
        return explanations
    
    def _build_audit_prompt(self, concept_id: str, explanations: Dict) -> str:
        """Build structured prompt for subagent auditor."""
        prompt = f"""# Independent Audit Task

You are an objective, critical evaluator. You have NO prior context about this concept.
Your job is to find gaps, contradictions, and weaknesses.

## Concept: {concept_id}

### D1 Explanation (8-year-old level):
{explanations.get('D1', {}).get('explanation', 'N/A')}

### D2 Explanation (middle-schooler level):
{explanations.get('D2', {}).get('explanation', 'N/A')}

### D3 Explanation (university level):
{explanations.get('D3', {}).get('explanation', 'N/A')}

### D4 Explanation (expert level):
{explanations.get('D4', {}).get('explanation', 'N/A')}

## Your Task

1. **Gap Analysis**: What critical aspects are missing or unclear?
2. **Contradiction Detection**: Do the four versions contradict each other?
3. **Confidence Assessment**: Rate confidence (0-1) across dimensions:
   - Internal consistency
   - External validity (can claims be verified?)
   - Coverage completeness
   - Explanation quality
4. **Recommendations**: What should be improved?

## Output Format

Return ONLY a JSON object:
```json
{{
  "gaps": [
    {{
      "type": "missing_foundation|oversimplification|circular|crisis",
      "severity": 1-10,
      "description": "What's missing",
      "affected_level": "D1|D2|D3|D4"
    }}
  ],
  "contradictions": [
    {{
      "between": "D1 and D3",
      "description": "What contradicts",
      "severity": 1-10
    }}
  ],
  "confidence": {{
    "overall": 0.0-1.0,
    "dimensions": {{
      "internal_consistency": 0.0-1.0,
      "external_validity": 0.0-1.0,
      "coverage": 0.0-1.0,
      "quality": 0.0-1.0
    }}
  }},
  "recommendations": ["specific action 1", "specific action 2"]
}}
```

Be CRITICAL. Assume the explanations are flawed until proven otherwise.
"""
        return prompt
    
    def _spawn_auditor(self, prompt: str, concept_id: str, 
                       explanations: Dict) -> Dict:
        """
        Spawn a subagent for independent audit.
        
        In production, this uses sessions_spawn.
        For testing, we use a local heuristic fallback.
        """
        # Try to spawn subagent via OpenClaw
        try:
            return self._spawn_subagent(prompt, concept_id)
        except Exception as e:
            print(f"   ⚠️ Subagent spawn failed ({e}), using local heuristic")
            return self._local_heuristic_audit(concept_id, explanations)
    
    def _spawn_subagent(self, prompt: str, concept_id: str) -> Dict:
        """
        Spawn a subagent via OpenClaw sessions_spawn.
        
        This is the production implementation.
        """
        # Build the task for subagent
        task = f"""You are an independent auditor. You have no prior context.

{prompt}

Read the concept lattice from {self.lattice.base_path}/concepts/{concept_id}.json
if it exists, then perform the audit.

Return your audit result as a JSON file at:
/tmp/audit_{concept_id}.json
"""
        
        # In actual implementation, this would call:
        # sessions_spawn(task=task, runtime="subagent")
        # For now, we simulate
        raise NotImplementedError("Subagent spawning requires OpenClaw runtime")
    
    def _local_heuristic_audit(self, concept_id: str, 
                               explanations: Dict) -> Dict:
        """
        Local heuristic audit when subagent is unavailable.
        
        This is a fallback that simulates critical evaluation
        without the main agent's biases.
        """
        gaps = []
        contradictions = []
        
        # Check if all levels exist
        for level in ["D1", "D2", "D3", "D4"]:
            if level not in explanations:
                gaps.append({
                    "type": "missing_foundation",
                    "severity": 9,
                    "description": f"{level} explanation is missing",
                    "affected_level": level
                })
        
        # Check D1 for technical terms (basic heuristic)
        d1 = explanations.get("D1", {}).get("explanation", "")
        if d1:
            technical_indicators = [
                "algorithm", "derivative", "gradient", "neural", 
                "backpropagation", "transformer", "attention"
            ]
            for term in technical_indicators:
                if term.lower() in d1.lower():
                    gaps.append({
                        "type": "oversimplification",
                        "severity": 7,
                        "description": f"D1 contains technical term: '{term}'",
                        "affected_level": "D1"
                    })
        
        # Check for contradictions between levels
        # Check for contradictions between levels
        d1_content = explanations.get("D1", {}).get("explanation", "")
        d2_content = explanations.get("D2", {}).get("explanation", "")
        d3_content = explanations.get("D3", {}).get("explanation", "")
        d4_content = explanations.get("D4", {}).get("explanation", "")
        
        # D1 vs D4: oversimplification check
        if d1_content and d4_content:
            d1_simple_words = ["easy", "simple", "just", "like"]
            d4_complex_words = ["complex", "complicated", "difficult", "advanced"]
            
            d1_has_simple = any(w in d1_content.lower() for w in d1_simple_words)
            d4_has_complex = any(w in d4_content.lower() for w in d4_complex_words)
            
            if d1_has_simple and d4_has_complex:
                contradictions.append({
                    "between": "D1 and D4",
                    "description": "D1 oversimplifies what D4 describes as complex",
                    "severity": 6
                })
        
        # D2 vs D3: operational vs formal consistency
        if d2_content and d3_content:
            # Check if D3 contradicts D2's operational description
            d2_operational = any(w in d2_content.lower() for w in ["step", "first", "then", "next", "finally"])
            d3_formal = any(w in d3_content.lower() for w in ["theorem", "lemma", "proof", "formally"])
            
            if d2_operational and not d3_formal:
                # Not necessarily a contradiction, but a gap in formal grounding
                gaps.append({
                    "type": "missing_foundation",
                    "severity": 5,
                    "description": "D3 lacks formal grounding for D2's operational description",
                    "affected_level": "D3"
                })
        
        # D3 vs D4: boundary consistency
        if d3_content and d4_content:
            d3_claims = ["always", "never", "must", "guarantee"]
            d4_boundaries = ["except", "unless", "when", "only if", "limitation"]
            
            d3_has_absolute = any(w in d3_content.lower() for w in d3_claims)
            d4_has_boundary = any(w in d4_content.lower() for w in d4_boundaries)
            
            if d3_has_absolute and d4_has_boundary:
                contradictions.append({
                    "between": "D3 and D4",
                    "description": "D3 makes absolute claims that D4 qualifies with boundaries",
                    "severity": 7
                })
        
        # Calculate confidence
        gap_penalty = len(gaps) * 0.1
        contradiction_penalty = len(contradictions) * 0.15
        base_confidence = 1.0 - gap_penalty - contradiction_penalty
        confidence = max(0.0, min(1.0, base_confidence))
        
        # Generate recommendations
        recommendations = []
        if gaps:
            # Group by affected level for clearer recommendations
            d1_gaps = [g for g in gaps if g.get("affected_level") == "D1"]
            d2_gaps = [g for g in gaps if g.get("affected_level") == "D2"]
            d3_gaps = [g for g in gaps if g.get("affected_level") == "D3"]
            d4_gaps = [g for g in gaps if g.get("affected_level") == "D4"]
            
            if d1_gaps:
                recommendations.append(f"Fix D1: {len(d1_gaps)} issues (technical terms, clarity)")
            if d2_gaps:
                recommendations.append(f"Fix D2: {len(d2_gaps)} issues (examples, operational detail)")
            if d3_gaps:
                recommendations.append(f"Fix D3: {len(d3_gaps)} issues (math formalization, derivations)")
            if d4_gaps:
                recommendations.append(f"Fix D4: {len(d4_gaps)} issues (boundaries, open problems)")
        
        if contradictions:
            recommendations.append(f"Resolve {len(contradictions)} contradictions between levels")
        
        if not explanations.get("D1"):
            recommendations.append("Create D1 explanation with visual metaphor")
        if not explanations.get("D2"):
            recommendations.append("Create D2 explanation with concrete example")
        if not explanations.get("D3"):
            recommendations.append("Create D3 explanation with math formalization")
        if not explanations.get("D4"):
            recommendations.append("Create D4 explanation with boundaries and open problems")
        
        return {
            "status": "completed",
            "method": "local_heuristic",  # Indicates fallback mode
            "gaps": gaps,
            "contradictions": contradictions,
            "confidence": {
                "overall": round(confidence, 3),
                "dimensions": {
                    "internal_consistency": round(max(0, confidence - 0.1), 3),
                    "external_validity": 0.5,  # Cannot verify without search
                    "coverage": round(max(0, 1.0 - len(gaps) * 0.15), 3),
                    "quality": round(max(0, confidence - 0.05), 3)
                }
            },
            "recommendations": recommendations,
            "auditor": "independent_heuristic"  # Marks this as independent evaluation
        }


def main():
    """CLI for independent audit."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Independent Auditor — Unbiased evaluation via subagent"
    )
    parser.add_argument("concept", help="Concept to audit")
    parser.add_argument("--lattice-path", help="Path to concept lattice")
    parser.add_argument("--json", "-j", action="store_true",
                       help="Output as JSON")
    
    args = parser.parse_args()
    
    auditor = IndependentAuditor(lattice_path=args.lattice_path)
    result = auditor.audit_concept(args.concept)
    
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"\n🔍 Independent Audit: {args.concept}")
        print(f"   Status: {result['status']}")
        print(f"   Method: {result['method']}")
        print(f"   Confidence: {result['confidence']['overall']}")
        print(f"   Gaps: {len(result['gaps'])}")
        print(f"   Contradictions: {len(result['contradictions'])}")
        
        if result['gaps']:
            print(f"\n   Gaps:")
            for g in result['gaps'][:5]:
                print(f"      [{g['severity']}/10] {g['type']}: {g['description']}")
        
        if result['recommendations']:
            print(f"\n   Recommendations:")
            for r in result['recommendations']:
                print(f"      → {r}")


if __name__ == "__main__":
    main()
