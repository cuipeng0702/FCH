#!/usr/bin/env python3
"""
Trigger Daemon — Layer 0 of CSED-CLIF v3.0

Background trigger scanner that monitors four trigger types:
- time: scheduled reviews due
- info: external information available
- failure: verification failed, needs revision
- propagation: upstream concept changed, downstream needs review

Usage:
    from scripts.trigger_daemon import TriggerDaemon, TriggerEvent
    daemon = TriggerDaemon()
    daemon.start()  # Start background scanning
    daemon.push_event(TriggerEvent(...))  # Manual event injection
"""

import json
import os
import sys
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum


class TriggerType(Enum):
    TIME = "time"
    INFO = "info"
    FAILURE = "failure"
    PROPAGATION = "propagation"


class Priority(Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class TriggerEvent:
    """A trigger event that can wake up the cognitive system."""
    type: TriggerType
    concept_id: str
    priority: Priority = Priority.MEDIUM
    source_concept: Optional[str] = None
    external_info: Optional[Dict] = None
    failure_reason: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "type": self.type.value,
            "concept_id": self.concept_id,
            "priority": self.priority.value,
            "source_concept": self.source_concept,
            "external_info": self.external_info,
            "failure_reason": self.failure_reason,
            "timestamp": self.timestamp,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "TriggerEvent":
        return cls(
            type=TriggerType(data.get("type", "time")),
            concept_id=data["concept_id"],
            priority=Priority(data.get("priority", "medium")),
            source_concept=data.get("source_concept"),
            external_info=data.get("external_info"),
            failure_reason=data.get("failure_reason"),
            timestamp=data.get("timestamp", datetime.now().isoformat()),
            metadata=data.get("metadata", {})
        )


class TriggerDaemon:
    """
    Layer 0: Trigger Detection and Event Queue.
    
    Responsibilities:
    1. Scan for time-based triggers (scheduled reviews)
    2. Accept external info triggers
    3. Accept failure triggers from VerificationLayer
    4. Accept propagation triggers from CascadeEngine
    5. Maintain priority queue of pending triggers
    6. Feed triggers to MetacognitiveLayer for evaluation
    """
    
    def __init__(self, lattice_manager=None, config: Dict = None):
        self.lattice = lattice_manager
        self.config = config or {}
        self.scan_interval = self.config.get("scan_interval_minutes", 60)
        self.max_concurrent = self.config.get("max_concurrent_reviews", 3)
        self.running = False
        self.thread = None
        
        # Event queue storage
        self.queue_path = os.path.expanduser(
            "~/.openclaw/workspace/knowledge-lattice/trigger_queue.json"
        )
        self._ensure_queue_storage()
        
        # Active processing set (deduplication)
        self.active_reviews = set()
    
    def _ensure_queue_storage(self):
        """Create queue storage if not exists."""
        os.makedirs(os.path.dirname(self.queue_path), exist_ok=True)
        if not os.path.exists(self.queue_path):
            self._save_queue([])
    
    def _load_queue(self) -> List[Dict]:
        """Load pending events from queue."""
        try:
            with open(self.queue_path, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []
    
    def _save_queue(self, queue: List[Dict]):
        """Save pending events to queue."""
        with open(self.queue_path, 'w') as f:
            json.dump(queue, f, indent=2)
    
    def push_event(self, event: TriggerEvent):
        """
        Push an event to the trigger queue.
        
        This is the primary interface for:
        - CascadeEngine (propagation events)
        - ContradictionDetector (failure events)
        - External systems (info events)
        - Time scanner (time events)
        """
        queue = self._load_queue()
        
        # Deduplicate: if same concept+type already pending, update
        existing_idx = None
        for i, e in enumerate(queue):
            if e["concept_id"] == event.concept_id and e["type"] == event.type.value:
                existing_idx = i
                break
        
        event_dict = event.to_dict()
        if existing_idx is not None:
            # Update with higher priority if needed
            old_priority = queue[existing_idx].get("priority", "medium")
            new_priority = event_dict["priority"]
            if self._priority_rank(new_priority) > self._priority_rank(old_priority):
                queue[existing_idx] = event_dict
        else:
            queue.append(event_dict)
        
        self._save_queue(queue)
        print(f"🔔 Trigger queued: {event.type.value} -> {event.concept_id} ({event.priority.value})")
    
    def pop_event(self) -> Optional[TriggerEvent]:
        """
        Pop highest priority event from queue.
        
        Returns None if queue is empty or max_concurrent reached.
        """
        if len(self.active_reviews) >= self.max_concurrent:
            return None
        
        queue = self._load_queue()
        if not queue:
            return None
        
        # Sort by priority, then timestamp
        priority_order = {"high": 0, "medium": 1, "low": 2}
        queue.sort(key=lambda e: (
            priority_order.get(e.get("priority", "medium"), 1),
            e.get("timestamp", "")
        ))
        
        event = queue.pop(0)
        self._save_queue(queue)
        
        # Track active review
        self.active_reviews.add(event["concept_id"])
        
        return TriggerEvent.from_dict(event)
    
    def complete_review(self, concept_id: str):
        """Mark a review as complete."""
        self.active_reviews.discard(concept_id)
    
    def _priority_rank(self, priority: str) -> int:
        """Convert priority string to numeric rank."""
        ranks = {"high": 2, "medium": 1, "low": 0}
        return ranks.get(priority, 1)
    
    def scan_time_triggers(self) -> List[TriggerEvent]:
        """
        Scan for time-based triggers (scheduled reviews that are due).
        
        Returns list of time trigger events.
        """
        if not self.lattice:
            return []
        
        triggers = []
        now = datetime.now()
        
        try:
            # Try to get all concepts
            all_concepts = self.lattice.list_all() if hasattr(self.lattice, 'list_all') else []
            
            for concept in all_concepts:
                status = concept.get("consolidation_status", {})
                next_review_str = status.get("next_review_scheduled")
                
                if next_review_str:
                    next_review = datetime.fromisoformat(next_review_str)
                    if next_review <= now and concept.get("core_id") not in self.active_reviews:
                        triggers.append(TriggerEvent(
                            type=TriggerType.TIME,
                            concept_id=concept.get("core_id"),
                            priority=Priority.MEDIUM,
                            metadata={"scheduled_time": next_review_str}
                        ))
        except Exception as e:
            print(f"Warning: Error scanning time triggers: {e}")
        
        return triggers
    
    def start(self):
        """Start background trigger scanning."""
        if self.running:
            print("TriggerDaemon already running")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._scan_loop, daemon=True)
        self.thread.start()
        print(f"🔔 TriggerDaemon started (scan_interval={self.scan_interval}m)")
    
    def stop(self):
        """Stop background trigger scanning."""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        print("🔔 TriggerDaemon stopped")
    
    def _scan_loop(self):
        """Background scanning loop."""
        while self.running:
            try:
                # Scan for time triggers
                triggers = self.scan_time_triggers()
                for trigger in triggers:
                    self.push_event(trigger)
                
                # Sleep for scan interval
                time.sleep(self.scan_interval * 60)
            except Exception as e:
                print(f"Error in trigger scan loop: {e}")
                time.sleep(60)  # Sleep 1 min on error
    
    def get_queue_status(self) -> Dict:
        """Get current queue status."""
        queue = self._load_queue()
        return {
            "pending_count": len(queue),
            "active_reviews": len(self.active_reviews),
            "max_concurrent": self.max_concurrent,
            "running": self.running,
            "scan_interval": self.scan_interval,
            "pending_events": queue[:10]  # Show first 10
        }
    
    def clear_queue(self):
        """Clear all pending events."""
        self._save_queue([])
        self.active_reviews.clear()


# CLI
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Trigger Daemon")
    parser.add_argument("command", choices=["status", "start", "stop", "clear"])
    parser.add_argument("--lattice-path", default="~/.openclaw/workspace/knowledge-lattice/")
    parser.add_argument("--concept-id", help="Concept ID for manual trigger")
    parser.add_argument("--type", choices=["time", "info", "failure", "propagation"], default="time")
    parser.add_argument("--priority", choices=["high", "medium", "low"], default="medium")
    
    args = parser.parse_args()
    
    from scripts.lattice_manager import LatticeManager
    lattice = LatticeManager(args.lattice_path)
    daemon = TriggerDaemon(lattice)
    
    if args.command == "status":
        status = daemon.get_queue_status()
        print(json.dumps(status, indent=2, ensure_ascii=False))
    elif args.command == "start":
        daemon.start()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            daemon.stop()
    elif args.command == "stop":
        daemon.stop()
    elif args.command == "clear":
        daemon.clear_queue()
        print("Queue cleared")
    
    # Manual trigger injection
    if args.concept_id and args.command != "status":
        event = TriggerEvent(
            type=TriggerType(args.type),
            concept_id=args.concept_id,
            priority=Priority(args.priority)
        )
        daemon.push_event(event)
        print(f"Manual trigger pushed: {args.type} -> {args.concept_id}")
