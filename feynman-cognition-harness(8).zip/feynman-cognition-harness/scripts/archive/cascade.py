#!/usr/bin/env python3
"""
Cascade Engine v2 — Decoupled + Semantic + Daemon

Key changes from v1:
  1. Decoupled trigger: cascade detection happens at LatticeManager.update(),
     not just orchestrator.run(). Any concept modification triggers cascade.
  2. SemanticDiff: embedding-based similarity replaces string comparison
     for "core definition changed" detection.
  3. CascadeDaemon: independent scanner that periodically processes
     cascade_flag=true concepts without waiting for orchestrator.

Usage:
    # In lattice_manager.update() — auto-triggered
    from scripts.cascade import CascadeTrigger
    trigger = CascadeTrigger()
    trigger.on_concept_update(concept_id, old_data, new_data)

    # Daemon mode
    from scripts.cascade import CascadeDaemon
    daemon = CascadeDaemon(check_interval=300)
    daemon.start()  # Runs in background, processes pending re-audits
"""

import argparse
import json
import sys
import os
import threading
import time
from typing import Dict, List, Set, Optional
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.lattice_manager import LatticeManager


class SemanticDiff:
    """
    Detect meaningful semantic changes in concept definitions.
    
    Uses Jaccard similarity on token sets as a lightweight proxy.
    Can be upgraded to embedding cosine similarity when embeddings available.
    """

    def __init__(self, threshold: float = 0.3):
        """
        Args:
            threshold: Jaccard distance below which change is considered "core".
                       Lower = stricter. Default 0.3 means >70% overlap = no core change.
        """
        self.threshold = threshold

    def _tokenize(self, text: str) -> Set[str]:
        """Extract clean tokens from text."""
        import re
        text = text.lower()
        text = re.sub(r'[^a-z0-9_\s]', ' ', text)
        tokens = {t.strip('_') for t in text.split() if len(t.strip('_')) > 2}
        return tokens

    def is_core_change(self, old_text: str, new_text: str) -> bool:
        """
        Determine if text change is a "core definition change" worthy of cascade.
        
        Uses Jaccard distance: 1 - |A∩B| / |A∪B|
        If distance > threshold, it's a core change.
        """
        old_tokens = self._tokenize(old_text)
        new_tokens = self._tokenize(new_text)

        if not old_tokens and not new_tokens:
            return False
        if not old_tokens or not new_tokens:
            return True  # Any addition to/from empty is a change

        intersection = old_tokens & new_tokens
        union = old_tokens | new_tokens
        jaccard_sim = len(intersection) / len(union)
        jaccard_dist = 1 - jaccard_sim

        return jaccard_dist > self.threshold

    def compare_concepts(self, old_concept: Dict, new_concept: Dict) -> Dict:
        """
        Full concept comparison across D1-D4 + dependency chain.
        Returns detailed diff report.
        """
        old_versions = old_concept.get("version_stack", [])
        new_versions = new_concept.get("version_stack", [])

        # Compare all D-levels (D1-D4)
        level_changes = {}
        any_level_changed = False
        for level in ["D1", "D2", "D3", "D4"]:
            old_content = next((v.get("content", "") for v in old_versions if v.get("level") == level), "")
            new_content = next((v.get("content", "") for v in new_versions if v.get("level") == level), "")
            changed = self.is_core_change(old_content, new_content)
            level_changes[level] = {
                "changed": changed,
                "jaccard_distance": self._jaccard_distance(old_content, new_content) if old_content or new_content else 0.0
            }
            if changed:
                any_level_changed = True

        # Compare confidence
        old_conf = old_concept.get("confidence", 0)
        new_conf = new_concept.get("confidence", 0)
        confidence_delta = new_conf - old_conf

        # Compare dependencies
        old_deps = set(old_concept.get("dependency_chain", []))
        new_deps = set(new_concept.get("dependency_chain", []))
        deps_added = list(new_deps - old_deps)
        deps_removed = list(old_deps - new_deps)

        # Cross-level contradiction detection
        contradictions = []
        try:
            from scripts.contradiction_detector import CrossLevelContradictionDetector
            detector = CrossLevelContradictionDetector()
            # Detect in new concept (current state)
            new_contradictions = detector.detect(new_concept)
            # Detect in old concept for comparison
            old_contradictions = detector.detect(old_concept)
            # New contradictions that weren't there before
            new_types = {json.dumps(c, sort_keys=True) for c in new_contradictions}
            old_types = {json.dumps(c, sort_keys=True) for c in old_contradictions}
            contradictions = [c for c in new_contradictions 
                            if json.dumps(c, sort_keys=True) not in old_types]
        except Exception:
            pass  # Contradiction detection is optional

        return {
            "d1_changed": level_changes.get("D1", {}).get("changed", False),
            "any_level_changed": any_level_changed,
            "level_changes": level_changes,
            "confidence_delta": confidence_delta,
            "deps_added": deps_added,
            "deps_removed": deps_removed,
            "contradictions": contradictions,
            "is_core_change": any_level_changed or len(deps_added) > 0 or len(deps_removed) > 0,
        }

    def _jaccard_distance(self, old_text: str, new_text: str) -> float:
        """Calculate Jaccard distance between two texts."""
        old_tokens = self._tokenize(old_text)
        new_tokens = self._tokenize(new_text)
        if not old_tokens and not new_tokens:
            return 0.0
        if not old_tokens or not new_tokens:
            return 1.0
        intersection = old_tokens & new_tokens
        union = old_tokens | new_tokens
        return 1 - len(intersection) / len(union)


class CascadeTrigger:
    """
    Decoupled cascade trigger. Can be called from anywhere (LatticeManager,
    orchestrator, CLI, or external events).
    """

    def __init__(self, lattice_path: str = None, max_depth: int = 3, semantic_threshold: float = 0.3):
        self.lattice = LatticeManager(lattice_path)
        self.max_depth = max_depth
        self.semantic_diff = SemanticDiff(threshold=semantic_threshold)
        self._update_buffer = []  # Batch pending for efficiency

    def on_concept_update(self, concept_id: str, old_concept: Dict = None, new_concept: Dict = None, reason: str = "auto") -> Dict:
        """
        Entry point: called whenever a concept is updated.
        
        Args:
            concept_id: The concept that was updated
            old_concept: Previous state (optional — will fetch if not provided)
            new_concept: New state (optional — will fetch if not provided)
            reason: Why the update happened

        Returns:
            Cascade report or {"status": "skipped", "reason": "..."}
        """
        # Fetch if not provided
        if new_concept is None:
            new_concept = self.lattice.read(concept_id)
        if old_concept is None:
            # Try to reconstruct from version history or assume minimal
            old_concept = {"version_stack": [], "confidence": 0, "dependency_chain": []}

        if not new_concept:
            return {"status": "error", "message": f"Concept '{concept_id}' not found"}

        # Determine if this is a core change worth cascading
        diff = self.semantic_diff.compare_concepts(old_concept, new_concept)

        if not diff["is_core_change"]:
            return {
                "status": "skipped",
                "reason": "no_core_change",
                "jaccard_distance": diff.get("jaccard_distance", 0),
                "concept_id": concept_id
            }

        # Execute cascade
        return self._execute_cascade(concept_id, reason=reason, diff=diff)

    def _execute_cascade(self, concept_id: str, reason: str, diff: Dict) -> Dict:
        """Internal: BFS propagation to dependents."""
        affected = self._find_affected(concept_id, self.max_depth)

        # If contradictions detected, propagate them as high-priority
        contradictions = diff.get("contradictions", [])
        contradiction_severity = max((c.get("severity", 0) for c in contradictions), default=0)

        cascade_report = {
            "status": "success",
            "trigger_concept": concept_id,
            "reason": reason,
            "semantic_diff": diff,
            "max_depth": self.max_depth,
            "timestamp": self._timestamp(),
            "total_affected": len(affected),
            "levels": {},
            "contradictions": contradictions,
            "contradiction_severity": contradiction_severity
        }

        for item in affected:
            depth = item["depth"]
            if depth not in cascade_report["levels"]:
                cascade_report["levels"][depth] = []
            cascade_report["levels"][depth].append(item)

        # Mark affected concepts for re-audit
        executed = []
        for item in affected:
            result = self._mark_for_reaudit(item, reason, diff)
            executed.append(result)
        cascade_report["executed"] = executed

        # v3.0: Push propagation events to TriggerDaemon for downstream concepts
        self._push_to_trigger_daemon(affected, contradictions)

        # Also mark the trigger concept itself if it has contradictions
        if contradictions:
            self._mark_self_for_contradiction_resolution(concept_id, contradictions)

        return cascade_report

    def _push_to_trigger_daemon(self, affected: List[Dict], contradictions: List[Dict]) -> None:
        """Push cascade propagation events to TriggerDaemon queue."""
        try:
            from scripts.trigger_daemon import TriggerDaemon, TriggerEvent, Priority
            daemon = TriggerDaemon()
            for item in affected:
                dep_id = item["concept_id"]
                priority = Priority.HIGH if contradictions else Priority.MEDIUM
                daemon.push_event(TriggerEvent(
                    type=TriggerEvent.from_dict({"type": "propagation", "concept_id": dep_id}).type,
                    concept_id=dep_id,
                    priority=priority,
                    source_concept=item.get("triggered_by"),
                    metadata={"cascade_depth": item.get("depth", 0)}
                ))
        except Exception as e:
            # TriggerDaemon is optional — silently skip if unavailable
            pass

    def _mark_self_for_contradiction_resolution(self, concept_id: str, contradictions: List[Dict]) -> None:
        """Mark the trigger concept itself for contradiction-driven learning."""
        concept = self.lattice.read(concept_id)
        if not concept:
            return

        if "pending_actions" not in concept:
            concept["pending_actions"] = []

        # Find the highest-severity contradiction
        priority = max(contradictions, key=lambda c: c.get("severity", 0))
        action_type = priority.get("type")

        # Deduplicate: don't add if same contradiction type already pending
        existing_types = {
            a.get("contradiction_type") for a in concept["pending_actions"]
            if a.get("action") == "contradiction_resolve"
        }
        if action_type in existing_types:
            return

        concept["pending_actions"].append({
            "action": "contradiction_resolve",
            "triggered_by": concept_id,
            "reason": "cross_level_contradiction_detected",
            "contradiction_type": action_type,
            "severity": priority.get("severity"),
            "levels_involved": priority.get("levels_involved"),
            "resolution_hint": priority.get("resolution_hint"),
            "triggered_at": self._timestamp()
        })

        self.lattice.update(concept_id, {
            "pending_actions": concept["pending_actions"],
            "cascade_flag": True
        })

    def _find_affected(self, concept_id: str, max_depth: int) -> List[Dict]:
        """BFS to find all dependent concepts."""
        visited = {concept_id: 0}
        queue = [(concept_id, 0)]
        affected = []

        while queue:
            current_id, current_depth = queue.pop(0)
            if current_depth >= max_depth:
                continue

            dependents = self.lattice.get_dependents(current_id)
            for dep_id in dependents:
                if dep_id not in visited:
                    visited[dep_id] = current_depth + 1
                    queue.append((dep_id, current_depth + 1))
                    affected.append({
                        "concept_id": dep_id,
                        "depth": current_depth + 1,
                        "triggered_by": current_id,
                        "reason": f"depends on {current_id}",
                        "action": "re_audit"
                    })

        return sorted(affected, key=lambda x: x["depth"])

    def _mark_for_reaudit(self, item: Dict, trigger_reason: str, diff: Dict) -> Dict:
        """Mark a concept with cascade flag and pending action."""
        concept_id = item["concept_id"]
        concept = self.lattice.read(concept_id)
        if not concept:
            return {"concept_id": concept_id, "status": "failed", "error": "Concept not found"}

        if "pending_actions" not in concept:
            concept["pending_actions"] = []

        concept["pending_actions"].append({
            "action": "re_audit",
            "triggered_by": item["triggered_by"],
            "reason": trigger_reason,
            "cascade_depth": item["depth"],
            "semantic_diff": diff,
            "triggered_at": self._timestamp()
        })

        self.lattice.update(concept_id, {
            "pending_actions": concept["pending_actions"],
            "cascade_flag": True
        })

        return {
            "concept_id": concept_id,
            "status": "success",
            "action": "marked_for_reaudit",
            "triggered_by": item["triggered_by"],
            "depth": item["depth"]
        }
    
    def oscillation_trigger(self, concept_id: str, d1_structure_changed: bool = True) -> Dict:
        """
        Trigger oscillation initialization for downstream concepts when
        a concept's D1 structure is significantly reconstructed.
        
        This propagates the oscillation pattern (D1_quick -> D4 -> D1_reconstruct)
        to dependent concepts, ensuring their D1 analogies remain aligned
        with the updated upstream concept.
        
        Args:
            concept_id: The concept whose D1 structure changed
            d1_structure_changed: Whether D1 structure actually changed (vs just content)
            
        Returns:
            Dict with affected concepts and oscillation triggers
        """
        if not d1_structure_changed:
            return {"status": "skipped", "reason": "D1 structure unchanged"}
        
        affected = self._find_affected(concept_id, self.max_depth)
        
        triggered = []
        for item in affected:
            dep_id = item["concept_id"]
            concept = self.lattice.read(dep_id)
            if not concept:
                continue
            
            if "pending_actions" not in concept:
                concept["pending_actions"] = []
            
            # Add oscillation initialization action
            concept["pending_actions"].append({
                "action": "oscillation_initialize",
                "triggered_by": concept_id,
                "reason": "upstream_d1_structure_changed",
                "cascade_depth": item["depth"],
                "triggered_at": self._timestamp()
            })
            
            self.lattice.update(dep_id, {
                "pending_actions": concept["pending_actions"],
                "cascade_flag": True
            })
            
            triggered.append({
                "concept_id": dep_id,
                "depth": item["depth"],
                "action": "oscillation_initialize"
            })
        
        return {
            "status": "success",
            "trigger_concept": concept_id,
            "triggered_count": len(triggered),
            "triggered": triggered,
            "message": f"Oscillation triggered for {len(triggered)} downstream concepts"
        }
    
    def metaphor_family_linkage(self, concept_id: str, metaphor_family: str = None) -> Dict:
        """
        Link concepts that share the same metaphor family for coordinated updates.
        
        When a concept's master analogy is updated, other concepts using the same
        metaphor family may need their analogies reviewed for consistency.
        
        Args:
            concept_id: The concept whose metaphor was updated
            metaphor_family: The metaphor family (e.g., "walking", "team", "water")
            
        Returns:
            Dict with linked concepts and linkage status
        """
        if not metaphor_family:
            # Try to extract from concept data
            concept = self.lattice.read(concept_id)
            if concept:
                metaphor_family = concept.get("metaphor_family", None)
        
        if not metaphor_family:
            return {"status": "skipped", "reason": "No metaphor family specified"}
        
        # Find all concepts with same metaphor family
        linked = []
        # In production, this would query the lattice index
        # For now, scan all concepts
        concepts_dir = os.path.join(self.lattice_path, "concepts")
        if os.path.exists(concepts_dir):
            for filename in os.listdir(concepts_dir):
                if not filename.endswith(".json"):
                    continue
                other_id = filename[:-5]
                if other_id == concept_id:
                    continue
                    
                other_concept = self.lattice.read(other_id)
                if other_concept and other_concept.get("metaphor_family") == metaphor_family:
                    linked.append(other_id)
                    
                    # Mark for metaphor review
                    if "pending_actions" not in other_concept:
                        other_concept["pending_actions"] = []
                    
                    other_concept["pending_actions"].append({
                        "action": "metaphor_review",
                        "triggered_by": concept_id,
                        "reason": "shared_metaphor_family_updated",
                        "metaphor_family": metaphor_family,
                        "triggered_at": self._timestamp()
                    })
                    
                    self.lattice.update(other_id, {
                        "pending_actions": other_concept["pending_actions"],
                        "cascade_flag": True
                    })
        
        return {
            "status": "success",
            "trigger_concept": concept_id,
            "metaphor_family": metaphor_family,
            "linked_count": len(linked),
            "linked_concepts": linked,
            "message": f"Metaphor family linkage: {len(linked)} concepts linked via '{metaphor_family}'"
        }

    def _timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().isoformat()


class CascadeDaemon:
    """
    Independent background daemon that scans for cascade_flag=true concepts
    and auto-processes pending re-audits.
    
    Usage:
        daemon = CascadeDaemon(check_interval=300)  # 5 minutes
        daemon.start()  # Non-blocking, starts background thread
        # ... later ...
        daemon.stop()
    """

    def __init__(self, lattice_path: str = None, check_interval: int = 300,
                 max_reaudit_per_cycle: int = 5, auto_callback=None):
        """
        Args:
            check_interval: Seconds between scans
            max_reaudit_per_cycle: Max concepts to process per scan
            auto_callback: Function(concept_id) -> None, called for each re-audit.
                           If None, just logs. Orchestrator can pass its audit function.
        """
        self.lattice = LatticeManager(lattice_path)
        self.check_interval = check_interval
        self.max_reaudit = max_reaudit_per_cycle
        self.auto_callback = auto_callback
        self._running = False
        self._thread = None
        self._history = []

    def start(self):
        """Start daemon in background thread."""
        if self._running:
            return {"status": "already_running"}
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        return {"status": "started", "interval": self.check_interval}

    def stop(self):
        """Stop daemon."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        return {"status": "stopped"}

    def _run_loop(self):
        """Main loop."""
        while self._running:
            self._process_cycle()
            time.sleep(self.check_interval)

    def _process_cycle(self) -> Dict:
        """One scan + process cycle."""
        pending = self._get_pending_reaudits()
        processed = []

        for item in pending[:self.max_reaudit]:
            concept_id = item["concept_id"]

            if self.auto_callback:
                try:
                    self.auto_callback(concept_id)
                    status = "callback_executed"
                except Exception as e:
                    status = f"callback_failed: {e}"
            else:
                status = "flagged_no_callback"

            # Clear cascade flag regardless of callback success
            self._clear_cascade_flag(concept_id)

            processed.append({
                "concept_id": concept_id,
                "status": status,
                "depth": item["highest_depth"],
                "confidence": item["confidence"]
            })

        cycle_report = {
            "timestamp": self._timestamp(),
            "pending_total": len(pending),
            "processed": len(processed),
            "details": processed
        }
        self._history.append(cycle_report)
        return cycle_report

    def _get_pending_reaudits(self) -> List[Dict]:
        """Get all concepts with cascade_flag=true."""
        all_concepts = self.lattice.list_all()
        pending = []

        for concept in all_concepts:
            full = self.lattice.read(concept["id"])
            if full and full.get("cascade_flag"):
                pending_actions = full.get("pending_actions", [])
                reaudit_actions = [a for a in pending_actions if a.get("action") == "re_audit"]
                if reaudit_actions:
                    pending.append({
                        "concept_id": concept["id"],
                        "confidence": concept.get("confidence", 0),
                        "pending_actions": reaudit_actions,
                        "highest_depth": max(a.get("cascade_depth", 0) for a in reaudit_actions)
                    })

        # Sort by depth (deepest first) then by confidence
        return sorted(pending, key=lambda x: (-x["highest_depth"], x["confidence"]))

    def _clear_cascade_flag(self, concept_id: str) -> Dict:
        """Clear cascade flag after processing."""
        concept = self.lattice.read(concept_id)
        if not concept:
            return {"status": "error", "message": f"Concept '{concept_id}' not found"}

        pending = concept.get("pending_actions", [])
        pending = [a for a in pending if a.get("action") != "re_audit"]

        self.lattice.update(concept_id, {
            "pending_actions": pending,
            "cascade_flag": False
        })
        return {"status": "success", "remaining_actions": len(pending)}

    def get_history(self) -> List[Dict]:
        return self._history

    def _timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().isoformat()


# ═══════════════════════════════════════════════════════════════
# Backward compatibility: CascadeEngine wraps new primitives
# ═══════════════════════════════════════════════════════════════

class CascadeEngine:
    """
    v1-compatible interface. Internally delegates to CascadeTrigger + Daemon.
    """

    def __init__(self, lattice_path: str = None, max_depth: int = 3):
        self.trigger = CascadeTrigger(lattice_path=lattice_path, max_depth=max_depth)
        self.history = []

    def cascade(self, concept_id: str, reason: str = "core_definition_changed",
                  dry_run: bool = False) -> Dict:
        """v1-compatible cascade() method."""
        if dry_run:
            # Dry run: only report what would happen, don't mark
            concept = self.trigger.lattice.read(concept_id)
            if not concept:
                return {"status": "error", "message": f"Concept '{concept_id}' not found"}
            affected = self.trigger._find_affected(concept_id, self.trigger.max_depth)
            return {
                "status": "dry_run",
                "trigger_concept": concept_id,
                "reason": reason,
                "total_affected": len(affected),
                "levels": self._group_by_depth(affected)
            }

        # Use trigger with minimal diff (assume significant change)
        result = self.trigger.on_concept_update(
            concept_id,
            reason=reason
        )
        self.history.append(result)
        return result

    def _group_by_depth(self, affected: List[Dict]) -> Dict:
        levels = {}
        for item in affected:
            d = item["depth"]
            if d not in levels:
                levels[d] = []
            levels[d].append(item)
        return levels

    def get_pending_reaudits(self) -> List[Dict]:
        """v1-compatible."""
        return CascadeDaemon(
            lattice_path=self.trigger.lattice.base_path
        )._get_pending_reaudits()

    def clear_cascade_flag(self, concept_id: str) -> Dict:
        """v1-compatible."""
        return CascadeDaemon(
            lattice_path=self.trigger.lattice.base_path
        )._clear_cascade_flag(concept_id)

    def detect_cycles(self, concept_id: str) -> List[List[str]]:
        """v1-compatible cycle detection."""
        cycles = []
        visited = set()
        path = []

        def dfs(current_id):
            if current_id in path:
                cycle_start = path.index(current_id)
                cycle = path[cycle_start:] + [current_id]
                cycles.append(cycle)
                return
            if current_id in visited:
                return
            visited.add(current_id)
            path.append(current_id)
            deps = self.trigger.lattice.get_dependencies(current_id)
            for dep in deps:
                dfs(dep)
            path.pop()

        dfs(concept_id)
        return cycles


# ═══════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Cascade Engine v2")
    parser.add_argument("command", choices=["trigger", "daemon", "pending", "clear"],
                        help="Command to run")
    parser.add_argument("--concept", help="Concept ID (for trigger/clear)")
    parser.add_argument("--reason", default="manual", help="Trigger reason")
    parser.add_argument("--dry-run", action="store_true", help="Dry run (trigger only)")
    parser.add_argument("--interval", type=int, default=300, help="Daemon check interval (seconds)")
    parser.add_argument("--output", "-o", help="Output JSON file")

    args = parser.parse_args()

    if args.command == "trigger":
        if not args.concept:
            print("Error: --concept required for trigger")
            sys.exit(1)
        trigger = CascadeTrigger()
        result = trigger.on_concept_update(args.concept, reason=args.reason)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "pending":
        daemon = CascadeDaemon()
        pending = daemon._get_pending_reaudits()
        print(json.dumps({"pending_count": len(pending), "items": pending},
                         indent=2, ensure_ascii=False))

    elif args.command == "clear":
        if not args.concept:
            print("Error: --concept required for clear")
            sys.exit(1)
        daemon = CascadeDaemon()
        result = daemon._clear_cascade_flag(args.concept)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "daemon":
        daemon = CascadeDaemon(check_interval=args.interval)
        print(f"Starting cascade daemon (interval={args.interval}s)...")
        daemon.start()
        try:
            while True:
                time.sleep(60)
                hist = daemon.get_history()
                if hist:
                    last = hist[-1]
                    print(f"[{last['timestamp']}] Processed {last['processed']}/{last['pending_total']} pending re-audits")
        except KeyboardInterrupt:
            daemon.stop()
            print("Daemon stopped.")


if __name__ == "__main__":
    main()
