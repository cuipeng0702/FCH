# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
Lattice Manager — Concept Lattice CRUD operations.

Usage:
    python lattice_manager.py <command> [options]
    
Commands:
    create <concept_id>    Create new concept node
    read <concept_id>      Read concept node
    update <concept_id>    Update concept node (from JSON file)
    delete <concept_id>    Delete concept node
    list                   List all concepts
    search <query>         Search concepts
    
Example:
    python lattice_manager.py create "transformer_attention" --from-file concept.json
    python lattice_manager.py list
"""

import argparse
import json
import sys
import os
from typing import Dict, List, Optional


class LatticeManager:
    """
    Manages the Concept Lattice persistence layer.
    
    Storage structure:
    ~/.openclaw/workspace/knowledge-lattice/
    ├── concepts/
    │   ├── {concept_id}.json
    │   └── index.json
    ├── audit-logs/
    │   └── {timestamp}-{concept_id}.json
    ├── learning-curves/
    │   └── {concept_id}-curve.json
    └── open-problems/
        └── queue.json
    """
    
    def __init__(self, base_path: str = None):
        raw_path = base_path or "~/.openclaw/workspace/knowledge-lattice/"
        self.base_path = os.path.expanduser(raw_path)
        self._ensure_directories()
    
    def _ensure_directories(self) -> None:
        """Create necessary directory structure."""
        dirs = ["concepts", "audit-logs", "learning-curves", "open-problems"]
        for d in dirs:
            os.makedirs(os.path.join(self.base_path, d), exist_ok=True)
    
    def _timestamp(self) -> str:
        """Return ISO 8601 timestamp."""
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).isoformat()
    
    def create(self, concept_id: str, concept_data: Dict = None) -> Dict:
        """
        Create a new concept node.
        
        Args:
            concept_id: Unique identifier (should be snake_case)
            concept_data: Initial concept data. If None, uses template.
            
        Returns:
            Created concept node
        """
        filepath = self._concept_path(concept_id)
        
        if os.path.exists(filepath):
            return {
                "status": "error",
                "message": f"Concept '{concept_id}' already exists",
                "path": filepath
            }
        
        # Use template if no data provided
        if concept_data is None:
            concept_data = self._load_template()
        
        # Set metadata
        concept_data["core_id"] = concept_id
        concept_data["created_at"] = self._timestamp()
        concept_data["updated_at"] = self._timestamp()
        concept_data["version"] = 1
        
        # Ensure required fields
        defaults = {
            "version_stack": [],
            "dependencies": [],
            "downstream_concepts": [],
            "confidence": 0.0,
            "contradictions": [],
            "open_problems": [],
            "audit_history": [],
            "learning_curve": [],
            "pending_actions": [],
            "cascade_flag": False,
            "epistemic_emotion": {
                "current_state": "curious",
                "intensity": 0.5,
                "history": []
            },
            "attention_focus": {
                "target_contradiction": None,
                "target_gap": None,
                "focus_level": 0.0
            },
            "consolidation_status": {
                "stage": "pending",
                "last_consolidated": None,
                "next_review_scheduled": None,
                "degradation_detected": False
            }
        }
        
        for key, value in defaults.items():
            if key not in concept_data:
                concept_data[key] = value
        
        # Save
        with open(filepath, 'w') as f:
            json.dump(concept_data, f, indent=2, ensure_ascii=False)
        
        # Update index
        self._update_index(concept_id, "add")
        
        return {
            "status": "success",
            "concept_id": concept_id,
            "path": filepath,
            "data": concept_data
        }
    
    def read(self, concept_id: str) -> Optional[Dict]:
        """Read a concept node."""
        filepath = self._concept_path(concept_id)
        
        if not os.path.exists(filepath):
            return None
        
        with open(filepath, 'r') as f:
            return json.load(f)
    
    def update(self, concept_id: str, updates: Dict) -> Dict:
        """
        Update a concept node.
        
        Args:
            concept_id: Concept to update
            updates: Dict of fields to update
            
        Returns:
            Updated concept node
        """
        concept = self.read(concept_id)
        
        if not concept:
            return {
                "status": "error",
                "message": f"Concept '{concept_id}' not found"
            }
        
        # Apply updates
        for key, value in updates.items():
            if key in ["version_stack", "dependencies", "downstream_concepts",
                      "contradictions", "open_problems", "audit_history", "learning_curve"]:
                # Append to list fields
                if isinstance(value, list):
                    concept[key].extend(value)
                else:
                    concept[key].append(value)
            else:
                concept[key] = value
        
        # Update metadata
        concept["updated_at"] = self._timestamp()
        concept["version"] = concept.get("version", 0) + 1
        
        # Save
        filepath = self._concept_path(concept_id)
        with open(filepath, 'w') as f:
            json.dump(concept, f, indent=2, ensure_ascii=False)
        
        # === CASCADE TRIGGER (decoupled) ===
        # Any concept update may trigger downstream re-audit if core definition changed
        self._maybe_trigger_cascade(concept_id, concept, "update")
        
        return {
            "status": "success",
            "concept_id": concept_id,
            "version": concept["version"],
            "data": concept
        }
    
    def delete(self, concept_id: str) -> Dict:
        """Delete a concept node."""
        filepath = self._concept_path(concept_id)
        
        if not os.path.exists(filepath):
            return {
                "status": "error",
                "message": f"Concept '{concept_id}' not found"
            }
        
        # Backup before delete
        backup_path = filepath + ".backup"
        os.rename(filepath, backup_path)
        
        # Update index
        self._update_index(concept_id, "remove")
        
        return {
            "status": "success",
            "concept_id": concept_id,
            "backup": backup_path
        }
    
    def list_all(self) -> List[Dict]:
        """List all concepts with summary."""
        concepts_dir = os.path.join(self.base_path, "concepts")
        concepts = []
        
        for filename in os.listdir(concepts_dir):
            if filename.endswith('.json') and filename != 'index.json':
                concept_id = filename[:-5]  # Remove .json
                concept = self.read(concept_id)
                if concept:
                    concepts.append({
                        "id": concept_id,
                        "confidence": concept.get("confidence", 0),
                        "version": concept.get("version", 0),
                        "updated_at": concept.get("updated_at", ""),
                        "gap_count": len(concept.get("open_problems", [])),
                        "dependency_count": len(concept.get("dependencies", []))
                    })
        
        return sorted(concepts, key=lambda x: x["confidence"])
    
    def search(self, query: str) -> List[Dict]:
        """Search concepts by keyword."""
        all_concepts = self.list_all()
        query_lower = query.lower()
        
        results = []
        for concept in all_concepts:
            # Search in concept data
            full_concept = self.read(concept["id"])
            text_to_search = json.dumps(full_concept, ensure_ascii=False).lower()
            
            if query_lower in text_to_search:
                # Calculate relevance score
                relevance = text_to_search.count(query_lower)
                concept["relevance"] = relevance
                results.append(concept)
        
        return sorted(results, key=lambda x: x.get("relevance", 0), reverse=True)
    
    def update_confidence(self, concept_id: str, new_confidence: float, reason: str = "") -> Dict:
        """
        Update concept confidence with audit trail.
        
        Confidence rules:
        - Only increases through successful audit
        - Never manually set without justification
        """
        if not 0 <= new_confidence <= 1:
            return {
                "status": "error",
                "message": "Confidence must be between 0 and 1"
            }
        
        concept = self.read(concept_id)
        if not concept:
            return {"status": "error", "message": f"Concept '{concept_id}' not found"}
        
        old_confidence = concept.get("confidence", 0)
        
        # Add to learning curve
        curve_point = {
            "timestamp": self._timestamp(),
            "old_confidence": old_confidence,
            "new_confidence": new_confidence,
            "confidence": new_confidence,  # v3.2: alias for metacognitive layer compatibility
            "reason": reason,
            "gap_count": len(concept.get("open_problems", []))
        }
        
        concept["learning_curve"].append(curve_point)
        concept["confidence"] = new_confidence
        concept["updated_at"] = self._timestamp()
        
        # Save
        filepath = self._concept_path(concept_id)
        with open(filepath, 'w') as f:
            json.dump(concept, f, indent=2, ensure_ascii=False)
        
        return {
            "status": "success",
            "concept_id": concept_id,
            "old_confidence": old_confidence,
            "new_confidence": new_confidence,
            "delta": new_confidence - old_confidence
        }
    
    def add_version(self, concept_id: str, level: str, explanation: str, 
                    confidence: float, metadata: Dict = None) -> Dict:
        """Add a new version to the version stack."""
        concept = self.read(concept_id)
        if not concept:
            return {"status": "error", "message": f"Concept '{concept_id}' not found"}
        
        version_entry = {
            "level": level,
            "content": explanation,
            "confidence": confidence,
            "created_at": self._timestamp(),
            "metadata": metadata or {}
        }
        
        # Remove old version at same level if exists
        concept["version_stack"] = [
            v for v in concept["version_stack"] 
            if v.get("level") != level
        ]
        
        concept["version_stack"].append(version_entry)
        concept["updated_at"] = self._timestamp()
        
        # Save
        filepath = self._concept_path(concept_id)
        with open(filepath, 'w') as f:
            json.dump(concept, f, indent=2, ensure_ascii=False)
        
        # === CASCADE TRIGGER (decoupled) ===
        # Adding a new version (especially D1) may change core definition
        self._maybe_trigger_cascade(concept_id, concept, f"add_version:{level}")
        
        return {
            "status": "success",
            "concept_id": concept_id,
            "level": level,
            "version_count": len(concept["version_stack"])
        }
    
    def get_dependencies(self, concept_id: str, recursive: bool = False) -> List[str]:
        """Get dependencies of a concept."""
        concept = self.read(concept_id)
        if not concept:
            return []
        
        deps = concept.get("dependencies", [])
        
        if recursive:
            all_deps = set(deps)
            for dep in deps:
                all_deps.update(self.get_dependencies(dep, recursive=True))
            return list(all_deps)
        
        return deps
    
    def get_dependents(self, concept_id: str) -> List[str]:
        """Get concepts that depend on this concept."""
        all_concepts = self.list_all()
        dependents = []
        
        for concept in all_concepts:
            full_concept = self.read(concept["id"])
            if full_concept and concept_id in full_concept.get("dependencies", []):
                dependents.append(concept["id"])
        
        return dependents
    
    def _concept_path(self, concept_id: str) -> str:
        """Get file path for a concept."""
        # Sanitize concept_id for filesystem
        safe_id = "".join(c if c.isalnum() or c in "_-" else "_" for c in concept_id)
        return os.path.join(self.base_path, "concepts", f"{safe_id}.json")
    
    def _update_index(self, concept_id: str, action: str) -> None:
        """Update the concept index."""
        index_path = os.path.join(self.base_path, "concepts", "index.json")
        
        index = {}
        if os.path.exists(index_path):
            with open(index_path, 'r') as f:
                index = json.load(f)
        
        if action == "add":
            index[concept_id] = {
                "added_at": self._timestamp(),
                "path": self._concept_path(concept_id)
            }
        elif action == "remove" and concept_id in index:
            del index[concept_id]
        
        with open(index_path, 'w') as f:
            json.dump(index, f, indent=2)
    
    def _load_template(self) -> Dict:
        """Load concept lattice template."""
        template_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "assets", "concept-lattice-template.json"
        )
        
        if os.path.exists(template_path):
            with open(template_path, 'r') as f:
                return json.load(f)
        
        return {}
    
    def _maybe_trigger_cascade(self, concept_id: str, new_concept: Dict, reason: str) -> None:
        """
        Decoupled cascade trigger. Called after any write operation.
        
        Uses lazy import to avoid circular dependency.
        Silently fails if cascade module unavailable.
        """
        try:
            from scripts.cascade import CascadeTrigger
            trigger = CascadeTrigger(lattice_path=self.base_path)
            # We don't have old state here; CascadeTrigger will fetch it
            # and use semantic diff to decide if cascade is warranted
            trigger.on_concept_update(concept_id, new_concept=new_concept, reason=reason)
        except Exception:
            # Cascade is optional; silently skip if module missing or fails
            pass

    def get_version_history(self, concept_id: str) -> List[Dict]:
        """Return all historical versions of a concept."""
        concept = self.read(concept_id)
        if not concept:
            return []
        return concept.get("version_stack", [])
    
    def get_confidence_trend(self, concept_id: str) -> List[Dict]:
        """Return confidence time series for trend analysis."""
        concept = self.read(concept_id)
        if not concept:
            return []
        curve = concept.get("learning_curve", [])
        return [
            {"timestamp": entry.get("timestamp"), "confidence": entry.get("confidence", 0)}
            for entry in curve
        ]
    
    def schedule_review(self, concept_id: str, next_review_date: str) -> Dict:
        """Set the next review date for a concept."""
        return self.update(concept_id, {
            "consolidation_status": {
                "stage": "consolidated",
                "last_consolidated": self._timestamp(),
                "next_review_scheduled": next_review_date,
                "degradation_detected": False
            }
        })
    
    def get_due_reviews(self) -> List[Dict]:
        """Return all concepts whose next_review_scheduled has passed."""
        concepts = self.list_all()
        due = []
        now = self._timestamp()
        for c in concepts:
            review_time = c.get("consolidation_status", {}).get("next_review_scheduled")
            if review_time and review_time <= now:
                due.append(c)
        return due


def main():
    parser = argparse.ArgumentParser(description="Lattice Manager — Concept Lattice CRUD")
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Create
    create_parser = subparsers.add_parser("create", help="Create new concept")
    create_parser.add_argument("concept_id", help="Unique concept identifier")
    create_parser.add_argument("--from-file", help="Load initial data from JSON file")
    
    # Read
    read_parser = subparsers.add_parser("read", help="Read concept")
    read_parser.add_argument("concept_id", help="Concept identifier")
    
    # Update
    update_parser = subparsers.add_parser("update", help="Update concept")
    update_parser.add_argument("concept_id", help="Concept identifier")
    update_parser.add_argument("--from-file", required=True, help="Update data from JSON file")
    
    # Delete
    delete_parser = subparsers.add_parser("delete", help="Delete concept")
    delete_parser.add_argument("concept_id", help="Concept identifier")
    
    # List
    subparsers.add_parser("list", help="List all concepts")
    
    # Search
    search_parser = subparsers.add_parser("search", help="Search concepts")
    search_parser.add_argument("query", help="Search query")
    
    # Add version
    version_parser = subparsers.add_parser("add-version", help="Add version to concept")
    version_parser.add_argument("concept_id", help="Concept identifier")
    version_parser.add_argument("--level", required=True, choices=["D1", "D2", "D3", "D4"])
    version_parser.add_argument("--content", required=True, help="Explanation content")
    version_parser.add_argument("--confidence", type=float, default=0.5)
    
    args = parser.parse_args()
    
    manager = LatticeManager()
    
    if args.command == "create":
        data = None
        if args.from_file:
            with open(args.from_file, 'r') as f:
                data = json.load(f)
        result = manager.create(args.concept_id, data)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.command == "read":
        result = manager.read(args.concept_id)
        if result:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            print(f"Concept '{args.concept_id}' not found", file=sys.stderr)
            sys.exit(1)
    
    elif args.command == "update":
        with open(args.from_file, 'r') as f:
            updates = json.load(f)
        result = manager.update(args.concept_id, updates)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.command == "delete":
        result = manager.delete(args.concept_id)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.command == "list":
        results = manager.list_all()
        print(json.dumps(results, indent=2, ensure_ascii=False))
    
    elif args.command == "search":
        results = manager.search(args.query)
        print(json.dumps(results, indent=2, ensure_ascii=False))
    
    elif args.command == "add-version":
        result = manager.add_version(args.concept_id, args.level, args.content, args.confidence)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
