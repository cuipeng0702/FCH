# LEGACY v3.2 — DEPRECATED
# This module is part of the v3.2 monolithic architecture.
# v3.5+ uses harness/agents/ distributed templates + orchestrator.py state-machine.
# Keep for backward compatibility only; new development should use harness/ modules.
# See ../README.md for v3.5 Ralph Loop integration.

#!/usr/bin/env python3
"""
Verification Layer — Layer 3 of CSED-CLIF v3.0

Cross-temporal auditing: compare current version with historical versions
to verify depth increment and analogy stability.

Usage:
    from scripts.verification_layer import VerificationLayer
    verifier = VerificationLayer(lattice_manager)
    result = verifier.cross_temporal_audit("gradient_descent", current_version, previous_versions)
"""

import json
import re
from typing import Dict, List, Optional
from datetime import datetime


class VerificationLayer:
    """
    Cross-temporal verification that ensures each deepening cycle
    produces genuine cognitive progress, not mere variation.
    """
    
    def __init__(self, lattice_manager=None, config: Dict = None):
        self.lattice = lattice_manager
        self.config = config or {}
        self.depth_delta_threshold = self.config.get("depth_delta_threshold", 0.1)
        self.analogy_stability_threshold = self.config.get("analogy_stability_threshold", 0.7)
    
    def cross_temporal_audit(self, concept_id: str, current: Dict, history: List[Dict]) -> Dict:
        """
        Compare current version against all historical versions.
        
        Checks:
        1. Depth increment: Has the concept genuinely deepened?
        2. Analogy stability: Has the D1 analogy changed meaningfully?
        3. Mapping consistency: Does PRINCIPLE MAP still align with D3?
        
        Returns:
            Dict with audit results and recommendation (accept / revise / reject)
        """
        print(f"\n🔍 CROSS-TEMPORAL AUDIT: '{concept_id}'")
        
        if not history:
            print("   No history — first version, auto-accept")
            return {
                "recommendation": "accept",
                "depth_delta": 0.0,
                "analogy_stability": 1.0,
                "mapping_consistency": 1.0,
                "reason": "First version — no prior to compare against"
            }
        
        # Compare with most recent version
        previous = history[-1]
        
        # Check 1: Depth increment
        depth_delta = self._calculate_depth_increment(current, previous)
        print(f"   Depth delta: {depth_delta:.3f}")
        
        # Check 2: Analogy stability
        analogy_stability = self._calculate_analogy_stability(current, previous)
        print(f"   Analogy stability: {analogy_stability:.3f}")
        
        # Check 3: Mapping consistency (D1 PRINCIPLE MAP vs D3)
        mapping_consistency = self._check_mapping_consistency(current)
        print(f"   Mapping consistency: {mapping_consistency:.3f}")
        
        # Decision logic
        recommendation = self._make_recommendation(depth_delta, analogy_stability, mapping_consistency)
        
        return {
            "recommendation": recommendation,
            "depth_delta": round(depth_delta, 3),
            "analogy_stability": round(analogy_stability, 3),
            "mapping_consistency": round(mapping_consistency, 3),
            "reason": self._explain_recommendation(recommendation, depth_delta, analogy_stability, mapping_consistency)
        }
    
    def _calculate_depth_increment(self, current: Dict, previous: Dict) -> float:
        """
        Calculate how much deeper the current version is compared to previous.
        
        Dimensions:
        - New open problems introduced (D4)
        - Boundary conditions expanded (D4)
        - Principles mapped more precisely (D1 PRINCIPLE MAP count)
        """
        current_d4 = current.get("D4", {}).get("explanation", "")
        previous_d4 = previous.get("D4", {}).get("explanation", "")
        
        # Count open problems
        current_problems = len(re.findall(r'OPEN\s+PROBLEM|open problem', current_d4, re.IGNORECASE))
        previous_problems = len(re.findall(r'OPEN\s+PROBLEM|open problem', previous_d4, re.IGNORECASE))
        problem_delta = (current_problems - previous_problems) / max(previous_problems, 1)
        
        # Count boundary conditions
        current_boundaries = len(re.findall(r'boundary|limitation|constraint|exception|counterexample', current_d4, re.IGNORECASE))
        previous_boundaries = len(re.findall(r'boundary|limitation|constraint|exception|counterexample', previous_d4, re.IGNORECASE))
        boundary_delta = (current_boundaries - previous_boundaries) / max(previous_boundaries, 1)
        
        # Count principle mappings
        current_d1 = current.get("D1", {}).get("explanation", "")
        previous_d1 = previous.get("D1", {}).get("explanation", "")
        current_mappings = len(re.findall(r'^[a-z]\.|^\d+\.', current_d1, re.MULTILINE))
        previous_mappings = len(re.findall(r'^[a-z]\.|^\d+\.', previous_d1, re.MULTILINE))
        mapping_delta = (current_mappings - previous_mappings) / max(previous_mappings, 1)
        
        # Average depth delta
        depth_delta = (problem_delta + boundary_delta + mapping_delta) / 3
        return max(-1.0, min(1.0, depth_delta))
    
    def _calculate_analogy_stability(self, current: Dict, previous: Dict) -> float:
        """
        Calculate how stable the D1 analogy is across versions.
        
        High stability = analogy is robust, not fragile.
        Low stability = analogy changed significantly (may indicate previous was pseudo).
        """
        current_analogy = self._extract_analogy_keywords(current.get("D1", {}).get("explanation", ""))
        previous_analogy = self._extract_analogy_keywords(previous.get("D1", {}).get("explanation", ""))
        
        if not current_analogy or not previous_analogy:
            return 0.5  # Unknown
        
        # Jaccard similarity
        intersection = current_analogy & previous_analogy
        union = current_analogy | previous_analogy
        
        if not union:
            return 0.5
        
        return len(intersection) / len(union)
    
    def _extract_analogy_keywords(self, d1_text: str) -> set:
        """Extract keywords from D1 analogy (exclude generic terms)."""
        if not d1_text:
            return set()
        
        # Extract MASTER ANALOGY section
        lines = d1_text.split('\n')
        analogy_lines = []
        in_analogy = False
        for line in lines:
            if "MASTER ANALOGY" in line.upper():
                in_analogy = True
                continue
            if in_analogy:
                if re.search(r'^(PRINCIPLE MAP|BOUNDARY)', line, re.IGNORECASE):
                    break
                analogy_lines.append(line)
        
        analogy_text = ' '.join(analogy_lines)
        # Extract meaningful words (5+ chars, not common stop words)
        stop_words = {'about', 'above', 'across', 'after', 'against', 'along', 'among', 'around', 'because', 'before', 'behind', 'below', 'beneath', 'beside', 'between', 'beyond', 'during', 'except', 'inside', 'instead', 'outside', 'through', 'throughout', 'under', 'underneath', 'until', 'within', 'without'}
        words = set(re.findall(r'\b[A-Za-z]{5,}\b', analogy_text.lower()))
        return words - stop_words
    
    def _check_mapping_consistency(self, version: Dict) -> float:
        """
        Check if D1 PRINCIPLE MAP genuinely maps to D3 principles.
        
        Returns 1.0 if every D3 principle has a non-vague D1 mapping,
        0.0 if mappings are missing or pseudo.
        """
        from scripts.d1_validator import D1Validator
        validator = D1Validator()
        
        d1_text = version.get("D1", {}).get("explanation", "")
        d3_text = version.get("D3", {}).get("explanation", "")
        
        if not d1_text or not d3_text:
            return 0.5
        
        result = validator.check_pseudo_mapping(d1_text, d3_text)
        return 1.0 - (1.0 if result["is_pseudo"] else 0.0)
    
    def _make_recommendation(self, depth_delta: float, analogy_stability: float, mapping_consistency: float) -> str:
        """
        Make recommendation based on three checks.
        
        Rules:
        - accept: depth_delta > threshold AND mapping_consistency > 0.5
        - revise: depth_delta < 0 OR mapping_consistency < 0.3
        - accept_with_warning: otherwise
        """
        if depth_delta < -0.2 or mapping_consistency < 0.3:
            return "revise"
        elif depth_delta > self.depth_delta_threshold and mapping_consistency > 0.5:
            return "accept"
        else:
            return "accept_with_warning"
    
    def _explain_recommendation(self, recommendation: str, depth_delta: float, analogy_stability: float, mapping_consistency: float) -> str:
        """Generate human-readable explanation for recommendation."""
        if recommendation == "accept":
            return f"Version accepted: depth increased by {depth_delta:.1%}, analogy stable ({analogy_stability:.2f}), mapping consistent ({mapping_consistency:.2f})"
        elif recommendation == "revise":
            reasons = []
            if depth_delta < -0.2:
                reasons.append(f"depth decreased ({depth_delta:.1%})")
            if mapping_consistency < 0.3:
                reasons.append(f"mapping pseudo ({mapping_consistency:.2f})")
            return f"Version needs revision: {', '.join(reasons)}"
        else:
            return f"Version accepted with warning: depth delta {depth_delta:.1%}, analogy stability {analogy_stability:.2f}, mapping {mapping_consistency:.2f}"


def main():
    """CLI for verification layer testing."""
    import argparse
    parser = argparse.ArgumentParser(description="Verification Layer — Cross-temporal audit")
    parser.add_argument("concept_id", help="Concept ID to audit")
    parser.add_argument("--current", required=True, help="Current version JSON file")
    parser.add_argument("--previous", nargs='+', help="Previous version JSON files")
    args = parser.parse_args()
    
    with open(args.current) as f:
        current = json.load(f)
    
    history = []
    if args.previous:
        for path in args.previous:
            with open(path) as f:
                history.append(json.load(f))
    
    verifier = VerificationLayer()
    result = verifier.cross_temporal_audit(args.concept_id, current, history)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

    def calculate_murphy_decomposition(self, predictions: list, outcomes: list) -> dict:
        """BS = RELIABILITY - RESOLUTION + UNCERTAINTY"""
        n = len(predictions)
        if n == 0:
            return {"reliability": 0.0, "resolution": 0.0, "uncertainty": 0.0, "bs": 0.0}
        
        # Bin predictions
        bins = {i/10: [] for i in range(10)}  # 0.0-0.1, 0.1-0.2, ...
        for p, o in zip(predictions, outcomes):
            bin_key = min(int(p * 10) / 10, 0.9)
            bins[bin_key].append(o)
        
        # Reliability: mean squared discrepancy within bins
        reliability = 0.0
        total_count = 0
        for bin_key, bin_outcomes in bins.items():
            if not bin_outcomes:
                continue
            bin_freq = sum(bin_outcomes) / len(bin_outcomes)
            for o in bin_outcomes:
                reliability += (bin_key - bin_freq) ** 2
                total_count += 1
        reliability = reliability / total_count if total_count > 0 else 0.0
        
        # Resolution: variance of bin frequencies from overall base rate
        overall_rate = sum(outcomes) / len(outcomes) if outcomes else 0.5
        resolution = 0.0
        for bin_key, bin_outcomes in bins.items():
            if not bin_outcomes:
                continue
            bin_freq = sum(bin_outcomes) / len(bin_outcomes)
            resolution += len(bin_outcomes) * (bin_freq - overall_rate) ** 2
        resolution = resolution / len(outcomes) if outcomes else 0.0
        
        # Uncertainty: base rate variance
        uncertainty = overall_rate * (1 - overall_rate)
        
        bs = reliability - resolution + uncertainty
        return {
            "reliability": round(reliability, 4),
            "resolution": round(resolution, 4),
            "uncertainty": round(uncertainty, 4),
            "bs": round(bs, 4)
        }
    
    def get_confidence_tier(self, posterior_mass: float, data_age_days: int, kl_stability: float = None) -> str:
        """Progressive tier classification"""
        if data_age_days < 1:
            return "NULL"
        if posterior_mass >= 0.95 and data_age_days >= 30:
            return "CORRELATION"
        if posterior_mass >= 0.85 and data_age_days >= 14 and (kl_stability is None or kl_stability < 0.1):
            return "PATTERN"
        if posterior_mass >= 0.70 and data_age_days >= 5:
            return "CLUE"
        return "EXPLORATORY"

