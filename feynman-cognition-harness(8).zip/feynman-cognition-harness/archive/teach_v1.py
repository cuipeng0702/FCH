#!/usr/bin/env python3
"""
Teach Engine — Generate D1-D4 explanations for any concept.

Usage:
    python teach.py <concept> [--d1] [--d2] [--d3] [--d4] [--all]
    
Example:
    python teach.py "transformer attention" --all
"""

import argparse
import json
import sys
import os

# Add parent to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Try to import LLM Bridge for default model calling
try:
    from scripts.llm_bridge import create_model_caller, LLMBridge
    HAS_LLM_BRIDGE = True
except ImportError:
    HAS_LLM_BRIDGE = False


class TeachEngine:
    """Generates multi-granularity explanations (D1-D4) for concepts."""
    
    LEVELS = {
        "D1": {
            "name": "8-year-old",
            "constraints": [
                "ZERO technical terms allowed",
                "Must include visual metaphor (🌈)",
                "Use everyday objects and experiences",
                "Max 3 sentences per key idea",
                "If stuck, mark as knowledge gap immediately"
            ],
            "prompt_template": """Explain "{concept}" to an 8-year-old child.

Rules:
- Use ZERO technical terms. If you need a technical term, explain it first with everyday language.
- Include at least one visual metaphor (🌈) using everyday objects.
- Keep each key idea to 3 sentences maximum.
- If you cannot explain without technical terms, state: "🕳️ KNOWLEDGE GAP: I cannot explain [specific part] simply."

Output format:
1. Explanation (plain language only)
2. Assumed Knowledge List: What does this explanation assume the listener already knows?
3. Visual Metaphor Used: Describe the metaphor
4. Confidence (0-1): How well can you explain this simply?"""
        },
        "D2": {
            "name": "middle-schooler",
            "constraints": [
                "Basic terms allowed (define on first use)",
                "Must include concrete example or experiment",
                "Show cause-and-effect relationships",
                "Avoid mathematical notation"
            ],
            "prompt_template": """Explain "{concept}" to a middle school student.

Rules:
- Basic technical terms allowed, but define each on first use.
- Include at least one concrete example, experiment, or real-world application.
- Show clear cause-and-effect relationships.
- No mathematical notation or formulas.
- If a concept relies on another concept you haven't explained, mark it as a dependency.

Output format:
1. Explanation (with defined terms)
2. Example/Experiment: Concrete demonstration
3. Assumed Knowledge List: Prerequisites the student needs
4. Dependencies: Other concepts this explanation relies on
5. Confidence (0-1): How complete is this explanation?"""
        },
        "D3": {
            "name": "university-student",
            "constraints": [
                "Mathematical formalization required",
                "Derivations allowed and encouraged",
                "Use standard notation",
                "Show edge cases and assumptions"
            ],
            "prompt_template": """Explain "{concept}" to a university student in the relevant field.

Rules:
- Use mathematical formalization where applicable.
- Include derivations or proofs for key results.
- Use standard academic notation.
- Explicitly state assumptions, edge cases, and limitations.
- Reference foundational theorems or principles this builds on.

Output format:
1. Formal Definition (mathematical where possible)
2. Derivation/Proof of key results
3. Assumptions and Preconditions
4. Edge Cases and Limitations
5. Connections to foundational concepts
6. Confidence (0-1): How rigorous is this formalization?"""
        },
        "D4": {
            "name": "peer-expert",
            "constraints": [
                "Note controversies and debates",
                "Identify boundaries of applicability",
                "List open problems and active research",
                "Cite recent advances and counterexamples"
            ],
            "prompt_template": """Discuss "{concept}" with a peer expert in the field.

Rules:
- Identify active controversies, debates, or competing interpretations.
- Clearly mark boundaries: where does this concept apply, where does it fail?
- List open problems and current research directions.
- Note known counterexamples or cases where the standard understanding breaks down.
- Cite recent advances (last 5 years if possible).

Output format:
1. Standard Understanding (brief summary)
2. Controversies and Debates
3. Boundaries of Applicability
4. Open Problems and Active Research
5. Known Counterexamples or Edge Cases
6. Recent Advances (last 5 years)
7. Confidence (0-1): How well-established is this knowledge?"""
        }
    }
    
    def __init__(self, model_caller=None):
        """
        Initialize TeachEngine.
        
        Args:
            model_caller: Function to call LLM (concept, level_prompt) -> explanation
                         If None, uses LLM Bridge (Kimi-Claw proxy) if available,
                         otherwise falls back to placeholder.
        """
        if model_caller:
            self.model_caller = model_caller
        elif HAS_LLM_BRIDGE:
            self.model_caller = create_model_caller()
        else:
            self.model_caller = self._default_caller
        self.history = []
    
    def _default_caller(self, concept: str, prompt: str) -> dict:
        """Placeholder for LLM call. In production, this calls kimi-claw or similar."""
        return {
            "concept": concept,
            "level": "placeholder",
            "explanation": f"[Placeholder explanation for {concept}]",
            "assumed_knowledge": [],
            "confidence": 0.5,
            "raw_prompt": prompt
        }
    
    def teach(self, concept: str, level: str = None) -> dict:
        """
        Generate explanation for a concept at specified level(s).
        
        Args:
            concept: The concept to explain
            level: "D1", "D2", "D3", "D4", or None for all
            
        Returns:
            dict with explanations, metadata, and knowledge gaps
        """
        levels_to_generate = [level] if level else ["D1", "D2", "D3", "D4"]
        results = {}
        
        for lvl in levels_to_generate:
            if lvl not in self.LEVELS:
                raise ValueError(f"Unknown level: {lvl}. Use D1, D2, D3, or D4.")
            
            config = self.LEVELS[lvl]
            prompt = config["prompt_template"].format(concept=concept)
            
            # Call LLM
            result = self.model_caller(concept, prompt)
            result["level"] = lvl
            result["level_name"] = config["name"]
            result["constraints"] = config["constraints"]
            
            results[lvl] = result
            
            # Check for knowledge gaps in D1
            if lvl == "D1" and "🕳️ KNOWLEDGE GAP" in result.get("explanation", ""):
                result["has_gap"] = True
                # Extract gap details
                gaps = self._extract_gaps(result["explanation"])
                result["gaps"] = gaps
            else:
                result["has_gap"] = False
                result["gaps"] = []
        
        # Cross-reference assumed knowledge
        if len(levels_to_generate) > 1:
            self._cross_reference_assumptions(results)
        
        self.history.append({
            "concept": concept,
            "results": results,
            "timestamp": self._timestamp()
        })
        
        return results
    
    def _extract_gaps(self, explanation: str) -> list:
        """Extract knowledge gaps from D1 explanation."""
        gaps = []
        lines = explanation.split("\n")
        for line in lines:
            if "🕳️ KNOWLEDGE GAP" in line:
                # Extract the specific gap
                gap_text = line.split("🕳️ KNOWLEDGE GAP:")[1].strip() if "🕳️ KNOWLEDGE GAP:" in line else line
                gaps.append({
                    "type": "basic",
                    "description": gap_text,
                    "severity": 10,  # D1 gaps are always high severity
                    "strategy": "dimensional_reduction"
                })
        return gaps
    
    def _cross_reference_assumptions(self, results: dict) -> None:
        """Cross-reference assumed knowledge across levels."""
        # Collect all assumptions
        all_assumptions = {}
        for lvl, result in results.items():
            assumptions = result.get("assumed_knowledge", [])
            all_assumptions[lvl] = set(assumptions) if isinstance(assumptions, list) else set()
        
        # Find assumptions that appear in D3/D4 but not in D1/D2
        # These are potential knowledge gaps (terms used without foundation)
        advanced_assumptions = all_assumptions.get("D3", set()) | all_assumptions.get("D4", set())
        basic_assumptions = all_assumptions.get("D1", set()) | all_assumptions.get("D2", set())
        
        untranslated_terms = advanced_assumptions - basic_assumptions
        
        # Add warning to results
        if untranslated_terms:
            for lvl in ["D3", "D4"]:
                if lvl in results:
                    if "warnings" not in results[lvl]:
                        results[lvl]["warnings"] = []
                    results[lvl]["warnings"].append({
                        "type": "untranslated_terms",
                        "message": f"Terms used without D1 equivalent: {untranslated_terms}",
                        "terms": list(untranslated_terms)
                    })
    
    def _timestamp(self) -> str:
        """Get current ISO timestamp."""
        from datetime import datetime
        return datetime.now().isoformat()
    
    def get_history(self) -> list:
        """Return teaching history."""
        return self.history
    
    def export(self, filepath: str) -> None:
        """Export history to JSON file."""
        with open(filepath, 'w') as f:
            json.dump(self.history, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Teach Engine — Generate D1-D4 explanations")
    parser.add_argument("concept", help="Concept to explain")
    parser.add_argument("--d1", action="store_true", help="Generate D1 only")
    parser.add_argument("--d2", action="store_true", help="Generate D2 only")
    parser.add_argument("--d3", action="store_true", help="Generate D3 only")
    parser.add_argument("--d4", action="store_true", help="Generate D4 only")
    parser.add_argument("--all", action="store_true", help="Generate all levels (default)")
    parser.add_argument("--output", "-o", help="Output JSON file")
    
    args = parser.parse_args()
    
    # Determine levels
    levels = []
    if args.d1: levels.append("D1")
    if args.d2: levels.append("D2")
    if args.d3: levels.append("D3")
    if args.d4: levels.append("D4")
    if not levels or args.all:
        levels = None  # All levels
    
    # Generate
    engine = TeachEngine()
    
    if levels and len(levels) == 1:
        results = engine.teach(args.concept, levels[0])
    else:
        results = engine.teach(args.concept)
    
    # Output
    output = {
        "concept": args.concept,
        "levels": results,
        "generated_at": engine._timestamp()
    }
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(output, f, indent=2)
        print(f"Saved to {args.output}")
    else:
        print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
