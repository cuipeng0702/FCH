---
tag: [LEGACY]
load_when: "历史归档与废弃文档"
---

## 文档结构审计报告

### 根目录文档
| 文档 | 结构评分 | 完整评分 | 问题 |
|------|---------|---------|------|
| SKILL.md | 3 | 2 | **严重过时**：描述的是 v2.1 架构（Teach→Audit→Grow→Visualize→Cascade），未提及 harness/、Ralph Loop、D1-D4 四层结构。文件结构列表仅包含 `scripts/` 下旧脚本，完全遗漏当前核心文件（orchestrator.py、state_manager.py、各 agent 模板等）。版本号不一致（正文说 v3.2，但系统已是 v3.3）。 |
| README.md | 4 | 5 | 整体完整但篇幅过长（671行）。"Ralph Loop" 章节段落过长（>200字），信息密度虽高但可读性下降。版本号声明为 v3.3，与 SKILL.md 的 v3.2 冲突。 |
| Log.md | 4 | 3 | 仅 3 条记录，未覆盖 v3.1→v3.3 的大量变更（结构性涌现、UCC、校准引擎、BDD 等）。作为版本历史严重缺失。 |
| ARCHITECTURE_AUDIT.md | 4 | 3 | 标题为 v3.0 审计，但系统已迭代至 v3.3。"Version Alignment" 表格中 SKILL.md 和 README.md 仍标记为 v3.0，与实际不符。若此文档描述的是历史审计，应在标题中明确标注。 |
| OPTIMIZATION_PLAN.md | 3 | 2 | **实质为空**：仅列出 3 个阶段标题，无具体计划内容。Phase 1 写"文档对齐"但无任何对齐项；Phase 2/3 各只有一句话。57 行不构成可执行计划。 |
| OPTIMIZATION_REPORT.md | 4 | 3 | 提到修复了 UCC 测试发现的 5 个漏洞，但引用 `UCC_NEW.md`（第 28 行附近）——该文件在目录树中不存在。报告完整性因此受损。 |

### harness/ 文档
| 文档 | 结构评分 | 完整评分 | 问题 |
|------|---------|---------|------|
| harness/design.md | 4 | 4 | 多处仍写"current version: v3.0"（如第 1 节），与 config.yaml 的 3.3.0 不一致。架构描述本身清晰。 |
| harness/structural_emergence_design.md | 3 | 5 | 内容极其详尽（1376行），但存在大量超长段落（>200字），尤其 "Cross-Layer Mapping Catalog" 和 "Emergence Detection Protocol" 章节几乎为纯文本墙，缺乏子标题拆分。 |
| harness/ucc.md | 4 | 4 | **数据错误**：`HistoricalUCCRecord` 表格标题写 "12 Fields"，实际列出约 15 个字段（含 audit_scores、bdd_confidence 等）。字段计数不准确。 |
| harness/PRD.md | 4 | 4 | §2 标题写 "5-phase cycle"，但表格列出 6 个阶段（Search/Teach/Audit/Grow/Verify/Consolidate）。§4.5 引用 `contradiction-agent` 和 `contradictions.json`，但 agents/ 目录下不存在 contradiction-agent 模板。 |
| harness/checklist.md | 3 | 3 | **编号混乱**：Phase 3 中步骤从 3.5 跳至 4.2、4.3、4.4、4.5，然后 Phase 4 又从 4.1 开始。Phase 4 和 Phase 5 的编号存在重复/跳跃，无法作为可信执行清单。 |
| harness/config.yaml | 5 | 5 | 结构清晰，版本号 3.3.0 明确，模块配置完整，无显著问题。 |

### agents/ 模板
| 文档 | 结构评分 | 完整评分 | 问题 |
|------|---------|---------|------|
| teach_task_template.md | 3 | 4 | **内容重复**："Cross-Layer Mapping Requirements" 章节在文件中出现了两次（约第 95 行和第 120 行），第二次为碎片化的重复表格。 |
| audit_task_template.md | 4 | 4 | 无显著问题。 |
| grow_task_template.md | 3 | 4 | **内容重复**："Mapping-Driven Gap Rules (REVISED — Structural Emergence)" 表格及说明在文件中完整重复了两次（约第 45 行和第 75 行）。 |
| search_task_template.md | 4 | 4 | 无显著问题。 |
| verify_task_template.md | 4 | 4 | 无显著问题。 |
| bdd_task_template.md | 4 | 4 | 无显著问题。 |
| consolidate_task_template.md | 4 | 4 | 无显著问题。 |
| audit_quality_task_template.md | 4 | 4 | 无显著问题。 |
| teach_subagent_prompt.md | 4 | 4 | 与 `teach_task_template.md` 功能定位重叠——两者都定义 teach-agent 的行为，但未说明何时使用哪个。边界模糊。 |
| audit_subagent_prompt.md | 4 | 4 | 与 `audit_task_template.md` 存在同样的定位重叠问题。 |

### 遗留/历史文档
| 文档 | 结构评分 | 完整评分 | 问题 |
|------|---------|---------|------|
| docs/v21_vs_v30_comparison.md | 4 | 4 | 作为历史对比文档有价值，但全文使用 v3.0 指代当前系统，而实际已至 v3.3。若作为历史归档，应在顶部加标注说明。 |
| docs/v31_roadmap.md | 4 | 4 | 历史路线图，大部分内容已在后续版本中实现。无显著问题。 |
| docs/v32_auto_deepening_plan.md | 4 | 3 | 篇幅过短（67行），config.json 改造方案是否已在 config.yaml 中落实未明确说明。 |
| archive/DOCUMENT_AUDIT_v1.md | 4 | 3 | 明确标注已过时，作为 v1.x 历史归档合理。 |
| archive/epistemic_design_rejected.md | 3 | 5 | 文档标题写 "rejected"，但正文末尾写 "Design status: Ready for implementation"，且全文未解释**为何被拒绝**、**什么替代了它**。1126 行的详细设计与 "rejected" 状态矛盾， archival 理由缺失。 |

---

### 问题清单（按严重程度）

1. **[CRITICAL] SKILL.md 严重过时，误导用户** — SKILL.md 是 OpenClaw 集成入口文档，却描述 v2.1 架构、列举已废弃的 scripts/ 文件，完全不提及 harness/、Ralph Loop、D1-D4、子 agent 体系。用户通过 SKILL.md 无法了解技能实际工作原理。版本号仍写 v3.2，与系统实际 v3.3 脱节。

2. **[CRITICAL] 版本号在文档间不一致** — config.yaml 声明 3.3.0；SKILL.md 写 3.2；ARCHITECTURE_AUDIT.md 和 design.md 多处写 3.0；OPTIMIZATION_REPORT.md 聚焦 3.2。用户无法从文档中确认当前版本。

3. **[MAJOR] PRD.md 引用不存在的 agent** — PRD §4.5 Ming Wu 条件 #5 引用 `contradiction-agent` 和 `contradictions.json`，但 agents/ 目录下无 contradiction-agent 模板。此条件在当前的 Ralph Loop 中由谁执行、如何生成，无文档说明。

4. **[MAJOR] 两份模板存在内容重复** — `grow_task_template.md` 中 "Mapping-Driven Gap Rules" 完整重复两次；`teach_task_template.md` 中 Cross-Layer Mapping 表格重复出现。重复内容会导致子 agent 接收混乱指令。

5. **[MAJOR] checklist.md 编号混乱** — Phase 3 的 3.5 之后直接跳至 4.2-4.5，然后 Phase 4 又从 4.1 开始。Phase 编号体系失效，无法作为可信执行清单使用。

6. **[MAJOR] OPTIMIZATION_REPORT.md 引用不存在的文件** — 报告中写 "参见 UCC_NEW.md"，但该文件在目录树中不存在，报告完整性受损。

7. **[MAJOR] archive/epistemic_design_rejected.md 缺乏拒绝 rationale** — 1126 行的详细设计文档被归档为 "rejected"，但全文未说明拒绝原因、未指出替代方案。文档末尾甚至写 "Ready for implementation"，与归档状态矛盾。

8. **[MINOR] ucc.md 字段计数错误** — `HistoricalUCCRecord` 表格声称 12 个字段，实际列出约 15 个（audit_scores、bdd_confidence、bdd_decision、gap_count、converged、budget_used、routing 等）。

9. **[MINOR] PRD.md 标题与内容不一致** — §2 标题声明 "5-phase cycle"，但表格列出 6 个阶段（含 Search）。

10. **[MINOR] 任务模板与子 agent prompt 边界模糊** — `teach_task_template.md` 和 `teach_subagent_prompt.md` 都定义 teach-agent 的行为；`audit_task_template.md` 和 `audit_subagent_prompt.md` 同理。文档未说明两者的分工差异和使用场景。

11. **[MINOR] OPTIMIZATION_PLAN.md 为实质空文档** — 57 行，仅列标题无内容，不构成可执行计划。

12. **[MINOR] Log.md 记录严重缺失** — 仅 3 条记录，未覆盖 v3.1→v3.3 的结构性涌现、UCC、校准引擎、BDD、T3 执行器、类比矩阵等重大变更。

---

### 建议

1. **重写 SKILL.md** — 将其更新为 v3.3 的 OpenClaw 集成说明，替换 legacy 的 `scripts/` 文件列表为 `harness/` 核心文件树，明确 Ralph Loop 的触发方式，与 README.md 的版本号对齐。

2. **统一全文档版本号** — 建立版本号管理规范：所有文档在顶部统一声明当前版本，由单一源（config.yaml 或 Log.md）驱动。修改 ARCHITECTURE_AUDIT.md 和 design.md 中的 "v3.0" 引用。

3. **修复 checklist.md 编号** — 重新编排 Phase 3 和 Phase 4 的步骤编号，消除跳跃和重复。

4. **删除或解释模板重复内容** — 清理 `grow_task_template.md` 和 `teach_task_template.md` 中的重复章节，确保每个规则只出现一次。

5. **澄清 contradiction-agent 的状态** — 在 PRD.md 中说明：contradiction-agent 是否已移除？其功能是否被 audit-agent 的 cross-depth audit 取代？或是否仍待实现？

6. **补全 OPTIMIZATION_PLAN.md 或删除** — 若暂无具体计划，建议删除此 stub 文档，避免给用户/开发者造成"有计划但未执行"的误解。

7. **补全 OPTIMIZATION_REPORT.md 的缺失引用** — 要么创建 `UCC_NEW.md`，要么在报告中直接写入漏洞详情，不要引用不存在的文件。

8. **为 archive/epistemic_design_rejected.md 添加拒绝说明** — 在文档顶部追加 3-5 行说明：为何被拒绝、替代方案是什么、哪些部分被采纳到当前系统。

9. **明确 teach_subagent_prompt.md 与 teach_task_template.md 的分工** — 在两者顶部各加一行说明："本模板用于 X 场景（如直接 spawn subagent 时使用），另一模板用于 Y 场景（如通过 orchestrator 调度时使用）"。

10. **扩充 Log.md** — 至少补充 v3.1（融合架构）、v3.2（Auto-Deepening）、v3.3（结构性涌现、UCC、校准引擎、BDD、T3 执行器、类比矩阵）的关键变更记录。
