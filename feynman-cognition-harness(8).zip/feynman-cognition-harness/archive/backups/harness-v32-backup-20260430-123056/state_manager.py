"""StateManager — atomic file-system I/O for FCH harness state.

All reads/writes are JSON-based. Writes are atomic (temp file + rename).
"""

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class StateManager:
    """Manages state.json, progress.json, and budget.json with atomic writes."""

    def __init__(self, harness_dir: str):
        self.harness_dir = Path(harness_dir)
        self.state_path = self.harness_dir / "state.json"
        self.progress_path = self.harness_dir / "progress.json"
        self.budget_path = self.harness_dir / "budget.json"

    # ── generic helpers ──────────────────────────────────────────────

    @staticmethod
    def _atomic_write(path: Path, data: dict) -> None:
        """Write JSON atomically via a temp file."""
        tmp = tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".json",
            prefix="tmp_",
            dir=str(path.parent),
            delete=False,
        )
        try:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, path)

    @staticmethod
    def _load_json(path: Path, default: dict) -> dict:
        """Load JSON from path; return default if missing or corrupt."""
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default

    # ── state.json ───────────────────────────────────────────────────

    def load_state(self) -> dict:
        """Load runtime state: concepts, confidence, contradictions, gaps."""
        default = {
            "current_concept": None,
            "concept_history": [],
            "confidence": {},
            "contradictions": [],
            "pending_fixes": [],
            "strategy_adjustments": [],
            "last_updated": self._now(),
        }
        return self._load_json(self.state_path, default)

    def save_state(self, state: dict) -> None:
        """Persist runtime state with fresh timestamp."""
        state["last_updated"] = self._now()
        self._atomic_write(self.state_path, state)

    # ── progress.json ────────────────────────────────────────────────

    def load_progress(self) -> dict:
        """Load execution progress: current iteration, completed steps, todo."""
        default = {
            "current_iteration": 1,
            "completed_steps": [],
            "next_step": "teach",
            "last_agent_spawned": None,
            "last_task_completed": None,
        }
        return self._load_json(self.progress_path, default)

    def save_progress(self, progress: dict) -> None:
        """Persist execution progress."""
        self._atomic_write(self.progress_path, progress)

    # ── budget.json ──────────────────────────────────────────────────

    def load_budget(self) -> dict:
        """Load spawn budget: remaining quota and used count."""
        default = {
            "max_spawn": 50,
            "remaining": 50,
            "used": 0,
        }
        return self._load_json(self.budget_path, default)

    def save_budget(self, budget: dict) -> None:
        """Persist budget counters."""
        self._atomic_write(self.budget_path, budget)

    # ── task queue ───────────────────────────────────────────────────

    CHECKLIST = ["teach", "audit", "grow", "verify", "consolidate"]

    def get_next_task(self, progress: dict) -> str | None:
        """Return the next uncompleted step for the current iteration.

        Returns None when all steps in the current iteration are done.
        """
        completed = set(progress.get("completed_steps", []))
        for step in self.CHECKLIST:
            if step not in completed:
                return step
        return None

    def mark_task_done(self, progress: dict, task: str) -> dict:
        """Mark a step as completed and update next_step."""
        completed = set(progress.get("completed_steps", []))
        completed.add(task)
        progress["completed_steps"] = sorted(completed, key=self.CHECKLIST.index)
        next_task = self.get_next_task(progress)
        progress["next_step"] = next_task
        progress["last_task_completed"] = self._now()
        return progress

    # ── exceptions ───────────────────────────────────────────────────

    def record_exception(self, iteration: int, exc: dict) -> None:
        """Append an exception record to the iteration's exceptions.json."""
        exc_dir = self.harness_dir / "results" / f"iteration_{iteration}"
        exc_dir.mkdir(parents=True, exist_ok=True)
        exc_path = exc_dir / "exceptions.json"
        data = self._load_json(exc_path, {"records": []})
        record = {
            "time": self._now(),
            **exc,
        }
        data["records"].append(record)
        self._atomic_write(exc_path, data)

    def get_recent_exceptions(self, iteration: int, limit: int = 3) -> list:
        """Return the last `limit` exception records for an iteration."""
        exc_path = self.harness_dir / "results" / f"iteration_{iteration}" / "exceptions.json"
        data = self._load_json(exc_path, {"records": []})
        return data["records"][-limit:]

    # ── utility ──────────────────────────────────────────────────────

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()
