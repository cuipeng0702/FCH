#!/usr/bin/env python3
"""
Test: Audit loop — inject bad output, verify NEEDS_FIX triggers fix cycle

Steps:
1. Create temporary harness directory
2. Initialize state.json, progress.json, budget.json
3. Mock orchestrator to always write malformed worker output (below PRD thresholds)
4. Mock auditor to always return NEEDS_FIX
5. Run a single task through the orchestrator
6. Verify: audit report says NEEDS_FIX
7. Verify: orchestrator enters fix loop (pending_fixes recorded)
8. Verify: after 3 fix attempts, task is marked REJECT
9. Verify: budget decremented for every spawn (worker + auditor per attempt)
10. Cleanup via tempfile.TemporaryDirectory
"""

import json
import sys
import tempfile
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).parent.parent))

from orchestrator import FCHOrchestrator
from state_manager import StateManager


class AuditLoopMockOrchestrator(FCHOrchestrator):
    """Mock orchestrator that always produces malformed output and auditors
    that always return NEEDS_FIX, forcing the full fix loop.
    """

    def _run_single_task(self, task_name, iteration, state, progress, budget):
        """Override to skip search task since it's not in the checklist."""
        if task_name == "search":
            out_dir = self._iter_dir(iteration)
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / "search_output.json"
            ts = datetime.now(timezone.utc).isoformat()
            data = {
                "iteration": iteration,
                "results": [],
                "timestamp": ts,
            }
            self._atomic_write(out_path, data)
            return "continue"
        return super()._run_single_task(task_name, iteration, state, progress, budget)

    def _spawn_worker(self, task_name, input_path, output_path):
        """Always write a malformed / below-threshold worker output."""
        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).isoformat()

        # Deliberately malformed: D1 too short, D2 empty, D3/D4 minimal
        data = {
            "concept_id": "bad_concept",
            "iteration": 1,
            "d1": "short",              # violates PRD §3.1 (≥20 words expected)
            "d2": [],                   # violates PRD §3.2 (≥3 steps)
            "d3": {},                   # violates PRD §3.3 (definition missing)
            "d4": {},                   # violates PRD §3.4 (boundaries missing)
            "timestamp": ts,
        }
        self._atomic_write(out_path, data)
        return str(out_path)

    def _spawn_auditor(self, worker_output, worker_template, prd_path):
        """Always return NEEDS_FIX with concrete issues."""
        worker_path = Path(worker_output)
        audit_path = worker_path.parent / "audit_report.json"
        ts = datetime.now(timezone.utc).isoformat()

        data = {
            "iteration": 1,
            "worker_type": worker_path.stem.replace("_output", ""),
            "status": "NEEDS_FIX",
            "issues": [
                {
                    "rule_violated": "PRD-3.1",
                    "detail": "D1 analogy is too short (< 20 words).",
                },
                {
                    "rule_violated": "PRD-3.2",
                    "detail": "D2 steps array is empty (< 3 steps).",
                },
                {
                    "rule_violated": "PRD-3.3",
                    "detail": "D3 definition field missing.",
                },
                {
                    "rule_violated": "PRD-3.4",
                    "detail": "D4 boundaries array missing.",
                },
            ],
            "timestamp": ts,
        }
        self._atomic_write(audit_path, data)
        return str(audit_path)


def main():
    """Verify fix loop handles NEEDS_FIX correctly and rejects after 3 attempts."""
    with tempfile.TemporaryDirectory(prefix="fch_audit_") as tmpdir:
        harness_dir = Path(tmpdir)

        # Step 1: Setup directory and templates
        (harness_dir / "agents").mkdir(parents=True, exist_ok=True)
        for task in ["teach", "audit", "grow", "verify", "consolidate", "search"]:
            (harness_dir / "agents" / f"{task}_task_template.md").write_text(
                f"# {task}\n"
            )
        (harness_dir / "PRD.md").write_text("# PRD\n")

        sm = StateManager(str(harness_dir))
        sm.save_state({
            "current_concept": "bad_concept",
            "concept_history": [],
            "confidence": {},
            "contradictions": [],
            "pending_fixes": [],
            "strategy_adjustments": [],
        })
        sm.save_progress({
            "current_iteration": 1,
            "completed_steps": [],
            "next_step": "teach",
        })
        sm.save_budget({
            "max_spawn": 50,
            "remaining": 50,
            "used": 0,
        })

        # Step 2: Run single task with bad output + bad audit
        orch = AuditLoopMockOrchestrator(str(harness_dir))
        state = sm.load_state()
        progress = sm.load_progress()
        budget = sm.load_budget()

        result = orch._run_single_task("teach", 1, state, progress, budget)

        # Persist state/progress changes made by _run_single_task
        sm.save_state(state)
        sm.save_progress(progress)
        sm.save_budget(budget)

        # Step 3: Verify results
        errors = []

        # Should be rejected after 3 fix attempts
        if result != "rejected":
            errors.append(f"Expected result 'rejected', got '{result}'")

        # Verify audit report exists and has NEEDS_FIX status
        iter_dir = harness_dir / "results" / "iteration_1"
        audit_path = iter_dir / "audit_report.json"
        if not audit_path.exists():
            errors.append("Missing audit_report.json")
        else:
            audit = json.loads(audit_path.read_text())
            if audit.get("status") != "NEEDS_FIX":
                errors.append(
                    f"Final audit status={audit.get('status')} expected NEEDS_FIX"
                )
            if not audit.get("issues"):
                errors.append("Audit report has no issues list")

        # Verify pending_fixes recorded in state (one per fix attempt)
        final_state = sm.load_state()
        fixes = final_state.get("pending_fixes", [])
        teach_fixes = [f for f in fixes if f.get("task") == "teach"]
        # There should be exactly 3 fix records (attempts 1, 2, 3)
        # Note: the 3rd attempt triggers rejection, but _enqueue_fix is NOT called
        # on the 3rd attempt. However, worker_failure may add pending_fixes too.
        # For NEEDS_FIX path: attempt 1 and 2 enqueue fixes. Attempt 3 rejects.
        # So we expect 2 NEEDS_FIX entries. Let's check >= 2.
        if len(teach_fixes) < 2:
            errors.append(
                f"Expected >=2 pending_fix records for teach, got {len(teach_fixes)}"
            )

        # Verify budget decremented for each spawn in the loop
        # 3 attempts × (worker + auditor) = 6 budget consumed
        expected_remaining = 50 - 6
        if budget.get("remaining") != expected_remaining:
            errors.append(
                f"Budget remaining={budget.get('remaining')} "
                f"(expected {expected_remaining})"
            )

        # Verify progress does NOT mark teach as completed (it was rejected)
        if "teach" in progress.get("completed_steps", []):
            errors.append("Teach should NOT be in completed_steps after rejection")

        # Verify strategy_adjustments recorded the rollback
        adjustments = final_state.get("strategy_adjustments", [])
        rollback_found = any(
            a.get("task") == "teach" and a.get("action") == "rollback_rejected"
            for a in adjustments
        )
        if not rollback_found:
            errors.append(
                "Missing rollback_rejected strategy_adjustment for teach"
            )

        if errors:
            print("FAIL")
            for exc in errors:
                print(f"  - {exc}")
            return 1

        print("PASS")
        return 0


if __name__ == "__main__":
    sys.exit(main())
