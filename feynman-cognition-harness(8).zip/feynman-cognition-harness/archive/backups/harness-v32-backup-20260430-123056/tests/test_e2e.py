#!/usr/bin/env python3
"""
Test: One complete FCH iteration (teach → audit → grow → verify → consolidate)

Steps:
1. Create temporary harness directory with all required structure
2. Initialize state.json, progress.json, budget.json
3. Create mock worker template files and PRD.md
4. Pre-create convergence files (mingwu + novelty) so iteration 1 converges
5. Mock orchestrator to write realistic worker outputs and PASS audit reports
6. Run orchestrator.run()
7. Verify all expected output files exist, JSON valid, timestamp present
8. Verify budget decremented correctly (5 tasks × 2 spawns = 10)
9. Verify state and progress correctly updated
10. Cleanup via tempfile.TemporaryDirectory
"""

import json
import os
import sys
import tempfile
from pathlib import Path
from datetime import datetime, timezone

# Add harness parent to path so we can import orchestrator and state_manager
sys.path.insert(0, str(Path(__file__).parent.parent))

from orchestrator import FCHOrchestrator
from state_manager import StateManager


class MockOrchestrator(FCHOrchestrator):
    """Mock orchestrator that simulates worker and auditor completion.

    Instead of writing pending markers, _spawn_worker writes realistic
    worker output matching the PRD schema. _spawn_auditor writes a PASS
    audit report. Convergence is deferred until all 5 tasks complete.
    """

    def _is_converged(self, state, iteration):
        """Override: only converge after the full 5-step checklist is done."""
        progress = self.sm.load_progress()
        completed = set(progress.get("completed_steps", []))
        return len(completed) >= 5

    def _run_single_task(self, task_name, iteration, state, progress, budget):
        """Override to skip search task since it's not in the checklist."""
        if task_name == "search":
            # search is not in the checklist, so we need to handle it specially
            # Just write output and return "continue" directly
            out_dir = self._iter_dir(iteration)
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / "search_output.json"
            ts = datetime.now(timezone.utc).isoformat()
            data = {
                "iteration": iteration,
                "results": [],
                "timestamp": ts,
            }
            self._atomic_write(out_path, data)
            return "continue"
        return super()._run_single_task(task_name, iteration, state, progress, budget)

    def _spawn_worker(self, task_name, input_path, output_path):
        """Write a realistic worker output file for the given task."""
        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        ts = datetime.now(timezone.utc).isoformat()
        concept_id = "test_concept"
        iteration = self.sm.load_progress().get("current_iteration", 1)

        # Write task-specific output matching PRD schema (§7.1–7.6)
        if task_name == "teach":
            data = {
                "concept_id": concept_id,
                "iteration": iteration,
                "d1": (
                    "Analogy: electricity is like water flowing through pipes. "
                    "Voltage is water pressure, current is flow rate, and resistance "
                    "is pipe narrowing. Just as more pressure pushes more water, "
                    "higher voltage drives more current."
                ),
                "d2": [
                    "Step 1: Identify the power source and load in the circuit.",
                    "Step 2: Measure voltage across the load with a multimeter.",
                    "Step 3: Measure current through the load using an ammeter in series.",
                ],
                "d3": {
                    "definition": "Electric current is the time rate of flow of electric charge.",
                    "notation": "I = dQ/dt",
                    "confidence": "high",
                },
                "d4": {
                    "boundaries": [
                        {
                            "condition": "Open circuit (broken wire)",
                            "counter_example": "A lamp with a snapped filament",
                            "failure_mechanism": "No closed path → charge cannot flow.",
                        },
                        {
                            "condition": "Superconducting state",
                            "counter_example": "Current in a Type-I superconductor above critical field",
                            "failure_mechanism": "Meissner effect expels magnetic field, breaking steady-state assumptions.",
                        },
                        {
                            "condition": "Quantum tunneling regime",
                            "counter_example": "Electron tunneling through an insulating barrier",
                            "failure_mechanism": "Classical drift-velocity model collapses; probability current dominates.",
                        },
                    ]
                },
                "timestamp": ts,
            }
        elif task_name == "audit":
            data = {
                "iteration": iteration,
                "valid": True,
                "issues": [],
                "summary": "All D1–D4 layers pass internal review with no contradictions.",
                "timestamp": ts,
            }
        elif task_name == "grow":
            data = {
                "iteration": iteration,
                "gaps": [],
                "strategy": "No knowledge gaps identified; proceed to verification.",
                "timestamp": ts,
            }
        elif task_name == "verify":
            data = {
                "iteration": iteration,
                "cross_time_consistent": True,
                "independent_reproduction": True,
                "external_sources": ["https://example.com/foundation"],
                "confidence": {
                    "overall": 0.95,
                    "d1": 0.92,
                    "d2": 0.90,
                    "d3": 0.95,
                    "d4": 0.93,
                },
                "timestamp": ts,
            }
        elif task_name == "consolidate":
            data = {
                "concept_id": concept_id,
                "version_stack": [f"v{iteration}"],
                "open_problems": [],
                "learning_curve": {
                    "difficulty": "low",
                    "iterations_to_ming_wu": iteration,
                    "confidence_trend": "improving",
                },
                "epistemic_emotion": {
                    "primary": "clarity",
                    "intensity": 0.9,
                    "trigger": "Verified understanding after cross-layer consistency check.",
                },
                "attention_focus": {
                    "current_layer": "d4",
                    "target_gap": "",
                    "next_action": "done",
                },
                "consolidation_status": {
                    "lattice_updated": True,
                    "nodes_added": 1,
                    "edges_added": 0,
                    "merge_conflicts": 0,
                },
                "review_schedule": {
                    "next_review": ts,
                    "interval_days": 7,
                    "reason": "Routine post-convergence review",
                },
                "timestamp": ts,
            }
        else:
            data = {"_mock": True, "task": task_name, "timestamp": ts}

        self._atomic_write(out_path, data)
        return str(out_path)

    def _spawn_auditor(self, worker_output, worker_template, prd_path):
        """Write a PASS audit report for the worker output."""
        worker_path = Path(worker_output)
        audit_path = worker_path.parent / "audit_report.json"

        ts = datetime.now(timezone.utc).isoformat()
        data = {
            "iteration": self.sm.load_progress().get("current_iteration", 1),
            "worker_type": worker_path.stem.replace("_output", ""),
            "status": "PASS",
            "issues": [],
            "timestamp": ts,
        }
        self._atomic_write(audit_path, data)
        return str(audit_path)


def main():
    """Run end-to-end test for one complete FCH iteration."""
    with tempfile.TemporaryDirectory(prefix="fch_e2e_") as tmpdir:
        harness_dir = Path(tmpdir)

        # Step 1: Create directory structure
        (harness_dir / "agents").mkdir(parents=True, exist_ok=True)
        (harness_dir / "results").mkdir(parents=True, exist_ok=True)

        # Step 2: Create dummy worker template files (orchestrator references them)
        for task in ["teach", "audit", "grow", "verify", "consolidate", "search"]:
            (harness_dir / "agents" / f"{task}_task_template.md").write_text(
                f"# {task} template\nPlaceholder for agent instructions.\n"
            )

        # Step 3: Copy or create PRD.md (auditor references it)
        prd_src = Path(__file__).parent.parent / "PRD.md"
        if prd_src.exists():
            prd_dst = harness_dir / "PRD.md"
            prd_dst.write_text(prd_src.read_text())
        else:
            (harness_dir / "PRD.md").write_text("# Dummy PRD\n")

        # Step 4: Initialize state files
        sm = StateManager(str(harness_dir))
        sm.save_state({
            "current_concept": None,
            "concept_history": [],
            "confidence": {},
            "contradictions": [],
            "pending_fixes": [],
            "strategy_adjustments": [],
        })
        sm.save_progress({
            "current_iteration": 1,
            "completed_steps": [],
            "next_step": "teach",
            "last_agent_spawned": None,
            "last_task_completed": None,
        })
        sm.save_budget({
            "max_spawn": 50,
            "remaining": 50,
            "used": 0,
        })

        # Step 5: Pre-create results directory for this iteration
        iter_dir = harness_dir / "results" / "iteration_1"
        iter_dir.mkdir(parents=True, exist_ok=True)

        # Step 6: Run orchestrator
        orch = MockOrchestrator(str(harness_dir))
        orch.run()

        # Step 7: Verify all expected output files exist, JSON valid, timestamp present
        errors = []
        expected_files = [
            "teach_output.json",
            "audit_output.json",
            "grow_output.json",
            "verify_output.json",
            "consolidate_output.json",
            "audit_report.json",
        ]

        for fname in expected_files:
            fpath = iter_dir / fname
            if not fpath.exists():
                errors.append(f"Missing output file: {fname}")
                continue
            try:
                data = json.loads(fpath.read_text())
            except json.JSONDecodeError as exc:
                errors.append(f"Invalid JSON in {fname}: {exc}")
                continue
            if "timestamp" not in data:
                errors.append(f"Missing 'timestamp' key in {fname}")

        # Step 8: Verify budget decremented correctly
        # 5 tasks × 2 spawns (worker + auditor) = 10 budget consumed
        final_budget = sm.load_budget()
        expected_remaining = 50 - 10
        if final_budget.get("remaining") != expected_remaining:
            errors.append(
                f"Budget remaining={final_budget.get('remaining')} "
                f"(expected {expected_remaining})"
            )
        if final_budget.get("used") != 10:
            errors.append(
                f"Budget used={final_budget.get('used')} (expected 10)"
            )

        # Step 9: Verify state updated by worker ingestion
        final_state = sm.load_state()
        if final_state.get("current_concept") != "test_concept":
            errors.append(
                f"State concept mismatch: {final_state.get('current_concept')}"
            )
        if "test_concept" not in final_state.get("concept_history", []):
            errors.append(
                "State concept_history not updated by consolidate ingestion"
            )
        # Verify confidence was set by verify-agent output
        if not final_state.get("confidence"):
            errors.append("State confidence not set by verify task")

        # Step 10: Verify progress shows completion
        final_progress = sm.load_progress()
        if final_progress.get("status") != "done":
            errors.append(f"Progress status not 'done': {final_progress}")
        expected_steps = ["teach", "audit", "grow", "verify", "consolidate"]
        if final_progress.get("completed_steps") != expected_steps:
            errors.append(
                f"Completed steps mismatch: {final_progress.get('completed_steps')}"
            )

        if errors:
            print("FAIL")
            for exc in errors:
                print(f"  - {exc}")
            return 1

        print("PASS")
        return 0


if __name__ == "__main__":
    sys.exit(main())
