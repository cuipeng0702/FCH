#!/usr/bin/env python3
"""
Test: Crash recovery — kill mid-iteration, verify state can resume

Steps:
1. Create temporary harness directory
2. Initialize state.json, progress.json, budget.json
3. Start a teach task: write a stale pending marker (simulates a crashed worker)
4. Simulate crash: corrupt progress.json to show teach as incomplete
5. Re-run orchestrator with a mock that recovers on second worker spawn
6. Verify orchestrator detects the stale marker, records exception, retries
7. Verify task completes successfully after recovery
8. Verify no duplicate outputs and budget consistent with retry overhead
9. Cleanup via tempfile.TemporaryDirectory
"""

import json
import sys
import tempfile
from pathlib import Path
from datetime import datetime, timezone, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))

from orchestrator import FCHOrchestrator
from state_manager import StateManager


class ResumeMockOrchestrator(FCHOrchestrator):
    """Mock orchestrator that simulates a crashed worker on first spawn,
    then writes valid output on the retry. Convergence deferred until all
    5 tasks are completed.
    """

    def __init__(self, harness_dir):
        super().__init__(harness_dir)
        self._spawn_calls = 0

    def _is_converged(self, state, iteration):
        """Only converge after the full 5-step checklist is done."""
        progress = self.sm.load_progress()
        completed = set(progress.get("completed_steps", []))
        return len(completed) >= 5

    def _run_single_task(self, task_name, iteration, state, progress, budget):
        """Override to skip search task since it's not in the checklist."""
        if task_name == "search":
            out_dir = self._iter_dir(iteration)
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / "search_output.json"
            ts = datetime.now(timezone.utc).isoformat()
            data = {
                "iteration": iteration,
                "results": [],
                "timestamp": ts,
            }
            self._atomic_write(out_path, data)
            return "continue"
        return super()._run_single_task(task_name, iteration, state, progress, budget)

    def _spawn_worker(self, task_name, input_path, output_path):
        """On first call write a stale pending marker (crashed worker).
        On second call write valid output (recovery).
        """
        self._spawn_calls += 1
        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        if self._spawn_calls == 1:
            # Simulate crashed worker: pending marker with old timestamp
            # (900 seconds ago → guaranteed timeout vs 600s default)
            stale_ts = (datetime.now(timezone.utc) - timedelta(seconds=900)).isoformat()
            data = {
                "_pending": True,
                "task": task_name,
                "timestamp": stale_ts,
            }
        else:
            # Recovery: valid worker output
            ts = datetime.now(timezone.utc).isoformat()
            data = {
                "concept_id": "test_concept",
                "iteration": 1,
                "d1": (
                    "Analogy: electricity is like water in pipes. "
                    "Voltage is pressure, current is flow."
                ),
                "d2": [
                    "Step 1: Close the circuit.",
                    "Step 2: Read the ammeter.",
                    "Step 3: Record the value.",
                ],
                "d3": {
                    "definition": "Current is charge flow per unit time.",
                    "notation": "I = Q/t",
                    "confidence": "high",
                },
                "d4": {
                    "boundaries": [
                        {
                            "condition": "Open circuit",
                            "counter_example": "Broken filament",
                            "failure_mechanism": "No closed path for charge.",
                        },
                        {
                            "condition": "Superconductor",
                            "counter_example": "Current above critical field",
                            "failure_mechanism": "Magnetic field expelled.",
                        },
                        {
                            "condition": "Quantum tunneling",
                            "counter_example": "Insulator barrier",
                            "failure_mechanism": "Classical model breaks down.",
                        },
                    ]
                },
                "timestamp": ts,
            }

        self._atomic_write(out_path, data)
        return str(out_path)

    def _spawn_auditor(self, worker_output, worker_template, prd_path):
        """Write a PASS audit report."""
        worker_path = Path(worker_output)
        audit_path = worker_path.parent / "audit_report.json"
        ts = datetime.now(timezone.utc).isoformat()
        data = {
            "iteration": 1,
            "worker_type": worker_path.stem.replace("_output", ""),
            "status": "PASS",
            "issues": [],
            "timestamp": ts,
        }
        self._atomic_write(audit_path, data)
        return str(audit_path)


def main():
    """Simulate crash mid-task and verify orchestrator resumes correctly."""
    with tempfile.TemporaryDirectory(prefix="fch_resume_") as tmpdir:
        harness_dir = Path(tmpdir)

        # Step 1: Create directory structure
        (harness_dir / "agents").mkdir(parents=True, exist_ok=True)
        (harness_dir / "results").mkdir(parents=True, exist_ok=True)
        for task in ["teach", "audit", "grow", "verify", "consolidate", "search"]:
            (harness_dir / "agents" / f"{task}_task_template.md").write_text(
                f"# {task}\n"
            )
        (harness_dir / "PRD.md").write_text("# PRD\n")

        sm = StateManager(str(harness_dir))
        sm.save_state({
            "current_concept": None,
            "concept_history": [],
            "confidence": {},
            "contradictions": [],
            "pending_fixes": [],
            "strategy_adjustments": [],
        })
        sm.save_progress({
            "current_iteration": 1,
            "completed_steps": [],
            "next_step": "teach",
        })
        sm.save_budget({
            "max_spawn": 11,
            "remaining": 11,
            "used": 0,
        })

        iter_dir = harness_dir / "results" / "iteration_1"
        iter_dir.mkdir(parents=True, exist_ok=True)

        # Step 2: Run orchestrator (first worker will be stale, second recovers)
        orch = ResumeMockOrchestrator(str(harness_dir))
        orch.run()

        # Step 3: Verify results
        errors = []

        # Verify progress completed all steps after recovery
        final_progress = sm.load_progress()
        expected_steps = ["teach", "audit", "grow", "verify", "consolidate"]
        if final_progress.get("completed_steps") != expected_steps:
            errors.append(
                f"Completed steps mismatch: {final_progress.get('completed_steps')}"
            )

        # Verify no duplicate teach output files (only one teach_output.json)
        teach_files = list(iter_dir.glob("teach_output*.json"))
        if len(teach_files) != 1:
            errors.append(f"Duplicate or missing teach outputs: {len(teach_files)} files")

        # Verify budget consumed accounts for the retry
        # teach: worker attempt 1 (stale, timeout) + worker attempt 2 + auditor = 3
        # audit, grow, verify, consolidate: each 2 = 8
        # total = 11
        final_budget = sm.load_budget()
        expected_remaining = 11 - 11
        if final_budget.get("remaining") != expected_remaining:
            errors.append(
                f"Budget remaining={final_budget.get('remaining')} "
                f"(expected {expected_remaining})"
            )

        # Verify state shows concept ingested (teach task succeeded on retry)
        final_state = sm.load_state()
        if final_state.get("current_concept") != "test_concept":
            errors.append(
                f"Concept not ingested: {final_state.get('current_concept')}"
            )

        # Verify exception was recorded for the timed-out worker
        exc_path = iter_dir / "exceptions.json"
        if not exc_path.exists():
            errors.append("Missing exceptions.json for worker timeout")
        else:
            exc_data = json.loads(exc_path.read_text())
            records = exc_data.get("records", [])
            timeout_records = [r for r in records if r.get("error") == "WORKER_FAILURE"]
            if not timeout_records:
                errors.append("No WORKER_FAILURE recorded for stale pending marker")

        # Verify pending_fixes tracked the timeout
        fixes = final_state.get("pending_fixes", [])
        teach_fixes = [f for f in fixes if f.get("task") == "teach"]
        if not teach_fixes:
            errors.append("No pending_fix recorded for teach timeout")

        if errors:
            print("FAIL")
            for exc in errors:
                print(f"  - {exc}")
            return 1

        print("PASS")
        return 0


if __name__ == "__main__":
    sys.exit(main())
