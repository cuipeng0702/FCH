#!/usr/bin/env python3
"""
Test: Structural mapping analysis — verify _analyze_mappings and sub-methods

Tests the 3 new mapping methods with mock data:
- _check_d1_d2_mapping()
- _check_d2_d3_mapping()
- _count_gaps()

Setup: Uses mock_teach_output.json fixture with gradient descent data.
"""

import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from orchestrator import FCHOrchestrator


class MockStateManager:
    """Minimal mock state manager for testing."""

    def __init__(self, harness_dir):
        self.harness_dir = Path(harness_dir)
        self._state = {}
        self._progress = {}
        self._budget = {}

    def load_state(self):
        return self._state.copy()

    def save_state(self, state):
        self._state = state.copy()

    def load_progress(self):
        return self._progress.copy()

    def save_progress(self, progress):
        self._progress = progress.copy()

    def load_budget(self):
        return self._budget.copy()

    def save_budget(self, budget):
        self._budget = budget.copy()

    def mark_task_done(self, progress, task_name):
        progress = progress.copy()
        completed = progress.get("completed_steps", [])
        if task_name not in completed:
            completed.append(task_name)
        progress["completed_steps"] = completed
        return progress

    def record_exception(self, iteration, exc):
        pass

    def get_next_task(self, progress):
        return None


class TestStructuralMappings(unittest.TestCase):
    """Test structural mapping analysis methods."""

    @classmethod
    def setUpClass(cls):
        cls.fixture_path = Path(__file__).parent / "fixtures" / "mock_teach_output.json"
        with open(cls.fixture_path, "r", encoding="utf-8") as f:
            cls.mock_teach_output = json.load(f)

    def setUp(self):
        """Create a minimal orchestrator with mocked state manager."""
        self.harness_dir = Path("/tmp/fch_structural_test")
        self.harness_dir.mkdir(parents=True, exist_ok=True)
        self.orch = FCHOrchestrator(str(self.harness_dir))
        # Replace state manager with mock
        self.orch.sm = MockStateManager(str(self.harness_dir))
        self.orch.sm.save_state({"concept_history": []})
        self.orch.sm.save_progress({"current_iteration": 1})

    def tearDown(self):
        """Clean up temp directory."""
        import shutil
        if self.harness_dir.exists():
            shutil.rmtree(self.harness_dir)

    # ── Test 1: _check_d1_d2_mapping ─────────────────────────────

    def test_d1_d2_mapping_detects_orphans(self):
        """D1 'fog' has no D2 correspondent → orphan_d1_elements includes 'fog'."""
        mapping_d1_d2 = self.mock_teach_output["mappings"]["d1_d2"]
        result = self.orch._check_d1_d2_mapping(mapping_d1_d2)

        orphan_elements = [o["element"] for o in result.get("orphan_d1_elements", [])]
        self.assertIn("fog", orphan_elements,
                      "'fog' from D1 should be detected as orphan (no D2 step)")

    def test_d1_d2_mapping_detects_hiker_correspondent(self):
        """D1 'hiker' has D2 correspondent (step 1 'feel around')."""
        mapping_d1_d2 = self.mock_teach_output["mappings"]["d1_d2"]
        result = self.orch._check_d1_d2_mapping(mapping_d1_d2)

        # "hiker" should NOT be in orphans because it maps to step 1
        orphan_elements = [o["element"] for o in result.get("orphan_d1_elements", [])]
        self.assertNotIn("hiker", orphan_elements,
                         "'hiker' should have D2 correspondent, not be orphan")

    def test_d1_d2_mapping_detects_mountain_orphan(self):
        """D1 'mountain' has no D2 correspondent → orphan_d1_elements includes 'mountain'."""
        mapping_d1_d2 = self.mock_teach_output["mappings"]["d1_d2"]
        result = self.orch._check_d1_d2_mapping(mapping_d1_d2)

        orphan_elements = [o["element"] for o in result.get("orphan_d1_elements", [])]
        self.assertIn("mountain", orphan_elements,
                      "'mountain' from D1 should be detected as orphan (no D2 step)")

    # ── Test 2: _check_d2_d3_mapping ─────────────────────────────

    def test_d2_d3_mapping_detects_eta_manipulated(self):
        """η is manipulated in D2 step 2 ('take one step down' implies step size = η)."""
        mapping_d2_d3 = self.mock_teach_output["mappings"]["d2_d3"]
        result = self.orch._check_d2_d3_mapping(mapping_d2_d3)

        unmanipulated_vars = [o["variable"] for o in result.get("unmanipulated_variables", [])]
        self.assertNotIn("η", unmanipulated_vars,
                         "'η' should be detected as manipulated in D2 step 2")

    def test_d2_d3_mapping_detects_gradient_manipulated(self):
        """∇L(θ) is manipulated in D2 step 1 ('feel around for steepest slope')."""
        mapping_d2_d3 = self.mock_teach_output["mappings"]["d2_d3"]
        result = self.orch._check_d2_d3_mapping(mapping_d2_d3)

        unmanipulated_vars = [o["variable"] for o in result.get("unmanipulated_variables", [])]
        self.assertNotIn("∇L(θ)", unmanipulated_vars,
                         "'∇L(θ)' should be detected as manipulated in D2 step 1")

    def test_d2_d3_mapping_detects_theta_t_unmanipulated(self):
        """θ_t is NOT directly manipulated in any D2 step → unmanipulated_variables includes 'θ_t'."""
        mapping_d2_d3 = self.mock_teach_output["mappings"]["d2_d3"]
        result = self.orch._check_d2_d3_mapping(mapping_d2_d3)

        unmanipulated_vars = [o["variable"] for o in result.get("unmanipulated_variables", [])]
        self.assertIn("θ_t", unmanipulated_vars,
                      "'θ_t' should be detected as unmanipulated (no D2 step directly sets it)")

    # ── Test 3: _count_gaps ──────────────────────────────────────

    def test_count_gaps_returns_positive_when_failures_exist(self):
        """When mapping failures exist, _count_gaps returns ≥1."""
        failures = {
            "d1_d2": {
                "orphan_d1_elements": [{"element": "fog"}],
                "orphan_d2_steps": [],
                "implied_actions_missing": [],
            },
            "d2_d3": {
                "unmanipulated_variables": [{"variable": "θ_t"}],
                "unformalized_steps": [],
                "operation_mismatches": [],
            },
            "d1_d3": {"orphans_formal": [], "orphans_analogy": [], "fractures": []},
            "d2_d4": {"unguarded_boundaries": [], "phantom_guards": [], "silent_failures": []},
            "d3_d4": {"unconstructible_counters": [], "hidden_assumptions": [], "vacuous_boundaries": []},
            "cross_layer": [],
            "cross_concept": {
                "definition_mismatches": [],
                "analogy_collisions": [],
                "boundary_violations": [],
                "dependency_drifts": [],
            },
        }
        count = self.orch._count_gaps(failures)
        self.assertGreaterEqual(count, 1,
                                f"Expected ≥1 gap when failures exist, got {count}")

    def test_count_gaps_returns_zero_when_all_mappings_pass(self):
        """When all mappings pass (no failures), _count_gaps returns 0."""
        failures = {
            "d1_d2": {
                "orphan_d1_elements": [],
                "orphan_d2_steps": [],
                "implied_actions_missing": [],
            },
            "d2_d3": {
                "unmanipulated_variables": [],
                "unformalized_steps": [],
                "operation_mismatches": [],
            },
            "d1_d3": {"orphans_formal": [], "orphans_analogy": [], "fractures": []},
            "d2_d4": {"unguarded_boundaries": [], "phantom_guards": [], "silent_failures": []},
            "d3_d4": {"unconstructible_counters": [], "hidden_assumptions": [], "vacuous_boundaries": []},
            "cross_layer": [],
            "cross_concept": {
                "definition_mismatches": [],
                "analogy_collisions": [],
                "boundary_violations": [],
                "dependency_drifts": [],
            },
        }
        count = self.orch._count_gaps(failures)
        self.assertEqual(count, 0,
                         f"Expected 0 gaps when all mappings pass, got {count}")

    def test_count_gaps_counts_all_failure_types(self):
        """_count_gaps correctly aggregates across all failure categories."""
        failures = {
            "d1_d2": {
                "orphan_d1_elements": [{"element": "a"}, {"element": "b"}],
                "orphan_d2_steps": [{"step": 1}],
                "implied_actions_missing": ["x"],
            },
            "d2_d3": {
                "unmanipulated_variables": [{"variable": "v1"}],
                "unformalized_steps": [{"step": 2}],
                "operation_mismatches": [{"step": 3}],
            },
            "d1_d3": {
                "orphans_formal": ["t1"],
                "orphans_analogy": ["t2"],
                "fractures": [{"term": "t3"}],
            },
            "d2_d4": {
                "unguarded_boundaries": ["b1"],
                "phantom_guards": ["b2"],
                "silent_failures": [{"zone": "z1"}],
            },
            "d3_d4": {
                "unconstructible_counters": ["c1"],
                "hidden_assumptions": ["a1"],
                "vacuous_boundaries": ["v1"],
            },
            "cross_layer": [{"type": "fracture"}],
            "cross_concept": {
                "definition_mismatches": [{"type": "def_mismatch"}],
                "analogy_collisions": [{"type": "analogy_collision"}],
                "boundary_violations": [{"type": "boundary_violation"}],
                "dependency_drifts": [{"type": "dependency_drift"}],
            },
        }
        count = self.orch._count_gaps(failures)
        # Expected: 2+1+1 + 1+1+1 + 1+1+1 + 1+1+1 + 1+1+1 + 1 + 1+1+1+1 = 20
        self.assertEqual(count, 21,
                         f"Expected 21 gaps for comprehensive failure set, got {count}")


if __name__ == "__main__":
    unittest.main()
