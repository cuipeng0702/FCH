# Grow Agent Task Template

## Objective
Analyze audit findings to identify knowledge gaps, classify them by layer (D1–D4), and generate a targeted learning strategy to close those gaps in the next iteration. This agent must think like a learning strategist, not just a bug reporter.

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "audit_output_path": "string (path to audit_output.json)",
  "teach_output_path": "string (path to teach_output.json)",
  "state_path": "string (path to state.json)",
  "concept": "string",
  "concept_id": "string",
  "iteration": 1,
  "previous_grow": {
    "iteration": 1,
    "gaps": [],
    "strategy": "string"
  }
}
```

Notes:
- Load `audit_output.json`, `teach_output.json`, and `state.json` from their respective paths.
- `previous_grow` may be `null` on first grow phase.

## Output

Write to: `{output_path}`

Format: JSON with schema (see PRD.md §7.3):
```json
{
  "iteration": 1,
  "timestamp": "ISO-8601 string",
  "gaps": [
    {
      "id": "string",
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "external_knowledge_required": true,
      "query": "string (search query if external)"
    }
  ],
  "strategy": "string (how to close gaps)",
  "metadata": {
    "gap_count": 0,
    "external_knowledge_count": 0,
    "priority_layer": "d1|d2|d3|d4|null"
  }
}
```

## Gap Analysis Framework

### Step 1: Map Audit Issues to Gaps
For each audit issue, determine:
- Is this a **knowledge gap** (missing understanding) or a **presentation gap** (understanding exists but poorly expressed)?
- Which D-layer is primarily affected?
- Can this gap be closed by rethinking the explanation, or does it require external knowledge?

### Step 2: Classify Gaps by Type
| Type | Definition | Example |
|------|------------|---------|
| **Conceptual Gap** | Core understanding missing | D3 definition is circular or tautological |
| **Procedural Gap** | Know what, not how | D2 steps skip a non-trivial sub-procedure |
| **Boundary Gap** | Don't know where concept breaks | D4 lists only 2 genuine boundaries, rest are trivial |
| **Analogy Gap** | No good mapping to intuition | D1 analogy breaks under simple stress-test |
| **Confidence Gap** | Unsure about formal claim | D3 marks confidence `low` on a central definition |
| **Mapping Gap (NEW)** | Cross-layer mapping failure | D1↔D2 or D2↔D3 mapping incomplete per teach-agent mapping requirements |

### Mapping-Driven Gap Rules (REVISED — Structural Emergence)
| Rule | Detected Pattern | Gap Type | Auto-Fix Strategy |
|------|-----------------|----------|-------------------|
| 9 | orphan_procedure | unexecutable_intuition | add_execution_step |
| 10 | unmanipulated_formal | unmanipulated_formal | add_variable_step |
| 11 | definition_mismatch | definition_collision | disambiguate_term |
| 12 | analogy_collision | analogy_overload | diversify_analogy |
| 13 | boundary_violation | boundary_violation | guard_dependency |
| 14 | dependency_drift | dependency_drift | pin_dependency_version |

**Rule 9 — orphan_procedure**: A D1 analogy element has no corresponding D2 step. The intuition is unexecutable. **Fix**: Add an execution step to D2 that operationalizes the orphan element.

**Rule 10 — unmanipulated_formal**: A D3 variable/term is never manipulated in D2. The formalism is inert. **Fix**: Add a variable introduction/manipulation step to D2, or remove the variable from D3 if it is not essential.

**Rule 11 — definition_mismatch**: Two D3 definitions of the same term (from different iterations or sources) conflict. **Fix**: Disambiguate the term — split into term_A and term_B, or merge definitions with explicit conditions.

**Rule 12 — analogy_collision**: The same D1 analogy is overloaded across multiple concepts, causing cross-talk. **Fix**: Diversify the analogy — invent a new D1 analogy specific to this concept, or namespace analogies by concept_id.

**Rule 13 — boundary_violation**: A D4 boundary condition is violated by a cross-concept dependency (e.g., concept A assumes concept B holds, but B's D4 says it breaks under that condition). **Fix**: Guard the dependency — add a precondition check in D2, or refine D4 to exclude the dependency case.

**Rule 14 — dependency_drift**: A referenced concept's D3 definition has drifted across iterations, breaking the cross-concept mapping. **Fix**: Pin the dependency version — record the exact iteration/hash of the referenced concept's lattice that this concept depends on.
| **Mapping Gap (NEW)** | Cross-layer mapping failure | D1↔D2 or D2↔D3 mapping incomplete per teach-agent mapping requirements |

### Mapping-Driven Gap Rules (REVISED — Structural Emergence)
| Rule | Detected Pattern | Gap Type | Auto-Fix Strategy |
|------|-----------------|----------|-------------------|
| 9 | orphan_procedure | unexecutable_intuition | add_execution_step |
| 10 | unmanipulated_formal | unmanipulated_formal | add_variable_step |
| 11 | definition_mismatch | definition_collision | disambiguate_term |
| 12 | analogy_collision | analogy_overload | diversify_analogy |
| 13 | boundary_violation | boundary_violation | guard_dependency |
| 14 | dependency_drift | dependency_drift | pin_dependency_version |

**Rule 9 — orphan_procedure**: A D1 analogy element has no corresponding D2 step. The intuition is unexecutable. **Fix**: Add an execution step to D2 that operationalizes the orphan element.

**Rule 10 — unmanipulated_formal**: A D3 variable/term is never manipulated in D2. The formalism is inert. **Fix**: Add a variable introduction/manipulation step to D2, or remove the variable from D3 if it is not essential.

**Rule 11 — definition_mismatch**: Two D3 definitions of the same term (from different iterations or sources) conflict. **Fix**: Disambiguate the term — split into term_A and term_B, or merge definitions with explicit conditions.

**Rule 12 — analogy_collision**: The same D1 analogy is overloaded across multiple concepts, causing cross-talk. **Fix**: Diversify the analogy — invent a new D1 analogy specific to this concept, or namespace analogies by concept_id.

**Rule 13 — boundary_violation**: A D4 boundary condition is violated by a cross-concept dependency (e.g., concept A assumes concept B holds, but B's D4 says it breaks under that condition). **Fix**: Guard the dependency — add a precondition check in D2, or refine D4 to exclude the dependency case.

**Rule 14 — dependency_drift**: A referenced concept's D3 definition has drifted across iterations, breaking the cross-concept mapping. **Fix**: Pin the dependency version — record the exact iteration/hash of the referenced concept's lattice that this concept depends on.

### Step 3: Prioritize Gaps
Priority order (override only with explicit reason):
1. **Critical audit issues first** (severity = critical)
2. **D3 gaps before D1 gaps** (formal understanding drives analogy quality)
3. **Conceptual gaps before presentation gaps**
4. **Gaps requiring external knowledge** (these may trigger Auto-Search per PRD §6)

### Step 4: Generate Search Queries (if needed)
For any gap where `external_knowledge_required: true`, generate a specific `query` string:
- The query must be answerable by a web search
- Avoid overly broad queries ("explain quantum mechanics"); instead use precise questions ("Bell's theorem precise statement and assumptions")
- If ≥2 gaps require external knowledge, the orchestrator may spawn a search-agent (PRD §6.C)

### Step 5: Formulate Learning Strategy
The `strategy` field must be a concise, actionable plan. It should state:
- Which gap to tackle first and why
- Whether to adjust the generation strategy (e.g., "switch from analogy-first to formal-first for D3");
- Whether external knowledge acquisition is needed;
- What the target improvement looks like for the next iteration.

## Available Tools

- **kimi_search**: for researching gaps that require external knowledge
- **kimi_fetch**: for reading authoritative sources to verify whether a gap is real or a presentation issue
- **LLM via localhost:18790**: for reasoning through gap classification and strategy generation

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. All required keys present — `iteration`, `timestamp`, `gaps`, `strategy`, `metadata`
4. Every gap has non-empty `id`, `description`, `layer` ∈ {d1, d2, d3, d4}
5. Every gap has boolean `external_knowledge_required`
6. If `external_knowledge_required == true`, then `query` must be non-empty string
7. `strategy` is non-empty string (≥30 words)
8. Top-level `timestamp` key exists and is ISO-8601 formatted
9. `metadata.gap_count` equals `len(gaps)`
10. `metadata.external_knowledge_count` equals count of gaps with `external_knowledge_required: true`
11. `metadata.priority_layer` is one of {d1, d2, d3, d4, null}; null means no gaps or all layers equally critical

## Auto-Search Trigger Logic (PRD §6)

This agent does **not** spawn search agents. Instead, it signals the orchestrator by setting `external_knowledge_required: true` on gaps. The orchestrator reads `grow_output.json` and applies PRD §6 rules:
- **Condition C**: ≥2 gaps tagged `external_knowledge_required` → orchestrator spawns search-agent
- **Condition A**: concept un-Ming-Wu for ≥3 iterations → search-agent triggered (orchestrator tracks)
- **Condition D**: novelty stall → search-agent triggered (orchestrator tracks via novelty-agent)

## Orchestrator Integration

After writing output, announce completion with:
```
DONE: {output_path}
Concept: {concept_id}
Iteration: {iteration}
Gaps identified: {gap_count}
External knowledge needed: {external_knowledge_count}
Priority layer: {priority_layer}
```
