# Search Agent Task Template

## Objective
Perform comprehensive web search on a concept to gather factual foundation for D1–D4 generation. Produce one complete `search_results.json` per task invocation.

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "concept_id": "string (stable identifier)",
  "concept_name": "string (the concept to research)",
  "iteration": 1,
  "previous_queries": ["string (query from prior iteration)", "..."]
}
```

Notes:
- `previous_queries` may be empty on iteration 1.
- Use `previous_queries` to avoid repeating the same search queries across iterations.
- The orchestrator guarantees `concept_id` and `concept_name` are non-empty.

## Output

Write to: `{output_path}`

Format: JSON with schema (see PRD.md §7 search_results.json):
```json
{
  "concept_id": "string",
  "queries": ["string (query 1)", "string (query 2)", "..."],
  "results": [
    {
      "source": "string (domain or site name)",
      "url": "string (full URL)",
      "snippet": "string (relevant excerpt)",
      "relevance": "number (0–1)"
    }
  ],
  "synthesis": "string (comprehensive synthesis of key findings)",
  "timestamp": "ISO-8601 string"
}
```

## Search Strategy

### Query Design Rules
1. Execute at least 3 distinct search queries per task invocation.
2. Vary query intent across:
   - **Definition/ formal**: e.g., `"{concept_name} definition"`, `"{concept_name} formal specification"`
   - **Analogy/ intuitive**: e.g., `"{concept_name} explained simply"`, `"{concept_name} analogy"`
   - **Boundary/ counter-example**: e.g., `"{concept_name} limitations"`, `"{concept_name} when it fails"`, `"{concept_name} edge cases"`
3. Do not repeat any query listed in `previous_queries`.
4. Prefer authoritative sources: academic papers, official documentation, textbooks, reputable technical blogs.
5. If first query returns low-quality results, reformulate and retry before recording.

### Result Evaluation Rules
1. For each result, assign `relevance` ∈ [0.0, 1.0] based on:
   - **0.8–1.0**: Directly defines or deeply explains the concept
   - **0.5–0.79**: Related background, useful analogy, or adjacent technique
   - **0.0–0.49**: Tangential or low-quality source
2. Record at least 5 results with `relevance >= 0.5`.
3. Every recorded result must have non-empty `source`, `url`, `snippet`, and numeric `relevance`.
4. `snippet` should be a direct excerpt or a concise paraphrase of the most relevant passage (not the entire page).

### Synthesis Rules
1. `synthesis` must be non-empty (≥50 words).
2. Synthesize across all results — do not merely list them.
3. Cover:
   - Core definition and key properties
   - Most useful intuitive framing(s)
   - Known limitations, edge cases, or failure modes
   - Any notation or formal conventions observed
4. Flag conflicting information and note which source(s) support each claim.

## Available Tools

- **kimi_search** (primary): execute web search queries; use for all initial discovery
- **kimi_fetch** (secondary): read result pages in depth when a search result promises high-value detail but the snippet is insufficient
- **LLM via localhost:18790**: for synthesizing findings and evaluating relevance scores

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. All required keys present — `concept_id`, `queries`, `results`, `synthesis`, `timestamp`
4. Top-level `timestamp` key exists and is ISO-8601 formatted
5. `queries` array length >= 3
6. `results` array contains at least 5 items with `relevance >= 0.5`
7. Every result has non-empty `source`, `url`, `snippet`, and numeric `relevance` ∈ [0.0, 1.0]
8. `synthesis` is non-empty string (≥50 words) and synthesizes key findings (not a list)
9. No query in `queries` duplicates any item in `previous_queries`
10. `concept_id` in output matches input `concept_id`

## Failure Protocol

If any completion criterion fails, do not write output. Instead:
1. Identify which criterion failed and why
2. Attempt one self-correction using available tools (e.g., run additional queries, re-evaluate relevance scores)
3. If still failing, write a partial failure report to `{output_path}.failed` with keys: `failed_criterion`, `reason`, `attempted_fix`

## Orchestrator Integration

After writing output, announce completion with:
```
DONE: {output_path}
Concept: {concept_id}
Iteration: {iteration}
Queries executed: {N}
High-relevance results: {M}
```
