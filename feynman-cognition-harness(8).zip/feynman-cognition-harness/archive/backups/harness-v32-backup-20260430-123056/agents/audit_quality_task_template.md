# Audit-Quality Agent Task Template

## Objective

Independent, adversarial quality verification of any worker agent's output. Assume the worker's deliverable is flawed until proven otherwise. Validate against the worker's own completion criteria, the FCH PRD functional requirements, and machine-verifiable structural constraints.

## Input

Read three files in order:

1. **Worker output**: `{worker_output_path}` — The JSON file produced by the worker agent (e.g., `teach_output.json`, `audit_output.json`, `grow_output.json`, `verification_output.json`, etc.)
2. **Worker template**: `{worker_template_path}` — The task template used by the worker (to know what completion criteria the worker was supposed to meet)
3. **PRD**: `{prd_path}` — FCH PRD.md for functional reference and schema definitions

## Output

Write to: `{audit_report_path}`

Format: JSON with schema:

```json
{
  "iteration": 1,
  "worker_type": "teach-agent|audit-agent|grow-agent|verify-agent|consolidate-agent|...",
  "status": "PASS|NEEDS_FIX|REJECT",
  "score": 85,
  "issues": [
    {
      "severity": "critical|warning|info",
      "description": "string (what is wrong)",
      "location": "string (JSON path, e.g., '$.d2[2]')",
      "fix_suggestion": "string (how to fix it)",
      "rule_violated": "string (PRD section or worker template criterion ref)"
    }
  ],
  "recommendations": [
    "string (actionable improvement, present if status != PASS)"
  ],
  "machine_checks": {
    "file_exists": true,
    "valid_json": true,
    "required_keys_present": true,
    "schema_types_correct": true,
    "timestamp_present": true,
    "timestamp_iso8601": true
  },
  "timestamp": "2026-04-28T12:00:00+08:00"
}
```

## Audit Protocol (Execute in Order)

### Phase 1: Structural Validation (Machine-Verifiable)

Run these checks first. Any failure here is automatic grounds for NEEDS_FIX or REJECT.

| # | Check | Method | Failure Threshold |
|---|-------|--------|-------------------|
| 1.1 | File exists | `os.path.exists(worker_output_path)` | If false → REJECT |
| 1.2 | Valid JSON | `json.loads(content)` without exception | If false → REJECT |
| 1.3 | Required top-level keys | Read worker template "Completion Criteria" section; verify all mandatory keys exist in output | Missing key → NEEDS_FIX |
| 1.4 | Top-level `timestamp` key exists | Key-in-dict check | Missing → NEEDS_FIX |
| 1.5 | `timestamp` is ISO-8601 formatted | Regex match | Invalid format → NEEDS_FIX |
| 1.6 | Schema types correct | Type check per key against PRD schema (§7.x matching worker type) | Type mismatch → NEEDS_FIX |
| 1.7 | No `null` values in mandatory fields | Null check on required keys | `null` in required field → NEEDS_FIX |

### Phase 2: Worker-Template Compliance

Read the worker template's "Completion Criteria" section. For each criterion listed:

| # | Check | Source | Failure |
|---|-------|--------|---------|
| 2.1 | Criterion implemented | Verify the output satisfies the stated check | If not → NEEDS_FIX |
| 2.2 | Numeric constraints met | Length checks, range checks, word counts | Violation → NEEDS_FIX |
| 2.3 | Array/object cardinality | Min/max counts per template spec | Violation → NEEDS_FIX |
| 2.4 | Self-check claims | If template requires "No contradictory claims", verify | Contradiction found → NEEDS_FIX |
| 2.5 | Failure protocol followed | If output has `.failed` extension, audit the failure report instead | Report whether failure was legitimate |

### Phase 3: PRD Functional Alignment

Cross-reference the worker output against PRD.md:

| Worker Type | PRD Section | Key Checks |
|-------------|-------------|------------|
| **teach-agent** | §3 (D1–D4) + §7.1 | D1 ≤150 words, no jargon; D2 ≥3 steps ≤10; D3 confidence marked; D4 ≥3 boundaries with counter-examples and failure mechanisms |
| **audit-agent** | §7.2 | `valid` boolean present; `issues` array with `layer`, `severity`, `description`; `summary` non-empty |
| **grow-agent** | §7.3 | `gaps` array with `id`, `description`, `layer`, `external_knowledge_required`, `query`; `strategy` non-empty |
| **verify-agent** | §7.4 | `cross_time_consistent` and `independent_reproduction` booleans; `external_sources` array; `confidence.overall` float in [0.0, 1.0] |
| **consolidate-agent** | §7.6 | `version_stack`, `open_problems`, `learning_curve`, `epistemic_emotion`, `attention_focus`, `consolidation_status`, `review_schedule` all present and typed correctly |
| **any other** | §7.x matching type | Schema compliance per PRD |

### Phase 4: Content Quality (Adversarial Deep Check)

Run these even if structural checks pass. Be skeptical.

| # | Check | Method | Severity if Failed |
|---|-------|--------|---------------------|
| 4.1 | Claims are falsifiable | Every factual statement must be checkable or sourced | Warning if unverifiable; Critical if demonstrably false |
| 4.2 | No circular definitions | D3 must not define the concept using itself or its synonyms | Critical |
| 4.3 | Boundary conditions are real | D4 counter-examples must show actual failure, not trivial edge cases | Warning |
| 4.4 | Analogy maps structurally | D1 analogy must have clear structural correspondence to the concept | Warning |
| 4.5 | Steps are independently executable | D2 steps must not reference undefined variables or prior unstated knowledge | Critical |
| 4.6 | Confidence values are justified | `confidence` fields must have implicit or explicit justification | Info |
| 4.7 | No trivial tautologies | Content must add information, not restate the obvious | Info |
| 4.8 | Cross-layer consistency | Claims in D1–D4 must not contradict each other (use contradiction-agent output if available) | Critical if contradiction found |

### Phase 5: External Fact-Checking (If Applicable)

Use `kimi_fetch` for any URL claims in the output. Use `kimi_search` for factual claims that can be externally verified.

| # | Check | Trigger | Severity |
|---|-------|---------|----------|
| 5.1 | URL accessible | `external_sources` contains URLs | Warning if 404 or unreachable |
| 5.2 | Claim verifiable | Output makes specific factual claim about a named entity, formula, or historical event | Warning if unverified; Critical if contradicted by source |
| 5.3 | Notation/formula correct | Mathematical or formal notation present | Warning if suspected incorrect |

## Scoring Formula

```
score = 100
- (critical_count * 25)    // capped at -75
- (warning_count * 10)     // capped at -20
- (info_count * 2)         // capped at -5

If structural validation (Phase 1) has any failure: max score = 60
If JSON is invalid or file missing: score = 0

status = PASS      if score >= 80 and critical_count == 0 and structural checks all pass
status = NEEDS_FIX if score >= 40 and (critical_count > 0 or structural checks have minor failures)
status = REJECT    if score < 40 or structural checks have major failures (invalid JSON, missing file)
```

## Available Tools

- **kimi_fetch**: Read web pages for fact-checking URLs or external claims
- **kimi_search**: Search the internet to verify factual claims in the worker output
- **LLM via localhost:18790**: For reasoning about logical consistency, contradiction detection, and quality assessment

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{audit_report_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. `status` is exactly one of: `"PASS"`, `"NEEDS_FIX"`, `"REJECT"`
4. `score` is integer in range [0, 100]
5. `issues` is an array (empty allowed only if `status == "PASS"`)
6. Each issue in `issues` has all required keys: `severity`, `description`, `location`, `fix_suggestion`, `rule_violated`
7. `severity` values are only: `"critical"`, `"warning"`, `"info"`
8. At least one recommendation in `recommendations` array if `status != "PASS"`
9. `timestamp` is present and valid ISO-8601
10. `machine_checks` object is present with all 6 boolean keys: `file_exists`, `valid_json`, `required_keys_present`, `schema_types_correct`, `timestamp_present`, `timestamp_iso8601`
11. `worker_type` is a non-empty string matching the worker's agent type
12. `iteration` is an integer ≥ 1

## Failure Protocol

If any completion criterion for the audit report itself fails:
1. Identify which criterion failed and why
2. Re-run the failed check or regenerate the report
3. If still failing after one self-correction attempt, write a partial failure report to `{audit_report_path}.failed` with keys: `failed_criterion`, `reason`, `attempted_fix`, `partial_report` (include what you were able to produce)

## Orchestrator Integration

After writing the audit report, announce completion with:

```
DONE: {audit_report_path}
Worker: {worker_type}
Status: {status}
Score: {score}
Issues: {issues_count} critical, {warnings_count} warning, {infos_count} info
```
