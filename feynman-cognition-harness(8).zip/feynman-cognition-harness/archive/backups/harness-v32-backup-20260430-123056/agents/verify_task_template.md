# Verify Agent Task Template

## Objective
Perform multi-dimensional verification of the current iteration's knowledge: cross-temporal consistency, independent reproduction feasibility, and external source validation. Output a structured confidence assessment per D-layer and overall.

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "grow_output_path": "string (path to grow_output.json)",
  "teach_output_path": "string (path to teach_output.json)",
  "audit_output_path": "string (path to audit_output.json)",
  "state_path": "string (path to state.json)",
  "concept": "string",
  "concept_id": "string",
  "iteration": 1,
  "previous_verification": {
    "iteration": 1,
    "cross_time_consistent": true,
    "confidence": {"overall": 0.85}
  }
}
```

Notes:
- Load all referenced JSON files from their paths.
- `previous_verification` may be `null` on first verify phase.

## Output

Write to: `{output_path}`

Format: JSON with schema (see PRD.md §7.4):
```json
{
  "iteration": 1,
  "timestamp": "ISO-8601 string",
  "cross_time_consistent": true,
  "independent_reproduction": true,
  "external_sources": ["url1", "url2"],
  "confidence": {
    "overall": 0.85,
    "d1": 0.9,
    "d2": 0.8,
    "d3": 0.85,
    "d4": 0.8
  },
  "verification_details": {
    "cross_time_notes": "string",
    "reproduction_notes": "string",
    "external_validation_notes": "string"
  },
  "metadata": {
    "sources_checked": 0,
    "contradictions_found": 0
  }
}
```

## Verification Dimensions (PRD §7.4)

### Dimension 1: Cross-Temporal Consistency
- Compare current `teach_output.json` against all previous `teach_output.json` files (if any).
- Check: Are D3 definitions stable or improving? (Refinement is allowed; contradiction is not.)
- Check: Are D4 boundaries expanding or staying consistent?
- Check: Does D1 analogy evolve without losing the core structural mapping?
- Set `cross_time_consistent: false` if any D-layer contradicts its historical version.

### Dimension 2: Independent Reproduction
- Assess whether a second, independent agent could reproduce the D2 procedure from the D3 definition alone.
- Assess whether the D3 definition is sufficiently precise to constrain D2 to the observed steps.
- Set `independent_reproduction: false` if D2 steps contain arbitrary choices not derivable from D3.

### Dimension 3: External Validation
- For each D3 formal claim marked `high` confidence, attempt to find an external authoritative source confirming it.
- For D4 counter-examples, verify they are genuinely outside the concept scope per external definitions.
- Populate `external_sources` with URLs of sources checked (not necessarily all confirming; dissenting sources should be noted in `verification_details`).
- If external knowledge gaps were flagged by grow-agent, verify whether the search results (if available) resolved them.

## Confidence Scoring Rules

Score each D-layer and overall on [0.0, 1.0]:

| Layer | Scoring Criteria |
|-------|-----------------|
| **D1** | 1.0 if analogy is vivid, structurally accurate, and stress-tested; deduct 0.1 for each of: jargon, mixed analogy, superficial mapping |
| **D2** | 1.0 if all steps are executable, ordered, and derive from D3; deduct 0.1 for each of: ambiguous step, missing success criteria, steps not derivable from D3 |
| **D3** | 1.0 if definition is precise, notation correct, and externally confirmed; deduct 0.1 for each of: circular definition, unmarked low-confidence claim, notation error |
| **D4** | 1.0 if all boundaries are genuine, counter-examples are correct, and mechanisms are explained; deduct 0.1 for each of: boundary inside scope, wrong counter-example, missing mechanism |
| **Overall** | Average of D1–D4, then adjust ±0.05 based on cross-temporal consistency and external validation results |

**Ming Wu Threshold** (PRD §4):
- `overall >= 0.90` is required for `confidence_high` condition
- If `overall < 0.90`, note in `verification_details` which layer(s) dragged the score down

## Available Tools

- **kimi_search**: for finding external sources to validate D3 claims and D4 counter-examples
- **kimi_fetch**: for reading external pages to confirm or challenge formal statements
- **LLM via localhost:18790**: for reasoning through cross-temporal comparison and reproduction feasibility

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. All required keys present — `iteration`, `timestamp`, `cross_time_consistent`, `independent_reproduction`, `external_sources`, `confidence`, `verification_details`, `metadata`
4. `cross_time_consistent` is boolean
5. `independent_reproduction` is boolean
6. `external_sources` is array of strings (may be empty if no sources checked, but prefer at least 1)
7. `confidence` object has keys `overall`, `d1`, `d2`, `d3`, `d4`, all floats in [0.0, 1.0]
8. `confidence.overall` is within ±0.05 of the average of `d1`–`d4` (sanity check)
9. `verification_details` has non-empty strings for `cross_time_notes`, `reproduction_notes`, `external_validation_notes` (each ≥20 words)
10. Top-level `timestamp` key exists and is ISO-8601 formatted
11. `metadata.sources_checked` equals `len(external_sources)`
12. `metadata.contradictions_found` is non-negative integer

## Confidence Collapse Detection (PRD §6.B)

This agent must detect and report confidence collapse:
- If `previous_verification` exists and `confidence.overall` dropped by ≥0.2 from previous iteration, set a flag in `verification_details`:
  ```json
  "confidence_collapse": {
    "detected": true,
    "previous_overall": 0.85,
    "current_overall": 0.60,
    "drop": 0.25
  }
  ```
- The orchestrator reads this and may trigger Auto-Search per PRD §6.B.

## Orchestrator Integration

After writing output, announce completion with:
```
DONE: {output_path}
Concept: {concept_id}
Iteration: {iteration}
Cross-time consistent: {true|false}
Independent reproduction feasible: {true|false}
Confidence overall: {confidence.overall}
Sources checked: {sources_checked}
```
