# FCH Ralph-Style Harness — 执行 Checklist

> 主控 agent 维护此清单。每步完成后更新状态。

## 总体任务
将 FCH v3.2 改造为 Ralph Loop 执行模式：主控纯协调，子 agent 分工执行，文件系统传递成果，审计闭环，异常恢复。

---

## Phase 1: 基础设施

| 步骤 | 描述 | 输出文件 | 负责 Agent | 状态 | 审计 Agent |
|------|------|----------|-----------|------|-----------|
| 1.1 | 创建 harness/ 目录结构 | harness/ 目录树 | infra-agent | ✅ 已完成 | audit-infra | 已创建
| 1.2 | 编写 PRD.md | harness/PRD.md | infra-agent | ✅ 已完成 | audit-infra | 236行，审计NEEDS_FIX
| 1.3 | 编写主控 orchestrator（纯协调版） | harness/orchestrator.py | infra-agent | ✅ 已完成 | audit-infra | 316行，语法通过
| 1.4 | 编写状态管理工具 | harness/state_manager.py | infra-agent | ✅ 已完成 | audit-infra | 156行，原子写入
| 1.5 | 修复 PRD.md 阈值+schema | harness/PRD.md | fix-agent | ✅ 已完成 | re-audit | 3处修正
| 1.6 | 重新审计验收修复 | harness/audit_phase1_reverify.md | re-audit | ✅ 已通过 | re-audit | 全部3项PASS

## Phase 2: Worker Agent 模板

| 步骤 | 描述 | 输出文件 | 负责 Agent | 状态 | 审计 Agent |
|------|------|----------|-----------|------|-----------|
| 2.1 | teach-agent 模板 | harness/agents/teach_task_template.md | worker-agent | ✅ 已完成 | audit-worker | 109行，审计NEEDS_FIX
| 2.2 | audit-agent 模板 | harness/agents/audit_task_template.md | worker-agent | ✅ 已完成 | audit-worker | 135行，审计NEEDS_FIX
| 2.3 | grow-agent 模板 | harness/agents/grow_task_template.md | worker-agent | ✅ 已完成 | audit-worker | 132行，审计NEEDS_FIX
| 2.4 | verify-agent 模板 | harness/agents/verify_task_template.md | worker-agent | ✅ 已完成 | audit-worker | 145行，审计NEEDS_FIX
| 2.5 | 修复 timestamp schema | 4个模板文件 | fix-agent | ✅ 已完成 | re-audit | 4处修正

## Phase 3: 审计闭环

| 步骤 | 描述 | 输出文件 | 负责 Agent | 状态 | 审计 Agent |
|------|------|----------|-----------|------|-----------|
| 3.1 | audit-quality-agent 模板 | harness/agents/audit_quality_task_template.md | audit-agent | ✅ 已完成 | meta-audit | 已创建
| 3.2 | 主控集成审计逻辑 | harness/orchestrator.py 更新 | orchestrator-agent | ✅ 已完成 | meta-audit | 语法通过
| 3.3 | 修复 orchestrator 审计缺陷 | harness/orchestrator.py | fix-agent | ✅ 已通过 | re-audit | 2处修正，4项全通
| 3.4 | 修正 Self-Test 位置 | PRD.md + orchestrator.py | prd-fix | 🔄 修复中 | meta-audit | startup检查
| 3.5 | 搜索改为必选项（前置步骤） | PRD.md + orchestrator.py + templates | multi-fix | ✅ 3/3 完成 | meta-audit | ✅ 15/15 通过
| 4.2 | **补充 D1↔D2、D2↔D3 + 跨概念映射冲突** | harness/structural_emergence_design.md 追加 | structural-arch | ✅ 设计完成 | meta-audit | +502行, 1373行总计
| 4.3 | **实施：模板修改 + orchestrator接线** | harness/* | structural-impl | ✅ 已完成 | meta-audit | template-agent + orchestrator-agent 通过
| 4.4 | **集成测试：映射分析 + 跨概念 + 回归** | harness/tests/test_structural_*.py | structural-impl | ✅ 全部通过 | meta-audit | 19/19 PASS
| 4.5 | **最终验收：meta-audit 全部修改** | harness/* | structural-impl | ✅ 验收通过 | meta-audit | 23/23 PASS

## Phase 4: 异常处理

| 步骤 | 描述 | 输出文件 | 负责 Agent | 状态 | 审计 Agent |
|------|------|----------|-----------|------|-----------|
| 4.1 | 超时检测机制 | harness/orchestrator.py 更新 | exception-agent | ✅ 已通过 | meta-audit | 7项全通
| 4.2 | 修复循环（NEEDS_FIX） | harness/orchestrator.py | exception-agent | ✅ 已通过 | meta-audit | 7项全通
| 4.3 | 策略调整（连续失败） | harness/orchestrator.py | exception-agent | ✅ 已通过 | meta-audit | 7项全通

## Phase 5: 集成测试

| 步骤 | 描述 | 输出文件 | 负责 Agent | 状态 | 审计 Agent |
|------|------|----------|-----------|------|-----------|
| 5.1 | 端到端测试 | harness/tests/test_e2e.py | test-agent | ✅ 已通过 | audit-test | PASS
| 5.2 | 状态恢复测试 | harness/tests/test_resume.py | test-agent | ✅ 已通过 | audit-test | PASS
| 5.3 | 审计闭环测试 | harness/tests/test_audit_loop.py | test-agent | ✅ 已通过 | audit-test | PASS

## Phase 6: 文档系统清理与对齐

| 步骤 | 描述 | 输出文件 | 负责 Agent | 状态 | 审计 Agent | 备注 |
|------|------|----------|-----------|------|-----------|------|
| 6.1 | **创建 Log.md + 清理 README/SKILL Changelog** | Log.md, README.md, SKILL.md | cleanup-agent | ✅ 已完成 | meta-audit | Log.md 已创建，README/SKILL 已移除 Changelog，版本号 3.0.0→3.2.0 |
| 6.2 | **P0: 删除过时文件 + 测试残留** | - | cleanup-agent | ✅ 已完成 | meta-audit | DOCUMENT_AUDIT.md + epistemic_design.md 已归档；测试残留目录不存在 |
| 6.3 | **P1: PRD bss 阈值 + 审计报告冗余** | PRD.md, archive/ | fix-agent | ✅ 已完成 | meta-audit | BSS Note 已添加；8 个中间审计文件已归档 |
| 6.4 | **P2: legacy 文件 + references 引用** | - | fix-agent | ✅ 无需修改 | meta-audit | legacy 是活跃策略数据源；references 已被引用 |
| 6.5 | **最终验收：meta-audit 全部修改** | - | meta-audit | ✅ 18/18 PASS | - | 全部通过，无遗留

---

## 当前状态

**阶段**: Phase 1-6 全部完成 ✅
**最终审计**: PASS (18/18)
**文档系统清理**: 完成
