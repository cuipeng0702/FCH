# Phase 3 Audit Report

## Summary
Status: NEEDS_FIX
Issues found: 2

## audit_quality_task_template.md
Status: PASS
Details:
- Universal: PASS. Template handles any worker type via placeholders (`{worker_output_path}`, `{worker_template_path}`) and explicitly lists teach-agent, audit-agent, grow-agent, verify-agent, consolidate-agent, and "any other" in Phase 3.
- Adversarial framing: PASS. Opens with "Assume the worker's deliverable is flawed until proven otherwise" and Phase 4 is titled "Content Quality (Adversarial Deep Check)".
- Input includes worker_output + worker_template + PRD: PASS. Explicitly lists all three in the Input section.
- Output has status/score/issues: PASS. Schema defines `status` (PASS/NEEDS_FIX/REJECT), `score` (0-100), `issues` array with `severity`, `description`, `location`, `fix_suggestion`, `rule_violated`.
- Completion criteria are machine-verifiable: PASS. Lists 12 verifiable criteria with explicit methods: `os.path.exists()`, `json.loads()`, key-in-dict, type checks, ISO-8601 regex, range checks.
- References PRD sections correctly: PASS. Phase 3 maps worker types to PRD §3, §7.1-§7.6 accurately. Section numbers match PRD.md exactly.

## orchestrator.py
Status: NEEDS_FIX
Details:
- Has `_spawn_worker()` method: PASS. Exists (lines 97-112) with correct signature and output path return.
- Has `_spawn_auditor()` method: PASS. Exists (lines 114-127) with correct signature and audit path return.
- Has `_handle_audit_result()` method: PASS. Exists (lines 129-146), handles PASS/NEEDS_FIX/REJECT, safe default for unknown status.
- Has `_run_single_task()` with audit integration: PASS. Exists (lines 37-93), implements worker → auditor → fix-loop with max 3 attempts.
- Budget tracking at every spawn point: PASS. Checked and decremented before worker spawn and before auditor spawn; fix-loop iterations are also budgeted.
- Pure coordinator (no direct LLM calls): PASS. Only file I/O, JSON manipulation, state management, and stdout reporting. No LLM calls.
- Ralph loop structure intact: PASS. `run()` implements: LOAD → CHECK BUDGET → PICK TASK → RUN SINGLE TASK → CHECK CONVERGENCE → SAVE STATE → LOOP.
- No syntax errors (`python3 -m py_compile`): PASS. Verified successfully.

Issues:
1. **CRITICAL** — `_handle_audit_result()` defaults missing/corrupt audit reports to `"PASS"`. Line `status = audit.get("status", "PASS")` with `audit` defaulting to `{}` if file is missing or JSON is invalid. A failed/crashed auditor that writes no file silently approves the worker output. Safe default must be `"NEEDS_FIX"` or `"REJECT"`.
2. **MINOR** — `_spawn_auditor()` does not pass the PRD path to the auditor. The audit template requires three inputs (worker output, worker template, PRD), but the orchestrator only provides two. The PRD path should be passed as a third argument or embedded in the spawn context so the auditor can reference PRD.md during validation.

## Action Required

1. **Fix audit default safety** (`orchestrator.py`, `_handle_audit_result`):
   - Change `audit.get("status", "PASS")` to `audit.get("status", "NEEDS_FIX")`.
   - Alternatively, explicitly check if the audit file exists and is valid JSON before reading status; if missing/corrupt, return `"REJECT"` and log an exception.

2. **Pass PRD path to auditor** (`orchestrator.py`, `_spawn_auditor`):
   - Add `prd_path` parameter to `_spawn_auditor()` signature.
   - In `_run_single_task()`, compute `prd_path = str(self.harness_dir / "PRD.md")` and pass it to `_spawn_auditor()`.
   - Include `prd_path` in the pending marker or spawn task context so the auditor subagent can read it.
