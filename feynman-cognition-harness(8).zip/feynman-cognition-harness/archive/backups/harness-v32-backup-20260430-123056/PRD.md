# FCH Ralph-Style Execution Harness — Product Requirements Document

## 1. Overview

This document defines the functional specification for the Feynman Cognition Harness (FCH) Ralph-Style execution harness. The harness is a pure-coordinator architecture: the main orchestrator delegates all work to specialized sub-agents and only manages file-system state, budget, and scheduling.

## 2. Execution Cycle: Teach → Audit → Grow → Verify → Consolidate

Each iteration of the harness follows a 5-phase cycle:

| Phase | Agent | Purpose | Input | Output |
|-------|-------|---------|-------|--------|
| **Search** | search-agent | Comprehensive web search on the concept | `state.json` (concept) | `search_results.json` |
| **Teach** | teach-agent | Decompose a concept into D1–D4 explanations | `state.json` (concept ID) + `search_results.json` | `teach_output.json` |
| **Audit** | audit-agent | Critically review the D1–D4 explanations | `teach_output.json` | `audit_output.json` |
| **Grow** | grow-agent | Identify knowledge gaps and propose learning strategies | `audit_output.json` + `state.json` | `grow_output.json` |
| **Verify** | verify-agent | Cross-check, external-validate, and score confidence | `grow_output.json` + `state.json` | `verification_output.json` |
| **Consolidate** | consolidate-agent | Merge verified knowledge into the lattice | All iteration results | Lattice update + next schedule |

After every worker output, an **audit-quality-agent** independently validates the output against this PRD. The cycle only advances on `PASS`.

## 3. D1–D4 Definitions and Generation Requirements

### 3.1 D1 — Intuitive Analogy
- **Definition**: Explain the concept as if to an 8-year-old using a concrete, everyday analogy.
- **Requirements**:
  - One vivid analogy that maps the target concept to a familiar experience.
  - No jargon. No abstractions. Every noun must be tactile or visual.
  - Max 150 words.

### 3.2 D2 — Step-by-Step Procedure
- **Definition**: A reproducible, ordered list of actions that demonstrates or applies the concept.
- **Requirements**:
  - Numbered steps (≥3, ≤10).
  - Each step must be executable by a human without external clarification.
  - Include a "success criteria" sentence at the end.

### 3.3 D3 — Formal Definition
- **Definition**: The precise, academic/technical formulation of the concept, including notation or taxonomy.
- **Requirements**:
  - Cite domain-standard terminology.
  - If mathematical: include core equation or formal statement.
  - If non-mathematical: include definitional sentence + boundary conditions.
  - Mark confidence level (`high` / `medium` / `low`) for each formal claim.

### 3.4 D4 — Boundary & Counter-Example Map
- **Definition**: A crisp delineation of where the concept applies and where it breaks, including concrete counter-examples.
- **Requirements**:
  - List ≥3 boundary conditions.
  - For each boundary, provide a concrete counter-example showing failure.
  - Explain *why* the failure occurs at the boundary (mechanism, not just symptom).

## 4. Ming Wu 6 Conditions (Detailed Specification)

A concept node is considered "deeply understood" (Ming Wu) only when all six conditions are met simultaneously.

| # | Condition | Machine-Verifiable Test | Threshold |
|---|-----------|------------------------|-----------|
| 1 | **D1 Completeness** | `teach_output.json` contains a non-empty `d1` string of ≥20 words. | `true` |
| 2 | **D2 Actionability** | `teach_output.json` contains a `d2` array with length ≥3. | `true` |
| 3 | **D3 Formal Soundness** | `teach_output.json` contains a non-empty `d3` string with at least one defined term. | `true` |
| 4 | **D4 Boundary Clarity** | `teach_output.json` contains a `d4` object with `boundaries` array length ≥3 and each item has a `counter_example`. | `true` |
| 5 | **Cross-Layer Consistency** | `contradictions.json` (from contradiction-agent) reports `count == 0` between D1–D4. | `count == 0` |
| 6 | **Confidence ≥ 0.90** | `confidence_result.json` contains `overall >= 0.90`. | `overall >= 0.90` |

**Note**: Brier Skill Score (BSS) threshold is 0.60 when `brier_data` exists. If no prediction history exists, BSS condition is skipped (N/A).

**Ming Wu Result Format**:
```json
{
  "passed": true,
  "conditions": {
    "d1_complete": true,
    "d2_actionable": true,
    "d3_sound": true,
    "d4_clear": true,
    "cross_layer_consistent": true,
    "confidence_high": true
  },
  "timestamp": "2026-04-28T11:43:00+08:00"
}
```

## 5. Novelty Calculation Algorithm

**Purpose**: Prevent repetitive explanations by measuring how much the current `teach_output.json` diverges from all historical `teach_output.json` files.

**Algorithm**:
1. Extract the union of all unique tokens (words, normalized) from current `d1 + d3`.
2. For each historical iteration `i`, extract the same token union.
3. Compute Jaccard similarity: `J(i) = |current ∩ hist_i| / |current ∪ hist_i|`.
4. Novelty ratio = `1 - max(J(i))` over all historical iterations.
5. If no history exists, novelty ratio = `1.0`.

**Thresholds**:
- `novelty_ratio >= 0.15`: ACCEPT (sufficiently new)
- `novelty_ratio < 0.15`: STALE (trigger regrow or search)

**Output Format**:
```json
{
  "novelty_ratio": 0.42,
  "decision": "ACCEPT",
  "max_similar_iteration": 2,
  "timestamp": "2026-04-28T11:43:00+08:00"
}
```

## 6. Search Prerequisites

Search is a **mandatory prerequisite** for every Teach phase.

- **search-agent** runs **before** teach-agent in every iteration.
- Search results (`search_results.json`) are passed as input to teach-agent.
- The orchestrator spawns search-agent unconditionally at the start of each iteration.
- **Additional searches** may be triggered by grow-agent when gaps require external knowledge (this is the only conditional search).

## 7. JSON Schema for Each Step

### 7.1 search_results.json
```json
{
  "concept_id": "string",
  "queries": ["string"],
  "results": [
    {
      "source": "string",
      "url": "string",
      "snippet": "string",
      "relevance": "number (0-1)"
    }
  ],
  "synthesis": "string (comprehensive synthesis of search findings)",
  "timestamp": "ISO-8601"
}
```

### 7.2 teach_output.json

**Input**: `state.json` (concept ID) + `search_results.json` (mandatory prerequisite from search-agent)

```json
{
  "concept_id": "string",
  "iteration": 1,
  "d1": "string (analogy, ≤150 words)",
  "d2": ["string (step 1)", "string (step 2)", "..."],
  "d3": {
    "definition": "string",
    "notation": "string (optional)",
    "confidence": "high|medium|low"
  },
  "d4": {
    "boundaries": [
      {
        "condition": "string (where it breaks)",
        "counter_example": "string",
        "failure_mechanism": "string"
      }
    ]
  },
  "timestamp": "ISO-8601"
}
```

### 7.3 audit_output.json
```json
{
  "iteration": 1,
  "valid": true,
  "issues": [
    {
      "layer": "d1|d2|d3|d4",
      "severity": "minor|major|critical",
      "description": "string"
    }
  ],
  "summary": "string",
  "timestamp": "ISO-8601"
}
```

### 7.4 grow_output.json
```json
{
  "iteration": 1,
  "gaps": [
    {
      "id": "string",
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "external_knowledge_required": true,
      "query": "string (search query if external)"
    }
  ],
  "strategy": "string (how to close gaps)",
  "timestamp": "ISO-8601"
}
```

### 7.5 verification_output.json
```json
{
  "iteration": 1,
  "cross_time_consistent": true,
  "independent_reproduction": true,
  "external_sources": ["url1", "url2"],
  "confidence": {
    "overall": 0.85,
    "d1": 0.9,
    "d2": 0.8,
    "d3": 0.85,
    "d4": 0.8
  },
  "timestamp": "ISO-8601"
}
```

### 7.6 audit_report.json (audit-quality-agent)
```json
{
  "iteration": 1,
  "worker_type": "teach-agent|audit-agent|...",
  "status": "PASS|NEEDS_FIX|REJECT",
  "issues": [
    {
      "rule_violated": "string (PRD section ref)",
      "detail": "string"
    }
  ],
  "timestamp": "ISO-8601"
}
```

### 7.7 consolidate_output.json
```json
{
  "concept_id": "string",
  "version_stack": ["string (version history)"],
  "open_problems": [
    {
      "id": "string",
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "priority": "high|medium|low"
    }
  ],
  "learning_curve": {
    "difficulty": "high|medium|low",
    "iterations_to_ming_wu": "number",
    "confidence_trend": "improving|stable|declining"
  },
  "epistemic_emotion": {
    "primary": "string (e.g., curiosity, confusion, clarity)",
    "intensity": "number (0.0–1.0)",
    "trigger": "string (what caused the emotion)"
  },
  "attention_focus": {
    "current_layer": "d1|d2|d3|d4",
    "target_gap": "string (gap id or description)",
    "next_action": "string"
  },
  "consolidation_status": {
    "lattice_updated": true,
    "nodes_added": "number",
    "edges_added": "number",
    "merge_conflicts": "number"
  },
  "review_schedule": {
    "next_review": "ISO-8601",
    "interval_days": "number",
    "reason": "string"
  },
  "timestamp": "ISO-8601"
}
```

## 8. Machine-Verifiable Completion Criteria

| Check | Method | Pass Condition |
|-------|--------|--------------|
| File exists | `os.path.exists(path)` | `true` |
| Valid JSON | `json.loads(content)` | No exception |
| Required keys present | Key-in-dict check | All mandatory keys present |
| Schema types correct | Type check per key | Match schema |
| Ming Wu passed | `mingwu_result.json["passed"]` | `true` |
| Novelty acceptable | `novelty_result.json["decision"]` | `"ACCEPT"` |
| State updated | `state.json["last_updated"]` | Timestamp >= iteration start |
| Budget not exceeded | `budget.json["remaining"]` | `>= 0` |
| No unhandled exceptions | `exceptions.json` | Empty or all resolved |

## 9. Orchestrator Behavior Contract

1. **Pure Coordination**: The orchestrator never performs concept analysis, writing, or reasoning itself.
2. **One Task Per Loop**: Each Ralph loop iteration spawns exactly one worker agent (and one auditor).
3. **File-System Memory**: All state persists in JSON files; no in-memory caching for durability.
4. **Budget Enforced**: `max_spawn` is a hard ceiling. Exceeding it terminates the loop with a report.
5. **Atomic Writes**: All JSON writes use temp-file-then-rename to prevent corruption.
6. **Resume Capability**: On startup, the orchestrator reads existing `state.json`, `progress.json`, and `budget.json` and continues from the last uncompleted task.
7. **Startup Self-Test**: On initialization, the orchestrator runs a one-time health check (module imports, config validation, path writability). This is NOT part of the iteration loop.
