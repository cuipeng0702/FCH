# Structural Emergence Design: Knowledge Gaps from Layer Tension

## 1. Core Insight: D1-D4 as Mapping System

D1-D4 is not four independent explanations of the same concept. It is a **cross-layer mapping system** where each layer constrains and is constrained by the others. Knowledge gaps do not live inside any single layer — they live in the **mapping failures between layers**.

### Why Layers Alone Don't Produce Gaps

A perfectly written D1, D2, D3, and D4 can still contain massive blind spots if the layers don't talk to each other. Example:
- D1: "Gradient descent is like water flowing downhill"
- D3: "Gradient descent is iterative parameter update: θ_{t+1} = θ_t - η∇L(θ_t)"
- D4: "Diverges when η > 2/λ_max"

Each layer is internally coherent. But the mapping between them is broken: water flowing downhill has no "learning rate" — the analogy fails exactly where D4's boundary matters. This failure is not visible inside any layer. It is visible only in the **gap between D1 and D4**.

### The Structural Tension Engine

Knowledge gaps emerge spontaneously when:
1. A concept exists in one layer but has **no corresponding construct** in another layer
2. An analogy that works for the **central case** breaks at a **boundary** defined in D4
3. A procedure (D2) produces results in a **failure zone** (D4) without detecting it
4. A counter-example (D4) **cannot be constructed** from the formal primitives (D3)

These are not "audited" — they are **structural residues** that remain when you try to map one layer onto another and the mapping fails.

---

## 2. Four Mapping Dimensions

### Mapping 1: D1↔D3 (Analogy ↔ Formal)

**What is mapped**: Every formal concept in D3 must have a corresponding intuitive element in D1. Every intuitive element in D1 must map to a formal construct in D3.

**How to detect failure**:
- Extract all defined terms from D3 (nouns, operators, parameters, variables)
- Extract all concrete objects/actions from D1 (nouns, verbs, relationships)
- Build a bidirectional mapping table
- Check: does every D3 term have ≥1 D1 correspondent? Does every D1 element map back to a D3 term?

**Failure types**:
| Failure | Detection | Meaning |
|---------|-----------|---------|
| **Orphan formal** | D3 term has no D1 mapping | "We can formally define X but cannot intuitively explain it" |
| **Orphan analogy** | D1 element has no D3 mapping | "We have an intuitive picture that doesn't correspond to any formal structure" |
| **Analogy fracture** | D1 element maps to D3 term, but D4 boundary breaks the analogy | "The analogy works for the central case but fails at [boundary]" |

**Machine-checkable example**:
```python
def check_d1_d3_mapping(teach_output):
    d3_terms = extract_defined_terms(teach_output["d3"]["definition"])
    d1_elements = extract_concrete_elements(teach_output["d1"])
    
    orphans_formal = [t for t in d3_terms if not has_d1_correspondent(t, d1_elements)]
    orphans_analogy = [e for e in d1_elements if not has_d3_correspondent(e, d3_terms)]
    
    # Analogy fracture: check if D4 boundaries break any D1↔D3 mapping
    fractures = []
    for boundary in teach_output["d4"]["boundaries"]:
        broken_mappings = find_mappings_broken_by(boundary, d1_elements, d3_terms)
        fractures.extend(broken_mappings)
    
    return {
        "orphans_formal": orphans_formal,      # spontaneous gap type 1
        "orphans_analogy": orphans_analogy,   # spontaneous gap type 2
        "fractures": fractures,               # spontaneous gap type 3
    }
```

### Mapping 2: D2↔D4 (Procedure ↔ Boundary)

**What is mapped**: Every D4 boundary condition must be testable by some step in D2. Every D2 step must not produce undefined behavior inside any D4 failure zone.

**How to detect failure**:
- Extract all boundary conditions from D4 (conditions, thresholds, limits)
- Extract all decision points and checks from D2 steps
- Check: does every D4 condition appear as a guard/check in D2?
- Check: does D2 ever produce output inside a D4 failure zone without erroring?

**Failure types**:
| Failure | Detection | Meaning |
|---------|-----------|---------|
| **Unguarded boundary** | D4 states "fails when X" but D2 has no step checking X | "We know the boundary exists but the procedure doesn't guard against it" |
| **Silent failure** | D2 produces a result that falls inside D4's failure zone | "The procedure silently produces garbage in the failure zone" |
| **Phantom guard** | D2 checks something not mentioned in any D4 boundary | "The procedure guards against a condition we don't understand" |

**Machine-checkable example**:
```python
def check_d2_d4_mapping(teach_output):
    d4_conditions = extract_boundary_conditions(teach_output["d4"]["boundaries"])
    d2_checks = extract_guard_conditions(teach_output["d2"])
    
    unguarded = [c for c in d4_conditions if not is_checked_in_d2(c, d2_checks)]
    phantom = [c for c in d2_checks if not is_boundary_in_d4(c, d4_conditions)]
    
    # Silent failure: simulate D2 execution at boundary values
    silent_failures = []
    for boundary in teach_output["d4"]["boundaries"]:
        if d2_produces_output_in_zone(teach_output["d2"], boundary):
            silent_failures.append(boundary["condition"])
    
    return {
        "unguarded_boundaries": unguarded,
        "phantom_guards": phantom,
        "silent_failures": silent_failures,
    }
```

### Mapping 3: D3↔D4 (Formal ↔ Counter-example)

**What is mapped**: Every D4 counter-example must be constructible using D3's formal primitives. Every D3 assumption must be tested by some D4 counter-example.

**How to detect failure**:
- Extract all formal primitives from D3 (variables, operators, axioms, assumptions)
- Extract all counter-examples from D4
- Check: can each counter-example be expressed using D3 primitives?
- Check: does each D3 assumption have a corresponding D4 counter-example that violates it?

**Failure types**:
| Failure | Detection | Meaning |
|---------|-----------|---------|
| **Unconstructible counter-example** | D4 counter-example uses concepts not in D3 | "We found a failure mode but our formal language cannot express it" |
| **Hidden assumption** | D3 proof/definition assumes X, D4 has counter-example violating X | "The formal proof has a hidden assumption that the counter-example violates" |
| **Vacuous boundary** | D4 boundary exists but D3 already excludes it by definition | "The boundary is formally impossible — why did we list it?" |

**Machine-checkable example**:
```python
def check_d3_d4_mapping(teach_output):
    d3_primitives = extract_formal_primitives(teach_output["d3"])
    d4_counters = teach_output["d4"]["boundaries"]
    
    unconstructible = []
    hidden_assumptions = []
    vacuous = []
    
    for boundary in d4_counters:
        # Can counter-example be built from D3 primitives?
        if not constructible_from(boundary["counter_example"], d3_primitives):
            unconstructible.append(boundary["counter_example"])
        
        # Does counter-example violate a hidden D3 assumption?
        violated = find_violated_assumptions(boundary, teach_output["d3"])
        if violated:
            hidden_assumptions.extend(violated)
        
        # Is boundary already excluded by D3 definition?
        if is_excluded_by_definition(boundary, teach_output["d3"]):
            vacuous.append(boundary["condition"])
    
    return {
        "unconstructible_counters": unconstructible,
        "hidden_assumptions": hidden_assumptions,
        "vacuous_boundaries": vacuous,
    }
```

### Mapping 4: Cross-Layer Consistency (via Contradiction-Agent)

**What is mapped**: The existing contradiction-agent already detects D1-D4 inconsistencies. The mapping system **reinterprets contradictions as mapping failures**.

**How to detect failure**:
- When contradiction-agent reports `count > 0`, do not treat it as "you have contradictions"
- Instead: for each contradiction, identify which **specific mapping** it violates
- The contradiction is not the gap — the **broken mapping that causes the contradiction** is the gap

**Failure types**:
| Contradiction Pattern | Mapping Failure | Meaning |
|----------------------|-----------------|---------|
| D1 says X, D3 says not-X | D1↔D3 orphan or fracture | "The analogy and formal definition describe different things" |
| D2 step N contradicts D3 equation | D2↔D3 misalignment | "The procedure doesn't follow from the formal definition" |
| D4 counter-example satisfies D3 definition | D3↔D4 hidden assumption | "The formal definition is too broad; the boundary reveals it" |

**Machine-checkable example**:
```python
def interpret_contradictions_as_mapping_failures(contradictions, teach_output):
    mapping_failures = []
    
    for contradiction in contradictions:
        layers = contradiction["layers_involved"]  # e.g., ["d1", "d3"]
        
        if set(layers) == {"d1", "d3"}:
            # Determine if orphan or fracture
            d3_term = extract_contradicted_term(contradiction, teach_output["d3"])
            if not has_d1_correspondent(d3_term, teach_output["d1"]):
                mapping_failures.append({
                    "type": "orphan_formal",
                    "layers": ["d1", "d3"],
                    "term": d3_term,
                    "gap": f"D3 defines '{d3_term}' but D1 has no intuitive correspondent"
                })
            else:
                mapping_failures.append({
                    "type": "analogy_fracture",
                    "layers": ["d1", "d3"],
                    "term": d3_term,
                    "gap": f"D1 maps '{d3_term}' to an analogy that breaks under contradiction"
                })
        
        elif set(layers) == {"d2", "d4"}:
            mapping_failures.append({
                "type": "unguarded_boundary",
                "layers": ["d2", "d4"],
                "gap": f"D4 states boundary but D2 does not guard against it"
            })
        
        elif set(layers) == {"d3", "d4"}:
            mapping_failures.append({
                "type": "hidden_assumption",
                "layers": ["d3", "d4"],
                "gap": f"D4 counter-example violates unstated D3 assumption"
            })
    
    return mapping_failures
```

---

## 2.5 Mapping Dimension: D1↔D2 (Analogy ↔ Procedure)

**What is mapped**: Every concrete object/action in D1 must correspond to a step in D2. Every step in D2 must be explainable by D1's analogy.

**How to detect failure**:
- Extract all concrete objects and actions from D1 (nouns that can be pictured, verbs that can be acted out)
- Extract all steps from D2 (imperative statements, sequential operations)
- Build a bidirectional mapping table
- Check: does every D1 element have ≥1 D2 step that executes it? Does every D2 step map back to a D1 element?

**Failure types**:
| Failure | Detection | Meaning |
|---------|-----------|---------|
| **D1 orphan** | D1 element has NO D2 step | "We can intuitively describe X but don't know how to execute it" |
| **D2 orphan** | D2 step has NO D1 correspondent | "We have a step but it makes no sense in the analogy" |
| **Analogy implication gap** | D1 analogy implies an action that D2 doesn't include | "The analogy suggests checking surroundings but the procedure has no such check" |

**Machine-checkable example**:
```python
def check_d1_d2_mapping(teach_output):
    d1_elements = extract_concrete_elements(teach_output["d1"])
    d2_steps = extract_steps(teach_output["d2"])
    
    # D1 orphan: concrete element with no executable step
    d1_orphans = []
    for element in d1_elements:
        corresponding_steps = find_steps_for_element(element, d2_steps)
        if not corresponding_steps:
            d1_orphans.append({
                "element": element,
                "gap": f"D1 describes '{element}' but D2 has no step to execute it"
            })
    
    # D2 orphan: step with no intuitive correspondent
    d2_orphans = []
    for step in d2_steps:
        corresponding_elements = find_elements_for_step(step, d1_elements)
        if not corresponding_elements:
            d2_orphans.append({
                "step": step,
                "gap": f"D2 step '{step}' has no correspondent in D1 analogy"
            })
    
    # Analogy implication gap: D1 suggests actions not in D2
    implied_actions = extract_implied_actions(teach_output["d1"])
    d2_actions = extract_actions_from_steps(d2_steps)
    implication_gaps = [a for a in implied_actions if a not in d2_actions]
    
    return {
        "d1_orphans": d1_orphans,
        "d2_orphans": d2_orphans,
        "implication_gaps": implication_gaps,
    }
```

---

## 2.6 Mapping Dimension: D2↔D3 (Procedure ↔ Formal)

**What is mapped**: Every variable/parameter in D3 must be manipulated by some D2 step. Every D2 step must be formalizable in D3 notation.

**How to detect failure**:
- Extract all variables and parameters from D3 (symbols, Greek letters, subscripted terms)
- Extract all manipulations from D2 steps (assignments, updates, comparisons, arithmetic)
- Build a bidirectional mapping table
- Check: does every D3 variable get set/changed by some D2 step? Does every D2 manipulation correspond to a D3 operation?

**Failure types**:
| Failure | Detection | Meaning |
|---------|-----------|---------|
| **D3 orphan** | D3 variable has NO D2 manipulation | "We formally define η but the procedure never sets it" |
| **D2 orphan** | D2 step manipulates something NOT in D3 | "The procedure does X but X has no formal representation" |
| **Operation mismatch** | D2 step's informal operation differs from D3's formal operation | "D2 says 'move downhill' but D3 says subtract gradient; the sign could be wrong" |

**Machine-checkable example**:
```python
def check_d2_d3_mapping(teach_output):
    d3_vars = extract_variables(teach_output["d3"]["definition"])
    d3_ops = extract_operations(teach_output["d3"]["notation"])
    d2_steps = extract_steps(teach_output["d2"])
    
    # D3 orphan: variable never manipulated in D2
    d3_orphans = []
    for var in d3_vars:
        manipulating_steps = find_steps_manipulating(var, d2_steps)
        if not manipulating_steps:
            d3_orphans.append({
                "variable": var,
                "gap": f"D3 defines '{var}' but D2 never manipulates it"
            })
    
    # D2 orphan: step manipulates something not in D3
    d2_orphans = []
    for step in d2_steps:
        manipulated = extract_manipulated_entities(step)
        for entity in manipulated:
            if entity not in d3_vars and not is_derived_from(entity, d3_vars):
                d2_orphans.append({
                    "step": step,
                    "entity": entity,
                    "gap": f"D2 step manipulates '{entity}' but D3 has no such variable"
                })
    
    # Operation mismatch: informal vs formal operation differ
    mismatches = []
    for step in d2_steps:
        informal_op = extract_informal_operation(step)
        formal_op = find_corresponding_formal_operation(informal_op, d3_ops)
        if formal_op and not operations_compatible(informal_op, formal_op):
            mismatches.append({
                "step": step,
                "informal": informal_op,
                "formal": formal_op,
                "gap": f"D2 says '{informal_op}' but D3 formalizes as '{formal_op}'; operations may differ"
            })
    
    return {
        "d3_orphans": d3_orphans,
        "d2_orphans": d2_orphans,
        "operation_mismatches": mismatches,
    }
```

---

## 2.7 Cross-Concept Mapping Conflict Detection

**When activated**: When the lattice contains ≥2 concepts, detect cross-concept mapping conflicts.

**What is mapped**: Each concept has its own D1-D4 layers and internal mappings. When concepts are used together (e.g., Concept B depends on Concept A), cross-concept conflicts emerge from mismatched mappings.

**How to detect failure**:
- Build a concept dependency graph (which concepts depend on which)
- For each pair of concepts, compare their D1-D4 mappings
- Check: do they use the same term with different definitions? Same analogy for different operations? Compatible boundaries? Consistent dependencies?

**Failure types**:
| Failure | Detection | Meaning |
|---------|-----------|---------|
| **Definition mismatch** | Same term, different D3 definitions | Concept A's "gradient" = ∇L(θ); Concept B's "gradient" = directional derivative. Used together, D3 mismatch causes confusion. |
| **Analogy collision** | Same D1 analogy used for different D3 operations | Concept A uses "water flowing downhill" for gradient descent; Concept B uses it for backpropagation. Analogy conflates two different formal operations. |
| **Boundary inconsistency** | D4 boundary of A violated by B's usage | Concept A's D4 says "converges for convex functions"; Concept B (depends on A) uses it for non-convex. Boundary violated. |
| **Dependency drift** | B's D2 depends on A's D3, but A's D3 changed | Concept B's D2 step 3 "compute gradient" depends on Concept A's D3 definition of gradient. A's D3 changed in later version; dependency is now a mapping failure. |

**Machine-checkable example**:
```python
def check_cross_concept_conflicts(lattice):
    """
    lattice: dict of concept_id → teach_output (with mappings)
    Returns: list of cross-concept conflicts
    """
    conflicts = []
    concepts = list(lattice.keys())
    
    for i, concept_a in enumerate(concepts):
        for concept_b in concepts[i+1:]:
            a = lattice[concept_a]
            b = lattice[concept_b]
            
            # 1. Definition mismatch: same term, different D3
            a_d3_terms = extract_defined_terms(a["d3"]["definition"])
            b_d3_terms = extract_defined_terms(b["d3"]["definition"])
            for term in set(a_d3_terms.keys()) & set(b_d3_terms.keys()):
                if a_d3_terms[term] != b_d3_terms[term]:
                    conflicts.append({
                        "type": "definition_mismatch",
                        "term": term,
                        "concept_a": concept_a,
                        "concept_b": concept_b,
                        "definition_a": a_d3_terms[term],
                        "definition_b": b_d3_terms[term],
                        "gap": f"'{term}' defined differently in {concept_a} vs {concept_b}"
                    })
            
            # 2. Analogy collision: same D1 analogy, different D3
            a_analogies = extract_core_analogies(a["d1"])
            b_analogies = extract_core_analogies(b["d1"])
            for analogy in set(a_analogies) & set(b_analogies):
                a_mapped_ops = a_analogies[analogy]
                b_mapped_ops = b_analogies[analogy]
                if a_mapped_ops != b_mapped_ops:
                    conflicts.append({
                        "type": "analogy_collision",
                        "analogy": analogy,
                        "concept_a": concept_a,
                        "concept_b": concept_b,
                        "formal_op_a": a_mapped_ops,
                        "formal_op_b": b_mapped_ops,
                        "gap": f"Both concepts use '{analogy}' but map to different formal operations"
                    })
            
            # 3. Boundary inconsistency: A's D4 violated by B
            if depends_on(concept_b, concept_a):
                a_boundaries = a["d4"]["boundaries"]
                b_usage = extract_usage_context(b, concept_a)
                for boundary in a_boundaries:
                    if violates_boundary(b_usage, boundary):
                        conflicts.append({
                            "type": "boundary_violation",
                            "boundary": boundary["condition"],
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "gap": f"{concept_b} violates {concept_a}'s boundary: '{boundary['condition']}'"
                        })
            
            # 4. Dependency drift: B's D2 depends on A's D3, but A changed
            if depends_on(concept_b, concept_a):
                b_d2_deps = extract_d2_dependencies(b["d2"], concept_a)
                a_d3_current = a["d3"]["definition"]
                for dep in b_d2_deps:
                    if not matches_current_definition(dep, a_d3_current):
                        conflicts.append({
                            "type": "dependency_drift",
                            "dependency": dep,
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "gap": f"{concept_b}'s D2 depends on {concept_a}'s old D3 definition; drift detected"
                        })
    
    return conflicts
```

**Integration with contradiction-agent**:
```python
def integrate_with_contradictions(cross_concept_conflicts, contradiction_output):
    """
    Cross-concept conflicts are a SOURCE of contradictions.
    When contradiction-agent reports conflicts between concepts,
    map them to specific cross-concept failure types.
    """
    enriched = []
    for conflict in contradiction_output.get("contradictions", []):
        layers = conflict.get("layers_involved", [])
        # Cross-concept contradictions involve different concepts, not just layers
        if "concept_a" in conflict and "concept_b" in conflict:
            matched = find_matching_cross_conflict(conflict, cross_concept_conflicts)
            if matched:
                enriched.append({
                    **conflict,
                    "cross_concept_type": matched["type"],
                    "root_cause": matched["gap"],
                    "mapping_failure": matched
                })
    return enriched
```

---

## 3. Gap Emergence Rules (Mechanistic)

These rules are **if-then-derive** statements. No human judgment required. Each rule produces a gap description and a learning strategy directly from the mapping failure.

### Rule Schema

```
IF [mapping_condition] THEN [gap_type] WITH [learning_strategy] AND [affected_layers]
```

### Rule Set

#### Rule 1: Orphan Formal
```
IF d3_term ∈ D3 AND d3_term ∉ MAPPED(D1)
THEN gap_type = "intuition_deficit"
WITH learning_strategy = "reformulate_d1"
AND affected_layers = ["d1", "d3"]
AND gap_description = "D3 defines '{term}' but D1 provides no intuitive access"
```

**Mechanism**: Extract all technical terms from D3.definition. Check if each appears (directly or via synonym) in D1. If not, the formal concept has no intuitive handle.

**Learning strategy**: "Reformulate D1 analogy to explicitly include '{term}' as a concrete element."

#### Rule 2: Analogy Fracture
```
IF d1_element ↔ d3_term AND d4_boundary_breaks(d1_element, d3_term)
THEN gap_type = "boundary_intuition_mismatch"
WITH learning_strategy = "extend_or_replace_analogy"
AND affected_layers = ["d1", "d3", "d4"]
AND gap_description = "D1 analogy for '{term}' works in central case but fails at D4 boundary '{condition}'"
```

**Mechanism**: For each D4 boundary, simulate whether the D1 analogy still holds. If the boundary condition makes the analogy produce wrong intuition, the analogy is fractured.

**Learning strategy**: "Replace D1 analogy with one that naturally accommodates '{condition}', or add D1 qualifier: 'except when {condition}'."

#### Rule 3: Unguarded Boundary
```
IF d4_condition ∈ D4 AND d4_condition ∉ D2_GUARDS
THEN gap_type = "procedure_safety_gap"
WITH learning_strategy = "add_guard_step"
AND affected_layers = ["d2", "d4"]
AND gap_description = "D4 states failure at '{condition}' but D2 has no step to detect/prevent it"
```

**Mechanism**: Extract all threshold conditions from D4.boundaries. Check if any D2 step tests for that condition before proceeding.

**Learning strategy**: "Add D2 step: 'Check if {condition}; if yes, abort/report/branch'."

#### Rule 4: Silent Failure
```
IF d2_produces_output_in(d4_failure_zone) AND d2_does_not_error
THEN gap_type = "silent_corruption"
WITH learning_strategy = "add_validation_step"
AND affected_layers = ["d2", "d4"]
AND gap_description = "D2 produces results in D4 failure zone '{zone}' without detecting invalidity"
```

**Mechanism**: For each D4 boundary, check if D2's final output falls inside the failure zone. If yes and D2 reports success, it's a silent failure.

**Learning strategy**: "Add D2 validation step: 'Verify output is not in {zone}; if it is, flag as invalid'."

#### Rule 5: Unconstructible Counter-Example
```
IF d4_counter_example AND NOT constructible_from(d3_primitives)
THEN gap_type = "formal_expressiveness_gap"
WITH learning_strategy = "expand_d3_primitives"
AND affected_layers = ["d3", "d4"]
AND gap_description = "D4 counter-example '{example}' cannot be expressed using D3's formal language"
```

**Mechanism**: Parse D3.definition into primitive constructs. Attempt to build D4.counter_example from those primitives. If impossible, the formal language is incomplete.

**Learning strategy**: "Expand D3 definition to include primitives needed for '{example}', or acknowledge D3 is a simplified model."

#### Rule 6: Hidden Assumption
```
IF d3_contains_assumption(X) AND d4_counter_example_violates(X)
THEN gap_type = "unstated_formal_limit"
WITH learning_strategy = "make_assumption_explicit"
AND affected_layers = ["d3", "d4"]
AND gap_description = "D3 implicitly assumes '{assumption}' which D4 counter-example '{example}' violates"
```

**Mechanism**: Extract implicit assumptions from D3 (e.g., "convergence proof assumes lr < 0.5"). Check if any D4 counter-example violates them.

**Learning strategy**: "Make '{assumption}' explicit in D3 as a stated precondition, and add corresponding D4 boundary."

#### Rule 7: Vacuous Boundary
```
IF d4_boundary AND d3_definition_already_excludes(boundary)
THEN gap_type = "redundant_boundary"
WITH learning_strategy = "remove_or_reframe"
AND affected_layers = ["d3", "d4"]
AND gap_description = "D4 boundary '{condition}' is already impossible per D3 definition"
```

**Mechanism**: Check if D4 boundary condition is logically excluded by D3 definition. If yes, the boundary is vacuous.

**Learning strategy**: "Remove '{condition}' from D4 or reframe as 'D3 definition implicitly excludes this; make explicit if pedagogically useful'."

#### Rule 8: Cross-Layer Contradiction (from contradiction-agent)
```
IF contradiction_detected(layers=[L1, L2])
THEN gap_type = "mapping_misalignment"
WITH learning_strategy = "resolve_mapping"
AND affected_layers = [L1, L2]
AND gap_description = "Contradiction between {L1} and {L2}: '{contradiction_text}' caused by {specific_mapping_failure}"
```

**Mechanism**: Feed contradiction-agent output into mapping interpreter. The gap is not "contradiction exists" but "contradiction exists BECAUSE [specific mapping fails]".

**Learning strategy**: "Fix the {specific_mapping_failure} between {L1} and {L2}, not the surface contradiction."

---

### Rule 9: D1 Step Gap
```
IF d1_element ∈ D1 AND d1_element ∉ MAPPED(D2)
THEN gap_type = "unexecutable_intuition"
WITH learning_strategy = "add_procedure_step"
AND affected_layers = ["d1", "d2"]
AND gap_description = "D1 describes '{element}' but D2 has no step to execute it"
```

**Mechanism**: Extract all concrete objects/actions from D1. Check if each appears as an executable step in D2. If not, the intuitive concept has no procedural handle.

**Learning strategy**: "Add D2 step that explicitly executes '{element}', or remove '{element}' from D1 if it is not actionable."

### Rule 10: D2 Variable Gap
```
IF d3_variable ∈ D3 AND d3_variable ∉ MAPPED(D2)
THEN gap_type = "unmanipulated_formal"
WITH learning_strategy = "add_variable_manipulation"
AND affected_layers = ["d2", "d3"]
AND gap_description = "D3 defines '{variable}' but D2 never manipulates it"
```

**Mechanism**: Extract all variables/parameters from D3.definition. Check if each is set, updated, or compared in any D2 step. If not, the formal variable is procedurally inert.

**Learning strategy**: "Add D2 step that initializes or updates '{variable}', or remove '{variable}' from D3 if it is not used."

### Rule 11: Cross-Concept Definition Mismatch
```
IF term ∈ ConceptA.D3 AND term ∈ ConceptB.D3 AND DefinitionA(term) ≠ DefinitionB(term)
THEN gap_type = "definition_collision"
WITH learning_strategy = "disambiguate_or_unify"
AND affected_layers = ["d3"]
AND affected_concepts = [ConceptA, ConceptB]
AND gap_description = "'{term}' defined as '{def_a}' in {ConceptA} but '{def_b}' in {ConceptB}"
```

**Mechanism**: For each pair of concepts, extract defined terms from D3. Compare definitions for shared terms. If definitions differ, the term is semantically overloaded.

**Learning strategy**: "Either rename one term to disambiguate, or unify definitions by finding the more general form that subsumes both."

### Rule 12: Cross-Concept Analogy Collision
```
IF analogy ∈ ConceptA.D1 AND analogy ∈ ConceptB.D1 AND FormalOpA(analogy) ≠ FormalOpB(analogy)
THEN gap_type = "analogy_overload"
WITH learning_strategy = "replace_analogy_or_formalize"
AND affected_layers = ["d1", "d3"]
AND affected_concepts = [ConceptA, ConceptB]
AND gap_description = "Both {ConceptA} and {ConceptB} use '{analogy}' but map to different formal operations"
```

**Mechanism**: Extract core analogies from D1 for each concept. For shared analogies, check what D3 operation they map to in each concept. If different, the analogy conflates distinct operations.

**Learning strategy**: "Replace one analogy with a distinct image, or add D1 qualifier specifying which formal operation the analogy refers to in each concept."

### Rule 13: Cross-Concept Boundary Violation
```
IF ConceptB depends_on ConceptA AND ConceptB.usage_context violates ConceptA.D4_boundary
THEN gap_type = "boundary_violation"
WITH learning_strategy = "restrict_usage_or_weaken_boundary"
AND affected_layers = ["d4"]
AND affected_concepts = [ConceptA, ConceptB]
AND gap_description = "{ConceptB} uses {ConceptA} in context '{context}' which violates boundary '{boundary}'"
```

**Mechanism**: Build concept dependency graph. For each dependency, check if dependent concept's usage context satisfies the dependency's D4 boundaries. If not, the boundary is violated.

**Learning strategy**: "Either restrict {ConceptB}'s usage to contexts satisfying '{boundary}', or weaken {ConceptA}'s boundary if the violation reveals the boundary was too strong."

### Rule 14: Cross-Concept Dependency Drift
```
IF ConceptB.D2 references ConceptA.D3 AND ConceptA.D3 changed_since(version_used_by_B)
THEN gap_type = "dependency_drift"
WITH learning_strategy = "update_dependency_or_pin_version"
AND affected_layers = ["d2", "d3"]
AND affected_concepts = [ConceptA, ConceptB]
AND gap_description = "{ConceptB}'s D2 step '{step}' depends on {ConceptA}'s old D3 definition; drift detected"
```

**Mechanism**: Track D2 dependencies across concepts. Compare the D3 definition that D2 was written against with the current D3 definition. If they differ, the dependency is stale.

**Learning strategy**: "Update {ConceptB}'s D2 to match {ConceptA}'s current D3, or pin {ConceptA} to the version {ConceptB} was written against and document the constraint."

---

## 4. Modified Teach-Agent Protocol

### Core Change: Generate D1-D4 AND the Cross-Layer Mapping Graph

The teach-agent's job is no longer "write 4 layers." It is "write 4 layers AND explicitly declare how they map to each other."

### Modified Output Schema

The `teach_output.json` gains a top-level `mappings` object. No epistemic metadata. No claims. Just the **structural connections between layers**.

```json
{
  "concept_id": "string",
  "iteration": 1,
  "d1": "string",
  "d2": ["string"],
  "d3": {
    "definition": "string",
    "notation": "string",
    "confidence": "high|medium|low"
  },
  "d4": {
    "boundaries": [
      {
        "condition": "string",
        "counter_example": "string",
        "failure_mechanism": "string"
      }
    ]
  },
  "mappings": {
    "d1_d3": {
      "correspondences": [
        {
          "d3_term": "gradient",
          "d1_element": "slope of the hill",
          "mapping_type": "direct|approximate|metaphorical",
          "confidence": "high|medium|low"
        }
      ],
      "unmapped_d3_terms": ["learning_rate", "parameter_space"],
      "unmapped_d1_elements": ["water"]
    },
    "d1_d2": {
      "correspondences": [
        {
          "d1_element": "water",
          "d2_step_index": 1,
          "mapping_type": "direct|approximate|metaphorical",
          "confidence": "high|medium|low"
        }
      ],
      "unmapped_d1_elements": ["hill"],
      "unmapped_d2_steps": [2]
    },
    "d2_d3": {
      "correspondences": [
        {
          "d2_step_index": 1,
          "d3_variable": "θ",
          "operation_type": "initialization|update|comparison",
          "confidence": "high|medium|low"
        }
      ],
      "unmapped_d3_variables": ["η"],
      "unmapped_d2_steps": [3]
    },
    "d2_d4": {
      "guards": [
        {
          "d2_step_index": 3,
          "d4_condition": "learning_rate > 2/λ_max",
          "guard_type": "explicit_check|implicit_avoidance|none"
        }
      ],
      "unguarded_boundaries": ["non-convex_loss"]
    },
    "d3_d4": {
      "constructibility": [
        {
          "d4_counter_example": "divergence with lr=1.0",
          "constructible_from_d3": true,
          "primitives_used": ["θ_update", "L(θ)", "∇L(θ)"]
        }
      ],
      "unconstructible_counters": []
    },
    "cross_concept": {
      "conflicts": [
        {
          "type": "definition_mismatch|analogy_collision|boundary_violation|dependency_drift",
          "concept_a": "string",
          "concept_b": "string",
          "description": "string",
          "severity": "critical|warning|info"
        }
      ]
    }
  },
  "timestamp": "ISO-8601"
}
```

### Teach-Agent Task Template Addition

Add the following section to `teach_task_template.md` after "D-Level Requirements":

```markdown
## Cross-Layer Mapping Requirements (NEW)

After generating D1-D4, you MUST produce the `mappings` object.

### Step 1: Map D1↔D3
- List every technical term in D3.definition
- For each term, identify what it maps to in D1 (or declare "unmapped")
- List every concrete object/action in D1
- For each, identify what D3 term it maps to (or declare "unmapped")
- Mark mapping_type: direct (isomorphic), approximate (close but not exact), metaphorical (loose)

### Step 2: Map D1↔D2
- List every concrete object/action in D1
- For each, identify which D2 step executes it (or declare "unmapped")
- List every step in D2
- For each, identify what D1 element it corresponds to (or declare "unmapped")
- Mark mapping_type: direct (one-to-one), approximate (step partially covers element), metaphorical (loose)

### Step 3: Map D2↔D3
- List every variable/parameter in D3.definition and notation
- For each, identify which D2 step manipulates it (or declare "unmapped")
- List every step in D2
- For each, identify what D3 variable it manipulates and what formal operation it corresponds to
- Check: does the informal operation in D2 match the formal operation in D3? Flag mismatches.

### Step 4: Map D2↔D4
- List every boundary condition in D4
- For each, check: does any D2 step test for this condition before proceeding?
- Mark guard_type: explicit_check (step says "if X, then..."), implicit_avoidance (procedure naturally avoids X), none
- List any D4 boundaries with guard_type = "none" as "unguarded"

### Step 5: Map D3↔D4
- For each D4 counter-example, ask: can I build this using only D3's notation and primitives?
- If yes, list the primitives used
- If no, list as "unconstructible"
- For each D3 assumption (implicit or explicit), ask: does any D4 counter-example violate it?
- If yes, the assumption is "hidden" and must be made explicit

### Step 6: Cross-Concept Conflict Check (if lattice has ≥2 concepts)
- For each pair of concepts, compare D3 definitions of shared terms
- Flag any term with different definitions across concepts
- Compare D1 analogies: flag any shared analogy that maps to different D3 operations
- Check concept dependencies: does dependent concept's usage violate dependency's D4 boundaries?
- Check dependency drift: does any D2 step reference a D3 definition that has changed?

### Step 7: Self-Check
- If unmapped_d3_terms is non-empty → D1 is incomplete
- If unmapped_d2_steps is non-empty → D2 has unexplained steps
- If unmapped_d3_variables is non-empty → D2 is incomplete
- If unguarded_boundaries is non-empty → D2 is unsafe
- If unconstructible_counters is non-empty → D3 is incomplete
- If cross_concept.conflicts is non-empty → lattice has structural conflicts
- These are NOT failures to fix now. They are structural facts to record.
```

---

## 5. Modified Grow-Agent Protocol

### Core Change: Grow-Agent Does Not "Find Gaps"

Grow-agent **reads mapping failures** from `teach_output.json["mappings"]` and derives learning strategies from them. The gap is not an input to grow; the mapping failure IS the gap.

### Modified Input

```json
{
  "audit_output_path": "string",
  "teach_output_path": "string",
  "state_path": "string",
  "concept": "string",
  "concept_id": "string",
  "iteration": 1,
  "mapping_failures": {
    "d1_d3": {
      "orphans_formal": ["term1", "term2"],
      "fractures": [{"term": "gradient", "boundary": "lr > 2/λ_max"}]
    },
    "d1_d2": {
      "d1_orphans": [{"element": "water", "gap": "D1 describes 'water' but D2 has no step to execute it"}],
      "d2_orphans": [{"step": 2, "gap": "D2 step 2 has no correspondent in D1 analogy"}],
      "implication_gaps": ["checking surroundings"]
    },
    "d2_d3": {
      "d3_orphans": [{"variable": "η", "gap": "D3 defines 'η' but D2 never manipulates it"}],
      "d2_orphans": [{"step": 3, "entity": "momentum", "gap": "D2 step 3 manipulates 'momentum' but D3 has no such variable"}],
      "operation_mismatches": [{"step": 1, "informal": "move downhill", "formal": "subtract gradient", "gap": "sign may differ"}]
    },
    "d2_d4": {
      "unguarded_boundaries": ["non-convex_loss"],
      "silent_failures": []
    },
    "d3_d4": {
      "unconstructible_counters": [],
      "hidden_assumptions": ["lr < 0.5 for convergence proof"]
    },
    "cross_concept": {
      "conflicts": [
        {
          "type": "definition_mismatch",
          "concept_a": "gradient_descent",
          "concept_b": "sgd",
          "description": "'gradient' defined as ∇L(θ) in gradient_descent but as batch average in sgd",
          "severity": "warning"
        }
      ]
    }
  },
  "previous_grow": {
    "iteration": 1,
    "gaps": [],
    "strategy": "string"
  }
}
```

### Modified Gap Generation Logic

Instead of the current "analyze audit issues → classify gaps" flow, grow-agent now:

1. **Read mapping failures** from input (pre-computed by mapping analyzer)
2. **Apply gap emergence rules** (§3) to each failure
3. **Derive learning strategy** directly from rule output

### Modified Output Schema

```json
{
  "iteration": 1,
  "timestamp": "ISO-8601",
  "gaps": [
    {
      "id": "string",
      "description": "string",
      "gap_type": "intuition_deficit|boundary_intuition_mismatch|procedure_safety_gap|silent_corruption|formal_expressiveness_gap|unstated_formal_limit|redundant_boundary|mapping_misalignment|unexecutable_intuition|unmanipulated_formal|definition_collision|analogy_overload|boundary_violation|dependency_drift",
      "source_mapping_failure": {
        "layers": ["d1", "d3"],
        "failure_type": "orphan_formal",
        "specific": "D3 term 'parameter_space' has no D1 correspondent"
      },
      "affected_layers": ["d1", "d3"],
      "external_knowledge_required": true,
      "query": "string"
    }
  ],
  "strategy": "string",
  "mapping_analysis": {
    "failures_total": 5,
    "by_type": {
      "intuition_deficit": 2,
      "procedure_safety_gap": 1,
      "unstated_formal_limit": 2
    }
  }
}
```

### Grow-Agent Task Template Addition

Replace the "Gap Analysis Framework" section in `grow_task_template.md` with:

```markdown
## Gap Analysis Framework (REVISED — Mapping-Driven)

You do NOT find gaps. You READ gaps that have already emerged from layer mappings.

### Input Source
The `mapping_failures` object in your input contains all structural failures detected between D1-D4. Each failure is a knowledge gap waiting for a learning strategy.

### Step 1: Apply Gap Emergence Rules
For each mapping failure, apply the corresponding rule from the Structural Emergence Design:

| Mapping Failure | Rule | Gap Type | Default Strategy |
|----------------|------|----------|-----------------|
| orphan_formal (D1↔D3) | Rule 1 | intuition_deficit | reformulate_d1 |
| analogy_fracture (D1↔D3) | Rule 2 | boundary_intuition_mismatch | extend_or_replace_analogy |
| d1_orphan (D1↔D2) | Rule 9 | unexecutable_intuition | add_procedure_step |
| d2_orphan (D1↔D2) | Rule 9 | unexecutable_intuition | add_procedure_step |
| d3_orphan (D2↔D3) | Rule 10 | unmanipulated_formal | add_variable_manipulation |
| d2_orphan (D2↔D3) | Rule 10 | unmanipulated_formal | add_variable_manipulation |
| operation_mismatch (D2↔D3) | Rule 10 | unmanipulated_formal | add_variable_manipulation |
| unguarded_boundary (D2↔D4) | Rule 3 | procedure_safety_gap | add_guard_step |
| silent_failure (D2↔D4) | Rule 4 | silent_corruption | add_validation_step |
| unconstructible_counter (D3↔D4) | Rule 5 | formal_expressiveness_gap | expand_d3_primitives |
| hidden_assumption (D3↔D4) | Rule 6 | unstated_formal_limit | make_assumption_explicit |
| vacuous_boundary (D3↔D4) | Rule 7 | redundant_boundary | remove_or_reframe |
| definition_mismatch (cross-concept) | Rule 11 | definition_collision | disambiguate_or_unify |
| analogy_collision (cross-concept) | Rule 12 | analogy_overload | replace_analogy_or_formalize |
| boundary_violation (cross-concept) | Rule 13 | boundary_violation | restrict_usage_or_weaken_boundary |
| dependency_drift (cross-concept) | Rule 14 | dependency_drift | update_dependency_or_pin_version |
| contradiction (cross-layer) | Rule 8 | mapping_misalignment | resolve_mapping |

### Step 2: Prioritize Gaps
Priority order:
1. **silent_corruption** (produces wrong results without warning)
2. **procedure_safety_gap** (procedure doesn't guard against known failure)
3. **unstated_formal_limit** (hidden assumptions undermine formal claims)
4. **intuition_deficit** (formal concept has no intuitive access)
5. **boundary_intuition_mismatch** (analogy breaks at boundary)
6. **formal_expressiveness_gap** (counter-example exceeds formal language)
7. **redundant_boundary** (cosmetic issue)
8. **mapping_misalignment** (general contradiction)
9. **unexecutable_intuition** (D1 element has no D2 step)
10. **unmanipulated_formal** (D3 variable has no D2 manipulation)
11. **definition_collision** (same term, different definitions across concepts)
12. **analogy_overload** (same analogy for different operations)
13. **boundary_violation** (dependent concept violates dependency boundary)
14. **dependency_drift** (D2 references stale D3 definition)

### Step 3: Generate Search Queries
For gaps requiring external knowledge, generate queries that target the SPECIFIC mapping failure:
- Bad: "explain gradient descent"
- Good: "intuitive explanation of parameter space dimensionality for gradient descent"
- Bad: "gradient descent boundaries"
- Good: "how to detect non-convex loss surfaces in gradient descent procedures"

### Step 4: Formulate Strategy
The strategy must state:
- Which mapping failure to fix first and why
- Whether to modify D1, D2, D3, or D4 (or multiple)
- Whether external knowledge is needed
- What the corrected mapping should look like
```

---

## 6. Integration into Existing Ralph Loop

### Where Mapping Analysis Fits

Mapping analysis is **not a new phase**. It is a **pre-processing step** inside existing phases.

```
┌─────────────┐
│   SEARCH    │ ← unchanged
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   TEACH     │ ← teach-agent generates D1-D4 + mappings
│  (+mappings)│
└──────┬──────┘
       │
       ▼
┌─────────────────────────┐
│  MAPPING ANALYZER       │ ← NEW: pure function, not an agent
│  (runs inside orchestrator)│   Reads teach_output["mappings"]
│                           │   Applies gap emergence rules
│                           │   Produces mapping_failures.json
└───────────┬───────────────┘
            │
            ▼
┌─────────────┐
│   AUDIT     │ ← audit-agent receives mapping_failures as additional input
│  (+mapping) │   Can reference mapping failures in issues
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   GROW      │ ← grow-agent reads mapping_failures, applies rules, generates gaps
│  (mapping-  │   No "finding" — only "reading" and "deriving strategy"
│   driven)   │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   VERIFY    │ ← unchanged (but can reference mapping consistency)
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ CONSOLIDATE │ ← unchanged
└─────────────┘
```

### Orchestrator Changes

Add a `_analyze_mappings()` method to `orchestrator.py`:

```python
def _analyze_mappings(self, teach_output: dict, iteration: int) -> dict:
    """Pure function: analyze cross-layer mappings and produce failures.
    
    This is NOT a new agent spawn. It is a deterministic computation
    that runs inside the orchestrator between teach and audit.
    """
    mappings = teach_output.get("mappings", {})
    
    failures = {
        "d1_d3": self._check_d1_d3_mapping(mappings.get("d1_d3", {})),
        "d1_d2": self._check_d1_d2_mapping(mappings.get("d1_d2", {})),
        "d2_d3": self._check_d2_d3_mapping(mappings.get("d2_d3", {})),
        "d2_d4": self._check_d2_d4_mapping(mappings.get("d2_d4", {})),
        "d3_d4": self._check_d3_d4_mapping(mappings.get("d3_d4", {}), teach_output),
        "cross_concept": self._check_cross_concept_conflicts(teach_output),
    }
    
    # Also interpret contradiction-agent output if available
    contradictions_path = self._iter_dir(iteration) / "contradictions.json"
    if contradictions_path.exists():
        contradictions = self._load_json_safe(contradictions_path, {})
        failures["cross_layer"] = self._interpret_contradictions(
            contradictions.get("contradictions", []), teach_output
        )
    
    # Write mapping_failures.json for downstream agents
    failures_path = self._iter_dir(iteration) / "mapping_failures.json"
    self._atomic_write(failures_path, {
        "iteration": iteration,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "failures": failures,
        "gap_count": self._count_gaps(failures),
    })
    
    return failures
```

### Modified Task Dispatch

In `_run_single_task()`, after teach-agent completes:

```python
# After teach-agent output is validated
if task_name == "teach":
    teach_data = self._load_json_safe(Path(output_path), {})
    mapping_failures = self._analyze_mappings(teach_data, iteration)
    
    # If critical mapping failures exist, they become part of the audit input
    # Audit-agent can reference them but does not need to detect them
```

### Audit-Agent Input Modification

The audit-agent now receives `mapping_failures.json` as additional context:

```json
{
  "teach_output_path": "string",
  "mapping_failures_path": "string",  // NEW
  "concept": "string",
  "concept_id": "string",
  "iteration": 1
}
```

Audit-agent can:
- Reference mapping failures in its issues ("D1↔D3 mapping failure: orphan formal 'parameter_space'")
- Verify that mapping failures are correctly categorized
- But does NOT need to independently detect them — they are pre-computed

### Grow-Agent Input Modification

Grow-agent receives mapping failures directly:

```json
{
  "audit_output_path": "string",
  "teach_output_path": "string",
  "mapping_failures": { ... },  // NEW: inline, not a path
  "state_path": "string",
  "concept": "string",
  "concept_id": "string",
  "iteration": 1
}
```

---

## 7. Machine-Verifiable Criteria

### How to Check That the Mechanism Works

#### Test 1: Orphan Detection
**Input**: A teach_output where D3 defines "Hessian matrix" but D1 mentions only "slope" and "hill".
**Expected**: mapping_failures.d1_d3.orphans_formal contains "Hessian matrix".
**Check**: `assert "Hessian matrix" in failures["d1_d3"]["orphans_formal"]`

#### Test 2: Fracture Detection
**Input**: D1 says "water flows downhill" (3D space), D3 says "gradient in 10^6D parameter space", D4 says "fails when curvature changes sign" (saddle points).
**Expected**: mapping_failures.d1_d3.fractures contains an entry linking "downhill" to "saddle point" boundary.
**Check**: `assert any(f["term"] == "downhill" and "saddle" in f["boundary"] for f in fractures)`

#### Test 3: Unguarded Boundary
**Input**: D4 states "algorithm fails when p > n" but D2 has no step checking "p > n".
**Expected**: mapping_failures.d2_d4.unguarded_boundaries contains "p > n".
**Check**: `assert "p > n" in failures["d2_d4"]["unguarded_boundaries"]`

#### Test 4: Hidden Assumption
**Input**: D3 convergence proof assumes "learning rate < 0.5", D4 counter-example uses "learning rate = 1.0".
**Expected**: mapping_failures.d3_d4.hidden_assumptions contains "learning rate < 0.5".
**Check**: `assert any("learning rate" in a for a in failures["d3_d4"]["hidden_assumptions"])`

#### Test 5: Contradiction Interpretation
**Input**: contradiction-agent reports "D1 says water always flows to lowest point; D3 says gradient descent can get stuck at saddle points".
**Expected**: mapping_failures.cross_layer contains entry with type "analogy_fracture", layers ["d1", "d3"], gap description mentions "saddle point".
**Check**: `assert any(f["type"] == "analogy_fracture" and "saddle" in f["gap"] for f in cross_layer)`

#### Test 6: Grow-Agent Consumption
**Input**: mapping_failures with 3 orphans_formal and 2 unguarded_boundaries.
**Expected**: grow_output.gaps has exactly 5 entries, with gap_types matching Rule 1 and Rule 3.
**Check**: `assert len(grow_output["gaps"]) == 5` and `assert set(g["gap_type"] for g in gaps) == {"intuition_deficit", "procedure_safety_gap"}`

#### Test 7: No External Epistemic Layer
**Input**: Any teach_output.
**Expected**: No `epistemic_metadata`, `claims`, `ignorance_map`, or `epistemic_health_score` fields exist anywhere in the output files.
**Check**: `assert "epistemic_metadata" not in teach_output` and `assert "epistemic_metadata" not in grow_output`

#### Test 8: No New Loop Phase
**Input**: Full Ralph loop execution.
**Expected**: Loop phases remain Search→Teach→Audit→Grow→Verify→Consolidate. No "Mapping" or "Epistemic" phase inserted.
**Check**: `assert progress["completed_steps"] in valid_sequences` where valid_sequences never contain "mapping" or "epistemic".

#### Test 9: D1↔D2 Orphan Detection
**Input**: D1 describes "checking surroundings" but D2 has no such step.
**Expected**: mapping_failures.d1_d2.d1_orphans contains element "checking surroundings".
**Check**: `assert any(o["element"] == "checking surroundings" for o in failures["d1_d2"]["d1_orphans"])`

#### Test 10: D2↔D3 Variable Gap
**Input**: D3 defines "η" (learning rate) but D2 never sets or updates it.
**Expected**: mapping_failures.d2_d3.d3_orphans contains variable "η".
**Check**: `assert any(o["variable"] == "η" for o in failures["d2_d3"]["d3_orphans"])`

#### Test 11: Cross-Concept Definition Mismatch
**Input**: Concept A defines "gradient" as ∇L(θ); Concept B defines "gradient" as batch average.
**Expected**: mapping_failures.cross_concept.conflicts contains type "definition_mismatch" for term "gradient".
**Check**: `assert any(c["type"] == "definition_mismatch" and c["term"] == "gradient" for c in conflicts)`

#### Test 12: Cross-Concept Boundary Violation
**Input**: Concept A's D4 says "converges for convex functions"; Concept B (depends on A) uses it for non-convex.
**Expected**: mapping_failures.cross_concept.conflicts contains type "boundary_violation".
**Check**: `assert any(c["type"] == "boundary_violation" for c in conflicts)`

---

## Appendix A: Mapping Analyzer Pseudocode

```python
#!/usr/bin/env python3
"""Mapping analyzer — pure function, no agent spawn.

Runs inside orchestrator between teach and audit.
Produces mapping_failures.json for downstream consumption.
"""

import json
from typing import Dict, List, Any

class MappingAnalyzer:
    """Deterministic analysis of D1-D4 cross-layer mappings."""
    
    def analyze(self, teach_output: dict) -> dict:
        """Main entry point. Returns mapping failures dict."""
        mappings = teach_output.get("mappings", {})
        
        return {
            "d1_d3": self._analyze_d1_d3(mappings.get("d1_d3", {})),
            "d1_d2": self._analyze_d1_d2(mappings.get("d1_d2", {})),
            "d2_d3": self._analyze_d2_d3(mappings.get("d2_d3", {})),
            "d2_d4": self._analyze_d2_d4(mappings.get("d2_d4", {})),
            "d3_d4": self._analyze_d3_d4(
                mappings.get("d3_d4", {}),
                teach_output.get("d3", {}),
                teach_output.get("d4", {})
            ),
            "cross_concept": self._analyze_cross_concept(teach_output),
        }
    
    def _analyze_d1_d3(self, mapping: dict) -> dict:
        correspondences = mapping.get("correspondences", [])
        unmapped_d3 = mapping.get("unmapped_d3_terms", [])
        unmapped_d1 = mapping.get("unmapped_d1_elements", [])
        
        # Detect fractures: correspondences where D4 breaks the mapping
        fractures = []
        # (fracture detection requires D4 context; simplified here)
        
        return {
            "orphans_formal": unmapped_d3,
            "orphans_analogy": unmapped_d1,
            "fractures": fractures,
            "correspondence_count": len(correspondences),
        }
    
    def _analyze_d1_d2(self, mapping: dict) -> dict:
        correspondences = mapping.get("correspondences", [])
        unmapped_d1 = mapping.get("unmapped_d1_elements", [])
        unmapped_d2 = mapping.get("unmapped_d2_steps", [])
        
        # Detect implication gaps: D1 suggests actions not in D2
        implication_gaps = []
        # (requires parsing D1 for implied actions; simplified)
        
        return {
            "d1_orphans": [{"element": e, "gap": f"D1 describes '{e}' but D2 has no step to execute it"} for e in unmapped_d1],
            "d2_orphans": [{"step": s, "gap": f"D2 step {s} has no correspondent in D1 analogy"} for s in unmapped_d2],
            "implication_gaps": implication_gaps,
            "correspondence_count": len(correspondences),
        }
    
    def _analyze_d2_d3(self, mapping: dict) -> dict:
        correspondences = mapping.get("correspondences", [])
        unmapped_d3 = mapping.get("unmapped_d3_variables", [])
        unmapped_d2 = mapping.get("unmapped_d2_steps", [])
        
        # Detect operation mismatches
        mismatches = []
        for corr in correspondences:
            if not operations_compatible(corr.get("informal_op"), corr.get("formal_op")):
                mismatches.append({
                    "step": corr.get("d2_step_index"),
                    "informal": corr.get("informal_op"),
                    "formal": corr.get("formal_op"),
                    "gap": f"D2 says '{corr.get('informal_op')}' but D3 formalizes as '{corr.get('formal_op')}'"
                })
        
        return {
            "d3_orphans": [{"variable": v, "gap": f"D3 defines '{v}' but D2 never manipulates it"} for v in unmapped_d3],
            "d2_orphans": [{"step": s, "gap": f"D2 step {s} has no formal correspondent"} for s in unmapped_d2],
            "operation_mismatches": mismatches,
            "correspondence_count": len(correspondences),
        }
    
    def _analyze_d2_d4(self, mapping: dict) -> dict:
        guards = mapping.get("guards", [])
        unguarded = mapping.get("unguarded_boundaries", [])
        
        # Detect silent failures
        silent = []
        # (requires simulating D2 against D4 zones; simplified)
        
        return {
            "guarded_boundaries": [g["d4_condition"] for g in guards if g["guard_type"] != "none"],
            "unguarded_boundaries": unguarded,
            "phantom_guards": [],  # D2 checks not in D4
            "silent_failures": silent,
        }
    
    def _analyze_d3_d4(self, mapping: dict, d3: dict, d4: dict) -> dict:
        constructibility = mapping.get("constructibility", [])
        
        unconstructible = [c["d4_counter_example"] for c in constructibility 
                          if not c.get("constructible_from_d3", False)]
        
        # Hidden assumptions: D3 claims that D4 violates
        hidden = []
        # (requires parsing D3 assumptions; simplified)
        
        # Vacuous boundaries: D4 conditions already excluded by D3
        vacuous = []
        # (requires logical analysis; simplified)
        
        return {
            "constructible_counters": [c["d4_counter_example"] for c in constructibility 
                                      if c.get("constructible_from_d3", False)],
            "unconstructible_counters": unconstructible,
            "hidden_assumptions": hidden,
            "vacuous_boundaries": vacuous,
        }
    
    def _analyze_cross_concept(self, teach_output: dict) -> dict:
        """Analyze cross-concept conflicts from the lattice."""
        conflicts = []
        # (requires access to full lattice; simplified placeholder)
        
        return {
            "conflicts": conflicts,
            "conflict_count": len(conflicts),
        }
```

## Appendix B: Files to Modify

| File | Change | Nature |
|------|--------|--------|
| `PRD.md` | Add §3.5 "Cross-Layer Mapping Requirements", update teach_output schema to include `mappings` | Append |
| `orchestrator.py` | Add `_analyze_mappings()` method; wire between teach and audit | New method + insertion |
| `agents/teach_task_template.md` | Add "Cross-Layer Mapping Requirements" section | Append |
| `agents/grow_task_template.md` | Replace "Gap Analysis Framework" with mapping-driven version | Replace section |
| `agents/audit_task_template.md` | Add `mapping_failures_path` to input; add mapping-aware audit items | Append |
| `harness/mapping_analyzer.py` | New pure-function module | New file |
| `harness/structural_emergence_design.md` | This document | New file |

## Appendix C: What This Design Deliberately Does NOT Include

1. **No epistemic_metadata field** — gaps emerge from structure, not from claims about knowledge
2. **No epistemic audit agent** — no external auditor of "how do you know what you know"
3. **No ignorance_map** — unknowns emerge from mapping failures, not from self-reflection
4. **No new Ralph loop phase** — mapping analysis is a computation inside the orchestrator, not a phase
5. **No confidence_source or falsification_conditions per claim** — D4 boundaries ARE the falsification conditions
6. **No reasoning_chain per claim** — the mapping graph IS the reasoning chain

The epistemic material is already in D4 (boundaries, counter-examples). The engine is already in the tension between D1-D4. This design makes that tension explicit and mechanistic.

---

*Document version: 1.1*
*Design status: Extended with D1↔D2, D2↔D3, and Cross-Concept Mapping Conflict Detection*
*Breaking changes: None (additive only)*
*Estimated implementation effort: ~2 hours (templates) + ~1 hour (mapping analyzer) + ~1 hour (orchestrator wiring) + ~1 hour (integration testing)*
