#!/usr/bin/env python3
"""FCH Ralph-Style Orchestrator — pure coordinator, does NO work itself.

Ralph loop:
  1. LOAD STATE
  2. CHECK BUDGET
  3. PICK NEXT TASK
  4. SPAWN WORKER
  5. SPAWN AUDITOR
  6. UPDATE PROGRESS
  7. CHECK CONVERGENCE
  8. SAVE STATE
  9. LOOP or EXIT

Each iteration performs exactly ONE task + ONE audit.
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from state_manager import StateManager

# v3.3 conditional module imports — inactive when modules are disabled in config
try:
    from calibration_engine import CalibrationEngine
except Exception:
    CalibrationEngine = None
try:
    from analogy_selector import AnalogySelector
except Exception:
    AnalogySelector = None
try:
    from t3_executor import T3Executor
except Exception:
    T3Executor = None
try:
    from termination_checker import TerminationEvaluator
except Exception:
    TerminationEvaluator = None
try:
    from routing_classifier import HybridRouter
except Exception:
    HybridRouter = None


class FCHOrchestrator:
    """Pure-coordinator orchestrator for the Feynman Cognition Harness."""

    def __init__(self, harness_dir: str):
        self.harness_dir = Path(harness_dir)
        self.results_dir = self.harness_dir / "results"
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.sm = StateManager(str(self.harness_dir))
        # v3.3: load unified config for conditional module enabling
        self.config = self._load_config()

    # ── v3.3 config helpers ──────────────────────────────────────────

    def _load_config(self) -> dict:
        """Load v3.3 config.yaml if present; return empty dict if absent."""
        config_path = self.harness_dir / "config.yaml"
        if not config_path.exists():
            return {}
        try:
            import yaml
            with open(config_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    def _module_enabled(self, module_name: str) -> bool:
        """Check if a v3.3 module is enabled in config."""
        return self.config.get("modules", {}).get(module_name, {}).get("enabled", False)

    # ── core Ralph loop ──────────────────────────────────────────────

    def _run_single_task(self, task_name: str, iteration: int,
                         state: dict, progress: dict, budget: dict) -> str:
        """Execute one task with audit-loop and fix-loop.

        Returns:
            "continue" — task completed successfully
            "rejected" — task was rejected, strategy adjusted
            "budget_exhausted" — no budget left to proceed
        """
        input_path = str(self.harness_dir / "state.json")
        out_dir = self._iter_dir(iteration)
        output_path = str(out_dir / f"{task_name}_output.json")
        task_template = str(self.harness_dir / "agents" / f"{task_name}_task_template.md")

        max_fix_attempts = 3

        # Count existing pending fixes from prior attempts (e.g., after crash/restart)
        existing_fixes = [
            f for f in state.get("pending_fixes", [])
            if f.get("task") == task_name and f.get("iteration") == iteration
        ]
        fix_attempt = len(existing_fixes)

        while True:
            # Check budget before worker spawn
            if budget.get("remaining", 0) <= 0:
                return "budget_exhausted"

            # Strategy adjustment: if 3+ consecutive failures, consider escalation
            if fix_attempt > 0:
                pattern = self._analyze_failure_pattern(task_name)
                if pattern["action"] == "abort":
                    self._handle_rejection(task_name, iteration, state, progress)
                    return "rejected"
                elif pattern["action"] == "escalate":
                    # Record strategy adjustment and proceed as rejected
                    state["strategy_adjustments"].append({
                        "iteration": iteration,
                        "task": task_name,
                        "action": "escalate",
                        "reason": pattern["reason"],
                    })
                    self._handle_rejection(task_name, iteration, state, progress)
                    return "rejected"

            # 1. SPAWN WORKER
            self._decrement_budget(budget)
            output_path = self._spawn_worker(task_name, input_path, output_path)

            # Check worker timeout
            if self._check_worker_timeout(output_path, max_wait_seconds=600):
                self._handle_worker_failure(task_name, iteration, state, progress)
                fix_attempt += 1
                if fix_attempt >= max_fix_attempts:
                    self._handle_rejection(task_name, iteration, state, progress)
                    return "rejected"
                # Save state with timeout failure recorded, then retry
                self.sm.save_state(state)
                continue

            # Check budget before auditor spawn
            if budget.get("remaining", 0) <= 0:
                return "budget_exhausted"

            # 2. SPAWN AUDITOR
            self._decrement_budget(budget)
            prd_path = str(self.harness_dir / "PRD.md")
            audit_path = self._spawn_auditor(output_path, task_template, prd_path)

            # 3. HANDLE AUDIT RESULT
            action = self._handle_audit_result(audit_path, task_name)

            if action == "continue":
                # PASS: mark done, ingest output
                progress = self.sm.mark_task_done(progress, task_name)
                self._ingest_worker_output(task_name, iteration, state)
                return "continue"

            elif action == "needs_fix":
                fix_attempt += 1
                if fix_attempt >= max_fix_attempts:
                    # Too many fix attempts — treat as rejected
                    self._handle_rejection(task_name, iteration, state, progress)
                    return "rejected"
                # Load audit details and enqueue fix
                audit = self._load_json_safe(Path(audit_path), {})
                self._enqueue_fix(task_name, iteration, audit, state)
                # Persist state so fix survives crash/restart
                self.sm.save_state(state)
                # Loop back to re-execute with fixes noted in state
                continue

            elif action == "rejected":
                self._handle_rejection(task_name, iteration, state, progress)
                return "rejected"

        # Should never reach here
        return "continue"

    def _self_test(self) -> None:
        """One-time startup health check. NOT part of iteration loop."""
        # Verify state_manager import (already done at module level, but check it's usable)
        if StateManager is None:
            raise RuntimeError("StateManager import failed")
        # Verify harness_dir exists and is writable
        if not self.harness_dir.exists():
            raise RuntimeError(f"Harness directory does not exist: {self.harness_dir}")
        if not os.access(self.harness_dir, os.W_OK):
            raise RuntimeError(f"Harness directory is not writable: {self.harness_dir}")
        # Verify results_dir can be created
        try:
            self.results_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise RuntimeError(f"Cannot create results directory: {exc}")
        # Verify PRD.md and agent templates exist
        prd_path = self.harness_dir / "PRD.md"
        if not prd_path.exists():
            raise RuntimeError(f"PRD.md not found: {prd_path}")
        for task_name in ("teach", "verify", "consolidate", "search"):
            template_path = self.harness_dir / "agents" / f"{task_name}_task_template.md"
            if not template_path.exists():
                raise RuntimeError(f"Agent template not found: {template_path}")

    def run(self) -> None:
        """Run the Ralph loop until budget exhausted or converged."""
        self._self_test()
        while True:
            # 1. LOAD STATE
            state = self.sm.load_state()
            progress = self.sm.load_progress()
            budget = self.sm.load_budget()

            iteration = progress.get("current_iteration", 1)

            # 2. CHECK BUDGET
            if budget.get("remaining", 0) <= 0:
                self._report("BUDGET_EXHAUSTED", progress, budget)
                break

            # 3. PICK NEXT TASK
            task = self.sm.get_next_task(progress)
            if task is None:
                # iteration complete → check convergence
                if self._is_converged(state, iteration):
                    self._finalize(state, progress, budget)
                    break
                # start next iteration
                iteration += 1
                progress["current_iteration"] = iteration
                progress["completed_steps"] = []
                progress["next_step"] = "teach"
                task = "teach"

            # v3.3: BDD task injection (inactive when disabled)
            if self._module_enabled("hybrid_routing"):
                override_task = self._get_task_sequence(progress, state)
                if override_task:
                    task = override_task

            # 4. RUN SINGLE TASK (with embedded audit + fix loop)
            # Before teach, always run search first
            if task == "teach" and not self._search_completed_for_iteration(iteration):
                search_action = self._run_single_task("search", iteration, state, progress, budget)
                if search_action == "budget_exhausted":
                    self._report("BUDGET_EXHAUSTED", progress, budget)
                    break
                # Continue to teach after search completes

            # v3.3: BDD task uses dedicated runner (inactive when disabled)
            if task == "bdd" and self._module_enabled("hybrid_routing"):
                action = self._run_bdd_task(iteration, state, progress, budget)
            else:
                action = self._run_single_task(task, iteration, state, progress, budget)

            # Handle special termination actions
            if action == "budget_exhausted":
                self._report("BUDGET_EXHAUSTED", progress, budget)
                break

            # v3.3: record UCC instance after each completed task (inactive when disabled)
            if action == "continue" and self._module_enabled("threshold_calibration"):
                self._record_ucc_instance(task, iteration, state)

            # v3.3: after verify, route gaps (inactive when disabled)
            if task == "verify" and action == "continue" and self._module_enabled("hybrid_routing"):
                self._route_gaps(state, iteration)

            # v3.3: termination check (inactive when disabled)
            if self._module_enabled("termination"):
                term_result = self._check_termination(state, iteration)
                if term_result.get("terminate"):
                    self._finalize_with_meta_summary(state, progress, budget, term_result)
                    break

            # 5. CHECK CONVERGENCE (early-exit if converged mid-iteration)
            if self._is_converged(state, iteration):
                self._finalize(state, progress, budget)
                break

            # 6. SAVE STATE
            self._save_all(state, progress, budget)

            # 7. LOOP or EXIT
            # loop continues automatically

    # ── task dispatch ────────────────────────────────────────────────

    def _spawn_worker(self, task_name: str, input_path: str, output_path: str) -> str:
        """Spawn a worker agent for the given task.

        Reads the task template, fills placeholders, and spawns a subagent.
        Returns the output file path.
        """
        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        # Write a pending marker so the auditor knows what to expect.
        self._atomic_write(out_path, {
            "_pending": True,
            "task": task_name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        # TODO(Phase 2): replace with actual sessions_spawn call.
        # e.g. sessions_spawn(
        #     task=f"Run {task_name}-agent with input={input_path} output={output_path}"
        # )
        return str(out_path)

    def _spawn_auditor(self, worker_output: str, worker_template: str, prd_path: str) -> str:
        """Spawn an independent audit agent to check worker output.

        Returns the audit report path.
        """
        worker_path = Path(worker_output)
        # Audit report lives in the same iteration directory as the worker output
        audit_path = worker_path.parent / "audit_report.json"

        # v3.3: inject adaptive threshold into audit template (inactive when disabled)
        injected_template = self._inject_threshold_into_template(worker_template)

        self._atomic_write(audit_path, {
            "_pending": True,
            "worker_type": worker_path.stem.replace("_output", ""),
            "worker_template": injected_template,
            "prd_path": prd_path,
        })

        # TODO(Phase 3): replace with actual sessions_spawn call.
        return str(audit_path)

    def _handle_audit_result(self, audit_report_path: str, worker_task: str) -> str:
        """Handle audit result.

        - PASS: mark task done, return "continue"
        - NEEDS_FIX: spawn fix agent, return "needs_fix"
        - REJECT: log failure, try alternative strategy, return "rejected"
        """
        audit = self._load_json_safe(Path(audit_report_path), {})
        status = audit.get("status", "NEEDS_FIX")

        if status == "PASS":
            return "continue"
        elif status == "NEEDS_FIX":
            return "needs_fix"
        elif status == "REJECT":
            return "rejected"
        else:
            # Unknown status treated as NEEDS_FIX for safety
            return "needs_fix"

    # ── failure handling ────────────────────────────────────────────

    def _handle_worker_failure(self, task: str, iteration: int,
                                state: dict, progress: dict) -> None:
        """Handle worker timeout / crash."""
        exc = {
            "agent": f"{task}-agent",
            "error": "WORKER_FAILURE",
            "task": task,
        }
        self.sm.record_exception(iteration, exc)
        state["pending_fixes"].append({
            "iteration": iteration,
            "task": task,
            "reason": "worker_failure",
        })

    def _handle_audit_failure(self, task: str, iteration: int,
                               state: dict, progress: dict) -> None:
        """Handle auditor timeout / crash."""
        exc = {
            "agent": "audit-quality-agent",
            "error": "AUDITOR_FAILURE",
            "task": task,
        }
        self.sm.record_exception(iteration, exc)

    def _enqueue_fix(self, task: str, iteration: int,
                     audit: dict, state: dict) -> None:
        """Queue a fix when auditor returns NEEDS_FIX."""
        fixes = audit.get("issues", [])
        state["pending_fixes"].append({
            "iteration": iteration,
            "task": task,
            "reason": "needs_fix",
            "issues": fixes,
        })

    def _handle_rejection(self, task: str, iteration: int,
                          state: dict, progress: dict) -> None:
        """Handle REJECT by rolling back the step and recording strategy."""
        progress["completed_steps"] = [
            s for s in progress.get("completed_steps", [])
            if s != task
        ]
        state["strategy_adjustments"].append({
            "iteration": iteration,
            "task": task,
            "action": "rollback_rejected",
        })

    # ── convergence ──────────────────────────────────────────────────

    def _is_converged(self, state: dict, iteration: int) -> bool:
        """Check whether the FCH cycle has converged.

        Convergence requires:
        A. Ming Wu 6 conditions passed
        B. Novelty ratio >= 0.3
        C. No stuck state (same concept un-Ming-Wu for <3 iterations)
        D. v3.3: termination-aware check (inactive when disabled)
        """
        # v3.3: termination-aware convergence (inactive when disabled)
        if self._module_enabled("termination"):
            history = self.sm.load_history()
            if history:
                latest = history[-1]
                if latest.get("termination_triggered"):
                    return True

        # v3.3: load adaptive thresholds if calibration enabled
        # (available for future convergence criteria; fallback to v3.2 behavior)
        if self._module_enabled("threshold_calibration"):
            _ = self.sm.load_thresholds()  # noqa: F841

        # A. Ming Wu
        mw_path = self._iter_dir(iteration) / "mingwu_result.json"
        mw = self._load_json_safe(mw_path, {})
        if not mw.get("passed"):
            return False

        # B. Novelty
        nov_path = self._iter_dir(iteration) / "novelty_result.json"
        nov = self._load_json_safe(nov_path, {})
        if nov.get("decision") != "ACCEPT":
            return False

        # C. Stuck detection (>=3 iterations without Ming Wu)
        stuck_count = 0
        for i in range(max(1, iteration - 2), iteration + 1):
            p = self._iter_dir(i) / "mingwu_result.json"
            m = self._load_json_safe(p, {})
            if not m.get("passed"):
                stuck_count += 1
        if stuck_count >= 3:
            return False

        return True

    def _finalize(self, state: dict, progress: dict, budget: dict) -> None:
        """Clean termination: save final state and emit summary."""
        state["status"] = "CONVERGED"
        progress["status"] = "done"
        self._save_all(state, progress, budget)
        self._report("CONVERGED", progress, budget)

    # ── v3.3 method stubs (inactive when modules disabled) ─────────

    def _get_task_sequence(self, progress: dict, state: dict) -> str | None:
        """Optionally inject BDD task when pending gaps exist.

        Returns 'bdd' if gaps are pending and BDD not yet completed this iteration;
        otherwise returns None to let standard sequence proceed.
        """
        completed = set(progress.get("completed_steps", []))
        if "verify" in completed and "bdd" not in completed:
            if state.get("pending_bdd_gaps"):
                return "bdd"
        return None

    def _route_gaps(self, state: dict, iteration: int) -> None:
        """Classify gaps and route to FCH or BDD (v3.3 stub).

        Inactive when hybrid_routing module is disabled.
        """
        if not self._module_enabled("hybrid_routing") or HybridRouter is None:
            return
        gaps = state.get("pending_gaps", [])
        if not gaps:
            return
        # TODO(Phase 2): call HybridRouter.route(gaps, iteration)
        # For Phase 1: store gaps as pending_bdd_gaps unconditionally
        state["pending_bdd_gaps"] = gaps
        state.pop("pending_gaps", None)
        # Log routing decision
        decision = {
            "iteration": iteration,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "gaps_count": len(gaps),
            "routed_to": "bdd",
            "note": "Phase 1 stub — unconditional BDD routing",
        }
        self.sm.append_routing_decision(decision)

    def _run_bdd_task(self, iteration: int, state: dict, progress: dict, budget: dict) -> str:
        """Run BDD phase (T1/T2 theory + T3 experiments) (v3.3 stub).

        Returns:
            "continue" — BDD completed
            "budget_exhausted" — no budget left
            "rejected" — BDD was rejected
        """
        if not self._module_enabled("hybrid_routing"):
            return "continue"
        # Check budget
        if budget.get("remaining", 0) <= 0:
            return "budget_exhausted"
        self._decrement_budget(budget)
        out_dir = self._iter_dir(iteration)
        out_dir.mkdir(parents=True, exist_ok=True)
        bdd_output_path = out_dir / "bdd_output.json"
        self._atomic_write(bdd_output_path, {
            "_pending": True,
            "task": "bdd",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "note": "Phase 1 stub — BDD agent spawn placeholder",
        })
        # TODO(Phase 2): spawn BDD agent using bdd_task_template.md
        # TODO(Phase 2): BDD agent internally invokes t3_executor.py
        # Mark BDD as completed for this iteration
        progress["completed_steps"] = list(dict.fromkeys(
            progress.get("completed_steps", []) + ["bdd"]
        ))
        state.pop("pending_bdd_gaps", None)
        return "continue"

    def _record_ucc_instance(self, task: str, iteration: int, state: dict) -> None:
        """Build and append a HistoricalUCCRecord (v3.3 stub).

        Inactive when threshold_calibration module is disabled.
        """
        if not self._module_enabled("threshold_calibration"):
            return
        record = {
            "iteration": iteration,
            "task": task,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "concept_id": state.get("current_concept"),
            "confidence": state.get("confidence", {}),
            "note": "Phase 1 stub — UCC record placeholder",
        }
        self.sm.append_history_record(record)

    def _inject_threshold_into_template(self, template_path: str) -> str:
        """Read audit template and substitute adaptive threshold variables (v3.3 stub).

        Inactive when threshold_calibration module is disabled.
        Returns path to the injected template (original path if disabled).
        """
        if not self._module_enabled("threshold_calibration"):
            return template_path
        thresholds = self.sm.load_thresholds()
        point = thresholds.get("audit_aggregate", {}).get("point_estimate", 0.85)
        ci_low = thresholds.get("audit_aggregate", {}).get("ci_low", 0.80)
        ci_high = thresholds.get("audit_aggregate", {}).get("ci_high", 0.90)
        sample_size = thresholds.get("audit_aggregate", {}).get("sample_size", 0)
        # TODO(Phase 2): read template, substitute {{ADAPTIVE_THRESHOLD}}, etc.
        # For Phase 1: return original path (injection is no-op)
        _ = (point, ci_low, ci_high, sample_size)  # noqa: F841
        return template_path

    def _check_termination(self, state: dict, iteration: int) -> dict:
        """Evaluate 4 termination conditions (v3.3 stub).

        Inactive when termination module is disabled.
        Returns {"terminate": bool, "reason": str, "meta_cognitive_summary": dict}.
        """
        if not self._module_enabled("termination") or TerminationEvaluator is None:
            return {"terminate": False}
        bdd_history = self.sm.extract_bdd_history(state)
        current_bdd = self.sm.extract_current_bdd_state(iteration)
        # TODO(Phase 2): instantiate TerminationEvaluator and call evaluate()
        _ = (bdd_history, current_bdd)  # noqa: F841
        return {"terminate": False}

    def _finalize_with_meta_summary(self, state: dict, progress: dict, budget: dict,
                                     term_result: dict | None = None) -> None:
        """Finalize with meta-cognitive triage summary (v3.3 stub).

        Inactive when termination module is disabled.
        """
        if term_result and term_result.get("terminate"):
            state["status"] = "TERMINATED"
            progress["status"] = "done"
            self._save_all(state, progress, budget)
            summary = term_result.get("meta_cognitive_summary", {})
            summary_path = self.harness_dir / "meta_cognitive_summary.json"
            self._atomic_write(summary_path, {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "termination_reason": term_result.get("reason"),
                "summary": summary,
            })
            self._report("TERMINATED", progress, budget)
        else:
            self._finalize(state, progress, budget)

    # ── state ingestion ──────────────────────────────────────────────

    def _ingest_worker_output(self, task: str, iteration: int, state: dict) -> None:
        """Merge a validated worker output into state.json."""
        out_path = self._iter_dir(iteration) / f"{task}_output.json"
        data = self._load_json_safe(out_path, {})

        if task == "teach":
            state["current_concept"] = data.get("concept_id")
            state["confidence"] = {"d1": 0.5, "d2": 0.5, "d3": 0.5, "d4": 0.5}
        elif task == "verify":
            conf = data.get("confidence", {})
            state["confidence"] = conf
            # v3.3: extract gaps for routing classification (inactive when disabled)
            if self._module_enabled("hybrid_routing"):
                gaps = data.get("gaps", [])
                if gaps:
                    state["pending_gaps"] = gaps
        elif task == "consolidate":
            concept = data.get("concept_id")
            if concept:
                state.setdefault("concept_history", []).append(concept)
        elif task == "search":
            # Search results are used by teach-agent, no direct state mutation needed
            pass

    # ── helpers ──────────────────────────────────────────────────────

    def _iter_dir(self, iteration: int) -> Path:
        return self.results_dir / f"iteration_{iteration}"

    def _search_completed_for_iteration(self, iteration: int) -> bool:
        """Check if search_results.json exists for this iteration."""
        return (self._iter_dir(iteration) / "search_output.json").exists()

    def _audit_report_path(self, iteration: int) -> Path:
        return self._iter_dir(iteration) / "audit_report.json"

    def _check_worker_timeout(self, output_path: str, max_wait_seconds: int = 600) -> bool:
        """Check if a worker has exceeded time limit.
        Reads the pending marker file timestamp.
        Returns True if timed out.
        """
        path = Path(output_path)
        if not path.exists():
            return True  # File doesn't exist = timeout

        data = self._load_json_safe(path, {})
        if not data.get("_pending"):
            return False  # Worker completed, not pending

        # Check timestamp in marker
        marker_time_str = data.get("timestamp")
        if marker_time_str:
            try:
                marker_time = datetime.fromisoformat(marker_time_str)
                elapsed = (datetime.now(timezone.utc) - marker_time).total_seconds()
                return elapsed > max_wait_seconds
            except (ValueError, TypeError):
                pass

        # Fallback: use file modification time
        try:
            mtime = path.stat().st_mtime
            from time import time
            elapsed = time() - mtime
            return elapsed > max_wait_seconds
        except OSError:
            return True

    def _analyze_failure_pattern(self, task_name: str) -> dict:
        """Read exceptions.json history for this task.
        If 3+ consecutive failures, analyze root cause and suggest strategy change.
        Returns: {"action": "continue" | "escalate" | "abort", "reason": str}
        """
        current_iteration = self.sm.load_progress().get("current_iteration", 1)
        failure_records = []

        # Scan last 5 iterations for exceptions related to this task
        for i in range(max(1, current_iteration - 4), current_iteration + 1):
            exc_path = self._iter_dir(i) / "exceptions.json"
            exc_data = self._load_json_safe(exc_path, {"records": []})
            for record in exc_data.get("records", []):
                if record.get("task") == task_name:
                    failure_records.append({
                        "iteration": i,
                        "error": record.get("error", "UNKNOWN"),
                        "agent": record.get("agent", "unknown"),
                        "time": record.get("time", ""),
                    })

        # Check for 3+ failures in the same task
        if len(failure_records) >= 3:
            last_three = failure_records[-3:]
            iterations = [r["iteration"] for r in last_three]
            # Verify they span at most 3 consecutive iterations
            if iterations[-1] - iterations[0] <= 2:
                errors = [r["error"] for r in last_three]
                agents = [r["agent"] for r in last_three]

                if len(set(errors)) == 1:
                    return {
                        "action": "escalate",
                        "reason": (
                            f"Task '{task_name}' failed 3+ times with same error "
                            f"'{errors[-1]}'. Suggest strategy change or agent swap."
                        ),
                    }
                elif len(set(agents)) > 1:
                    return {
                        "action": "escalate",
                        "reason": (
                            f"Task '{task_name}' failed across multiple agents. "
                            f"Likely input data or strategy issue."
                        ),
                    }
                else:
                    return {
                        "action": "abort",
                        "reason": (
                            f"Task '{task_name}' repeatedly failed with agent "
                            f"'{agents[-1]}'. Aborting to prevent budget drain."
                        ),
                    }

        return {"action": "continue", "reason": "No consecutive failure pattern detected."}

    def _decrement_budget(self, budget: dict) -> None:
        budget["remaining"] = max(0, budget.get("remaining", 0) - 1)
        budget["used"] = budget.get("used", 0) + 1

    def _save_all(self, state: dict, progress: dict, budget: dict) -> None:
        self.sm.save_state(state)
        self.sm.save_progress(progress)
        self.sm.save_budget(budget)

    def _report(self, status: str, progress: dict, budget: dict) -> None:
        """Emit a machine-readable status line to stdout."""
        report = {
            "status": status,
            "iteration": progress.get("current_iteration"),
            "remaining_budget": budget.get("remaining"),
            "used_budget": budget.get("used"),
        }
        print(json.dumps(report, ensure_ascii=False))

    @staticmethod
    def _load_json_safe(path: Path, default: dict) -> dict:
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default

    @staticmethod
    def _atomic_write(path: Path, data: dict) -> None:
        import tempfile
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", prefix="tmp_",
            dir=str(path.parent), delete=False,
        )
        try:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, path)


# ── mapping analysis ───────────────────────────────────────────────

    def _check_d1_d3_mapping(self, mapping_d1_d3: dict) -> dict:
        """Check D1↔D3 mapping: Analogy ↔ Formal.

        Detects: orphan formal terms, orphan analogy elements, analogy fractures.
        """
        correspondences = mapping_d1_d3.get("correspondences", [])
        unmapped_d3 = mapping_d1_d3.get("unmapped_d3_terms", [])
        unmapped_d1 = mapping_d1_d3.get("unmapped_d1_elements", [])
        return {
            "orphans_formal": unmapped_d3,
            "orphans_analogy": unmapped_d1,
            "fractures": [],
            "correspondence_count": len(correspondences),
        }

    def _check_d2_d4_mapping(self, mapping_d2_d4: dict) -> dict:
        """Check D2↔D4 mapping: Procedure ↔ Boundary.

        Detects: unguarded boundaries, phantom guards, silent failures.
        """
        guards = mapping_d2_d4.get("guards", [])
        unguarded = mapping_d2_d4.get("unguarded_boundaries", [])
        return {
            "guarded_boundaries": [
                g["d4_condition"] for g in guards if g.get("guard_type") != "none"
            ],
            "unguarded_boundaries": unguarded,
            "phantom_guards": [],
            "silent_failures": [],
        }

    def _check_d3_d4_mapping(self, mapping_d3_d4: dict, teach_output: dict) -> dict:
        """Check D3↔D4 mapping: Formal ↔ Counter-example.

        Detects: unconstructible counters, hidden assumptions, vacuous boundaries.
        """
        constructibility = mapping_d3_d4.get("constructibility", [])
        unconstructible = [
            c["d4_counter_example"]
            for c in constructibility
            if not c.get("constructible_from_d3", False)
        ]
        return {
            "constructible_counters": [
                c["d4_counter_example"]
                for c in constructibility
                if c.get("constructible_from_d3", False)
            ],
            "unconstructible_counters": unconstructible,
            "hidden_assumptions": [],
            "vacuous_boundaries": [],
        }

    def _check_cross_layer_mapping(self, contradictions: list, teach_output: dict) -> list:
        """Interpret contradictions as mapping failures between layers."""
        mapping_failures = []
        for contradiction in contradictions:
            layers = contradiction.get("layers_involved", [])
            layer_set = set(layers)
            if layer_set == {"d1", "d3"}:
                mapping_failures.append({
                    "type": "analogy_fracture",
                    "layers": ["d1", "d3"],
                    "gap": contradiction.get("text", "D1↔D3 contradiction"),
                })
            elif layer_set == {"d2", "d4"}:
                mapping_failures.append({
                    "type": "unguarded_boundary",
                    "layers": ["d2", "d4"],
                    "gap": contradiction.get("text", "D2↔D4 contradiction"),
                })
            elif layer_set == {"d3", "d4"}:
                mapping_failures.append({
                    "type": "hidden_assumption",
                    "layers": ["d3", "d4"],
                    "gap": contradiction.get("text", "D3↔D4 contradiction"),
                })
            else:
                mapping_failures.append({
                    "type": "mapping_misalignment",
                    "layers": layers,
                    "gap": contradiction.get("text", "Cross-layer contradiction"),
                })
        return mapping_failures

    def _check_d1_d2_mapping(self, mapping_d1_d2: dict) -> dict:
        """Check D1↔D2 mapping: Analogy ↔ Procedure.

        Detects:
        - orphan D1 elements (concrete nouns/verbs with no D2 step)
        - orphan D2 steps (steps with no D1 correspondent)
        - implied actions missing (analogy suggests actions not in D2)
        """
        correspondences = mapping_d1_d2.get("correspondences", [])
        unmapped_d1 = mapping_d1_d2.get("unmapped_d1_elements", [])
        unmapped_d2 = mapping_d1_d2.get("unmapped_d2_steps", [])

        # Detect implied actions from D1 that are missing in D2
        d2_step_indices = {
            c.get("d2_step_index") for c in correspondences
            if c.get("d2_step_index") is not None
        }
        implied_actions_missing = []
        for corr in correspondences:
            d1_elem = corr.get("d1_element", "")
            # Heuristic: if D1 element is a verb-like action not reflected in D2
            if d1_elem and corr.get("mapping_type") == "metaphorical":
                implied_actions_missing.append(d1_elem)

        return {
            "orphan_d1_elements": [
                {"element": e, "gap": f"D1 describes '{e}' but D2 has no step to execute it"}
                for e in unmapped_d1
            ],
            "orphan_d2_steps": [
                {"step": s, "gap": f"D2 step {s} has no correspondent in D1 analogy"}
                for s in unmapped_d2
            ],
            "implied_actions_missing": implied_actions_missing,
            "correspondence_count": len(correspondences),
        }

    def _check_d2_d3_mapping(self, mapping_d2_d3: dict) -> dict:
        """Check D2↔D3 mapping: Procedure ↔ Formal.

        Detects:
        - unmanipulated D3 variables (variables never touched by D2)
        - unformalized D2 steps (steps with no D3 correspondent)
        - operation mismatches (informal vs formal operation differ)
        """
        correspondences = mapping_d2_d3.get("correspondences", [])
        unmapped_d3 = mapping_d2_d3.get("unmapped_d3_variables", [])
        unmapped_d2 = mapping_d2_d3.get("unmapped_d2_steps", [])

        # Detect operation mismatches from correspondences
        operation_mismatches = []
        for corr in correspondences:
            informal_op = corr.get("informal_op")
            formal_op = corr.get("formal_op")
            if informal_op and formal_op and informal_op != formal_op:
                operation_mismatches.append({
                    "step": corr.get("d2_step_index"),
                    "informal": informal_op,
                    "formal": formal_op,
                    "gap": (
                        f"D2 says '{informal_op}' but D3 formalizes as "
                        f"'{formal_op}'; operations may differ"
                    ),
                })

        return {
            "unmanipulated_variables": [
                {"variable": v, "gap": f"D3 defines '{v}' but D2 never manipulates it"}
                for v in unmapped_d3
            ],
            "unformalized_steps": [
                {"step": s, "gap": f"D2 step {s} has no formal correspondent"}
                for s in unmapped_d2
            ],
            "operation_mismatches": operation_mismatches,
            "correspondence_count": len(correspondences),
        }

    def _check_cross_concept_mapping(self, teach_output: dict) -> dict:
        """Check cross-concept mapping conflicts across the lattice.

        Detects:
        - definition mismatches (same term, different D3 definitions)
        - analogy collisions (same D1 analogy maps to different D3 ops)
        - boundary violations (dependent concept violates dependency's D4)
        - dependency drifts (B's D2 depends on A's old D3 definition)
        """
        state = self.sm.load_state()
        concept_history = state.get("concept_history", [])
        current_concept = teach_output.get("concept_id")

        definition_mismatches = []
        analogy_collisions = []
        boundary_violations = []
        dependency_drifts = []

        # Need at least 2 concepts to detect cross-concept conflicts
        all_concepts = list(
            dict.fromkeys(concept_history + ([current_concept] if current_concept else []))
        )
        if len(all_concepts) < 2:
            return {
                "definition_mismatches": definition_mismatches,
                "analogy_collisions": analogy_collisions,
                "boundary_violations": boundary_violations,
                "dependency_drifts": dependency_drifts,
            }

        # Build lattice: concept_id -> teach_output data
        lattice = {}
        for concept_id in all_concepts:
            if concept_id == current_concept:
                lattice[concept_id] = teach_output
            else:
                # Load from previous iteration teach outputs
                for i in range(1, 1000):
                    path = self._iter_dir(i) / "teach_output.json"
                    data = self._load_json_safe(path, {})
                    if data.get("concept_id") == concept_id:
                        lattice[concept_id] = data
                        break

        # Compare each pair of concepts
        concept_ids = list(lattice.keys())
        for i, concept_a in enumerate(concept_ids):
            for concept_b in concept_ids[i + 1:]:
                a_data = lattice.get(concept_a, {})
                b_data = lattice.get(concept_b, {})

                a_d3 = a_data.get("d3", {})
                b_d3 = b_data.get("d3", {})
                a_d1 = a_data.get("d1", "")
                b_d1 = b_data.get("d1", "")
                a_d4 = a_data.get("d4", {})

                # 1. Definition mismatch: same term, different D3 definitions
                a_terms = self._extract_defined_terms(a_d3.get("definition", ""))
                b_terms = self._extract_defined_terms(b_d3.get("definition", ""))
                for term in set(a_terms.keys()) & set(b_terms.keys()):
                    if a_terms[term] != b_terms[term]:
                        definition_mismatches.append({
                            "type": "definition_mismatch",
                            "term": term,
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "definition_a": a_terms[term],
                            "definition_b": b_terms[term],
                            "gap": (
                                f"'{term}' defined differently in {concept_a} "
                                f"vs {concept_b}"
                            ),
                        })

                # 2. Analogy collision: same D1 analogy maps to different D3 ops
                a_analogies = self._extract_core_analogies(a_d1)
                b_analogies = self._extract_core_analogies(b_d1)
                for analogy in set(a_analogies.keys()) & set(b_analogies.keys()):
                    if a_analogies[analogy] != b_analogies[analogy]:
                        analogy_collisions.append({
                            "type": "analogy_collision",
                            "analogy": analogy,
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "formal_op_a": a_analogies[analogy],
                            "formal_op_b": b_analogies[analogy],
                            "gap": (
                                f"Both concepts use '{analogy}' but map to "
                                f"different formal operations"
                            ),
                        })

                # 3. Boundary violation: B's usage context violates A's D4 boundaries
                a_boundaries = a_d4.get("boundaries", [])
                b_def = b_d3.get("definition", "")
                for boundary in a_boundaries:
                    condition = boundary.get("condition", "")
                    if condition and condition in b_def:
                        boundary_violations.append({
                            "type": "boundary_violation",
                            "boundary": condition,
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "gap": (
                                f"{concept_b} may violate {concept_a}'s boundary: "
                                f"'{condition}'"
                            ),
                        })

                # 4. Dependency drift: requires versioned D3 definitions (not yet tracked)
                # Placeholder: will be populated when version tracking is added.

        return {
            "definition_mismatches": definition_mismatches,
            "analogy_collisions": analogy_collisions,
            "boundary_violations": boundary_violations,
            "dependency_drifts": dependency_drifts,
        }

    def _extract_defined_terms(self, definition_text: str) -> dict:
        """Extract defined terms from D3 definition text.

        Looks for 'term = definition' or 'term: definition' patterns.
        """
        import re

        terms = {}
        if not definition_text:
            return terms
        for match in re.finditer(
            r"([A-Za-z_][A-Za-z0-9_\s]*[A-Za-z0-9_])\s*[:=]\s*([^;.\n]+)",
            definition_text,
        ):
            term = match.group(1).strip()
            definition = match.group(2).strip()
            if term:
                terms[term] = definition
        return terms

    def _extract_core_analogies(self, d1_text: str) -> dict:
        """Extract core analogies from D1 text.

        Returns a dict of analogy -> formal_operation mapping.
        This is a heuristic placeholder; full implementation requires
        NLP parsing of analogy structures.
        """
        return {}

    def _analyze_mappings(self, teach_output: dict, iteration: int) -> dict:
        """Pure function: analyze cross-layer mappings and produce failures.

        This is NOT a new agent spawn. It is a deterministic computation
        that runs inside the orchestrator between teach and audit.
        """
        mappings = teach_output.get("mappings", {})

        failures = {
            "d1_d3": self._check_d1_d3_mapping(mappings.get("d1_d3", {})),
            "d2_d4": self._check_d2_d4_mapping(mappings.get("d2_d4", {})),
            "d3_d4": self._check_d3_d4_mapping(
                mappings.get("d3_d4", {}), teach_output
            ),
            "cross_layer": self._check_cross_layer_mapping([], teach_output),
            "d1_d2": self._check_d1_d2_mapping(mappings.get("d1_d2", {})),
            "d2_d3": self._check_d2_d3_mapping(mappings.get("d2_d3", {})),
            "cross_concept": self._check_cross_concept_mapping(teach_output),
        }

        # Interpret contradiction-agent output if available
        contradictions_path = self._iter_dir(iteration) / "contradictions.json"
        if contradictions_path.exists():
            contradictions = self._load_json_safe(contradictions_path, {})
            failures["cross_layer"] = self._check_cross_layer_mapping(
                contradictions.get("contradictions", []), teach_output
            )

        # Write mapping_failures.json for downstream agents
        failures_path = self._iter_dir(iteration) / "mapping_failures.json"
        self._atomic_write(failures_path, {
            "iteration": iteration,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "failures": failures,
            "gap_count": self._count_gaps(failures),
        })

        return failures

    def _count_gaps(self, failures: dict) -> int:
        """Count total gaps across all failure categories."""
        count = 0

        # d1_d3
        d1_d3 = failures.get("d1_d3", {})
        count += len(d1_d3.get("orphans_formal", []))
        count += len(d1_d3.get("orphans_analogy", []))
        count += len(d1_d3.get("fractures", []))

        # d2_d4
        d2_d4 = failures.get("d2_d4", {})
        count += len(d2_d4.get("unguarded_boundaries", []))
        count += len(d2_d4.get("phantom_guards", []))
        count += len(d2_d4.get("silent_failures", []))

        # d3_d4
        d3_d4 = failures.get("d3_d4", {})
        count += len(d3_d4.get("unconstructible_counters", []))
        count += len(d3_d4.get("hidden_assumptions", []))
        count += len(d3_d4.get("vacuous_boundaries", []))

        # cross_layer
        count += len(failures.get("cross_layer", []))

        # d1_d2 (new)
        d1_d2 = failures.get("d1_d2", {})
        count += len(d1_d2.get("orphan_d1_elements", []))
        count += len(d1_d2.get("orphan_d2_steps", []))
        count += len(d1_d2.get("implied_actions_missing", []))

        # d2_d3 (new)
        d2_d3 = failures.get("d2_d3", {})
        count += len(d2_d3.get("unmanipulated_variables", []))
        count += len(d2_d3.get("unformalized_steps", []))
        count += len(d2_d3.get("operation_mismatches", []))

        # cross_concept (new)
        cross = failures.get("cross_concept", {})
        count += len(cross.get("definition_mismatches", []))
        count += len(cross.get("analogy_collisions", []))
        count += len(cross.get("boundary_violations", []))
        count += len(cross.get("dependency_drifts", []))

        return count


# ── entry point ────────────────────────────────────────────────────

def main() -> None:
    harness_dir = os.environ.get("FCH_HARNESS_DIR", str(Path(__file__).parent))
    orch = FCHOrchestrator(harness_dir)
    orch.run()


if __name__ == "__main__":
    main()
