#!/usr/bin/env python3
"""
Analogy Selector — FCH v3.3
Multi-domain analogy matrix with effectiveness tracking and breakage detection.

Replaces single-D1-per-teach with a domain-aware analogy matrix that selects
the best analogy based on learner profile, concept affinity, breakage avoidance,
and recency. Detects analogy migration failures and triggers reframe protocols.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("fch.analogy")


# ── helper (must be defined before dataclass defaults) ──────────

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ── data structures ───────────────────────────────────────────────

@dataclass
class AnalogyEntry:
    """A single analogy entry in the matrix."""
    analogy_id: str
    source_domain: str
    target_domain: str
    analogy_text: str
    d2_formalization: str
    d3_formula: str
    created_at: str
    last_used: Optional[str] = None
    use_count: int = 0
    effectiveness_ema: float = 0.5
    breakage_history: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "analogy_id": self.analogy_id,
            "source_domain": self.source_domain,
            "target_domain": self.target_domain,
            "analogy_text": self.analogy_text,
            "d2_formalization": self.d2_formalization,
            "d3_formula": self.d3_formula,
            "created_at": self.created_at,
            "last_used": self.last_used,
            "use_count": self.use_count,
            "effectiveness_ema": self.effectiveness_ema,
            "breakage_history": self.breakage_history,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AnalogyEntry":
        return cls(
            analogy_id=d["analogy_id"],
            source_domain=d["source_domain"],
            target_domain=d["target_domain"],
            analogy_text=d["analogy_text"],
            d2_formalization=d.get("d2_formalization", ""),
            d3_formula=d.get("d3_formula", ""),
            created_at=d.get("created_at", _utc_now_iso()),
            last_used=d.get("last_used"),
            use_count=d.get("use_count", 0),
            effectiveness_ema=d.get("effectiveness_ema", 0.5),
            breakage_history=d.get("breakage_history", []),
        )


@dataclass
class AnalogyMatrix:
    """Collection of analogy entries for a concept."""
    concept_id: str
    entries: List[AnalogyEntry] = field(default_factory=list)
    default_domain: str = "general"
    created_at: str = field(default_factory=_utc_now_iso)
    updated_at: str = field(default_factory=_utc_now_iso)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "concept_id": self.concept_id,
            "entries": [e.to_dict() for e in self.entries],
            "default_domain": self.default_domain,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AnalogyMatrix":
        return cls(
            concept_id=d.get("concept_id", "unknown"),
            entries=[AnalogyEntry.from_dict(e) for e in d.get("entries", [])],
            default_domain=d.get("default_domain", "general"),
            created_at=d.get("created_at", _utc_now_iso()),
            updated_at=d.get("updated_at", _utc_now_iso()),
        )


@dataclass
class SelectionContext:
    """Context used when selecting an analogy from the matrix."""
    learner_domain_background: str = "general"
    concept_category: str = "general"
    prior_analogy_id: Optional[str] = None
    prior_breakage_reason: Optional[str] = None
    target_depth: str = "D1"
    recency_weight: float = 0.10


@dataclass
class AnalogySelection:
    """Result of analogy selection."""
    analogy_id: str
    analogy_text: str
    source_domain: str
    selection_reason: str
    confidence: float
    scores: Dict[str, float]
    reframe_triggered: bool = False
    reframe_reason: Optional[str] = None


@dataclass
class BreakageReport:
    """Report of analogy migration failure."""
    analogy_id: str
    triggered: bool
    reason: str
    severity: str  # "minor", "moderate", "critical"
    indicators: Dict[str, Any]
    recommendation: str


# ── analogy selector ────────────────────────────────────────────

class AnalogySelector:
    """Select analogies from a matrix and detect migration breakages.

    Supports four-factor scoring (learner match, concept affinity, breakage
    avoidance, recency) and five trigger conditions for breakage detection.
    """

    # Default weights for 4-factor scoring
    DEFAULT_WEIGHTS = {
        "learner_match": 0.40,
        "concept_affinity": 0.30,
        "breakage_avoidance": 0.20,
        "recency": 0.10,
    }

    def __init__(self, matrix: Optional[AnalogyMatrix] = None, weights: Optional[Dict[str, float]] = None):
        self.matrix = matrix
        self.weights = weights or dict(self.DEFAULT_WEIGHTS)

    def select_analogy(
        self,
        context: SelectionContext,
    ) -> AnalogySelection:
        """Select the best analogy from the matrix for the given context.

        If prior_breakage_reason is set, triggers reframe protocol which
        excludes the prior analogy and selects an alternative.

        Returns:
            AnalogySelection with selected analogy metadata.
        """
        if self.matrix is None or not self.matrix.entries:
            return AnalogySelection(
                analogy_id="none",
                analogy_text="No analogy available.",
                source_domain="none",
                selection_reason="Empty matrix — fallback to v3.2 behavior",
                confidence=0.0,
                scores={},
            )

        candidates = self.matrix.entries

        # Reframe protocol: exclude prior broken analogy
        if context.prior_analogy_id and context.prior_breakage_reason:
            candidates = [e for e in candidates if e.analogy_id != context.prior_analogy_id]
            if not candidates:
                return AnalogySelection(
                    analogy_id="reframe_needed",
                    analogy_text="All analogies exhausted — generate new analogy required.",
                    source_domain="none",
                    selection_reason="Reframe: no alternative analogy available after excluding broken one",
                    confidence=0.0,
                    scores={},
                    reframe_triggered=True,
                    reframe_reason=context.prior_breakage_reason,
                )

        scored = []
        for entry in candidates:
            scores = self._score_entry(entry, context)
            total = sum(self.weights.get(k, 0.0) * v for k, v in scores.items())
            scored.append((total, entry, scores))

        scored.sort(key=lambda x: x[0], reverse=True)
        best_total, best_entry, best_scores = scored[0]

        reframe_triggered = context.prior_analogy_id is not None and context.prior_breakage_reason is not None

        return AnalogySelection(
            analogy_id=best_entry.analogy_id,
            analogy_text=best_entry.analogy_text,
            source_domain=best_entry.source_domain,
            selection_reason=f"Highest composite score ({best_total:.3f}) across 4 factors",
            confidence=min(1.0, max(0.0, best_total)),
            scores=best_scores,
            reframe_triggered=reframe_triggered,
            reframe_reason=context.prior_breakage_reason,
        )

    def detect_breakage(
        self,
        teach_output: Dict[str, Any],
        audit_output: Dict[str, Any],
        analogy_id: str,
        target_domain: str,
    ) -> BreakageReport:
        """Detect whether an analogy migration has failed across 5 conditions.

        The 5 trigger conditions are:
        1. Audit score drop (aggregate < 0.65)
        2. D1↔D2 mapping failure (teach output lacks d2 formalization)
        3. D1↔D3 contradiction (d3 formula contradicts analogy implication)
        4. Pattern match (analogy text matches known breakage patterns)
        5. Migration score collapse (computed from domain distance heuristic)

        Returns:
            BreakageReport detailing which conditions triggered and why.
        """
        indicators: Dict[str, Any] = {}
        triggered = False
        reasons: List[str] = []
        severity = "minor"

        # Condition 1: Audit score drop
        audit_score = audit_output.get("total", audit_output.get("aggregate", 1.0))
        if audit_score < 0.65:
            triggered = True
            reasons.append(f"Audit score collapse ({audit_score:.2f} < 0.65)")
            indicators["audit_score_drop"] = True
            severity = max_severity(severity, "critical")
        else:
            indicators["audit_score_drop"] = False

        # Condition 2: D1↔D2 mapping failure
        has_d2 = bool(teach_output.get("d2", teach_output.get("formalization", "")))
        if not has_d2:
            triggered = True
            reasons.append("D1↔D2 mapping failure — no D2 formalization produced")
            indicators["d1_d2_mapping_failure"] = True
            severity = max_severity(severity, "moderate")
        else:
            indicators["d1_d2_mapping_failure"] = False

        # Condition 3: D1↔D3 contradiction (heuristic check)
        d3 = teach_output.get("d3", teach_output.get("formula", ""))
        d1 = teach_output.get("d1", teach_output.get("analogy", ""))
        contradiction = self._check_d1_d3_contradiction(d1, d3)
        if contradiction:
            triggered = True
            reasons.append("D1↔D3 contradiction detected")
            indicators["d1_d3_contradiction"] = True
            severity = max_severity(severity, "critical")
        else:
            indicators["d1_d3_contradiction"] = False

        # Condition 4: Pattern match
        breakage_patterns = ["circular", "tautology", "overfit", "mixed metaphor"]
        matched = self._pattern_match(d1, breakage_patterns)
        if matched:
            triggered = True
            reasons.append(f"Pattern match: '{matched}' detected in D1")
            indicators["pattern_match"] = True
            severity = max_severity(severity, "moderate")
        else:
            indicators["pattern_match"] = False

        # Condition 5: Migration score collapse
        entry = self._find_entry(analogy_id)
        if entry:
            migration_score = self._compute_migration_score(entry.source_domain, target_domain)
            if migration_score < 0.35:
                triggered = True
                reasons.append(f"Migration score collapse ({migration_score:.2f} < 0.35)")
                indicators["migration_score_collapse"] = True
                severity = max_severity(severity, "critical")
            else:
                indicators["migration_score_collapse"] = False
        else:
            indicators["migration_score_collapse"] = False

        reason_text = " | ".join(reasons) if reasons else "No breakage detected"
        recommendation = (
            "trigger_reframe" if triggered and severity in ("moderate", "critical")
            else "monitor" if triggered
            else "continue"
        )

        return BreakageReport(
            analogy_id=analogy_id,
            triggered=triggered,
            reason=reason_text,
            severity=severity,
            indicators=indicators,
            recommendation=recommendation,
        )

    def update_analogy_scores(
        self,
        analogy_id: str,
        domain: str,
        audit_score: float,
    ) -> None:
        """Update the effectiveness EMA for an analogy after audit.

        Uses exponential moving average with alpha=0.3:
        new_ema = 0.3 * audit_score + 0.7 * old_ema
        """
        entry = self._find_entry(analogy_id)
        if entry is None:
            return
        alpha = 0.3
        entry.effectiveness_ema = alpha * audit_score + (1 - alpha) * entry.effectiveness_ema
        entry.use_count += 1
        entry.last_used = _utc_now_iso()
        entry.target_domain = domain  # type: ignore[attr-defined]

    def generate_initial_matrix(
        self,
        concept_id: str,
        learner_profile: Dict[str, Any],
    ) -> AnalogyMatrix:
        """Seed an analogy matrix with 2–3 default analogies.

        In a full implementation this would invoke a generation agent.
        For Phase 1, returns a minimal scaffold.
        """
        background = learner_profile.get("domain_background", "general")
        matrix = AnalogyMatrix(concept_id=concept_id, default_domain=background)

        # Placeholder seed entries — real system would generate from concept analysis
        matrix.entries.append(
            AnalogyEntry(
                analogy_id=f"{concept_id}_analogy_1",
                source_domain=background,
                target_domain=background,
                analogy_text=f"Placeholder analogy for {concept_id}",
                d2_formalization="",
                d3_formula="",
                created_at=_utc_now_iso(),
            )
        )
        return matrix

    # ── internal helpers ────────────────────────────────────────

    def _score_entry(self, entry: AnalogyEntry, context: SelectionContext) -> Dict[str, float]:
        """Score a single analogy entry across 4 factors."""
        scores: Dict[str, float] = {}

        # 1. Learner match (domain overlap)
        learner_bg = context.learner_domain_background.lower()
        source = entry.source_domain.lower()
        if learner_bg == source or learner_bg in source or source in learner_bg:
            scores["learner_match"] = 1.0
        else:
            scores["learner_match"] = 0.5

        # 2. Concept affinity (placeholder: use effectiveness EMA)
        scores["concept_affinity"] = entry.effectiveness_ema

        # 3. Breakage avoidance (inverse of breakage frequency)
        breakage_count = len(entry.breakage_history)
        scores["breakage_avoidance"] = max(0.0, 1.0 - breakage_count * 0.25)

        # 4. Recency (higher if recently used and effective)
        if entry.last_used:
            scores["recency"] = 0.5 + 0.5 * entry.effectiveness_ema
        else:
            scores["recency"] = 0.3

        return scores

    def _find_entry(self, analogy_id: str) -> Optional[AnalogyEntry]:
        if self.matrix is None:
            return None
        for e in self.matrix.entries:
            if e.analogy_id == analogy_id:
                return e
        return None

    @staticmethod
    def _check_d1_d3_contradiction(d1: str, d3: str) -> bool:
        """Heuristic check for contradiction between D1 analogy and D3 formula."""
        # Placeholder: real implementation would use semantic analysis
        if not d1 or not d3:
            return False
        contradiction_markers = ["contradict", "inconsistent", "violates", "not applicable"]
        combined = (d1 + " " + d3).lower()
        return any(m in combined for m in contradiction_markers)

    @staticmethod
    def _pattern_match(text: str, patterns: List[str]) -> Optional[str]:
        """Check if text contains any breakage pattern."""
        if not text:
            return None
        low = text.lower()
        for p in patterns:
            if p in low:
                return p
        return None

    @staticmethod
    def _compute_migration_score(source_domain: str, target_domain: str) -> float:
        """Heuristic domain distance score. 1.0 = same domain, 0.0 = maximally distant."""
        s = source_domain.lower()
        t = target_domain.lower()
        if s == t:
            return 1.0
        # Simple overlap heuristic
        s_tokens = set(s.split())
        t_tokens = set(t.split())
        if not s_tokens or not t_tokens:
            return 0.5
        inter = s_tokens & t_tokens
        union = s_tokens | t_tokens
        return len(inter) / len(union) if union else 0.5


# ── utility functions ───────────────────────────────────────────

def max_severity(a: str, b: str) -> str:
    """Return the higher of two severity levels."""
    order = {"minor": 0, "moderate": 1, "critical": 2}
    return a if order.get(a, 0) >= order.get(b, 0) else b


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ── CLI entry point ────────────────────────────────────────────

def _main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="FCH v3.3 Analogy Selector")
    parser.add_argument("--generate-matrix", type=str, help="Concept ID to generate matrix for")
    parser.add_argument("--matrix-file", type=str, default="analogy_matrix.json", help="Matrix JSON path")
    args = parser.parse_args()

    if args.generate_matrix:
        selector = AnalogySelector()
        matrix = selector.generate_initial_matrix(args.generate_matrix, {})
        with open(args.matrix_file, "w", encoding="utf-8") as f:
            json.dump(matrix.to_dict(), f, indent=2, ensure_ascii=False)
        print(f"Generated matrix for {args.generate_matrix} -> {args.matrix_file}")
    else:
        parser.print_help()


if __name__ == "__main__":
    _main()

__all__ = [
    "AnalogySelector",
    "AnalogyMatrix",
    "AnalogyEntry",
    "SelectionContext",
    "AnalogySelection",
    "BreakageReport",
    "max_severity",
]
