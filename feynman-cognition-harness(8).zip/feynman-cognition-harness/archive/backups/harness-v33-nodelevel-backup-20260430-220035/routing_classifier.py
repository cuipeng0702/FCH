#!/usr/bin/env python3
"""
Routing Classifier — FCH v3.3
Hybrid routing mechanism with 5-band spectrum classification and FCH failure criteria.

Replaces binary internal/external routing with a continuum-based approach:
- 3-dimensional gap scoring (scope / depth / precedent)
- internal_ratio ∈ [0.0, 1.0] → Band I-V
- FCH-first-then-BDD fallback for hybrid bands
- Routing decision log for post-hoc analysis and threshold calibration
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger("fch.routing")


# ── data structures ─────────────────────────────────────────────

@dataclass
class Dimensions:
    """Three orthogonal dimensions for gap classification."""
    scope: float
    depth: float
    precedent: float

    def to_dict(self) -> Dict[str, float]:
        return {"scope": self.scope, "depth": self.depth, "precedent": self.precedent}


@dataclass
class Classification:
    """Classification result for a single gap."""
    gap_id: str
    dimensions: Dimensions
    internal_ratio: float
    band: str
    recommended_action: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "gap_id": self.gap_id,
            "dimensions": self.dimensions.to_dict(),
            "internal_ratio": self.internal_ratio,
            "band": self.band,
            "recommended_action": self.recommended_action,
        }


@dataclass
class DetectedGap:
    """A gap detected by the FCH difference detection module."""
    id: str
    description: str
    repair_type: str = "unknown"
    origin_layer: str = "unknown"
    rtdf_relationship: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "description": self.description,
            "repair_type": self.repair_type,
            "origin_layer": self.origin_layer,
            "rtdf_relationship": self.rtdf_relationship,
        }


@dataclass
class FCHResult:
    """Result of an FCH repair attempt."""
    audit_score: float
    fix_attempt_count: int
    new_gaps_introduced: int
    gap: DetectedGap
    artifacts: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RoutingDecision:
    """A single routing decision for a gap."""
    gap: DetectedGap
    classification: Classification
    initial_action: str
    fch_attempted: bool
    fch_iterations: int = 0
    fch_audit_scores: List[float] = field(default_factory=list)
    fch_failed: bool = False
    failure_criterion_triggered: str = "NONE"
    bdd_attempted: bool = False
    bdd_confidence: Optional[float] = None
    final_action: str = "PENDING"
    concepts_emerged: List[str] = field(default_factory=list)
    new_gaps_introduced: List[str] = field(default_factory=list)
    human_review_flag: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "gap": self.gap.to_dict(),
            "classification": self.classification.to_dict(),
            "initial_action": self.initial_action,
            "fch_attempted": self.fch_attempted,
            "fch_iterations": self.fch_iterations,
            "fch_audit_scores": self.fch_audit_scores,
            "fch_failed": self.fch_failed,
            "failure_criterion_triggered": self.failure_criterion_triggered,
            "bdd_attempted": self.bdd_attempted,
            "bdd_confidence": self.bdd_confidence,
            "final_action": self.final_action,
            "concepts_emerged": self.concepts_emerged,
            "new_gaps_introduced": self.new_gaps_introduced,
            "human_review_flag": self.human_review_flag,
        }


@dataclass
class FailureCriteria:
    """Criteria for determining FCH repair failure."""
    audit_threshold: float
    max_fix_attempts: int
    expressive_markers: List[str]
    cascade_detection: bool = True
    history_matching: bool = True
    history_similarity_threshold: float = 0.85


# ── RTDF scope score mapping ────────────────────────────────────

RTDF_SCOPE_MAP: Dict[str, float] = {
    "projection": 1.0,
    "inclusion": 1.0,
    "dualization": 1.0,
    "tensor": 1.0,
    "homomorphism": 1.0,
    "replacement_continuous": 0.5,
    "replacement_discrete": 0.5,
    "limit": 0.5,
    "gauge": 0.0,
    "deep_isomorphism": 0.0,
    "inductive": 0.0,
}


def rtdf_to_scope_score(rtdf_relationship: str) -> float:
    """Map an RTDF relationship type to a scope score.

    Args:
        rtdf_relationship: One of the 11 RTDF relationship types.

    Returns:
        Scope score ∈ [0.0, 1.0].
    """
    return RTDF_SCOPE_MAP.get(rtdf_relationship, 0.5)


def compute_internal_ratio(
    scope: float,
    depth: float,
    precedent: float,
    weights: Optional[Dict[str, float]] = None,
) -> float:
    """Compute internal_ratio ∈ [0.0, 1.0] from three dimensions.

    Args:
        scope: Scope of repair score.
        depth: Layer depth of origin score.
        precedent: Historical precedent score.
        weights: Optional override weights. Defaults to scope=0.4, depth=0.35, precedent=0.25.

    Returns:
        Clamped internal ratio.
    """
    w = weights or {"scope": 0.4, "depth": 0.35, "precedent": 0.25}
    raw = w["scope"] * scope + w["depth"] * depth + w["precedent"] * precedent
    return max(0.0, min(1.0, raw))


def ratio_to_band(ratio: float) -> str:
    """Map internal_ratio to Band I-V."""
    if ratio >= 0.90:
        return "I"
    elif ratio >= 0.60:
        return "II"
    elif ratio >= 0.40:
        return "III"
    elif ratio >= 0.10:
        return "IV"
    return "V"


def band_to_action(band: str) -> str:
    """Map band to recommended action string."""
    return {
        "I": "FCH_ONLY",
        "II": "FCH_THEN_BDD",
        "III": "FCH_THEN_BDD",
        "IV": "FCH_THEN_BDD",
        "V": "BDD_ONLY",
    }.get(band, "FCH_THEN_BDD")


# ── routing decision log ────────────────────────────────────────

class RoutingDecisionLog:
    """Append-only JSONL log for routing decisions.

    Supports similarity search, filtering, and aggregation for
    post-hoc analysis and precedent scoring.
    """

    def __init__(self, log_path: Optional[Path] = None):
        self.log_path = log_path
        self._entries: List[Dict[str, Any]] = []

    def load(self) -> None:
        """Load entries from JSONL file at ``log_path``."""
        self._entries = []
        if self.log_path is None or not self.log_path.exists():
            return
        with open(self.log_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    self._entries.append(json.loads(line))
                except json.JSONDecodeError:
                    log.warning("Skipping malformed routing log line.")

    def append(self, decision: RoutingDecision) -> None:
        """Append a routing decision to the log."""
        entry = decision.to_dict()
        entry["timestamp"] = _utc_now_iso()
        entry["entry_id"] = f"rdl-{len(self._entries) + 1:05d}"
        self._entries.append(entry)
        if self.log_path:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def find_similar(self, gap: DetectedGap, threshold: float = 0.8) -> List[Dict[str, Any]]:
        """Find past decisions for gaps similar to the given gap.

        Similarity is computed from description token overlap and
        matching RTDF relationship / origin layer.
        """
        results = []
        gap_tokens = set(gap.description.lower().split())
        for entry in self._entries:
            e_gap = entry.get("gap", {})
            e_desc = e_gap.get("description", "")
            e_tokens = set(e_desc.lower().split())
            if not gap_tokens or not e_tokens:
                continue
            inter = gap_tokens & e_tokens
            union = gap_tokens | e_tokens
            sim = len(inter) / len(union) if union else 0.0

            # Boost if same RTDF / origin layer
            if gap.rtdf_relationship and e_gap.get("rtdf_relationship") == gap.rtdf_relationship:
                sim = min(1.0, sim + 0.15)
            if gap.origin_layer and e_gap.get("origin_layer") == gap.origin_layer:
                sim = min(1.0, sim + 0.10)

            if sim >= threshold:
                results.append(entry)
        return results

    def filter(self, **kwargs) -> List[Dict[str, Any]]:
        """Filter log entries by key-value pairs."""
        results = []
        for entry in self._entries:
            match = True
            for key, value in kwargs.items():
                # Support nested access via dot notation
                parts = key.split(".")
                target = entry
                for part in parts:
                    if isinstance(target, dict) and part in target:
                        target = target[part]
                    else:
                        match = False
                        break
                if target != value:
                    match = False
                if not match:
                    break
            if match:
                results.append(entry)
        return results

    def aggregate_by(self, key: str) -> Dict[str, Any]:
        """Aggregate entries by a key, computing success rates."""
        groups: Dict[str, List[Dict[str, Any]]] = {}
        for entry in self._entries:
            val = entry.get(key, "unknown")
            groups.setdefault(val, []).append(entry)

        result = {}
        for val, items in groups.items():
            fch_only = sum(1 for d in items if d.get("final_action") == "FCH_SUCCESS")
            total = len(items)
            result[val] = {
                "total": total,
                "fch_success_rate": fch_only / total if total > 0 else 0.0,
                "bdd_escalation_rate": sum(1 for d in items if d.get("bdd_attempted")) / total if total > 0 else 0.0,
            }
        return result

    def recent(self, n: int = 5) -> List[Dict[str, Any]]:
        """Return the N most recent entries."""
        return self._entries[-n:] if self._entries else []

    def get_rtdf_success_rates(self) -> Dict[str, float]:
        """Return FCH success rate by RTDF relationship type."""
        rates: Dict[str, float] = {}
        rel_types = set()
        for entry in self._entries:
            rel = entry.get("gap", {}).get("rtdf_relationship")
            if rel:
                rel_types.add(rel)

        for rel_type in rel_types:
            decisions = [e for e in self._entries if e.get("gap", {}).get("rtdf_relationship") == rel_type]
            fch_only = sum(1 for d in decisions if d.get("final_action") == "FCH_SUCCESS")
            total = len(decisions)
            rates[rel_type] = fch_only / total if total > 0 else 0.5
        return rates


# ── hybrid router ───────────────────────────────────────────────

class HybridRouter:
    """Routes detected gaps to FCH or BDD based on spectrum classification.

    Supports 5-band classification (I-V), FCH failure criteria with 5 checks,
    and routing decision logging.
    """

    DEFAULT_WEIGHTS = {"scope": 0.4, "depth": 0.35, "precedent": 0.25}

    EXPRESSIVE_MARKERS = [
        "no computational rule",
        "cannot be expressed in",
        "requires additional primitive",
        "independent axiom",
        "no model within",
    ]

    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        decision_log: Optional[RoutingDecisionLog] = None,
    ):
        self.config = config or {}
        self.decision_log = decision_log or RoutingDecisionLog()
        self.failure_criteria = self._build_failure_criteria()

    def route(self, gaps: List[DetectedGap], iteration: int) -> List[RoutingDecision]:
        """Main entry point: classify and route all detected gaps.

        Args:
            gaps: List of detected gaps from verify task.
            iteration: Current UCC iteration number.

        Returns:
            List of RoutingDecision, one per gap.
        """
        decisions = []
        for gap in gaps:
            decision = self._route_single(gap, iteration)
            decisions.append(decision)
        return decisions

    def _route_single(self, gap: DetectedGap, iteration: int) -> RoutingDecision:
        classification = self._classify(gap)

        if classification.band == "I":  # Pure Internal
            fch_result = self._execute_fch_repair(gap, full=True)
            return self._log_decision(
                gap, classification, "FCH_ONLY",
                fch_result=fch_result, bdd_result=None,
            )

        elif classification.band in ("II", "III"):  # Hybrid
            fch_result = self._execute_fch_repair(gap, full=True)
            if self._fch_failed(fch_result):
                bdd_result = self._execute_bdd(gap, fch_artifacts=fch_result.artifacts)
                return self._log_decision(
                    gap, classification, "FCH_THEN_BDD",
                    fch_result=fch_result, bdd_result=bdd_result,
                )
            return self._log_decision(
                gap, classification, "FCH_ONLY",
                fch_result=fch_result, bdd_result=None,
            )

        elif classification.band == "IV":  # Hybrid External-preferred
            fch_result = self._execute_fch_repair(gap, full=False)  # Lightweight
            criteria = self._build_failure_criteria(relaxed=True)
            if self._fch_failed(fch_result, criteria=criteria):
                bdd_result = self._execute_bdd(gap, fch_artifacts=fch_result.artifacts)
                return self._log_decision(
                    gap, classification, "FCH_THEN_BDD",
                    fch_result=fch_result, bdd_result=bdd_result,
                )
            return self._log_decision(
                gap, classification, "FCH_ONLY",
                fch_result=fch_result, bdd_result=None,
            )

        elif classification.band == "V":  # Pure External
            bdd_result = self._execute_bdd(gap, fch_artifacts=None)
            return self._log_decision(
                gap, classification, "BDD_ONLY",
                fch_result=None, bdd_result=bdd_result,
            )

        else:
            raise ValueError(f"Unknown band: {classification.band}")

    def _classify(self, gap: DetectedGap) -> Classification:
        """Compute dimensions and internal ratio for a gap."""
        scope = self._score_scope(gap)
        depth = self._score_depth(gap)
        precedent = self._score_precedent(gap)

        internal_ratio = compute_internal_ratio(
            scope, depth, precedent, self.config.get("weights", self.DEFAULT_WEIGHTS)
        )
        band = ratio_to_band(internal_ratio)

        return Classification(
            gap_id=gap.id,
            dimensions=Dimensions(scope=scope, depth=depth, precedent=precedent),
            internal_ratio=internal_ratio,
            band=band,
            recommended_action=band_to_action(band),
        )

    def _score_scope(self, gap: DetectedGap) -> float:
        """Score based on where repair must happen."""
        if gap.repair_type == "layer_tension":
            return 1.0
        elif gap.repair_type == "primitive_extension":
            return 0.5
        elif gap.repair_type == "framework_replacement":
            return 0.0
        else:
            rtdf_type = gap.rtdf_relationship or "unknown"
            return rtdf_to_scope_score(rtdf_type)

    def _score_depth(self, gap: DetectedGap) -> float:
        """Score based on where the gap manifests."""
        origin = gap.origin_layer or "unknown"
        if origin in ("d1_d2", "d2_d3", "d3_d4", "d1_d3", "cross_layer"):
            return 1.0
        elif origin == "d4_boundary":
            return 0.5
        elif origin in ("external_comparison", "framework_limit"):
            return 0.0
        return 0.5

    def _score_precedent(self, gap: DetectedGap) -> float:
        """Score based on historical precedent from routing decision log."""
        similar_past = self.decision_log.find_similar(gap, threshold=0.8)
        if not similar_past:
            return 0.5
        fch_success_rate = sum(
            1 for d in similar_past if d.get("final_action") == "FCH_SUCCESS"
        ) / len(similar_past)
        if fch_success_rate >= 0.7:
            return 1.0
        elif fch_success_rate >= 0.3:
            return 0.5
        return 0.0

    def _fch_failed(
        self,
        fch_result: FCHResult,
        criteria: Optional[FailureCriteria] = None,
    ) -> bool:
        """Determine if FCH repair has failed and BDD escalation is needed.

        Checks 5 failure criteria in order:
        1. FAIL_AUDIT — audit score below threshold
        2. FAIL_ITERATIONS — max fix attempts exhausted
        3. FAIL_EXPRESSIVE — expressive gap markers in description
        4. FAIL_CASCADE — new gaps introduced by fix
        5. FAIL_HISTORY — similar gaps historically required BDD
        """
        crit = criteria or self.failure_criteria

        # Check 1: Audit score
        if fch_result.audit_score < crit.audit_threshold:
            return True

        # Check 2: Fix iteration exhaustion
        if fch_result.fix_attempt_count >= crit.max_fix_attempts:
            return True

        # Check 3: Expressive gap detection
        gap_text = fch_result.gap.description.lower()
        for marker in crit.expressive_markers:
            if marker.lower() in gap_text:
                return True

        # Check 4: Cascade detection
        if crit.cascade_detection and fch_result.new_gaps_introduced > 0:
            return True

        # Check 5: Historical pattern match
        if crit.history_matching:
            similar = self.decision_log.find_similar(
                fch_result.gap, threshold=crit.history_similarity_threshold
            )
            bdd_required_rate = (
                sum(1 for d in similar if "BDD" in d.get("final_action", ""))
                / max(len(similar), 1)
            )
            if bdd_required_rate >= 0.8 and len(similar) >= 2:
                return True

        return False

    def _execute_fch_repair(self, gap: DetectedGap, full: bool = True) -> FCHResult:
        """Execute FCH repair for a gap. Phase 1: stubbed."""
        # Phase 1: return a plausible stub result
        return FCHResult(
            audit_score=0.80,
            fix_attempt_count=1 if full else 1,
            new_gaps_introduced=0,
            gap=gap,
            artifacts={"repair_notes": f"FCH repair stub for {gap.id}"},
        )

    def _execute_bdd(self, gap: DetectedGap, fch_artifacts: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute BDD for a gap. Phase 1: stubbed."""
        return {
            "bdd_confidence": 0.85,
            "concepts_emerged": ["placeholder_concept"],
            "new_gaps": [],
            "fch_artifacts": fch_artifacts,
        }

    def _log_decision(
        self,
        gap: DetectedGap,
        classification: Classification,
        initial_action: str,
        fch_result: Optional[FCHResult],
        bdd_result: Optional[Dict[str, Any]],
    ) -> RoutingDecision:
        """Build and log a routing decision."""
        human_review = classification.band == "III"
        fch_failed = fch_result is not None and self._fch_failed(fch_result)

        decision = RoutingDecision(
            gap=gap,
            classification=classification,
            initial_action=initial_action,
            fch_attempted=fch_result is not None,
            fch_iterations=fch_result.fix_attempt_count if fch_result else 0,
            fch_audit_scores=[fch_result.audit_score] if fch_result else [],
            fch_failed=fch_failed,
            failure_criterion_triggered="NONE" if not fch_failed else "FAIL_AUDIT",
            bdd_attempted=bdd_result is not None,
            bdd_confidence=bdd_result.get("bdd_confidence") if bdd_result else None,
            final_action=(
                "FCH_SUCCESS" if fch_result and not fch_failed
                else "FCH_THEN_BDD_SUCCESS" if bdd_result
                else "BDD_SUCCESS" if bdd_result and not fch_result
                else "REJECTED"
            ),
            concepts_emerged=bdd_result.get("concepts_emerged", []) if bdd_result else [],
            new_gaps_introduced=bdd_result.get("new_gaps", []) if bdd_result else [],
            human_review_flag=human_review,
        )
        self.decision_log.append(decision)
        return decision

    def _build_failure_criteria(self, relaxed: bool = False) -> FailureCriteria:
        """Build failure criteria from config, optionally relaxed for lightweight repair."""
        cfg = self.config.get("failure_criteria", {})
        markers = cfg.get("expressive_markers", self.EXPRESSIVE_MARKERS)
        if relaxed:
            return FailureCriteria(
                audit_threshold=cfg.get("lightweight_audit_threshold", 0.75),
                max_fix_attempts=cfg.get("lightweight_max_fix_attempts", 1),
                expressive_markers=markers,
                cascade_detection=cfg.get("cascade_detection", True),
                history_matching=cfg.get("history_matching", True),
                history_similarity_threshold=cfg.get("history_similarity_threshold", 0.85),
            )
        return FailureCriteria(
            audit_threshold=cfg.get("audit_threshold", 0.90),
            max_fix_attempts=cfg.get("max_fix_attempts", 3),
            expressive_markers=markers,
            cascade_detection=cfg.get("cascade_detection", True),
            history_matching=cfg.get("history_matching", True),
            history_similarity_threshold=cfg.get("history_similarity_threshold", 0.85),
        )


# ── utility ───────────────────────────────────────────────────────

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ── CLI entry point ──────────────────────────────────────────────

def _main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="FCH v3.3 Routing Classifier")
    parser.add_argument("--classify", type=str, help="Gap description to classify")
    parser.add_argument("--gap-id", type=str, default="gap-test-001", help="Gap ID")
    parser.add_argument("--log", type=str, default="routing_decision_log.jsonl", help="Log path")
    args = parser.parse_args()

    if args.classify:
        router = HybridRouter(decision_log=RoutingDecisionLog(Path(args.log)))
        gap = DetectedGap(
            id=args.gap_id,
            description=args.classify,
            repair_type="unknown",
            origin_layer="d4_boundary",
        )
        decisions = router.route([gap], iteration=1)
        for d in decisions:
            print(json.dumps(d.to_dict(), indent=2, ensure_ascii=False))
    else:
        parser.print_help()


if __name__ == "__main__":
    _main()

__all__ = [
    "HybridRouter",
    "RoutingDecisionLog",
    "DetectedGap",
    "Classification",
    "Dimensions",
    "RoutingDecision",
    "FCHResult",
    "FailureCriteria",
    "compute_internal_ratio",
    "ratio_to_band",
    "band_to_action",
    "rtdf_to_scope_score",
    "RTDF_SCOPE_MAP",
]
