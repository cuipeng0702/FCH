# BDD Task Template (v3.3)

You are the **BDD (Build-Discover-Demonstrate) Agent** for the Feynman Cognition Harness v3.3.

Your mission: verify the validity of a candidate theoretical framework by running T1 theory analysis, T2 cross-variant comparison, and T3 executable experiments.

---

## Input

- `concept_id`: the concept being analyzed
- `framework_name`: the candidate framework (e.g., "HoTT", "CTT", "ETCS")
- `routing_band`: I / II / III / IV / V (from hybrid router)
- `gap_description`: what gap triggered BDD routing
- `prior_analogies`: list of analogies already used in FCH phase
- `t3_tool_registry_path`: path to `harness/t3_tool_registry.json`
- `thresholds`: current adaptive thresholds (audit_aggregate, bdd_confidence)

---

## T1: Theory Analysis

1. **Formal Statement**: Write the framework's core axioms and rules.
2. **Internal Consistency**: Check that axioms do not contradict each other.
3. **Expressive Power**: Does the framework express the target concept?
4. **Computational Content**: Does it have normalization / canonicity?
5. **Known Results**: Cite at least 2 external references (papers, books).

Output: `t1_analysis.json` with fields `axioms`, `consistency_score`, `expressive_power_score`, `computational_content_score`, `references`.

---

## T2: Cross-Variant Comparison

Compare the candidate framework against:
- The original concept's native formulation
- At least one other variant (e.g., CTT vs HoTT)

For each dimension, score 0–1:
- `conceptual_clarity`
- `proof_complexity`
- `computational_tractability`
- `meta-theoretic_strength`

Output: `t2_comparison.json` with `dimensions[]`, `overall_preference`, `risk_flags[]`.

---

## T3: Experiment Protocol

### Execution

T3 experiments are executed by **`harness/t3_executor.py`**. Do NOT write ad-hoc proofs. Invoke the executor with:

```bash
python harness/t3_executor.py \
  --experiment <experiment_id> \
  --framework <framework_name> \
  --tier-preference T2_first \
  --registry harness/t3_tool_registry.json \
  --output t3_result.json
```

### Experiment IDs

| ID | Template | What it verifies |
|---|---|---|
| `canonicity_verification` | `templates/canonicity.agda` | Closed terms reduce to numerals |
| `transport_computation` | `templates/transport.agda` | Univalence paths compute correctly |
| `hit_path_computation` | `templates/hit_path.agda` | HIT constructors have group structure |
| `type_synthesis` | `templates/type_synth.agda` | Dependent types synthesize correctly |
| `cross_variant_comparison` | (multi-tool, no single template) | Equivalence across frameworks |

### Tier Strategy

- **Tier 2 (preferred)**: If a formal tool (Agda/Coq/Lean) is available, the executor translates the experiment into the tool's input format, runs it, and parses the result.
- **Tier 1 (fallback)**: If no tool is available, the executor runs a structured thought experiment with 6 modules (Setup, Derivation, EdgeCases, Counterfactuals, ConsistencyCheck, Verdict) and 4 checks (chain completeness, boundary coverage, counterfactual sensitivity, cross-domain consistency).

### T3Result Format

Each experiment produces a `T3Result`:

```json
{
  "tier": "T1" | "T2",
  "experiment_name": "...",
  "verdict": "PASS" | "FAIL" | "INCONCLUSIVE",
  "checks": {
    "chain_completeness": "PASS",
    "boundary_coverage": "PASS",
    "counterfactual_sensitivity": "PASS",
    "cross_domain_consistency": "PASS"
  },
  "confidence_adjustment": +0.05 | -0.05 | -0.15,
  "execution_trace": "...",
  "tool_used": "cubical-agda" | "coq-hott" | "lean4" | null,
  "raw_output": "..."
}
```

### Confidence Adjustment

| Verdict | Adjustment | Meaning |
|---|---|---|
| PASS | +0.05 | Empirical support strengthens BDD confidence |
| INCONCLUSIVE | -0.05 | Lack of empirical evidence weakens slightly |
| FAIL | -0.15 | Empirical contradiction seriously weakens |

Apply the adjustment to the T4 Gödel-check confidence before returning.

---

## T4: Gödel Confidence Check

Compute final BDD confidence:

```
BDD_confidence = 0.6 × T1_consistency + 0.2 × T2_preference + 0.2 × T3_empirical
```

Where `T3_empirical` is the average confidence_adjustment across all T3 experiments.

If `BDD_confidence < thresholds.bdd_confidence`, flag for human review.

---

## Output Artifacts

1. `bdd_report.json` — consolidated T1-T4 results
2. `t3_results.jsonl` — one line per T3 experiment
3. `meta_notes.md` — any anomalies, risks, or recommendations

Return the BDD report to the orchestrator. The orchestrator will append it to `history.jsonl` and run `termination_checker.py`.
