# Audit Agent Task Template

## Objective
Independently audit D1–D4 explanations for internal consistency, coverage against PRD §3 requirements, and identification of knowledge gaps. This agent must be adversarial: assume the explanations are flawed until proven otherwise.

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "teach_output_path": "string (path to teach_output.json)",
  "concept": "string",
  "concept_id": "string",
  "iteration": 1,
  "previous_audit": {
    "iteration": 1,
    "valid": true,
    "issues": []
  }
}
```

Notes:
- Load the actual `teach_output.json` from `teach_output_path` to perform the audit.
- `previous_audit` may be `null` on first audit.

## Output

Write to: `{output_path}`

Format: JSON with schema (see PRD.md §7.2):
```json
{
  "iteration": 1,
  "timestamp": "ISO-8601 string",
  "valid": true,
  "issues": [
    {
      "layer": "d1|d2|d3|d4",
      "severity": "minor|major|critical",
      "description": "string"
    }
  ],
  "summary": "string",
  "metadata": {
    "issues_by_layer": {"d1": 0, "d2": 0, "d3": 0, "d4": 0},
    "critical_count": 0,
    "major_count": 0,
    "minor_count": 0
  }
}
```

## Adaptive Threshold Context (v3.3)

The current adaptive threshold for aggregate audit score is: **{{ADAPTIVE_THRESHOLD}}**.

- Confidence interval: [{{CI_LOW}}, {{CI_HIGH}}]
- Sample size: {{SAMPLE_SIZE}}
- If SAMPLE_SIZE < 5, this is a cold-start default. Use judgment; do not treat the threshold as statistically validated yet.

## Audit Checklist (PRD §3 + §4 Cross-Reference)

### D1 Audit Items
- [ ] Is there exactly one vivid analogy? (not multiple mixed analogies)
- [ ] Is there zero jargon? (no technical terms without immediate plain-English translation)
- [ ] Are all nouns tactile or visual? (can an 8-year-old picture it?)
- [ ] Is length ≤150 words?
- [ ] Does the analogy actually map to the concept structure, or is it only superficially similar?
- [ ] **(v3.3 conditional)** If `analogy_matrix_path` was provided: Was analogy selected from the matrix? Does `analogy_id` match `learner_profile.domain_background`?
- [ ] **(v3.3 conditional)** If cross-domain analogy used: Is migration_score ≥ 0.65? Are breakage_indicators checked and documented?
- [ ] **(v3.3 conditional)** If `reframe_triggered == true`: Does the new analogy avoid the `prior_breakage_reason`? Is `prior_analogy_id` excluded from reuse?

### D2 Audit Items
- [ ] Are there ≥3 and ≤10 numbered steps?
- [ ] Is each step executable by a human without external clarification?
- [ ] Is there a success criteria sentence at the end?
- [ ] Are steps ordered logically (no step depends on a later step)?
- [ ] Do the steps actually demonstrate/apply the concept (not generic procedure)?

### D3 Audit Items
- [ ] Does it cite domain-standard terminology?
- [ ] If mathematical: is there a core equation or formal statement?
- [ ] If non-mathematical: is there a definitional sentence + boundary conditions?
- [ ] Is every formal claim marked with confidence (high/medium/low)?
- [ ] Is the definition precise enough to distinguish the concept from near-neighbors?

### D4 Audit Items
- [ ] Are there ≥3 boundary conditions?
- [ ] Does each boundary have a concrete counter-example?
- [ ] Does each boundary explain the failure mechanism (why it breaks, not just that it breaks)?
- [ ] Are the counter-examples genuinely outside the concept's scope (not edge cases within scope)?

### Cross-Layer Consistency Audit Items
- [ ] Does D1 analogy contradict D3 formal definition?
- [ ] Does D2 procedure align with D3 definition?
- [ ] Do D4 boundaries invalidate any claim in D1–D3?
- [ ] If D3 marks a claim as `low` confidence, is that claim avoided or qualified in D1/D2?

## Available Tools

- **kimi_search**: for cross-checking terminology or verifying definitions against external sources
- **kimi_fetch**: for reading authoritative pages to validate formal claims
- **LLM via localhost:18790**: for reasoning through consistency checks

## Severity Definitions

| Severity | Definition | Action Required |
|----------|------------|-----------------|
| **critical** | Violates a hard PRD requirement (e.g., D1 >150 words, D2 <3 steps, D4 <3 boundaries). Output is invalid. | Orchestrator must trigger fix or reject |
| **major** | Significant quality flaw that undermines understanding (e.g., analogy doesn't map, procedure is ambiguous, counter-example is inside scope). | Orchestrator should trigger fix |
| **minor** | Cosmetic or clarity issue (e.g., typo, wording could be sharper, confidence label missing on one sub-claim). | Orchestrator may accept with note |

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. All required keys present — `iteration`, `timestamp`, `valid`, `issues`, `summary`, `metadata`
4. Top-level `timestamp` key exists and is ISO-8601 formatted
5. `valid` is boolean
6. If `valid == true`, then `issues` array must be empty or contain only `minor` severity items
7. If `valid == false`, then `issues` array must contain at least one `major` or `critical` item
8. Every issue has `layer` ∈ {d1, d2, d3, d4}, `severity` ∈ {minor, major, critical}, and non-empty `description`
9. `metadata.issues_by_layer` counts sum to `len(issues)`
10. `metadata.critical_count` + `metadata.major_count` + `metadata.minor_count` == `len(issues)`
11. `summary` is non-empty string (≥20 words)

## Failure Protocol

If the input `teach_output.json` is missing or unreadable:
1. Write output with `valid: false`
2. Add one critical issue: `{"layer": "d1", "severity": "critical", "description": "Input file missing or unreadable at {teach_output_path}"}`
3. Set `summary` to explain the file access failure

## Orchestrator Integration

After writing output, announce completion with:
```
DONE: {output_path}
Concept: {concept_id}
Iteration: {iteration}
Audit valid: {true|false}
Issues: {critical_count} critical, {major_count} major, {minor_count} minor
```
