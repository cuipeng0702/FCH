module TypeSynth where

-- FCH v3.3 Template: Type Synthesis / Type Checking
-- Purpose: Verify that a given term can be assigned a specific type
-- in a dependent type theory with Σ-types, Π-types, and identity types.
-- This is the generic template; tool-specific variants exist for
-- Agda, Coq, and Lean.

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma

-- ── Experiment Setup ──────────────────────────────────────
-- Given a context Γ and a term t, synthesize (or check) its type.
--
-- Experiment-specific parameters:
--   EXPERIMENT_CONCEPT_ID  : string
--   EXPERIMENT_FRAMEWORK   : string
--   CONTEXT                : list of (variable : Type) bindings
--   TERM                   : the term to synthesize
--   EXPECTED_TYPE          : the expected type (for checking mode)

-- ── Generic Type Synthesis Predicate ──────────────────────
-- We postulate a synthesis relation Γ ⊢ t ⇒ A.

postulate
  Context : Type
  Term    : Type
  TypeOf  : Type
  _⊢_⇒_  : Context → Term → TypeOf → Type

-- ── Example: Synthesize the type of (λ x → x) ─────────────
-- In context (A : Type), synthesize the type of the identity function.

postulate
  A : Type
  idTerm : Term

idType : TypeOf
idType = postulate "A → A"

idSynth : (Γ : Context) → Γ ⊢ idTerm ⇒ idType
idSynth Γ = postulate "synthesis_proof"

-- ── Example: Check a dependent pair ──────────────────────
-- Synthesize the type of (a , b) where a : A and b : B(a).

postulate
  aTerm bTerm pairTerm : Term
  B : A → Type

pairType : TypeOf
pairType = postulate "Σ A B"

pairSynth : (Γ : Context) → Γ ⊢ pairTerm ⇒ pairType
pairSynth Γ = postulate "synthesis_proof"

-- ── Verification Notes ─────────────────────────────────
-- This template verifies:
--   1. The framework's type synthesis algorithm is sound.
--   2. Dependent types (Π, Σ, Id) are handled correctly.
--   3. Context management (variable binding, substitution) works.
--
-- Tool-specific instructions:
--   • Agda:   Use C-c C-d (infer type) or C-c C-: (check type).
--   • Coq:    Use `Check t` or `Definition foo : T := t.`
--   • Lean:   Use `#check t` or `def foo : T := t`.
--
-- To complete the experiment:
--   • Replace postulates with concrete terms.
--   • Run the appropriate tool command.
