module HITPath where

-- FCH v3.3 Template: Higher Inductive Type (HIT) Path Computation
-- Purpose: Compute the behavior of the path constructor loop : base ≡ base
-- in the circle S¹, and verify that iterated applications match
-- the group structure of the integers (π₁(S¹) ≅ ℤ).

open import Cubical.Foundations.Prelude
open import Cubical.Foundations.Isomorphism
open import Cubical.HITs.S1
open import Cubical.Data.Int

-- ── Experiment Setup ──────────────────────────────────────
-- S¹ is the HIT with:
--   • base : S¹
--   • loop : base ≡ base
--
-- Experiment-specific parameters:
--   EXPERIMENT_CONCEPT_ID  : string
--   EXPERIMENT_FRAMEWORK   : string

-- ── Path Computation: winding number ────────────────────────
-- The winding number of a path p : base ≡ base is the integer
-- obtained by iterating loop or its inverse.

winding : base ≡ base → Int
winding p = windingNumber p

-- ── Boundary 1: zero winding (identity path) ───────────────
-- The constant path at base should wind 0 times.

zeroWinding : winding refl ≡ pos 0
zeroWinding = refl

-- ── Boundary 2: positive winding (loop) ──────────────────
-- loop : base ≡ base should wind +1.

loopWinding : winding loop ≡ pos 1
loopWinding = refl

-- ── Boundary 3: negative winding (sym loop) ──────────────
-- sym loop : base ≡ base should wind -1.

negLoopWinding : winding (sym loop) ≡ negsuc 0
negLoopWinding = refl

-- ── Iterated Path Computation ────────────────────────────
-- loopⁿ should wind n times for any integer n.

iteratedLoop : (n : Int) → winding (loopTimes n) ≡ n
iteratedLoop (pos zero)    = refl
iteratedLoop (pos (suc n)) = cong sucInt (iteratedLoop (pos n))
iteratedLoop (negsuc zero)  = refl
iteratedLoop (negsuc (suc n)) =
  cong predInt (iteratedLoop (negsuc n))

-- Helper: loop iterated n times
loopTimes : Int → base ≡ base
loopTimes (pos zero)       = refl
loopTimes (pos (suc n))    = loopTimes (pos n) ∙ loop
loopTimes (negsuc zero)    = sym loop
loopTimes (negsuc (suc n)) = loopTimes (negsuc n) ∙ sym loop

-- ── Verification Notes ─────────────────────────────────
-- This template verifies:
--   1. HIT path constructors have concrete computational behavior.
--   2. The fundamental group of S¹ is isomorphic to the integers.
--   3. Iterated applications of loop match the group operation.
--
-- To complete the experiment:
--   • Replace loopTimes with the framework's native iteration
--     primitive if available.
--   • Run: agda --cubical HITPath.agda
