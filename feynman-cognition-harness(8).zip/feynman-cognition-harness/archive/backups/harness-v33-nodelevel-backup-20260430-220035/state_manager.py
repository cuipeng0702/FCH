"""StateManager — atomic file-system I/O for FCH harness state.

All reads/writes are JSON-based. Writes are atomic (temp file + rename).
"""

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class StateManager:
    """Manages state.json, progress.json, and budget.json with atomic writes."""

    def __init__(self, harness_dir: str):
        self.harness_dir = Path(harness_dir)
        self.state_path = self.harness_dir / "state.json"
        self.progress_path = self.harness_dir / "progress.json"
        self.budget_path = self.harness_dir / "budget.json"
        # v3.3: new persistence paths (inactive when modules disabled)
        self.history_path = self.harness_dir / "history.jsonl"
        self.thresholds_path = self.harness_dir / "thresholds.json"
        self.routing_log_path = self.harness_dir / "routing_decision_log.jsonl"
        self.analogy_dir = self.harness_dir / "analogy_matrix"
        self.analogy_dir.mkdir(parents=True, exist_ok=True)

    # ── generic helpers ──────────────────────────────────────────────

    @staticmethod
    def _atomic_write(path: Path, data: dict) -> None:
        """Write JSON atomically via a temp file."""
        tmp = tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".json",
            prefix="tmp_",
            dir=str(path.parent),
            delete=False,
        )
        try:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, path)

    @staticmethod
    def _load_json(path: Path, default: dict) -> dict:
        """Load JSON from path; return default if missing or corrupt."""
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default

    # ── state.json ───────────────────────────────────────────────────

    def load_state(self) -> dict:
        """Load runtime state: concepts, confidence, contradictions, gaps."""
        default = {
            "current_concept": None,
            "concept_history": [],
            "confidence": {},
            "contradictions": [],
            "pending_fixes": [],
            "strategy_adjustments": [],
            "last_updated": self._now(),
        }
        return self._load_json(self.state_path, default)

    def save_state(self, state: dict) -> None:
        """Persist runtime state with fresh timestamp."""
        state["last_updated"] = self._now()
        self._atomic_write(self.state_path, state)

    # ── progress.json ────────────────────────────────────────────────

    def load_progress(self) -> dict:
        """Load execution progress: current iteration, completed steps, todo."""
        default = {
            "current_iteration": 1,
            "completed_steps": [],
            "next_step": "teach",
            "last_agent_spawned": None,
            "last_task_completed": None,
        }
        return self._load_json(self.progress_path, default)

    def save_progress(self, progress: dict) -> None:
        """Persist execution progress."""
        self._atomic_write(self.progress_path, progress)

    # ── budget.json ──────────────────────────────────────────────────

    def load_budget(self) -> dict:
        """Load spawn budget: remaining quota and used count."""
        default = {
            "max_spawn": 50,
            "remaining": 50,
            "used": 0,
        }
        return self._load_json(self.budget_path, default)

    def save_budget(self, budget: dict) -> None:
        """Persist budget counters."""
        self._atomic_write(self.budget_path, budget)

    # ── task queue ───────────────────────────────────────────────────

    CHECKLIST = ["teach", "audit", "grow", "verify", "consolidate"]

    def get_next_task(self, progress: dict) -> str | None:
        """Return the next uncompleted step for the current iteration.

        Returns None when all steps in the current iteration are done.
        """
        completed = set(progress.get("completed_steps", []))
        for step in self.CHECKLIST:
            if step not in completed:
                return step
        return None

    def mark_task_done(self, progress: dict, task: str) -> dict:
        """Mark a step as completed and update next_step."""
        completed = set(progress.get("completed_steps", []))
        completed.add(task)
        progress["completed_steps"] = sorted(completed, key=self.CHECKLIST.index)
        next_task = self.get_next_task(progress)
        progress["next_step"] = next_task
        progress["last_task_completed"] = self._now()
        return progress

    # ── exceptions ───────────────────────────────────────────────────

    def record_exception(self, iteration: int, exc: dict) -> None:
        """Append an exception record to the iteration's exceptions.json."""
        exc_dir = self.harness_dir / "results" / f"iteration_{iteration}"
        exc_dir.mkdir(parents=True, exist_ok=True)
        exc_path = exc_dir / "exceptions.json"
        data = self._load_json(exc_path, {"records": []})
        record = {
            "time": self._now(),
            **exc,
        }
        data["records"].append(record)
        self._atomic_write(exc_path, data)

    def get_recent_exceptions(self, iteration: int, limit: int = 3) -> list:
        """Return the last `limit` exception records for an iteration."""
        exc_path = self.harness_dir / "results" / f"iteration_{iteration}" / "exceptions.json"
        data = self._load_json(exc_path, {"records": []})
        return data["records"][-limit:]

    # ── v3.3 history persistence (inactive when modules disabled) ──

    def append_history_record(self, record: dict) -> None:
        """Atomic append to history.jsonl."""
        line = json.dumps(record, ensure_ascii=False) + "\n"
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".jsonl", prefix="tmp_",
            dir=str(self.history_path.parent), delete=False,
        )
        try:
            if self.history_path.exists():
                with open(self.history_path, "r", encoding="utf-8") as f:
                    tmp.write(f.read())
            tmp.write(line)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, self.history_path)

    def load_history(self) -> list[dict]:
        """Read all valid JSON lines from history.jsonl; skip corrupt."""
        if not self.history_path.exists():
            return []
        records = []
        with open(self.history_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    # ── v3.3 threshold persistence (inactive when modules disabled) ──

    def save_thresholds(self, thresholds: dict) -> None:
        """Atomic write to thresholds.json."""
        self._atomic_write(self.thresholds_path, thresholds)

    def load_thresholds(self) -> dict:
        """Load thresholds.json; return cold-start defaults if missing."""
        default = {
            "audit_aggregate": {
                "point_estimate": 0.85,
                "ci_low": 0.80,
                "ci_high": 0.90,
                "sample_size": 0,
            },
            "bdd_confidence": {
                "point_estimate": 0.75,
                "ci_low": 0.70,
                "ci_high": 0.80,
                "sample_size": 0,
            },
        }
        return self._load_json(self.thresholds_path, default)

    # ── v3.3 routing log (inactive when modules disabled) ────────────

    def append_routing_decision(self, decision: dict) -> None:
        """Atomic append to routing_decision_log.jsonl."""
        line = json.dumps(decision, ensure_ascii=False) + "\n"
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".jsonl", prefix="tmp_",
            dir=str(self.routing_log_path.parent), delete=False,
        )
        try:
            if self.routing_log_path.exists():
                with open(self.routing_log_path, "r", encoding="utf-8") as f:
                    tmp.write(f.read())
            tmp.write(line)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, self.routing_log_path)

    def load_routing_log(self) -> list[dict]:
        """Read all valid JSON lines from routing_decision_log.jsonl."""
        if not self.routing_log_path.exists():
            return []
        records = []
        with open(self.routing_log_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    # ── v3.3 analogy matrix persistence (inactive when modules disabled) ──

    def save_analogy_matrix(self, concept_id: str, matrix: dict) -> None:
        """Write analogy matrix JSON for a concept."""
        path = self.analogy_dir / f"{concept_id}_analogy_matrix.json"
        self._atomic_write(path, matrix)

    def load_analogy_matrix(self, concept_id: str) -> dict:
        """Load analogy matrix JSON for a concept; return empty dict if missing."""
        path = self.analogy_dir / f"{concept_id}_analogy_matrix.json"
        return self._load_json(path, {})

    # ── v3.3 BDD extraction helpers (inactive when modules disabled) ──

    def extract_bdd_history(self, state: dict) -> list[dict]:
        """Extract BDD-relevant records from history for termination checker."""
        history = self.load_history()
        return [
            rec for rec in history
            if rec.get("task") == "bdd" or rec.get("routed_to") == "bdd"
        ]

    def extract_current_bdd_state(self, iteration: int) -> dict:
        """Build current BDD state snapshot for termination checker."""
        bdd_output_path = (
            self.harness_dir / "results" / f"iteration_{iteration}" / "bdd_output.json"
        )
        bdd_data = self._load_json(bdd_output_path, {})
        return {
            "iteration": iteration,
            "timestamp": self._now(),
            "bdd_output_exists": bdd_output_path.exists(),
            "confidence": bdd_data.get("confidence", {}),
            "gaps_addressed": bdd_data.get("gaps_addressed", []),
        }

    # ── utility ──────────────────────────────────────────────────────

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()
