#!/usr/bin/env python3
"""
Termination Checker — FCH v3.3
Termination judgment mechanism with 4 conditions and meta-cognitive triage.

Prevents Zeno-effect infinite expansion by detecting:
1. Diminishing returns (confidence decay)
2. Cyclic boundaries (isomorphic boundary rediscovery)
3. Cumulative risk (3 consecutive 🟡 judgments)
4. Depth budget exhaustion (user-defined hard stop)

Produces structured meta-cognitive summary on stop: what we know, what we
don't know, what's not worth pursuing, and partial result assessment.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("fch.termination")


# ── data structures ─────────────────────────────────────────────

@dataclass
class TerminationDecision:
    """Unified termination decision from the evaluator."""
    terminate: bool
    decision: str  # "CONTINUE", "YIELD", "HALT"
    primary_reason: str
    triggering_condition: Optional[str] = None
    all_results: List[Dict[str, Any]] = field(default_factory=list)
    severity: str = "info"
    meta_summary: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "terminate": self.terminate,
            "decision": self.decision,
            "primary_reason": self.primary_reason,
            "triggering_condition": self.triggering_condition,
            "all_results": self.all_results,
            "severity": self.severity,
            "meta_summary": self.meta_summary,
        }


# ── base condition class ────────────────────────────────────────

class TerminationCondition:
    """Base class for termination conditions."""

    def check(self, state: Dict[str, Any], history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Evaluate this condition against current state and history.

        Args:
            state: Current iteration's BDD/FCH output state.
            history: Prior iteration outputs, ordered by iteration.

        Returns:
            Dict with keys: ``triggered`` (bool), ``reason`` (str),
            ``severity`` (str), and optional ``metrics`` (dict).
        """
        raise NotImplementedError


# ── condition 1: diminishing returns ──────────────────────────────

class DiminishingReturnsCondition(TerminationCondition):
    """Condition 1: New framework confidence < old framework confidence * alpha."""

    def __init__(self, alpha: float = 0.90):
        self.alpha = alpha

    def check(self, state: Dict[str, Any], history: List[Dict[str, Any]]) -> Dict[str, Any]:
        if len(history) < 1:
            return {"triggered": False, "reason": "No prior BDD to compare", "severity": "info"}

        current_confidence = state.get("confidence", 0.0)
        prior_framework = history[-1]
        prior_confidence = prior_framework.get("confidence", 0.0)

        if prior_confidence <= 0:
            return {"triggered": False, "reason": "Prior confidence is zero/undefined", "severity": "warning"}

        threshold = prior_confidence * self.alpha

        if current_confidence < threshold:
            return {
                "triggered": True,
                "reason": (
                    f"Diminishing returns: new framework confidence ({current_confidence:.3f}) "
                    f"is below threshold ({threshold:.3f} = {prior_confidence:.3f} × {self.alpha}). "
                    f"Further framework transitions are unlikely to improve resolution."
                ),
                "severity": "moderate",
                "metrics": {
                    "current_confidence": current_confidence,
                    "prior_confidence": prior_confidence,
                    "threshold": threshold,
                    "alpha": self.alpha,
                },
            }

        return {"triggered": False, "reason": "Confidence is acceptable", "severity": "info"}


# ── condition 2: cyclic boundary detection ──────────────────────

class CyclicBoundaryCondition(TerminationCondition):
    """Condition 2: New boundary is isomorphic to a previously encountered boundary."""

    _DEFAULT_REPLACEMENTS = {
        "univalence": "axiom_X",
        "mltt": "framework_Y",
        "cubical": "framework_Z",
        "hott": "framework_W",
        "n-cube": "dimension_n_structure",
        "exponential": "exponential",
        "combinatorial explosion": "exponential",
        "high-dimensional": "high_dimension",
        "girard": "paradox_type_A",
        "type : type": "self_reference_level_L",
        "canonicity": "computational_property_P",
        "transport": "structural_operation_O",
    }

    def __init__(self, similarity_threshold: float = 0.85):
        self.similarity_threshold = similarity_threshold

    def check(self, state: Dict[str, Any], history: List[Dict[str, Any]]) -> Dict[str, Any]:
        current_boundaries = state.get("new_boundaries", [])
        current_encoded = [self._encode_boundary(b) for b in current_boundaries]

        for prior_state in reversed(history):
            prior_boundaries = prior_state.get("new_boundaries", [])
            if not prior_boundaries:
                continue

            prior_encoded = [self._encode_boundary(b) for b in prior_boundaries]
            similarity = self._set_similarity(current_encoded, prior_encoded)

            if similarity >= self.similarity_threshold:
                return {
                    "triggered": True,
                    "reason": (
                        f"Cyclic boundary detected: current boundary set is {similarity:.2f} "
                        f"similar to boundaries from a prior iteration. "
                        f"The system is rediscovering structurally equivalent constraints "
                        f"under different conceptual labels. Further expansion will not "
                        f"produce novel epistemic value."
                    ),
                    "severity": "high",
                    "metrics": {
                        "similarity": similarity,
                        "threshold": self.similarity_threshold,
                        "matched_boundaries": len(prior_boundaries),
                        "current_boundaries": len(current_boundaries),
                    },
                }

        return {"triggered": False, "reason": "No cyclic boundaries detected", "severity": "info"}

    def _encode_boundary(self, boundary: Dict[str, Any]) -> Tuple[str, ...]:
        return (
            boundary.get("constraint_type", "unknown"),
            boundary.get("scope", "unknown"),
            self._canonicalize_pattern(boundary.get("formal_pattern", "")),
            boundary.get("dependency_pattern", "root"),
        )

    def _canonicalize_pattern(self, pattern: str) -> str:
        canonical = pattern.lower()
        for old, new in self._DEFAULT_REPLACEMENTS.items():
            canonical = canonical.replace(old, new)
        return canonical

    def _boundary_similarity(self, b1: Tuple[str, ...], b2: Tuple[str, ...]) -> float:
        weights = [0.35, 0.15, 0.40, 0.10]
        scores = []
        for i, (w, x, y) in enumerate(zip(weights, b1, b2)):
            if i == 2:
                score = self._string_similarity(x, y)
            else:
                score = 1.0 if x == y else 0.0
            scores.append(w * score)
        return sum(scores)

    @staticmethod
    def _string_similarity(s1: str, s2: str) -> float:
        tokens1 = set(s1.split())
        tokens2 = set(s2.split())
        if not tokens1 and not tokens2:
            return 1.0
        inter = tokens1 & tokens2
        union = tokens1 | tokens2
        return len(inter) / len(union) if union else 0.0

    def _set_similarity(self, new_set: List[Tuple[str, ...]], old_set: List[Tuple[str, ...]]) -> float:
        if not new_set or not old_set:
            return 0.0
        matched_scores = []
        used_old: set = set()
        for nb in new_set:
            best_score = 0.0
            best_idx = -1
            for idx, ob in enumerate(old_set):
                if idx in used_old:
                    continue
                score = self._boundary_similarity(nb, ob)
                if score > best_score:
                    best_score = score
                    best_idx = idx
            if best_idx >= 0:
                matched_scores.append(best_score)
                used_old.add(best_idx)
        if not matched_scores:
            return 0.0
        avg_matched = sum(matched_scores) / len(new_set)
        unmatched_penalty = (len(old_set) - len(used_old)) * 0.1
        return max(0.0, avg_matched - unmatched_penalty)


# ── condition 3: cumulative risk ──────────────────────────────────

class CumulativeRiskCondition(TerminationCondition):
    """Condition 3: Three consecutive 🟡 (VALID_WITH_ENHANCEMENTS) judgments."""

    def __init__(self, consecutive_threshold: int = 3):
        self.consecutive_threshold = consecutive_threshold

    def check(self, state: Dict[str, Any], history: List[Dict[str, Any]]) -> Dict[str, Any]:
        judgments = []
        for h in history:
            judgments.append(h.get("judgment_color", "unknown"))
        judgments.append(state.get("judgment_color", "unknown"))

        consecutive_yellow = 0
        for j in reversed(judgments):
            if j in ("VALID_WITH_ENHANCEMENTS", "🟡"):
                consecutive_yellow += 1
            else:
                break

        if consecutive_yellow >= self.consecutive_threshold:
            return {
                "triggered": True,
                "reason": (
                    f"Cumulative risk warning: {consecutive_yellow} consecutive "
                    f"🟡 (VALID_WITH_ENHANCEMENTS) judgments. Each 🟡 introduced "
                    f"a new framework with new boundaries. The system has reached "
                    f"sufficient exploration depth. Further expansion risks Zeno-effect "
                    f"infinite regression without proportional epistemic gain."
                ),
                "severity": "moderate",
                "metrics": {
                    "consecutive_yellow": consecutive_yellow,
                    "threshold": self.consecutive_threshold,
                    "total_judgments": len(judgments),
                    "yellow_ratio": judgments.count("🟡") / len(judgments) if judgments else 0,
                },
            }

        return {
            "triggered": False,
            "reason": f"Only {consecutive_yellow} consecutive 🟡 (need {self.consecutive_threshold})",
            "severity": "info",
            "metrics": {
                "consecutive_yellow": consecutive_yellow,
                "threshold": self.consecutive_threshold,
            },
        }


# ── condition 4: depth budget ─────────────────────────────────────

class DepthBudgetCondition(TerminationCondition):
    """Condition 4: User-defined maximum depth (hard stop)."""

    def __init__(self, max_depth: Optional[int] = None):
        self.max_depth = max_depth

    def check(self, state: Dict[str, Any], history: List[Dict[str, Any]]) -> Dict[str, Any]:
        if self.max_depth is None:
            return {"triggered": False, "reason": "No depth budget set", "severity": "info"}

        current_iteration = state.get("iteration", len(history) + 1)

        if current_iteration >= self.max_depth:
            return {
                "triggered": True,
                "reason": (
                    f"Depth budget exhausted: iteration {current_iteration} "
                    f"reaches user-defined maximum {self.max_depth}. "
                    f"This is a hard stop condition."
                ),
                "severity": "info",
                "metrics": {
                    "current_iteration": current_iteration,
                    "max_depth": self.max_depth,
                },
            }

        return {
            "triggered": False,
            "reason": f"Iteration {current_iteration} / {self.max_depth}",
            "severity": "info",
            "metrics": {
                "current_iteration": current_iteration,
                "max_depth": self.max_depth,
            },
        }


# ── meta-cognitive summary ────────────────────────────────────────

class MetaCognitiveSummary:
    """Generates the triage summary at termination: what we know / what we don't /
    what's not worth pursuing / partial result.
    """

    def generate(
        self,
        state: Dict[str, Any],
        history: List[Dict[str, Any]],
        termination_results: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Generate structured meta-cognitive summary at termination."""
        concept_chain = self._extract_concept_chain(history)
        resolved, open_boundaries, abandoned = self._classify_boundaries(history)
        key_insight = self._identify_key_insight(history)

        return {
            "what_we_know": {
                "concepts_resolved": [c["concept_id"] for c in concept_chain],
                "boundaries_understood": resolved,
                "key_insight": key_insight,
            },
            "what_we_dont_know": {
                "open_boundaries": open_boundaries,
                "unverified_assumptions": self._extract_assumptions(history),
                "needed_tools": self._identify_missing_tools(state),
            },
            "whats_not_worth_pursuing": {
                "abandoned_paths": abandoned,
                "why_stop": self._explain_stop_reason(termination_results),
            },
            "partial_result": {
                "deliverable": self._describe_deliverable(concept_chain),
                "usable_depth": self._assess_usable_depth(concept_chain),
                "recommended_next_step": self._suggest_next_step(open_boundaries, state),
            },
        }

    def _extract_concept_chain(self, history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        chain = []
        for h in history:
            if "recommended_framework" in h:
                chain.append({
                    "concept_id": h["recommended_framework"],
                    "confidence": h.get("confidence", 0),
                    "judgment": h.get("judgment_color", "unknown"),
                })
        return chain

    def _classify_boundaries(self, history: List[Dict[str, Any]]) -> Tuple[List[Any], List[Any], List[Any]]:
        resolved = []
        open_boundaries = []
        abandoned = []
        for h in history:
            for b in h.get("new_boundaries", []):
                status = b.get("status", "unknown")
                if status == "reframed":
                    resolved.append(b)
                elif status == "identified":
                    open_boundaries.append(b)
                elif status == "abandoned":
                    abandoned.append(b)
        return resolved, open_boundaries, abandoned

    def _identify_key_insight(self, history: List[Dict[str, Any]]) -> str:
        insights = []
        for h in history:
            if "key_insight" in h:
                insights.append({"text": h["key_insight"], "confidence": h.get("confidence", 0)})
        if not insights:
            return "No explicit insight recorded"
        insights.sort(key=lambda x: x["confidence"], reverse=True)
        return insights[0]["text"]

    @staticmethod
    def _extract_assumptions(history: List[Dict[str, Any]]) -> List[str]:
        assumptions = []
        for h in history:
            assumptions.extend(h.get("assumptions", []))
        return assumptions

    @staticmethod
    def _identify_missing_tools(state: Dict[str, Any]) -> List[str]:
        needed = state.get("tools_needed", [])
        available = state.get("tools_available", [])
        return [t for t in needed if t not in available]

    @staticmethod
    def _explain_stop_reason(termination_results: List[Dict[str, Any]]) -> str:
        triggered = [r for r in termination_results if r.get("triggered")]
        if not triggered:
            return "No termination conditions triggered (unexpected state)"
        return " | ".join(r.get("reason", "") for r in triggered)

    @staticmethod
    def _describe_deliverable(concept_chain: List[Dict[str, Any]]) -> str:
        if len(concept_chain) <= 1:
            first = concept_chain[0]["concept_id"] if concept_chain else "none"
            return f"Single concept exploration: {first}"
        concepts = [c["concept_id"] for c in concept_chain]
        return f"Conceptual network: {' → '.join(concepts)}"

    @staticmethod
    def _assess_usable_depth(concept_chain: List[Dict[str, Any]]) -> str:
        depths = []
        for c in concept_chain:
            judgment = c.get("judgment", "unknown")
            concept_id = c["concept_id"]
            if judgment in ("🟢", "FULLY_RESOLVED"):
                depths.append(f"{concept_id}: D1-D4 fully usable")
            elif judgment in ("🟡", "VALID_WITH_ENHANCEMENTS"):
                depths.append(f"{concept_id}: D1-D3 usable; D4 identified but not fully resolved")
            else:
                depths.append(f"{concept_id}: depth uncertain")
        return "; ".join(depths)

    def _suggest_next_step(self, open_boundaries: List[Dict[str, Any]], state: Dict[str, Any]) -> str:
        if not open_boundaries:
            return "No open boundaries — exploration is complete."
        missing_tools = self._identify_missing_tools(state)
        if missing_tools:
            boundary = open_boundaries[0].get("boundary", "open boundary")
            return f"If tools become available ({', '.join(missing_tools)}), revisit: {boundary}"
        boundary = open_boundaries[0].get("boundary", "open boundary")
        return f"Consider manual investigation of: {boundary}"


# ── master evaluator ────────────────────────────────────────────

class TerminationEvaluator:
    """Evaluates all termination conditions and produces a unified decision.

    Condition priority (higher = more important):
    - cyclic_boundary: 4 (highest — structural loop detected)
    - diminishing_returns: 3 (high — new framework weaker than old)
    - cumulative_risk: 2 (moderate — prudential pause)
    - depth_budget: 1 (lowest — user preference)
    """

    PRIORITIES = {
        "cyclic_boundary": 4,
        "diminishing_returns": 3,
        "cumulative_risk": 2,
        "depth_budget": 1,
    }

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        cfg = config or {}
        self.conditions = {
            "cyclic_boundary": CyclicBoundaryCondition(
                similarity_threshold=cfg.get("cyclic_threshold", 0.85)
            ),
            "diminishing_returns": DiminishingReturnsCondition(
                alpha=cfg.get("confidence_alpha", 0.90)
            ),
            "cumulative_risk": CumulativeRiskCondition(
                consecutive_threshold=cfg.get("yellow_threshold", 3)
            ),
            "depth_budget": DepthBudgetCondition(
                max_depth=cfg.get("max_depth", None)
            ),
        }

    def evaluate(self, state: Dict[str, Any], history: List[Dict[str, Any]]) -> TerminationDecision:
        """Evaluate all conditions and return a termination decision.

        Args:
            state: Current iteration state (BDD/FCH output).
            history: List of prior iteration outputs.

        Returns:
            TerminationDecision with terminate flag, decision type, and meta-summary.
        """
        all_results = []
        triggered = []

        for name, condition in self.conditions.items():
            result = condition.check(state, history)
            result["condition_name"] = name
            result["priority"] = self.PRIORITIES.get(name, 0)
            all_results.append(result)
            if result["triggered"]:
                triggered.append(result)

        if not triggered:
            return TerminationDecision(
                terminate=False,
                decision="CONTINUE",
                primary_reason="No termination conditions triggered",
                all_results=all_results,
                meta_summary=None,
            )

        triggered.sort(key=lambda x: x["priority"], reverse=True)
        primary = triggered[0]

        decision = self._map_to_decision(primary["condition_name"])

        return TerminationDecision(
            terminate=True,
            decision=decision,
            primary_reason=primary["reason"],
            triggering_condition=primary["condition_name"],
            all_results=all_results,
            severity=primary["severity"],
            meta_summary=MetaCognitiveSummary().generate(state, history, all_results),
        )

    @staticmethod
    def _map_to_decision(condition_name: str) -> str:
        if condition_name == "cyclic_boundary":
            return "HALT"
        if condition_name == "diminishing_returns":
            return "YIELD"
        if condition_name in ("cumulative_risk", "depth_budget"):
            return "YIELD"
        return "YIELD"


# ── utility ───────────────────────────────────────────────────────

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ── CLI entry point ──────────────────────────────────────────────

def _main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="FCH v3.3 Termination Checker")
    parser.add_argument("--evaluate", action="store_true", help="Run evaluation from JSON state")
    parser.add_argument("--state", type=str, help="Current state JSON file")
    parser.add_argument("--history", type=str, help="History JSON file (list of states)")
    args = parser.parse_args()

    if args.evaluate and args.state:
        with open(args.state, "r", encoding="utf-8") as f:
            state = json.load(f)
        history = []
        if args.history:
            with open(args.history, "r", encoding="utf-8") as f:
                history = json.load(f)
        evaluator = TerminationEvaluator()
        decision = evaluator.evaluate(state, history)
        print(json.dumps(decision.to_dict(), indent=2, ensure_ascii=False))
    else:
        parser.print_help()


if __name__ == "__main__":
    _main()

__all__ = [
    "TerminationEvaluator",
    "TerminationCondition",
    "DiminishingReturnsCondition",
    "CyclicBoundaryCondition",
    "CumulativeRiskCondition",
    "DepthBudgetCondition",
    "MetaCognitiveSummary",
    "TerminationDecision",
]
