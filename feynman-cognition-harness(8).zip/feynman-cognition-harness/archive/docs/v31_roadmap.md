# FCH v3.1 Fusion Architecture 改造计划

## 目标
将 v2.1 的横向问题检测/修复机制（矛盾、外部验证、精准生长）融入 v3.0 的纵向流程框架（五层架构），构建完整的 CSED-CLIF v3.1。

## 融合架构定义

```
Layer 0:   TriggerDaemon（v3.0 已有）
Layer 0.5: Oscillation Initialization（v2.1 PHASE 0 → 移植到 run_v3 开头）
Layer 1:   Metacognitive evaluation + Cognitive Classification（v3.0 + v2.1 融合）
Layer 2:   Genesis generation（v3.0 已有）
Layer 3:   Verification（v3.0 cross-temporal + v2.1 independent audit + v2.1 external search）
Layer 3.5: Contradiction Detection & Resolution（v2.1 _detect/_handle_contradictions）
Layer 3.6: GROW（v2.1 grow.grow(gap)）
Layer 4:   Consolidation（v3.0 已有）
Layer 5:   CASCADE（v2.1 cascade.cascade 在 consolidation 后触发）
```

## 改造顺序（依赖关系）

### Phase 1: 核心流程改造（orchestrator.py）
1. 重写 run_v3() — 按融合架构重新组织循环
   - 加入 Layer 0.5: Oscillation Initialization（概念全新时执行）
   - Layer 1 增强：加入 Cognitive Classification 输入
   - Layer 3 增强：整合 cross-temporal + independent + external
   - 新增 Layer 3.5: Contradiction Detection & Resolution
   - 新增 Layer 3.6: GROW（精准缺口填充）
   - 循环优先级：contradictions > gaps > revise
   - Layer 5: CASCADE 在 consolidation 后触发
2. 增强 _evaluate_metacognitive() — 加入 concept_type 参数
3. 新增 _aggregate_verification() — 多维验证结果聚合
4. 修复 _store_v3_versions() — 保留历史版本（当前只存最新）

### Phase 2: 辅助方法增强
1. _verify_versions() — 在 cross-temporal 基础上，fallback 时返回更丰富的 metrics
2. 确保 _detect_contradictions, _handle_contradictions, grow.grow 可在循环中正确调用

### Phase 3: 文档更新
1. README.md — 更新架构图、版本号 v3.1、融合架构说明
2. SKILL.md — 更新入口说明，加入融合架构描述
3. __init__.py — 确认导出正确

### Phase 4: 全局对齐检查
1. 检查所有脚本文件中的版本号引用
2. 检查新增/修改的方法在文档中被正确引用
3. 验证主流程中各层的调用不冲突
4. 端到端测试

## 关键设计决策

### 1. 循环优先级
```
After Genesis + Verification:
  IF contradictions detected:
    → _handle_contradictions() → continue (re-trigger)
  ELIF significant gaps AND confidence < threshold:
    → grow.grow(gap) → continue (re-trigger)
  ELIF verification == "accept":
    → consolidate → cascade → break
  ELSE:
    → standard failure trigger → continue
```

### 2. Verification 增强
不再只有 cross-temporal 一维。融合后：
- cross_temporal_result: {recommendation, depth_delta, analogy_stability, mapping_consistency}
- independent_audit: {status, gaps, contradictions, score}
- external_validation: {valid_count, total_claims}
- confidence_result: {overall_confidence, dimension_scores}

聚合逻辑：
- 任一维度严重失败 → "revise"
- 全部通过 → "accept"
- 外部验证通过率 < 50% → 强制 "revise"

### 3. Metacognitive 增强
加入 cognitive classification：
- 数学/形式科学 → threshold 提高到 0.85
- 生物/经验科学 → threshold 降低到 0.65
- 抽象概念 → 延长 deepen 阶段
- 工程概念 → 优先 external validation

### 4. Oscillation Initialization 整合
作为可选前置阶段：
- 新概念（lattice 中不存在）→ 执行 PHASE 0
- 已有概念 → 跳过（除非显式触发类型为 "oscillation"）

## 风险评估
1. **循环复杂度增加** → 增加 stuck 检测鲁棒性，max_iterations 保护
2. **外部搜索延迟** → 在 mock/测试模式下可禁用，保留接口
3. **矛盾处理可能无限循环** → 单次 _handle_contradictions 只处理 top-3，不递归
4. **版本存储增长** → version_stack 可配置上限（当前实现暂不设限）

## 测试策略
1. Mock LLM 端到端测试（固定文本，验证循环结构）
2. 真实 LLM 单轮测试（验证各层调用正常）
3. 文档/代码引用一致性检查（grep 扫描）
