# FCH v3.2 Auto-Deepening — 全自动化 Teach-Audit-Grow 改造方案

## 目标
基于 Iteration 1-7 反思，实现真正的全自动化认知深化循环：
- 初始化及每次增量研究（grow）自动使用外部搜索
- 内部 Ming Wu 触发器：每轮自动检查 6 条件，不满足则自主继续
- 新颖信息比例监测：重复率 >85% 时自动标记 stuck
- 外部信源切换阈值：内部 3 轮无显著结构发现 → 自动 spawn 搜索
- 代码改动自检：edit/write 后自动 import test

## 改进范围

### 1. grow.py — 外部搜索集成
**现状**：`_find_external_anchor` 和 `_identify_prerequisite` 是 stub，没有真实搜索
**改造**：
- 新增 `_search_external_knowledge(gap)` 方法：调用 kimi_search + kimi_fetch
- 在 `_find_external_anchor` 中调用搜索获取真实独立定义
- 在 `_identify_prerequisite` 中搜索 prerequisite 概念的定义
- 在 `_design_new_master_analogy` 中搜索类比灵感
- 新增 `_search_for_gap_filling(gap)`：针对 gap 描述进行外部搜索

### 2. orchestrator.py — 全自动化循环
**现状**：`run()` 和 `run_v3()` 是单轮/需用户触发继续
**改造**：
- 新增 `_ming_wu_check()`：6 条件自动评估
- 新增 `_novelty_ratio_check()`：计算迭代间内容重复率
- 新增 `_auto_search_trigger()`：3 轮无进展时自动外部搜索
- 新增 `_self_test_after_edit()`：代码改动后自动 import 验证
- 修改 `run()`：循环内自动判断是否继续（无需用户指令）
- 修改 `run_v3()`：相同自动化逻辑

### 3. config.json — 自动化参数
**新增**：
```json
{
  "auto_cycle": {
    "enabled": true,
    "ming_wu_threshold": {
      "confidence": 0.90,
      "bss": 0.60,
      "short_term_problems": 3,
      "contradictions": 5,
      "emotion_intensity": 0.30,
      "convergence_delta": 0.02
    },
    "novelty_threshold": 0.15,
    "search_trigger_after_stuck_iterations": 3,
    "max_auto_iterations": 10,
    "self_test_enabled": true
  }
}
```

### 4. 文档对齐
- README.md：更新自动化循环说明
- SKILL.md：更新使用方式
- docs/v31_roadmap.md：标记已完成项

## 执行顺序
1. Phase 1：修改 grow.py（外部搜索集成）
2. Phase 2：修改 orchestrator.py（自动化循环）
3. Phase 3：更新 config.json
4. Phase 4：文档对齐检查
5. Phase 5：端到端验证

## 版本号
v3.1.0 → v3.2.0（Auto-Deepening 版本）
