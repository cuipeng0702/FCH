---
tag: [LEGACY]
load_when: "历史归档与废弃文档"
---

# Epistemic Metadata Layer Design

## 1. Philosophy

### 1.1 What Epistemic Self-Awareness Is

A **quality audit** asks: "Does this output conform to the spec?" (PRD compliance, schema correctness, word counts).

An **epistemic audit** asks: "How does this agent know what it claims to know?" (justification chain), "What does it admit it does not know?" (ignorance map), and "What would prove it wrong?" (falsification conditions).

The difference is the difference between a **proofreader** and a **skeptic**.

| Dimension | Quality Audit | Epistemic Audit |
|-----------|--------------|-----------------|
| Question | "Did you follow instructions?" | "Why should anyone believe this?" |
| Focus | Output structure, format, completeness | Source of knowledge, reasoning chain, humility |
| Failure mode | Missing keys, wrong types | Unjustified claims, hidden assumptions, false confidence |
| Verdict | PASS / NEEDS_FIX / REJECT | EPISTEMICALLY_SOUND / EPISTEMICALLY_DEFICIENT / EPISTEMICALLY_HOLLOW |

### 1.2 Why the Existing System Needs This

The current harness already produces:
- Confidence scores (0.0–1.0) — **numeric** but **opaque**
- External source lists (URLs) — **cited** but **unevaluated**
- Audit issues (layer, severity) — **compliance-oriented**, not truth-oriented
- Gap lists (what is missing) — **reactive**, not systematically mapped

What it **does not** track:
1. **Per-claim provenance** — Which claim came from which source, and how reliable was that source?
2. **Reasoning chain visibility** — How did the agent get from search results to D3 definition?
3. **Explicit ignorance boundaries** — Not just "we need to search more" but "these are the questions we cannot currently answer"
4. **Falsifiability** — For every claim, what observation would invalidate it?

Without these, an agent can score `confidence: 0.95` while being **epistemically hollow** — high certainty built on sand.

### 1.3 Design Principles

1. **Non-breaking**: All existing JSON schemas remain valid. Epistemic metadata is an optional `epistemic_metadata` field.
2. **Machine-verifiable**: Every epistemic claim has pass/fail criteria that can be checked by code.
3. **Worker-native**: Each worker produces its own epistemic metadata; the epistemic auditor verifies it, not substitutes for it.
4. **Cumulative**: Epistemic metadata builds across iterations. Iteration N inherits and refines iteration N-1's ignorance map.
5. **Cheap to add, costly to ignore**: Adding the field is trivial; omitting it triggers an epistemic audit failure.

---

## 2. Epistemic Metadata Schema

Every worker output JSON (teach, audit, grow, verify, search) **shall** include an `epistemic_metadata` object. The schema is layered:

### 2.1 Top-Level Structure

```json
{
  "epistemic_metadata": {
    "version": "1.0",
    "generated_at": "ISO-8601",
    "worker_type": "teach-agent|audit-agent|grow-agent|verify-agent|search-agent",
    "claims": [],
    "method_reflection": {},
    "ignorance_map": {},
    "epistemic_health_score": 0.0
  }
}
```

### 2.2 `claims[]` — Justification Chain

Every **non-trivial claim** in the worker output must be registered here. A "non-trivial claim" is any statement that:
- Asserts a fact about the external world (not definitional or tautological)
- Could be disputed by a domain expert
- Serves as a premise for another claim

```json
{
  "claims": [
    {
      "claim_id": "c-001",
      "text": "Bell's theorem proves that no local hidden-variable theory can reproduce all predictions of quantum mechanics.",
      "location": "d3.definition",
      "justification": {
        "type": "derived_from_source|inferred_from_multiple|agent_reasoning|tentative_hypothesis|unverified_assertion",
        "sources": [
          {
            "source_id": "s-001",
            "url": "https://arxiv.org/abs/...",
            "snippet": "...",
            "reliability": "peer_reviewed|authoritative|popular|unknown",
            "accessed_at": "ISO-8601"
          }
        ],
        "reasoning_chain": [
          "Source states [X]",
          "Source is peer-reviewed → high reliability",
          "Therefore claim [C] is supported"
        ]
      },
      "confidence_source": "peer_reviewed_multiple|peer_reviewed_single|authoritative|heuristic|speculative|none",
      "falsification_conditions": [
        "A local hidden-variable theory is experimentally demonstrated to match QM predictions",
        "A loophole-free Bell test fails to violate Bell inequalities"
      ],
      "ignorance_notes": "Assumes standard quantum mechanics is complete; does not address superdeterminism loophole.",
      "domain_expert_would_agree": true
    }
  ]
}
```

#### Field Definitions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `claim_id` | string | Yes | Unique within this output file. Format: `c-{NNN}` |
| `text` | string | Yes | Verbatim claim text (must match output content) |
| `location` | string | Yes | JSON path to where this claim appears in the output (e.g., `d3.definition`, `d4.boundaries[0].condition`) |
| `justification.type` | enum | Yes | How the claim was arrived at |
| `justification.sources[]` | array | If `type != agent_reasoning` | Sources that support this claim |
| `justification.reasoning_chain[]` | array | Yes | Step-by-step reasoning from premises to claim |
| `confidence_source` | enum | Yes | Aggregate confidence based on source quality |
| `falsification_conditions[]` | array | Yes | ≥1 concrete observation that would invalidate the claim |
| `ignorance_notes` | string | No | Explicit caveats, known limitations, edge cases |
| `domain_expert_would_agree` | boolean | Yes | Self-assessment: would a domain expert likely accept this? |

#### `justification.type` Enumeration

| Value | Meaning | Machine-Checkable? |
|-------|---------|-------------------|
| `derived_from_source` | Directly quoted or closely paraphrased from a source | Check source snippet contains claim text |
| `inferred_from_multiple` | Synthesis of multiple sources | Check ≥2 sources listed |
| `agent_reasoning` | Deduced by the agent from prior claims | Check reasoning_chain non-empty |
| `tentative_hypothesis` | Educated guess, flagged as such | Check `confidence_source` ≤ `heuristic` |
| `unverified_assertion` | Stated without supporting evidence | Auto-fail epistemic audit unless marked as such |

#### `confidence_source` Enumeration (Ordinal)

```
peer_reviewed_multiple > peer_reviewed_single > authoritative > heuristic > speculative > none
```

### 2.3 `method_reflection` — Meta-Cognitive Record

```json
{
  "method_reflection": {
    "search_queries_used": [
      {
        "query": "Bell's theorem assumptions loopholes",
        "purpose": "Verify completeness of D4 boundary conditions",
        "results_count": 5,
        "quality_assessment": "high|medium|low"
      }
    ],
    "sources_evaluated": [
      {
        "source_id": "s-001",
        "url": "...",
        "evaluation": {
          "credibility": "high|medium|low",
          "recency": "current|dated|unknown",
          "bias_detected": "none|possible|significant",
          "domain_match": "exact|related|tangential"
        },
        "used_for_claims": ["c-001", "c-002"]
      }
    ],
    "reasoning_chain": {
      "summary": "Searched for formal definition → found peer-reviewed paper → extracted core equation → cross-checked with 2 other sources → formulated D3 definition",
      "key_decisions": [
        {
          "decision": "Chose von Neumann definition over Dirac notation",
          "alternatives_considered": ["Dirac bra-ket notation", "Feynman path integral formulation"],
          "why_chosen": "More widely cited in undergraduate textbooks; better D1 mapping"
        }
      ]
    }
  }
}
```

### 2.4 `ignorance_map` — Explicit Unknowns

```json
{
  "ignorance_map": {
    "known_unknowns": [
      {
        "id": "ku-001",
        "question": "What is the experimental error margin in recent loophole-free Bell tests?",
        "why_unknown": "Search results focused on theoretical statements; experimental precision not discussed.",
        "impact_on_claims": ["c-001"],
        "would_change_conclusion": "might_change|would_not_change|unknown",
        "blocking": false
      }
    ],
    "unknown_unknowns_suspected": [
      {
        "id": "uu-001",
        "suspicion_basis": "D3 definition uses standard QM formalism; did not encounter any discussion of QBism or relational quantum mechanics interpretations.",
        "mitigation": "Flag for future search on interpretational frameworks.",
        "priority": "low"
      }
    ],
    "ignorance_score": 0.3
  }
}
```

#### `known_unknowns` Field Definitions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | Yes | Format: `ku-{NNN}` |
| `question` | string | Yes | A well-formed question the agent cannot answer |
| `why_unknown` | string | Yes | Why the agent couldn't answer it (failed search, no sources, beyond scope) |
| `impact_on_claims` | string[] | Yes | Which `claim_id`s are affected by this ignorance |
| `would_change_conclusion` | enum | Yes | If answered, would it change the associated claims? |
| `blocking` | boolean | Yes | Does this ignorance block any Ming Wu condition? |

#### `unknown_unknowns_suspected` Field Definitions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | Yes | Format: `uu-{NNN}` |
| `suspicion_basis` | string | Yes | What triggered the suspicion (absence of expected topic, narrow source range, etc.) |
| `mitigation` | string | Yes | Concrete action to reduce this unknown-unknown |
| `priority` | enum | Yes | `high|medium|low` — how likely this is to matter |

### 2.5 `epistemic_health_score`

A composite score [0.0, 1.0] computed automatically by the epistemic auditor:

```json
{
  "epistemic_health_score": 0.72,
  "score_breakdown": {
    "claim_coverage": 0.9,
    "justification_quality": 0.8,
    "falsification_present": 1.0,
    "ignorance_explicitness": 0.5,
    "source_quality": 0.7
  }
}
```

**Formula** (initial proposal — configurable in epistemic-auditor):

```
epistemic_health_score = (
  0.25 * claim_coverage +
  0.25 * justification_quality +
  0.20 * falsification_present +
  0.15 * ignorance_explicitness +
  0.15 * source_quality
)
```

| Sub-score | Calculation |
|-----------|-------------|
| `claim_coverage` | `#claims_registered / #non_trivial_claims_detected` by auditor |
| `justification_quality` | Average `confidence_source` ordinal / max_ordinal |
| `falsification_present` | `%claims with ≥1 falsification_condition` |
| `ignorance_explicitness` | 1.0 if `known_unknowns` non-empty and mapped to claims; 0.0 if empty |
| `source_quality` | Average source reliability ordinal / max_ordinal |

---

## 3. Epistemic Audit Protocol

### 3.1 The Epistemic Auditor

A new worker: **epistemic-auditor-agent**. It runs after `verify-agent` and before `consolidate-agent`.

**Input**: All iteration outputs (`teach_output.json`, `audit_output.json`, `grow_output.json`, `verify_output.json`, `search_results.json`)

**Output**: `epistemic_audit_report.json`

### 3.2 Minimum Standards (Machine-Verifiable)

A worker output passes epistemic audit if and only if all of the following are true:

| # | Standard | Machine-Check Method | Pass Condition |
|---|----------|----------------------|----------------|
| E1 | `epistemic_metadata` present | `json.get("epistemic_metadata") is not None` | `true` |
| E2 | `claims[]` non-empty for non-trivial output | Auditor extracts claims via pattern matching, compares count | `len(claims) >= auditor_detected_claims * 0.8` |
| E3 | Every claim has `justification.reasoning_chain` | Key-in-dict + length check | `len(reasoning_chain) >= 2` |
| E4 | Every claim has ≥1 `falsification_condition` | Array length check | `len(falsification_conditions) >= 1` |
| E5 | No `unverified_assertion` with `confidence_source > speculative` | Cross-field check | `true` for all claims |
| E6 | `ignorance_map.known_unknowns` exists | Key check | `true` |
| E7 | `method_reflection.search_queries_used` exists | Key check | `true` |
| E8 | `epistemic_health_score >= 0.60` | Value check | `true` |
| E9 | `method_reflection.sources_evaluated` exists for teach/verify/search | Worker-type conditional check | `true` |
| E10 | `domain_expert_would_agree` is boolean (not null) | Type check | `true` for all claims |

### 3.3 Scoring Rubric (Epistemic Health Score)

| Score Range | Verdict | Meaning | Action |
|-------------|---------|---------|--------|
| 0.90–1.00 | EPISTEMICALLY_SOUND | Robust justification, explicit ignorance, falsifiable claims | Proceed to consolidate |
| 0.70–0.89 | EPISTEMICALLY_DEFICIENT | Some gaps in justification or ignorance mapping | Proceed with warning; flag for next iteration focus |
| 0.50–0.69 | EPISTEMICALLY_WEAK | Significant epistemic holes; high confidence without support | Trigger grow-agent with epistemic focus |
| < 0.50 | EPISTEMICALLY_HOLLOW | Claims made without justification; no falsification; no ignorance map | REJECT; force re-teach with epistemic instructions |

### 3.4 Epistemic Audit Report Schema

```json
{
  "iteration": 1,
  "timestamp": "ISO-8601",
  "status": "EPISTEMICALLY_SOUND|EPISTEMICALLY_DEFICIENT|EPISTEMICALLY_WEAK|EPISTEMICALLY_HOLLOW",
  "checks": {
    "e1_metadata_present": true,
    "e2_claim_coverage": 0.85,
    "e3_reasoning_chains": true,
    "e4_falsification_present": true,
    "e5_no_bogus_assertions": true,
    "e6_known_unknowns": true,
    "e7_search_queries": true,
    "e8_health_score": 0.72,
    "e9_sources_evaluated": true,
    "e10_expert_agreement": true
  },
  "epistemic_health_score": 0.72,
  "score_breakdown": {
    "claim_coverage": 0.85,
    "justification_quality": 0.75,
    "falsification_present": 1.0,
    "ignorance_explicitness": 0.4,
    "source_quality": 0.8
  },
  "epistemic_issues": [
    {
      "check_id": "E6",
      "severity": "major",
      "description": "known_unknowns exists but is empty; agent claims complete understanding without admitting gaps.",
      "affected_claims": ["c-003"],
      "recommendation": "Add explicit known_unknowns for boundary conditions not covered in D4."
    }
  ],
  "action": "PROCEED_WITH_WARNING|REGROW|REJECT",
  "metadata": {
    "auditor_version": "1.0",
    "claims_checked": 5,
    "sources_verified": 3
  }
}
```

### 3.5 Relationship to Quality Audit

The epistemic audit is **orthogonal** to the quality audit:

```
┌─────────────────┬──────────────────┐
│ Quality Audit   │ Epistemic Audit  │
├─────────────────┼──────────────────┤
│ Schema correct? │ Claims justified?│
│ Keys present?   │ Sources reliable?│
│ Word counts OK? │ Falsifiable?     │
│ D-layers valid? │ Ignorance mapped?│
└─────────────────┴──────────────────┘
```

**Both must pass** for the iteration to proceed to consolidate.

If quality audit passes but epistemic audit fails:
- The output is **well-formed but not believable**
- The orchestrator routes to grow-agent with an `epistemic_focus: true` flag

---

## 4. Integration Plan

### 4.1 Files to Modify (No Breaking Changes)

| File | Change | Nature |
|------|--------|--------|
| `PRD.md` | Add §10 "Epistemic Metadata Layer" with schema definitions, §6 update for mandatory epistemic audit | Append new section; no existing section modified |
| `orchestrator.py` | Add `_run_epistemic_audit()` method; insert epistemic audit between verify and consolidate; add `epistemic_audit_report.json` to `_is_converged()` | New method + single insertion point; existing methods unchanged |
| `agents/teach_task_template.md` | Add epistemic metadata requirements to Output section; add claims extraction instructions | Append to template |
| `agents/grow_task_template.md` | Add epistemic metadata requirements; add `epistemic_focus` handling | Append to template |
| `agents/verify_task_template.md` | Add epistemic metadata requirements; add source evaluation instructions | Append to template |

### 4.2 New Files to Create

| File | Purpose | Location |
|------|---------|----------|
| `agents/epistemic_audit_task_template.md` | Task template for epistemic-auditor-agent | `harness/agents/` |
| `harness/epistemic_validator.py` | Pure Python module for machine-verifiable epistemic checks (E1–E10) | `harness/` |
| `harness/epistemic_design.md` | This document | `harness/` |

### 4.3 Order of Changes

```
Step 1: Create epistemic_validator.py
    → Build the machine-verification logic first (E1–E10 checks)
    → Write unit tests against sample JSON

Step 2: Create agents/epistemic_audit_task_template.md
    → Define what the epistemic auditor does

Step 3: Modify worker templates (teach, grow, verify)
    → Add epistemic metadata production instructions

Step 4: Modify orchestrator.py
    → Wire epistemic audit into the Ralph loop

Step 5: Modify PRD.md
    → Document the new schemas and audit protocol

Step 6: Run integration test
    → Verify a full iteration with epistemic metadata flows correctly
```

### 4.4 Backward Compatibility

- All existing JSON schemas remain valid. `epistemic_metadata` is **optional at the schema level** but **mandatory at the audit level**.
- Old iteration files without `epistemic_metadata` are treated as `EPISTEMICALLY_HOLLOW` by the auditor (they fail E1).
- The `max_fix_attempts` logic in the orchestrator handles epistemic audit failures the same way it handles quality audit failures.

---

## 5. Modified Execution Flow

### 5.1 New Ralph Loop Sequence

```
┌─────────────┐
│   SEARCH    │ ← search-agent (produces search_results.json)
│  (unchanged)│
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   TEACH     │ ← teach-agent (produces teach_output.json + epistemic_metadata)
│  (+claims)  │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   AUDIT     │ ← audit-agent (quality audit, unchanged)
│  (unchanged)│
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   GROW      │ ← grow-agent (produces grow_output.json + epistemic_metadata)
│  (+ignorance)│
└──────┬──────┘
       │
       ▼
┌─────────────┐
├─────────────┤
│   VERIFY    │ ← verify-agent (produces verify_output.json + epistemic_metadata)
│  (+sources) │
├─────────────┤
│  EPISTEMIC  │ ← epistemic-auditor-agent (produces epistemic_audit_report.json)
│   AUDIT     │
│   (NEW)     │
├─────────────┤
│  CONSOLIDATE│ ← consolidate-agent (unchanged, receives epistemic_audit_report.json)
│             │
└─────────────┘
```

### 5.2 State Machine Update

The orchestrator's `_is_converged()` method now checks an additional condition:

```python
# After existing Ming Wu and Novelty checks, add:
epistemic_path = self._iter_dir(iteration) / "epistemic_audit_report.json"
epistemic = self._load_json_safe(epistemic_path, {})
if epistemic.get("status") not in ("EPISTEMICALLY_SOUND", "EPISTEMICALLY_DEFICIENT"):
    return False
```

**Ming Wu Condition 7** (new):

| # | Condition | Machine-Verifiable Test | Threshold |
|---|-----------|------------------------|-----------|
| 7 | **Epistemic Soundness** | `epistemic_audit_report.json` contains `status` ∈ {`EPISTEMICALLY_SOUND`, `EPISTEMICALLY_DEFICIENT`} | `true` |

### 5.3 Budget Impact

The epistemic audit costs **1 budget unit** (one subagent spawn). It is treated as a mandatory step, not optional.

If the epistemic audit fails and triggers regrow, the regrow also costs 1 unit. The total iteration cost becomes:

- Baseline: Search (1) + Teach (1) + Audit (1) + Grow (1) + Verify (1) + Epistemic Audit (1) = **6 units**
- With one regrow: +2 (regrow + re-verify + re-epistemic) = **8 units**
- With max fixes: capped by `max_fix_attempts` per task

### 5.4 Iteration Directory Structure (Updated)

```
results/iteration_{N}/
├── search_output.json
├── teach_output.json
├── audit_output.json
├── audit_report.json          # quality audit
├── grow_output.json
├── verify_output.json
├── epistemic_audit_report.json  # ← NEW
├── mingwu_result.json
├── novelty_result.json
└── exceptions.json
```

---

## 6. Worker Template Changes

### 6.1 Teach Agent Template Additions

Add the following section after the existing "Output" schema in `teach_task_template.md`:

```markdown
## Epistemic Metadata Requirements (NEW)

Your output MUST include an `epistemic_metadata` object at the top level.

### Step 1: Extract Claims
After generating D1–D4, extract every non-trivial claim into `epistemic_metadata.claims[]`:
- D1: The analogy itself is NOT a claim; any factual statement embedded in it IS.
- D2: Each step's underlying principle IS a claim.
- D3: Every formal definition, equation, and boundary condition IS a claim.
- D4: Every boundary condition and failure mechanism IS a claim.

### Step 2: Map Justification
For each claim, trace back to `search_results.json`:
- If directly supported by a search result → `derived_from_source`, cite source.
- If synthesized from multiple results → `inferred_from_multiple`, cite all sources.
- If derived from agent reasoning → `agent_reasoning`, show reasoning chain.
- If no source supports it → `tentative_hypothesis` or `unverified_assertion`, mark low confidence.

### Step 3: Generate Falsification Conditions
For each claim, ask: "What concrete observation or experiment would prove this wrong?"
- Must be specific, not vague ("someone proves it's wrong" is invalid).
- Must be at least 1 per claim.

### Step 4: Build Ignorance Map
After finishing D1–D4, honestly assess:
- What do you still not know about this concept? (`known_unknowns`)
- What might you be missing without realizing it? (`unknown_unknowns_suspected`)
- Map each `known_unknown` to the claim(s) it affects.

### Step 5: Method Reflection
Record:
- All search queries you used (including those that yielded poor results)
- Every source you evaluated, with a credibility/quality assessment
- Key reasoning decisions (why you chose one formulation over another)
```

### 6.2 Grow Agent Template Additions

Add the following section after the existing "Output" schema in `grow_task_template.md`:

```markdown
## Epistemic Metadata Requirements (NEW)

Your output MUST include an `epistemic_metadata` object.

### Step 1: Epistemic Gap Classification
For each gap, classify its epistemic nature:
- **Epistemic Gap**: A gap caused by lack of knowledge about the truth of a claim (e.g., "We assert X but have no source for it")
- **Expressive Gap**: A gap caused by poor explanation, not by missing knowledge (e.g., "D1 analogy is confusing but structurally sound")

### Step 2: Inherit Previous Ignorance Map
Read `previous_grow.epistemic_metadata.ignorance_map` (if exists) and:
- Mark resolved known_unknowns as `resolved: true`
- Carry forward unresolved ones
- Add newly discovered known_unknowns from this iteration's audit

### Step 3: Epistemic Strategy
In your `strategy` field, include an `epistemic_component`:
- If gaps are epistemic → "Search for authoritative sources on [topic]; re-verify claims after"
- If gaps are expressive → "Reformulate D1 using [different analogy framework]; no external search needed"

### Step 4: Search Query Quality
When generating `query` for `external_knowledge_required` gaps, include in `epistemic_metadata.method_reflection`:
- Why this query should yield the missing knowledge
- What source type you expect (peer-reviewed, textbook, technical documentation)
```

### 6.3 Verify Agent Template Additions

Add the following section after the existing "Output" schema in `verify_task_template.md`:

```markdown
## Epistemic Metadata Requirements (NEW)

Your output MUST include an `epistemic_metadata` object.

### Step 1: Validate Claim Justifications
Read `teach_output.json` and check every claim in `epistemic_metadata.claims[]`:
- Does the justification actually support the claim text?
- Is the source reliability assessment reasonable?
- Is the reasoning chain logically valid?

### Step 2: Source Evaluation
For each source cited in teach-output's `epistemic_metadata`:
- Verify the URL is reachable (do not fetch full content unless needed)
- Assess whether the source type matches the claimed reliability (e.g., arXiv preprint ≠ peer-reviewed)
- Flag any `peer_reviewed_multiple` claims that only cite one source

### Step 3: Falsification Condition Quality
Check every `falsification_conditions` entry:
- Is it concrete and testable? ("Prove quantum mechanics wrong" is invalid)
- Is it relevant to the claim? ("The sun explodes" is irrelevant to a math claim)
- Are there at least 1 per claim?

### Step 4: Ignorance Map Verification
Verify that `teach_output.epistemic_metadata.ignorance_map`:
- Is not empty (an agent claiming zero ignorance is epistemically suspicious)
- Maps `known_unknowns` to actual claims
- Includes `unknown_unknowns_suspected` (absence of this suggests overconfidence)

### Step 5: Confidence Calibration
Adjust `confidence` scores based on epistemic metadata:
- Deduct 0.1 if `unverified_assertion` claims exist with high confidence_source
- Deduct 0.1 if `known_unknowns` are empty
- Deduct 0.1 if `falsification_conditions` are vague or missing
- Add 0.05 if epistemic metadata is exceptionally thorough (≥80% claim coverage, all claims justified)

### Step 6: Cross-Time Epistemic Consistency
When checking cross-temporal consistency, also verify:
- Do claims from iteration N-1 still have the same justification in iteration N?
- Has the `ignorance_map` shrunk appropriately (some things should be resolved)?
- Are new `unknown_unknowns_suspected` being discovered (sign of deepening understanding)?
```

### 6.4 Search Agent Template Additions

Create or update `search_task_template.md` with:

```markdown
## Epistemic Metadata Requirements (NEW)

Your output MUST include an `epistemic_metadata` object.

### Step 1: Source Quality Assessment
For each result in `results[]`, add an `epistemic_assessment`:
```json
{
  "source": "...",
  "url": "...",
  "epistemic_assessment": {
    "credibility": "peer_reviewed|authoritative|popular|unknown",
    "recency": "current|dated|unknown",
    "bias_detected": "none|possible|significant",
    "domain_match": "exact|related|tangential"
  }
}
```

### Step 2: Query Reflection
In `epistemic_metadata.method_reflection`:
- List every query executed, even those returning zero results
- Note which queries were broad vs. precise
- Reflect on query quality: "Query Q1 was too broad; Q2 was precise but missed recent papers"

### Step 3: Synthesis Transparency
In `synthesis`, explicitly state:
- Which claims in the synthesis are directly supported by results
- Which are inferred from multiple results
- Which are your own reasoning beyond the sources
```

### 6.5 Epistemic Auditor Template (New)

Create `agents/epistemic_audit_task_template.md`:

```markdown
# Epistemic Auditor Agent Task Template

## Objective
Independently verify the epistemic rigor of all worker outputs from the current iteration. Assess whether the agents' claims are justified, whether ignorance is honestly mapped, and whether falsification conditions are valid.

## Input

Read from: `{input_path}`

Format: JSON containing paths to all iteration outputs:
```json
{
  "iteration": 1,
  "teach_output_path": "...",
  "audit_output_path": "...",
  "grow_output_path": "...",
  "verify_output_path": "...",
  "search_output_path": "..."
}
```

## Output

Write to: `{output_path}`

Format: `epistemic_audit_report.json` (see Epistemic Design §3.4)

## Audit Procedure

### Phase 1: Structural Checks (E1–E10)
For each worker output, verify minimum standards E1–E10. Use `epistemic_validator.py` if available.

### Phase 2: Claim Extraction and Coverage Check
- Extract non-trivial claims from the worker output using pattern matching
- Compare against `epistemic_metadata.claims[]`
- Compute `claim_coverage` score

### Phase 3: Justification Quality Assessment
- For each claim, verify that the justification actually supports the claim text
- Check that source reliability assessments are reasonable
- Flag `unverified_assertion` claims masquerading as `derived_from_source`

### Phase 4: Falsification Condition Validity
- Check each `falsification_condition` for concreteness and relevance
- Reject vague conditions like "someone proves it's wrong"
- Accept conditions like "Experimental measurement of X yields value outside [a, b]"

### Phase 5: Ignorance Map Sanity
- Verify `known_unknowns` is non-empty (zero ignorance is a red flag)
- Verify `unknown_unknowns_suspected` exists (absence suggests overconfidence)
- Check that `known_unknowns` map to actual claims

### Phase 6: Method Reflection Review
- Verify `search_queries_used` lists actual queries
- Verify `sources_evaluated` matches sources in the output
- Check `reasoning_chain` for logical gaps

### Phase 7: Score and Verdict
Compute `epistemic_health_score` and assign verdict per rubric (§3.3).

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}`
2. Valid JSON
3. All E1–E10 checks performed and recorded in `checks` object
4. `status` is one of the four valid enum values
5. `epistemic_health_score` is float in [0.0, 1.0]
6. `epistemic_issues[]` is non-empty if status is not EPISTEMICALLY_SOUND
7. `action` is one of PROCEED_WITH_WARNING, REGROW, REJECT
```

---

## Appendix A: Epistemic Metadata Example (Complete)

```json
{
  "concept_id": "quantum_entanglement",
  "iteration": 3,
  "d1": "Two entangled particles are like two coins that always land on opposite sides, no matter how far apart you flip them...",
  "d2": ["Prepare a pair of entangled photons...", "Measure polarization of photon A...", "Instantly know polarization of photon B..."],
  "d3": {
    "definition": "A quantum state of two or more particles where the state of each particle cannot be described independently...",
    "notation": "|Ψ⟩ = (1/√2)(|00⟩ + |11⟩)",
    "confidence": "high"
  },
  "d4": {
    "boundaries": [
      {
        "condition": "When particles decohere due to environmental interaction",
        "counter_example": "A macroscopic dust grain does not exhibit entanglement because decoherence time is ~10^-30s",
        "failure_mechanism": "Environmental interactions cause the density matrix to become diagonal in the pointer basis"
      }
    ]
  },
  "epistemic_metadata": {
    "version": "1.0",
    "generated_at": "2026-04-28T11:43:00+08:00",
    "worker_type": "teach-agent",
    "claims": [
      {
        "claim_id": "c-001",
        "text": "Bell's theorem proves no local hidden-variable theory can reproduce all quantum mechanical predictions",
        "location": "d3.definition",
        "justification": {
          "type": "derived_from_source",
          "sources": [
            {
              "source_id": "s-001",
              "url": "https://arxiv.org/abs/quant-ph/0402009",
              "snippet": "Bell's inequality is violated by quantum mechanics, ruling out local hidden variable theories",
              "reliability": "peer_reviewed",
              "accessed_at": "2026-04-28T10:00:00+08:00"
            }
          ],
          "reasoning_chain": [
            "Source is peer-reviewed review paper on Bell's theorem",
            "Source explicitly states Bell's theorem rules out local hidden variables",
            "Claim is a direct paraphrase of source conclusion"
          ]
        },
        "confidence_source": "peer_reviewed_single",
        "falsification_conditions": [
          "A loophole-free Bell experiment fails to violate Bell inequalities",
          "A local hidden variable theory is constructed that reproduces all QM predictions"
        ],
        "ignorance_notes": "Assumes standard quantum mechanics. Does not address superdeterminism or retrocausality interpretations.",
        "domain_expert_would_agree": true
      },
      {
        "claim_id": "c-002",
        "text": "Decoherence time for a macroscopic dust grain is approximately 10^-30 seconds",
        "location": "d4.boundaries[0].counter_example",
        "justification": {
          "type": "tentative_hypothesis",
          "sources": [],
          "reasoning_chain": [
            "Agent estimated based on knowledge of decoherence scaling with mass",
            "No direct source found for this specific number",
            "Order of magnitude likely correct but exact value unverified"
          ]
        },
        "confidence_source": "speculative",
        "falsification_conditions": [
          "Experimental measurement of decoherence time for a 1-micron dust grain yields a value > 1 second"
        ],
        "ignorance_notes": "Exact value is order-of-magnitude estimate. Actual decoherence time depends on environment temperature and coupling strength.",
        "domain_expert_would_agree": false
      }
    ],
    "method_reflection": {
      "search_queries_used": [
        {
          "query": "Bell's theorem proof assumptions",
          "purpose": "Verify D3 formal definition completeness",
          "results_count": 8,
          "quality_assessment": "high"
        },
        {
          "query": "decoherence time macroscopic objects",
          "purpose": "Find D4 counter-example data",
          "results_count": 3,
          "quality_assessment": "low"
        }
      ],
      "sources_evaluated": [
        {
          "source_id": "s-001",
          "url": "https://arxiv.org/abs/quant-ph/0402009",
          "evaluation": {
            "credibility": "high",
            "recency": "dated",
            "bias_detected": "none",
            "domain_match": "exact"
          },
          "used_for_claims": ["c-001"]
        }
      ],
      "reasoning_chain": {
        "summary": "Searched for formal definition → found arXiv review → extracted Bell theorem statement → searched for decoherence data → found qualitative discussions but no quantitative macroscopic values → constructed order-of-magnitude estimate for D4",
        "key_decisions": [
          {
            "decision": "Used Bell inequality formulation from arXiv review rather than original 1964 paper",
            "alternatives_considered": ["Bell 1964 original", "CHSH inequality formulation"],
            "why_chosen": "Review paper presents more pedagogically clear formulation suitable for D3"
          }
        ]
      }
    },
    "ignorance_map": {
      "known_unknowns": [
        {
          "id": "ku-001",
          "question": "What is the exact decoherence time for a 1-micron dust grain at room temperature?",
          "why_unknown": "Search results only provided qualitative scaling laws, no specific calculation for macroscopic objects",
          "impact_on_claims": ["c-002"],
          "would_change_conclusion": "might_change",
          "blocking": false
        },
        {
          "id": "ku-002",
          "question": "Does superdeterminism allow local hidden variables to evade Bell's theorem?",
          "why_unknown": "Search focused on standard interpretations; superdeterminism is a niche topic not encountered",
          "impact_on_claims": ["c-001"],
          "would_change_conclusion": "would_not_change",
          "blocking": false
        }
      ],
      "unknown_unknowns_suspected": [
        {
          "id": "uu-001",
          "suspicion_basis": "D3 uses standard Copenhagen interpretation formalism. No sources discussed QBism, relational QM, or Everettian interpretations. Interpretational bias possible.",
          "mitigation": "Flag for future search on quantum interpretations and their impact on entanglement formalism.",
          "priority": "low"
        }
      ],
      "ignorance_score": 0.35
    },
    "epistemic_health_score": 0.68
  }
}
```

## Appendix B: Epistemic Validator Module Design (`epistemic_validator.py`)

```python
#!/usr/bin/env python3
"""Machine-verifiable epistemic checks for FCH worker outputs.

Provides functions E1–E10 as pure, stateless checks.
Can be called by epistemic-auditor-agent or orchestrator.
"""

import json
from pathlib import Path
from typing import Dict, List, Any

# ── constants ──────────────────────────────────────────────────────

JUSTIFICATION_TYPES = {
    "derived_from_source", "inferred_from_multiple", "agent_reasoning",
    "tentative_hypothesis", "unverified_assertion"
}

CONFIDENCE_ORDINAL = {
    "peer_reviewed_multiple": 5,
    "peer_reviewed_single": 4,
    "authoritative": 3,
    "heuristic": 2,
    "speculative": 1,
    "none": 0,
}

RELIABILITY_ORDINAL = {
    "peer_reviewed": 3,
    "authoritative": 2,
    "popular": 1,
    "unknown": 0,
}

EPISTEMIC_STATUSES = {
    "EPISTEMICALLY_SOUND", "EPISTEMICALLY_DEFICIENT",
    "EPISTEMICALLY_WEAK", "EPISTEMICALLY_HOLLOW"
}

# ── check functions ────────────────────────────────────────────────

def check_e1_metadata_present(data: dict) -> bool:
    """E1: epistemic_metadata object exists."""
    return isinstance(data.get("epistemic_metadata"), dict)

def check_e2_claim_coverage(data: dict, auditor_detected: int) -> float:
    """E2: claims[] covers at least 80% of auditor-detected claims."""
    em = data.get("epistemic_metadata", {})
    claims = em.get("claims", [])
    if auditor_detected == 0:
        return 1.0 if len(claims) == 0 else 0.0
    return min(1.0, len(claims) / auditor_detected)

def check_e3_reasoning_chains(data: dict) -> bool:
    """E3: every claim has reasoning_chain with ≥2 steps."""
    em = data.get("epistemic_metadata", {})
    for c in em.get("claims", []):
        chain = c.get("justification", {}).get("reasoning_chain", [])
        if len(chain) < 2:
            return False
    return True

def check_e4_falsification_present(data: dict) -> float:
    """E4: %claims with ≥1 falsification_condition."""
    em = data.get("epistemic_metadata", {})
    claims = em.get("claims", [])
    if not claims:
        return 0.0
    good = sum(1 for c in claims if len(c.get("falsification_conditions", [])) >= 1)
    return good / len(claims)

def check_e5_no_bogus_assertions(data: dict) -> bool:
    """E5: no unverified_assertion with confidence > speculative."""
    em = data.get("epistemic_metadata", {})
    for c in em.get("claims", []):
        jtype = c.get("justification", {}).get("type")
        conf = c.get("confidence_source", "none")
        if jtype == "unverified_assertion" and CONFIDENCE_ORDINAL.get(conf, 0) > 1:
            return False
    return True

def check_e6_known_unknowns(data: dict) -> bool:
    """E6: ignorance_map.known_unknowns exists (may be empty but must exist)."""
    em = data.get("epistemic_metadata", {})
    im = em.get("ignorance_map", {})
    return "known_unknowns" in im

def check_e7_search_queries(data: dict) -> bool:
    """E7: method_reflection.search_queries_used exists."""
    em = data.get("epistemic_metadata", {})
    mr = em.get("method_reflection", {})
    return "search_queries_used" in mr

def check_e8_health_score(data: dict) -> float:
    """E8: epistemic_health_score >= 0.60."""
    em = data.get("epistemic_metadata", {})
    return em.get("epistemic_health_score", 0.0)

def check_e9_sources_evaluated(data: dict, worker_type: str) -> bool:
    """E9: sources_evaluated exists for teach/verify/search workers."""
    if worker_type not in ("teach-agent", "verify-agent", "search-agent"):
        return True  # not required for audit/grow
    em = data.get("epistemic_metadata", {})
    mr = em.get("method_reflection", {})
    return "sources_evaluated" in mr

def check_e10_expert_agreement(data: dict) -> bool:
    """E10: domain_expert_would_agree is boolean for all claims."""
    em = data.get("epistemic_metadata", {})
    for c in em.get("claims", []):
        val = c.get("domain_expert_would_agree")
        if not isinstance(val, bool):
            return False
    return True

# ── composite scoring ──────────────────────────────────────────────

def compute_health_score(data: dict, auditor_detected_claims: int) -> dict:
    """Compute epistemic_health_score and breakdown."""
    em = data.get("epistemic_metadata", {})
    claims = em.get("claims", [])

    # claim_coverage
    if auditor_detected_claims == 0:
        claim_coverage = 1.0
    else:
        claim_coverage = min(1.0, len(claims) / auditor_detected_claims)

    # justification_quality
    if claims:
        avg_conf = sum(CONFIDENCE_ORDINAL.get(c.get("confidence_source", "none"), 0) for c in claims) / len(claims)
        justification_quality = avg_conf / 5.0
    else:
        justification_quality = 0.0

    # falsification_present
    if claims:
        fals_present = sum(1 for c in claims if len(c.get("falsification_conditions", [])) >= 1) / len(claims)
    else:
        fals_present = 0.0

    # ignorance_explicitness
    ku = em.get("ignorance_map", {}).get("known_unknowns", [])
    uu = em.get("ignorance_map", {}).get("unknown_unknowns_suspected", [])
    ignorance_explicitness = 1.0 if (ku or uu) else 0.0

    # source_quality
    sources = em.get("method_reflection", {}).get("sources_evaluated", [])
    if sources:
        avg_rel = sum(RELIABILITY_ORDINAL.get(s.get("evaluation", {}).get("credibility", "unknown"), 0) for s in sources) / len(sources)
        source_quality = avg_rel / 3.0
    else:
        source_quality = 0.0

    score = (
        0.25 * claim_coverage +
        0.25 * justification_quality +
        0.20 * fals_present +
        0.15 * ignorance_explicitness +
        0.15 * source_quality
    )

    return {
        "epistemic_health_score": round(score, 2),
        "score_breakdown": {
            "claim_coverage": round(claim_coverage, 2),
            "justification_quality": round(justification_quality, 2),
            "falsification_present": round(fals_present, 2),
            "ignorance_explicitness": round(ignorance_explicitness, 2),
            "source_quality": round(source_quality, 2),
        }
    }

# ── full audit ─────────────────────────────────────────────────────

def run_epistemic_audit(data: dict, worker_type: str, auditor_detected_claims: int = 0) -> dict:
    """Run all E-checks and return a complete audit result dict."""
    checks = {
        "e1_metadata_present": check_e1_metadata_present(data),
        "e2_claim_coverage": round(check_e2_claim_coverage(data, auditor_detected_claims), 2),
        "e3_reasoning_chains": check_e3_reasoning_chains(data),
        "e4_falsification_present": round(check_e4_falsification_present(data), 2),
        "e5_no_bogus_assertions": check_e5_no_bogus_assertions(data),
        "e6_known_unknowns": check_e6_known_unknowns(data),
        "e7_search_queries": check_e7_search_queries(data),
        "e8_health_score": check_e8_health_score(data),
        "e9_sources_evaluated": check_e9_sources_evaluated(data, worker_type),
        "e10_expert_agreement": check_e10_expert_agreement(data),
    }

    health = compute_health_score(data, auditor_detected_claims)
    score = health["epistemic_health_score"]

    # Determine status
    if score >= 0.90:
        status = "EPISTEMICALLY_SOUND"
        action = "PROCEED_WITH_WARNING"
    elif score >= 0.70:
        status = "EPISTEMICALLY_DEFICIENT"
        action = "PROCEED_WITH_WARNING"
    elif score >= 0.50:
        status = "EPISTEMICALLY_WEAK"
        action = "REGROW"
    else:
        status = "EPISTEMICALLY_HOLLOW"
        action = "REJECT"

    # Override to REJECT if critical structural checks fail
    if not checks["e1_metadata_present"] or not checks["e5_no_bogus_assertions"]:
        status = "EPISTEMICALLY_HOLLOW"
        action = "REJECT"

    return {
        "status": status,
        "action": action,
        "checks": checks,
        "epistemic_health_score": score,
        "score_breakdown": health["score_breakdown"],
    }
```

---

*Document version: 1.0*
*Design status: Ready for implementation*
*Breaking changes: None*
*Estimated implementation effort: ~4 hours (templates) + ~2 hours (validator module) + ~2 hours (orchestrator wiring) + ~2 hours (integration testing)*
