---
tag: [LEGACY]
load_when: "历史归档与废弃文档"
---

# Feynman Cognition Harness — Change Log

> Record of all architectural changes, version history, and optimization decisions.
> Main documentation (README.md, SKILL.md) contains ONLY current-state information.

## v3.2.0 — Auto-Deepening (2026-04-28)

- **Internal Ming Wu trigger**: 6-condition automatic assessment (confidence, BSS, problems, contradictions, emotion, convergence)
- **Novelty monitoring**: Jaccard-based repetition detection; stuck when novelty < 0.15
- **Auto-search trigger**: External knowledge fetch after 3 stuck iterations or novelty threshold breach
- **Self-test on code change**: Automatic import validation after every file modification

## v3.1.0 — Phase 4: Fusion Architecture (2026-04-27)

Fuses v3.0 process framework with v2.1 problem mechanisms.
- **TriggerDaemon (Layer 0)**: Standardize any wake-up signal (time/info/failure/propagation) into canonical TriggerEvent. Priority queue with deduplication.
- **MetacognitiveLayer (Layer 1)**: Deepen vs Solidify decision based on epistemic emotion, confidence trend, failure triggers, external info.
- **GenesisLayer (Layer 2)**: D2→D3→D1→D4 generation with strict order enforcement. D1 built from D3, D4 problematizes.
- **VerificationLayer (Layer 3)**: Cross-temporal audit — compare current version with all historical versions. Checks depth increment, analogy stability, mapping consistency, pseudo-mapping detection.
- **ConsolidationLayer (Layer 4)**: Store verified versions to version_stack. Update learning_curve. Exponential backoff scheduling (success: interval doubles; failure: reset to base). Trigger cascade propagation on successful deepening.
- **GlobalIntegrationDaemon (Layer 6)**: Cross-concept coherence scan — detect orphan concepts, hub overload, missing bridges, and cross-concept contradictions. Generate inspiration events. Not review (AI doesn't forget), but "dreaming": global structure scan + cross-concept insight generation.
- **Orchestrator v3.2**: Enhanced `run_v3()` unified entry point. Backward-compatible `run()` preserved.
- **CascadeEngine v3.2**: Propagation events pushed to TriggerDaemon queue. High-severity contradictions trigger failure events.
- **ContradictionDetector v3.2**: Push high-severity contradictions to TriggerDaemon as failure events.
- **AuditEngine v3.2**: New `_check_mapping_consistency()` + `_check_pseudo_mapping()` + `audit_for_verification()` interface.
- **ConfidenceCalculator v3.2**: `get_confidence_trend()` + `batch_trend_report()` for metacognitive decision support.
- **LatticeManager v3.2 schema**: `consolidation_status` field added (pending → consolidated → needs_revision).

## v2.1.0 — Phase 2: Cognitive-State Tracking (2026-04-26)

- **LatticeManager schema extension**: `epistemic_emotion`, `attention_focus`, `consolidation_status`
- **Orchestrator consolidation hooks**: Converged concepts marked for 24h delayed review (simulates offline memory consolidation)
- **Epistemic emotion tracking**: Confusion/curiosity/satisfaction states drive iteration pacing
- **Attention focus update**: Contradiction detection triggers ACC-mediated attention reorienting (模拟前扣带皮层)
- **config.json alignment**: Updated D1 constraints, gap_strategies (6 total), audit_checks (6 total), d1_validation mode

## v2.0 — Phase 1: Oscillation & Metaphor Depth (2026-04-25 → 04-26)

- **D1Validator rewrite**: From "ZERO technical terms" to "MetaphorQualityValidator" — structural fingerprint + term scaffolding + metaphor completeness
- **TeachEngine D1 v2**: MASTER ANALOGY + PRINCIPLE MAP + BOUNDARY CONDITIONS + PRE-LOAD INVENTORY + HONESTY GAPS
- **AuditEngine expansion**: Added `oscillation_stability` + `compression_fidelity` checks
- **GrowEngine expansion**: Added `metaphor_reframe` + `embodied_reencode` strategies
- **ContradictionDetector**: New module — 5-type cross-level contradiction scanning
- **Orchestrator Phase 0**: Oscillation spiral initialization (D1_quick → D4 → D1_reconstruct)
- **CognitiveClassifier v2**: SemanticClusterEngine with synonym expansion + emergent clustering + AHA moment detection
- **CascadeEngine v2**: Decoupled trigger (LatticeManager-level) + SemanticDiff + CascadeDaemon
- **MetacognitiveMemory extension**: `oscillation_count`, `d1_structure_fingerprint`, `preferred_metaphor_family`

## v1.2 — Search & Validation (pre-2026-04-24)

- Search tool integration (kimi_search, web_search)
- External claim validation
- Multi-dimensional confidence calculation

## v1.0 — Initial Release

- Teach → Audit → Grow cycle
- D1-D4 explanation framework
- Concept Lattice persistence
- Cascade dependency propagation

## v3.3.0 — Ralph-Style Harness (2026-04-29 → 2026-05-01)

**核心变更**:
- 架构范式迁移: 从 monolithic self-driving loop → stateful coordinator + subagent outsourcing
- 新增 harness/ 目录，包含 8 个核心模块 + 7 个子 agent 模板
- 引入 Ralph Loop 8步流程: Search → Teach → Audit → Grow → Verify → Consolidate → Quality Audit → Termination
- 新增 RTDF (Routing + Teaching + Deepening + Formalization) 路由分类器 (`routing_classifier.py`)
- 新增 T3 可执行性验证层 (`t3_executor.py`): Tier 1 思想实验 + Tier 2 形式工具适配 (Agda/Coq/Lean)
- 新增 Calibration Engine (`calibration_engine.py`): 基于历史 UCC 记录的 isotonic regression 阈值校准
- 新增 Analogy Selector (`analogy_selector.py`): 多域类比矩阵管理 + 断裂检测 + reframe 协议
- 新增 Termination Checker (`termination_checker.py`): 收益递减/循环边界/累积风险/深度预算 四维度终止评估
- scripts/ 目录降级为 legacy library，6 个死代码文件移入 archive/，5 个模块加 deprecated 注释
- 移除 CSED-CLIF 7层架构中的后台扫描/级联传播/全局集成 daemon
- 独立审计: 从纸老虎 (scripts/independent_auditor.py NotImplementedError) 变为真实子 agent spawn (harness/orchestrator._spawn_auditor)
- UCC (Unified Cognition Cycle) 记录机制引入 (stub，待补全)

## v3.5.0 — FCMS + DREAM + Cascade Refactor (2026-05-01 → 2026-05-03)

**核心变更**:
- **FCMS (Feynman Cognition Meta-System)** 引入: L1 信号捕获 → L2 评估 → L3 反思 → L4 调节四层元认知闭环
  - `fcms/evaluator.py`: 8维度评分 (Clarity/Depth/Consistency/Novelty/Stability/Actionability/Coverage/Confidence)
  - `fcms/reflector.py`: 即时反思 + 批量反思 + 调节建议
  - `fcms/regulator.py`: 阈值边界保护 + 预算储备 + 策略推荐
- **DREAM 机制** (原 GlobalIntegrationDaemon 重构): 每日深夜自动全局整合
  - 模式发现 / 矛盾审计 / MECE 检查 / 结构优化
  - cron 定时触发 (0 2 * * *)
  - `harness/dream_engine.py` + `harness/dream_trigger.py`
- **Cascade Engine 重构**: 从单向下游检测 → 双向检测 + 多层间接影响 + gap list 输出
  - 上游依赖检测 (`_find_upstream_dependencies`)
  - 间接影响检测 (`_find_indirect_impacts`)
  - 输出改为 `cascade_gaps` (gap list 而非直接入队)
- **Consolidate 职责澄清**: 从"合并 D1-D4 / 解决矛盾"改为纯归档
  - 只记录状态引用 + 元数据 + 版本栈
  - 修改 D1-D4 的权力唯一归 Teach
  - 持久 gap ≥3 轮 → `structural_residues`
- **Teach 模板增强**: 新增 `teach_mode` (fresh/cascade_update) + `cascade_context` + `bridge_concepts` 输出字段
- **Grow 模板增强**: 新增主动搜索 (Phase 0) + 根因分析 (Phase 2) + `teach_candidates` / `intra_node_fixes` 输出
- **Audit 模板增强**: 新增 Output Validation Rules + Audit3+ 稳定性检测
- **Self-Awareness Coach 实际化**: 条件化实现 (HAS_SESSIONS_SPAWN)，生产环境自动切换
- **Cross-concept 术语统一层**: 4类检测 (definition mismatch / analogy collision / boundary violation / dependency drift)
- 版本号全局统一: v3.3 → v3.5 (SKILL.md / README.md / config.json / config.yaml / audit_subagent_prompt.md)

**5个漏洞修复**:
1. 阈值校准 — 从 hardcoded 0.90 到自适应 isotonic/logistic 回归
2. 类比迁移风险 — 多域类比矩阵 + breakage 检测 + reframe 协议
3. T3 可执行性缺口 — 6模块4检查思想实验 + 3工具适配器
4. Zeno 效应 — 4条件终止评估器 + 元认知摘要
5. 路由过简化 — 5-band spectrum + FCH-first-then-BDD fallback
