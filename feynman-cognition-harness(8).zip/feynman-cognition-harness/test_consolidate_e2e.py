#!/usr/bin/env python3
"""End-to-end validation for Consolidate v3.5 knowledge solidification.

Mock flow:
1. Create mock grow_output with new_node + merge suggestions
2. Create mock consolidate_output referencing it
3. Call orchestrator.ingest_result() for consolidate
4. Verify lattice files are correctly updated
"""

import json
import os
import sys
import tempfile
from pathlib import Path

# Add harness to path
sys.path.insert(0, "/root/.openclaw/workspace/skills/feynman-cognition-harness/harness")

from orchestrator import FeynmanOrchestrator


def setup_mock_environment(base_dir: str) -> dict:
    """Create mock output files for one iteration."""
    base = Path(base_dir)
    iter_dir = base / "results" / "iteration_1"
    iter_dir.mkdir(parents=True, exist_ok=True)

    # 1. Mock grow_output with new_node + merge suggestions + dependency_updates
    grow_output = {
        "concept": "backpropagation",
        "teach_candidates": [
            {
                "concept_id": "gradient_descent_momentum",
                "is_new_node": True,
                "prerequisite_concepts": ["gradient_descent", "exponential_moving_average"],
                "mode": "fresh",
            },
            {
                "concept_id": "relu_activation",
                "is_new_node": True,
                "prerequisite_concepts": ["activation_function"],
                "mode": "fresh",
            },
            {
                "concept_id": "backpropagation",
                "is_new_node": False,
                "prerequisite_concepts": ["chain_rule"],
            },
        ],
        "merge_suggestions": [
            {
                "primary_id": "backpropagation",
                "secondary_id": "反向传播",
                "confidence": 0.92,
                "rationale": "Synonym concept; merge to maintain canonical English identifier",
            },
            {
                "primary_id": "gradient_descent",
                "secondary_id": "gd",
                "confidence": 0.72,  # Below threshold — should be rejected
                "rationale": "Abbreviation merge",
            },
        ],
        "dependency_updates": [
            {
                "source_concept_id": "backpropagation",
                "target_concept_id": "chain_rule",
                "relation_type": "prerequisite",
                "confidence": 0.95,
                "bidirectional": False,
                "rationale": "Backpropagation fundamentally depends on chain rule",
            },
        ],
        "identified_gaps": [],
    }
    grow_path = iter_dir / "grow_output.json"
    with open(grow_path, "w") as f:
        json.dump(grow_output, f, indent=2)

    # 2. Pre-create some existing lattice nodes for merge testing
    lattice_dir = base.parent.parent / "knowledge-lattice" / "concepts"
    lattice_dir.mkdir(parents=True, exist_ok=True)

    backprop = {
        "concept_id": "backpropagation",
        "core_id": "backpropagation",
        "status": "learning",
        "version_stack": [
            {"iteration": 1, "timestamp": "2024-01-10T08:00:00+00:00", "depth_increment": 0.3}
        ],
        "dependencies": ["chain_rule", "computational_graph"],
        "downstream_concepts": [],
        "confidence": 0.6,
        "contradictions": [],
        "open_problems": ["vanishing gradient in deep networks"],
        "audit_history": [],
        "learning_curve": [],
        "cascade_flag": False,
        "created_at": "2024-01-10T08:00:00+00:00",
        "updated_at": "2024-01-10T08:00:00+00:00",
        "version": 1,
        "consolidation_status": "initial",
        "epistemic_emotion": "curious",
        "dependency_graph": {
            "chain_rule": {"relation": "prerequisite", "confidence": 0.9},
        },
    }
    (lattice_dir / "backpropagation.json").write_text(json.dumps(backprop, indent=2))

    fanxiang = {
        "concept_id": "反向传播",
        "core_id": "反向传播",
        "status": "learning",
        "version_stack": [
            {"iteration": 2, "timestamp": "2024-01-12T09:00:00+00:00", "depth_increment": 0.2}
        ],
        "dependencies": ["chain_rule"],
        "downstream_concepts": [],
        "confidence": 0.55,
        "contradictions": [],
        "open_problems": ["exploding gradients"],
        "audit_history": [],
        "learning_curve": [],
        "cascade_flag": False,
        "created_at": "2024-01-11T08:00:00+00:00",
        "updated_at": "2024-01-12T09:00:00+00:00",
        "version": 1,
        "consolidation_status": "initial",
        "epistemic_emotion": "curious",
        "dependency_graph": {
            "chain_rule": {"relation": "prerequisite", "confidence": 0.85},
            "automatic_differentiation": {"relation": "related", "confidence": 0.7},
        },
    }
    (lattice_dir / "反向传播.json").write_text(json.dumps(fanxiang, indent=2))

    # Also create a node that references 反向传播 to test redirect
    some_other = {
        "concept_id": "some_other",
        "core_id": "some_other",
        "status": "learning",
        "version_stack": [],
        "dependencies": [],
        "downstream_concepts": [],
        "confidence": 0.5,
        "dependency_graph": {
            "反向传播": {"relation": "depends_on", "confidence": 0.8},
        },
    }
    (lattice_dir / "some_other.json").write_text(json.dumps(some_other, indent=2))

    # Create index.json
    index = {
        "concepts": ["backpropagation", "反向传播", "some_other"],
        "relation_count": 0,
    }
    (lattice_dir / "index.json").write_text(json.dumps(index, indent=2))

    # 3. Mock consolidate_output referencing the grow_output
    consolidate_output = {
        "concept_id": "backpropagation",
        "iteration": 1,
        "source_outputs": {
            "teach_output": str(iter_dir / "teach_output.json"),
            "audit_output": str(iter_dir / "audit_output.json"),
            "grow_output": str(grow_path),
            "verify_output": str(iter_dir / "verify_output.json"),
        },
        "audit_status": {"valid": True, "critical_issues": []},
        "verification_status": {"overall_confidence": 0.75, "cross_time_consistent": True},
        "active_gaps": [],
        "version_stack_entry": {
            "version": 1,
            "timestamp": "2024-01-15T10:30:00+00:00",
            "depth_increment": 0.3,
            "novelty_ratio": 0.5,
            "converged": False,
        },
        "persistent_gaps": [],
        "structural_residues": [],
        "termination_status": "continue",
        "metadata": {
            "dependency_graph_verified": True,
            "dependency_graph_issues": [],
        },
    }
    consolidate_path = iter_dir / "consolidate_output.json"
    with open(consolidate_path, "w") as f:
        json.dump(consolidate_output, f, indent=2)

    return {
        "consolidate_path": str(consolidate_path),
        "grow_path": str(grow_path),
        "lattice_dir": str(lattice_dir),
    }


def run_validation():
    """Run end-to-end validation and print results."""
    # We need a harness dir inside a temp structure that mirrors:
    #   tmp/harness/  → harness dir
    #   tmp/knowledge-lattice/ → lattice dir (since harness.parent.parent resolves here)
    # Actually harness_dir is at skills/feynman-cognition-harness/harness/
    # So harness_dir.parent.parent = skills/ parent = workspace/
    # But we need knowledge-lattice at workspace level.
    # For this test, let's create a fake harness in a temp dir,
    # and pre-create the knowledge-lattice relative to it.
    
    with tempfile.TemporaryDirectory() as tmp:
        # Structure:
        #   tmp/workspace/knowledge-lattice/concepts/
        #   tmp/workspace/skills/feynman-cognition-harness/harness/
        #   tmp/workspace/skills/feynman-cognition-harness/scripts/export_to_graphify.py
        workspace = Path(tmp) / "workspace"
        harness = workspace / "skills" / "feynman-cognition-harness" / "harness"
        harness.mkdir(parents=True, exist_ok=True)
        scripts = workspace / "skills" / "feynman-cognition-harness" / "scripts"
        scripts.mkdir(parents=True, exist_ok=True)
        
        # Copy the real export_to_graphify.py
        real_script = Path("/root/.openclaw/workspace/skills/feynman-cognition-harness/scripts/export_to_graphify.py")
        import shutil
        shutil.copy2(real_script, scripts / "export_to_graphify.py")
        
        # Create state_manager stub if needed
        (harness / "state_manager.py").write_text("""
class StateManager:
    CHECKLIST = ["teach", "audit", "grow", "verify", "consolidate"]
    def load_state(self): return {}
    def save_state(self, s): pass
    def load_progress(self): return {"current_iteration": 1, "completed_steps": []}
    def save_progress(self, p): pass
    def load_budget(self): return {"remaining": 10, "used": 0}
    def save_budget(self, b): pass
    def get_next_task(self, p):
        for t in self.CHECKLIST:
            if t not in p.get("completed_steps", []):
                return t
        return None
    def mark_task_done(self, p, t):
        p.setdefault("completed_steps", []).append(t)
        return p
""")
        
        # Set up mock env using the harness path
        paths = setup_mock_environment(str(harness))
        
        # Initialize orchestrator
        orch = FeynmanOrchestrator(str(harness))
        
        # Simulate ingest_result for consolidate
        state = {}
        progress = {"current_iteration": 1, "completed_steps": []}
        budget = {"remaining": 10, "used": 0}
        
        result = orch.ingest_result(
            task_name="consolidate",
            iteration=1,
            output_path=paths["consolidate_path"],
            state=state,
            progress=progress,
            budget=budget,
        )
        
        # Now inspect results
        print("=" * 60)
        print("Consolidate ingest_result returned:")
        print(json.dumps({k: v for k, v in result.items() if k != "state"}, indent=2, default=str))
        print()
        
        # Check state for new_concepts_created, concepts_merged, graphify_export_status
        print("=" * 60)
        print("STATE after consolidate:")
        print(f"  new_concepts_created: {len(state.get('new_concepts_created', []))}")
        for nc in state.get("new_concepts_created", []):
            print(f"    - {nc['concept_id']}: {nc['status']}")
        print(f"  concepts_merged: {len(state.get('concepts_merged', []))}")
        for mc in state.get("concepts_merged", []):
            print(f"    - {mc['primary_id']} <- {mc['secondary_id']}: {mc['status']} (conf={mc['confidence']})")
        gs = state.get("graphify_export_status", {})
        print(f"  graphify_export_status: triggered={gs.get('triggered')}, success={gs.get('success')}")
        if gs.get("error"):
            print(f"    error: {gs['error']}")
        print()
        
        # Verify lattice files on disk
        lattice_dir = Path(paths["lattice_dir"])
        print("=" * 60)
        print("LATTICE FILES on disk:")
        for f in sorted(lattice_dir.glob("*.json")):
            data = json.loads(f.read_text())
            status = data.get("status", "unknown")
            merged_into = data.get("merged_into", "")
            deps = list(data.get("dependency_graph", {}).keys())
            vcount = len(data.get("version_stack", []))
            opcount = len(data.get("open_problems", []))
            print(f"  {f.name}: status={status}, versions={vcount}, open_problems={opcount}, deps={deps}")
            if merged_into:
                print(f"    merged_into={merged_into}, rationale={data.get('merge_rationale', '')}")
        print()
        
        # Assertions
        errors = []
        
        # 1. New concept gradient_descent_momentum should exist
        if not (lattice_dir / "gradient_descent_momentum.json").exists():
            errors.append("FAIL: gradient_descent_momentum.json not created")
        else:
            gd = json.loads((lattice_dir / "gradient_descent_momentum.json").read_text())
            if gd.get("status") != "learning":
                errors.append(f"FAIL: new node status={gd.get('status')} != learning")
            if gd.get("dependencies") != ["gradient_descent", "exponential_moving_average"]:
                errors.append(f"FAIL: new node deps mismatch: {gd.get('dependencies')}")
        
        # 2. New concept relu_activation should exist
        if not (lattice_dir / "relu_activation.json").exists():
            errors.append("FAIL: relu_activation.json not created")
        
        # 3. Merge: 反向传播 should be merged into backpropagation
        bp = json.loads((lattice_dir / "backpropagation.json").read_text())
        fx = json.loads((lattice_dir / "反向传播.json").read_text())
        
        if fx.get("status") != "merged":
            errors.append(f"FAIL: 反向传播 status={fx.get('status')} != merged")
        if fx.get("merged_into") != "backpropagation":
            errors.append(f"FAIL: 反向传播 merged_into={fx.get('merged_into')}")
        
        # 4. Merge: backpropagation should have merged version_stack (2 entries, deduped)
        if len(bp.get("version_stack", [])) != 2:
            errors.append(f"FAIL: backpropagation version_stack len={len(bp.get('version_stack', []))} != 2")
        
        # 5. Merge: backpropagation should have merged open_problems
        problems = bp.get("open_problems", [])
        if "exploding gradients" not in problems:
            errors.append(f"FAIL: merged open_problems missing 'exploding gradients': {problems}")
        if "vanishing gradient in deep networks" not in problems:
            errors.append(f"FAIL: original open_problems lost: {problems}")
        
        # 6. Merge: dependency_graph should have automatic_differentiation from 反向传播
        if "automatic_differentiation" not in bp.get("dependency_graph", {}):
            errors.append(f"FAIL: merged dependency_graph missing automatic_differentiation: {bp.get('dependency_graph', {}).keys()}")
        
        # 7. Redirect: some_other should reference backpropagation instead of 反向传播
        so = json.loads((lattice_dir / "some_other.json").read_text())
        if "反向传播" in so.get("dependency_graph", {}):
            errors.append(f"FAIL: some_other still references 反向传播: {so.get('dependency_graph', {}).keys()}")
        if "backpropagation" not in so.get("dependency_graph", {}):
            errors.append(f"FAIL: some_other missing backpropagation redirect: {so.get('dependency_graph', {}).keys()}")
        
        # 8. Rejected merge: gd should NOT be merged into gradient_descent
        # (we don't pre-create gradient_descent or gd, so just check state)
        merged_results = state.get("concepts_merged", [])
        rejected = [m for m in merged_results if m.get("status") == "rejected"]
        if len(rejected) != 1 or rejected[0].get("secondary_id") != "gd":
            errors.append(f"FAIL: expected 1 rejected merge for 'gd', got: {rejected}")
        
        # 9. Dependency updates: backpropagation dependency_graph should have chain_rule
        # (it already had one from pre-create, but should still be there)
        if "chain_rule" not in bp.get("dependency_graph", {}):
            errors.append(f"FAIL: dependency update missing chain_rule in backpropagation")
        
        if errors:
            print("=" * 60)
            print("VALIDATION ERRORS:")
            for e in errors:
                print(f"  {e}")
            print(f"\nResult: FAILED ({len(errors)} errors)")
            sys.exit(1)
        else:
            print("=" * 60)
            print("ALL ASSERTIONS PASSED")
            print("Result: SUCCESS")
            return True


if __name__ == "__main__":
    run_validation()
