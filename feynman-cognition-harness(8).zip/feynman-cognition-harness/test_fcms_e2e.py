#!/usr/bin/env python3
"""End-to-end FCMS v3.5 transformation verification."""

import json
import os
import sys
import tempfile
from pathlib import Path

# Add harness to path
HARNESS_DIR = Path(__file__).parent / "harness"
sys.path.insert(0, str(HARNESS_DIR))
sys.path.insert(0, str(HARNESS_DIR / "fcms"))

from orchestrator import FeynmanOrchestrator


def test_fcms_instant_regulation():
    """Test: mock FCMS report with regulation → state thresholds updated."""
    with tempfile.TemporaryDirectory() as tmpdir:
        harness_dir = Path(tmpdir) / "harness"
        harness_dir.mkdir()
        (harness_dir / "results").mkdir()
        (harness_dir / "agents").mkdir()

        # Create minimal required templates
        for task in ["teach", "grow", "search", "audit", "verify", "consolidate"]:
            (harness_dir / "agents" / f"{task}_task_template.md").write_text("# test")

        # Create PRD.md reference path
        ref_dir = harness_dir.parent / "references" / "design"
        ref_dir.mkdir(parents=True)
        (ref_dir / "PRD.md").write_text("# PRD")

        # Enable fcms module in config
        import yaml
        config = {"modules": {"fcms": {"enabled": True}}}
        (harness_dir / "config.yaml").write_text(yaml.dump(config))

        orch = FeynmanOrchestrator(str(harness_dir))

        # Mock state, progress, budget
        state = {"current_concept": "test", "thresholds": {"old": 0.5}}
        progress = {"current_iteration": 1, "completed_steps": [], "next_step": "teach"}
        budget = {"max_spawn": 100, "remaining": 80, "used": 20, "task_allocations": {}}

        # Mock report
        mock_report = {
            "alerts": ["test_alert"],
            "regulation": {
                "thresholds": {"audit_aggregate": 0.75},
                "budget": {"remaining": 70, "task_allocations": {"search": 15}},
                "routing": {"preferred_strategy": "analogy-first"},
            },
            "pitfall_guides": {
                "teach": ["D3 too abstract, start from concrete examples"],
                "grow": ["gap concentrated in D2, increase granularity"],
            },
            "cognitive_patterns": {
                "pattern_A": "analogy_overload_detected",
                "pattern_B": "d3_formalization_weak",
            },
        }

        # Monkey-patch assessor to return mock report
        class MockAssessor:
            def assess(self, **kwargs):
                return mock_report

        # Temporarily replace CognitiveHealthAssessor
        import orchestrator as orch_mod
        original_assessor = orch_mod.CognitiveHealthAssessor
        orch_mod.CognitiveHealthAssessor = MockAssessor

        try:
            orch._run_fcms_check(state, 1, progress, budget)
        finally:
            orch_mod.CognitiveHealthAssessor = original_assessor

        # --- Assertions ---
        errors = []

        # 1. Instant regulation applied
        if state.get("thresholds", {}).get("audit_aggregate") != 0.75:
            errors.append(f"thresholds not updated: {state.get('thresholds')}")
        if budget.get("remaining") != 70:
            errors.append(f"budget remaining not updated: {budget.get('remaining')}")
        if budget.get("task_allocations", {}).get("search") != 15:
            errors.append(f"budget task_allocations not updated: {budget.get('task_allocations')}")
        if state.get("routing_override", {}).get("preferred_strategy") != "analogy-first":
            errors.append(f"routing_override not set: {state.get('routing_override')}")

        # 2. Pitfall guides isolated by task
        if "fcms_pitfalls_teach" not in state:
            errors.append("fcms_pitfalls_teach missing")
        elif len(state["fcms_pitfalls_teach"]) != 1:
            errors.append(f"fcms_pitfalls_teach wrong length: {state['fcms_pitfalls_teach']}")

        if "fcms_pitfalls_grow" not in state:
            errors.append("fcms_pitfalls_grow missing")

        if "fcms_pitfalls_search" in state and state["fcms_pitfalls_search"]:
            errors.append("fcms_pitfalls_search should be empty or absent (no data in mock)")

        # 3. Cognitive patterns accumulated
        patterns = state.get("fcms_cognitive_patterns", [])
        if len(patterns) != 1:
            errors.append(f"patterns not accumulated: {len(patterns)} entries")
        elif patterns[0].get("iteration") != 1:
            errors.append(f"pattern iteration wrong: {patterns[0]}")

        # 4. Alerts preserved
        if "test_alert" not in state.get("fcms_alerts", []):
            errors.append("alerts not preserved")

        return errors


def test_pitfall_injection():
    """Test: run_step injects task-specific pitfalls into state['fcms_pitfalls']."""
    with tempfile.TemporaryDirectory() as tmpdir:
        harness_dir = Path(tmpdir) / "harness"
        harness_dir.mkdir()
        (harness_dir / "results").mkdir()
        (harness_dir / "agents").mkdir()

        for task in ["teach", "grow", "search", "audit", "verify", "consolidate"]:
            (harness_dir / "agents" / f"{task}_task_template.md").write_text("# test")

        ref_dir = harness_dir.parent / "references" / "design"
        ref_dir.mkdir(parents=True)
        (ref_dir / "PRD.md").write_text("# PRD")

        # Enable fcms module
        import yaml
        config = {"modules": {"fcms": {"enabled": True}}}
        (harness_dir / "config.yaml").write_text(yaml.dump(config))

        # Minimal state with pre-existing pitfalls
        state_data = {
            "current_concept": "recursion",
            "fcms_pitfalls_teach": ["D3 too abstract"],
            "fcms_pitfalls_grow": ["gap in D2"],
        }
        progress_data = {"current_iteration": 1, "completed_steps": ["search"], "next_step": "teach"}
        budget_data = {"max_spawn": 100, "remaining": 50, "used": 0}

        # Write state files
        import json
        (harness_dir / "state.json").write_text(json.dumps(state_data))
        (harness_dir / "progress.json").write_text(json.dumps(progress_data))
        (harness_dir / "budget.json").write_text(json.dumps(budget_data))

        # Pre-create search_output.json so search is considered complete
        # and orchestrator will proceed to teach
        results_dir = harness_dir / "results" / "iteration_1"
        results_dir.mkdir(parents=True)
        (results_dir / "search_output.json").write_text(json.dumps({"concept_id": "recursion"}))

        orch = FeynmanOrchestrator(str(harness_dir))
        action = orch.run_step("recursion")

        errors = []

        # Check that state.json now has fcms_pitfalls with teach-specific data
        saved_state = json.loads((harness_dir / "state.json").read_text())
        if "fcms_pitfalls" not in saved_state:
            errors.append("fcms_pitfalls not injected into saved state")
        elif saved_state["fcms_pitfalls"] != ["D3 too abstract"]:
            errors.append(f"fcms_pitfalls wrong content: {saved_state.get('fcms_pitfalls')}")

        # Check that action dict contains the pitfalls in state
        if action.get("state", {}).get("fcms_pitfalls") != ["D3 too abstract"]:
            errors.append(f"action.state.fcms_pitfalls wrong: {action.get('state', {}).get('fcms_pitfalls')}")

        return errors


def test_pitfall_compression():
    """Test: _compress_pitfalls retains recent 3 + cross-round recurrent entries."""
    with tempfile.TemporaryDirectory() as tmpdir:
        harness_dir = Path(tmpdir) / "harness"
        harness_dir.mkdir()
        (harness_dir / "results").mkdir()
        (harness_dir / "agents").mkdir()

        for task in ["teach", "grow", "search", "audit", "verify", "consolidate"]:
            (harness_dir / "agents" / f"{task}_task_template.md").write_text("# test")

        ref_dir = harness_dir.parent / "references" / "design"
        ref_dir.mkdir(parents=True)
        (ref_dir / "PRD.md").write_text("# PRD")

        orch = FeynmanOrchestrator(str(harness_dir))

        # Simulate state with pitfalls from iterations 1, 2, 3, 4
        # Iteration 4 is current; recent = 2,3,4; recurrent = appears in >=2 rounds
        state = {
            "fcms_pitfalls_teach": [
                {"text": "Old from iter1", "first_seen": 1, "rounds": [1]},
                {"text": "Recent from iter2", "first_seen": 2, "rounds": [2]},
                {"text": "Recurrent A", "first_seen": 2, "rounds": [2, 3, 4]},
                {"text": "Recurrent B", "first_seen": 3, "rounds": [3, 4]},
                {"text": "Very recent", "first_seen": 4, "rounds": [4]},
            ]
        }

        orch._compress_pitfalls(state, 4)

        compressed = state.get("fcms_pitfalls_teach", [])
        errors = []

        # Should contain: Recent from iter2, Recurrent A, Recurrent B, Very recent
        # Should NOT contain: Old from iter1 (too old, not recurrent)
        texts = set(compressed)
        if "Old from iter1" in texts:
            errors.append("Old from iter1 should have been pruned")
        if "Recent from iter2" not in texts:
            errors.append("Recent from iter2 should be kept")
        if "Recurrent A" not in texts:
            errors.append("Recurrent A should be kept (recurrent)")
        if "Recurrent B" not in texts:
            errors.append("Recurrent B should be kept (recurrent)")
        if "Very recent" not in texts:
            errors.append("Very recent should be kept")

        return errors


def main():
    all_errors = []

    print("=== FCMS v3.5 E2E Verification ===\n")

    print("[1/3] Testing instant regulation + pitfall isolation + pattern accumulation...")
    errs = test_fcms_instant_regulation()
    if errs:
        all_errors.extend([f"[instant_regulation] {e}" for e in errs])
        print(f"  FAIL: {len(errs)} error(s)")
        for e in errs:
            print(f"    - {e}")
    else:
        print("  PASS")

    print("\n[2/3] Testing pitfall injection in run_step...")
    errs = test_pitfall_injection()
    if errs:
        all_errors.extend([f"[pitfall_injection] {e}" for e in errs])
        print(f"  FAIL: {len(errs)} error(s)")
        for e in errs:
            print(f"    - {e}")
    else:
        print("  PASS")

    print("\n[3/3] Testing pitfall compression logic...")
    errs = test_pitfall_compression()
    if errs:
        all_errors.extend([f"[pitfall_compression] {e}" for e in errs])
        print(f"  FAIL: {len(errs)} error(s)")
        for e in errs:
            print(f"    - {e}")
    else:
        print("  PASS")

    print("\n=== Summary ===")
    if all_errors:
        print(f"FAILED: {len(all_errors)} error(s) total")
        for e in all_errors:
            print(f"  - {e}")
        sys.exit(1)
    else:
        print("ALL TESTS PASSED")
        sys.exit(0)


if __name__ == "__main__":
    main()
