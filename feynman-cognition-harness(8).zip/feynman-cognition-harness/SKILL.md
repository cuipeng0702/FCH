---
name: feynman-cognition-harness
description: >
  Feynman Cognition Harness (FCH) v3.5 — Auto-evolving knowledge system based on
  the Feynman Technique with Ralph Loop distributed architecture. Triggers on any
  concept requiring deep understanding: research tasks, technical explanations,
  knowledge gaps, "帮我研究一下", "explain this", "I don't understand".
tag: [CRITICAL]
---

# Feynman Cognition Harness v3.5

> "What I cannot create, I do not understand." — Richard Feynman

**Auto-evolving knowledge system with Ralph Loop v3.5 distributed architecture.**

---

## When to Use

This skill triggers automatically when an agent needs to deeply understand a concept.

- "帮我研究一下 X" / "explain how X works" / "I don't understand X"
- Any task requiring multi-granularity explanation (intuitive → formal → meta)
- Knowledge gap detection, contradiction resolution, or cross-level triangulation

---

## Quick Navigation (按需加载)

| 你要做什么 | 去哪里找 |
|-----------|----------|
| 了解 Ralph Loop 完整流程 | → `README.md`（Quick Start + 架构概览） |
| 了解设计决策与原理 | → `references/design/` |
| 查看子 Agent 模板 / 接口定义 | → `harness/agents/*.md` + 对应 `.py` docstring |
| 查看历史审计报告 | → `references/audit/` |
| 查看运维配置（cron / UCC） | → `references/ops/` |
| 查看基础理论（认知科学 / 费曼法） | → `references/cognitive-science.md`, `references/feynman-technique.md` |
| 回溯版本历史 | → `archive/` |

---

## Ralph Loop v3.5 — 7 层流水线

```
Search → Teach → Audit → Grow → Verify → Consolidate → Quality Audit → Termination
```

### Entry Points

```python
# 推荐：完整自动循环
from harness.orchestrator import FeynmanOrchestrator
orch = FeynmanOrchestrator()
result = orch.run_v3("concept")

# 单步模式（供外部 agent 调度）
step = orch.run_step()       # 返回 action dict
orch.ingest_result(result)   # 回灌外部 agent 结果
```

### 核心模块（harness/ 运行时）

| 模块 | 职责 |
|------|------|
| `orchestrator.py` | 状态机调度器，管理迭代状态 |
| `routing_classifier.py` | 5-band 路由：FCH-first-then-BDD fallback |
| `calibration_engine.py` | 自适应阈值校准（基于历史 UCC 统计回归） |
| `analogy_selector.py` | 多域类比矩阵 + 断裂检测 + 迁移协议 |
| `t3_executor.py` | T1 结构化思想实验 + T2 形式化工具适配器 |
| `termination_checker.py` | 5 条件终止判断 + 元认知摘要 |
| `state_manager.py` | 运行时状态 I/O（原子写） |
| `cascade_engine.py` | 下游依赖链级联更新（SemanticDiff + 传播） |
| `dream_engine.py` | 夜间全局知识图谱扫描（模式发现 / 全局矛盾 / MECE / 结构优化） |

---

## D1–D4 四层深度

| 深度 | 受众 | 认知模态 | 核心约束 |
|------|------|----------|----------|
| **D1** | 8 岁小孩 | 具身直觉 | 比喻编码深层原理，非简化；每个 D2-D4 原则须有 D1 映射 |
| **D2** | 初中生 | 因果操作 | 基本术语（首次定义），必须有具体例子，展示因果链 |
| **D3** | 大学生 | 形式符号 | 数学形式化，推导允许，标准记号，边界条件 |
| **D4** | 同行专家 | 元反思 | 标注争议、适用边界、开放问题、最新进展 |

> **核心洞见**：D1-D4 不是四层独立解释，而是**跨层映射系统**。层间映射失败处即为知识盲区。

---

## Configuration

`config.yaml` 关键字段：

```json
{
  "skill_name": "feynman-cognition-harness",
  "version": "3.5.0",
  "max_iterations": 5,
  "gap_threshold": 0.1,
  "confidence_threshold": 0.7,
  "cascade_depth_limit": 3,
  "storage_path": "~/.openclaw/workspace/knowledge-lattice/"
}
```

阈值自 v3.5 起为**自适应**（非硬编码），由 `calibration_engine.py` 根据历史 UCC 记录动态校准。冷启动（< 5 条记录）使用 `COLD_START_DEFAULTS`。

---

## Version History

- **v3.5**（当前）：Ralph Loop 分布式架构 — 状态机调度器 + 子 agent 外包
- v3.3-v3.4：级联引擎、元认知框架、结构涌现设计、T3 可执行化
- v3.2：Auto-Deepening — Ming Wu 检查、novelty 监控、自动搜索触发
- v2.1：CSED-CLIF 7 层单体架构

详见 `archive/Log.md`。

---

## 标签总览（按需加载指南）

| 标签 | 含义 | 加载时机 |
|------|------|----------|
| `[CRITICAL]` | 必须阅读。首次加载技能时读取。 | 启动时 |
| `[REFERENCE]` | 按需加载。执行特定子任务时才读取。 | 运行时 |
| `[DESIGN]` | 设计决策文档。解释「为什么这样设计」。 | 修改架构或 debug 深层问题时 |
| `[AUDIT]` | 审计报告。记录已完成审计结论、gap list、修复建议。 | 排查历史问题或执行新审计时 |
| `[LEGACY]` | 历史兼容。不再参与当前主流程，仅回溯版本历史。 | 极少 |
| `[RUNTIME]` | 运行时配置。技能实际执行时读取的模板、配置文件。 | 执行时 |

---

> License: MIT.
