# Ralph Loop 执行手册 (v3.5)

> 本文档面向主 Agent（Orchestrator 调用者）。目标：每一步都能一眼看到"现在在哪、接下来做什么、怎么验收"。

---

## 一、认知循环总览

```
┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐
│  Search │ → │  Teach  │ → │  Audit  │ → │  Grow   │ → │ Verify  │ → │Consolidate│
└─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘
     ↑                                                                            │
     └──────────────────────────────────── 收敛 / 预算耗尽 ←────────────────────┘
```

| 步骤 | 一句话定义 | 核心产出 |
|------|-----------|---------|
| **Search** | 为新概念或当前迭代的 teach 执行全面搜索，建立事实基础 | `search_output.json` |
| **Teach** | 基于搜索结果生成 D1–D4 认知分解（类比→步骤→形式化→边界） | `teach_output.json` |
| **Audit** | 对抗性审计：逐层检查 D1–D4 合规性、跨层一致性、缺口诚实性 | `audit_report.json` |
| **Grow** | 分析审计发现，分类知识缺口，规划下一迭代的修复策略 | `grow_output.json` |
| **Verify** | 三维验证：跨时间一致性、独立复现可行性、外部来源确认 | `verify_output.json` |
| **Consolidate** | 将本轮认知成果写入知识 lattice，执行节点创建/合并/依赖更新/图谱刷新 | `consolidate_output.json` |

---

## 二、主 Agent 快速决策卡

### 当前步骤判断

读取 `progress.json`：
```json
{
  "current_iteration": 1,
  "completed_steps": [],
  "next_step": "teach"
}
```

- **`completed_steps`** 已完成的步骤（按 CHECKLIST 顺序）。若为空，则下一个任务是 **search**。
- **`next_step`** 为 `null` 时，表示当前 iteration 所有步骤已完成。调用 `run_step()` 会检查收敛或开启新 iteration。
- **`current_iteration`** 当前迭代号。输出文件存放在 `results/iteration_{N}/`。

> **关键约定**：所有输出文件路径由 Orchestrator 的 `run_step()` 返回的 `output_path` 决定，不要自行构造。

---

### 每步速查卡

#### Step 1: Search
- **何时触发**: iteration 开始时（CHECKLIST 第一步），或 teach 前检测到 `search_output.json` 不存在
- **我该做什么**: 读取 `agents/search_persona_profile.md` → spawn Search Agent（Scout）
- **输入**: `state.json`（Orchestrator 已自动注入 `lattice_context`）
- **输出**: `results/iteration_{N}/search_output.json`
- **验收**:
  1. `os.path.exists(output_path)` → 真
  2. `json.loads()` 无异常
  3. 必需字段存在：`concept_id`, `queries`, `results`, `synthesis`, `timestamp`
  4. `queries` 数组长度 ≥3
  5. `results` 中 `relevance >= 0.5` 的数量 ≥5
  6. `synthesis` 长度 ≥50 词
  7. 无 query 与 `previous_queries` 重复
- **失败补救**:
  - 文件缺失 → 重新 spawn Search Agent，传入相同 `state.json`
  - JSON 损坏 → 删除损坏文件，重新 spawn（保留 `previous_queries` 避免重复搜索）
  - 验收指标未达标 → Search Agent 已内置一次 self-correction；若仍失败，会写 `{output_path}.failed`，读取后决定是否重试或跳过
- **详细 SOP**: `agents/search_task_template.md`（子 agent 读取）

#### Step 2: Teach
- **何时触发**: search 审计通过后（`completed_steps` 包含 `"search"` 和 `"audit"`）
- **我该做什么**: 读取 `agents/teach_persona_profile.md` → spawn Teach Agent（Socratic）
- **输入**: `state.json`（含 `search_results` 路径和 `lattice_context`）
- **输出**: `results/iteration_{N}/teach_output.json`
- **验收**:
  1. `os.path.exists(output_path)` → 真
  2. `json.loads()` 无异常
  3. 必需字段存在：`concept_id`, `iteration`, `timestamp`, `d1`, `d2`, `d3`, `d4`, `metadata`
  4. **D1**: 非空字符串，≥20 词且 ≤150 词，零术语
  5. **D2**: 数组长度 3–10，每个元素非空字符串
  6. **D3**: object，有非空 `definition`；数学概念时 `notation` 非空
  7. **D4**: `boundaries` 数组长度 ≥3，每个有非空 `condition`, `counter_example`, `failure_mechanism`
  8. `metadata.confidence_estimate` ∈ [0.0, 1.0]
  9. D1–D4 之间无矛盾 claims
  10. `teach_mode` 与输入一致（fresh / cascade_update / gap_driven）
- **失败补救**:
  - 文件缺失 → 重新 spawn Teach Agent
  - D1–D4 某层不达标 → Teach Agent 已内置一次 self-correction；若仍失败，写 `.failed` 文件
  - `confidence_estimate == 0.0`（`UNABLE_TO_EXPLAIN`）→ 标记该 concept 为无法解释，进入下一 concept 或请求用户介入
- **详细 SOP**: `agents/teach_task_template.md`（子 agent 读取）

#### Step 3: Audit
- **何时触发**: **每个 worker（search/teach/grow/verify/consolidate）完成后自动触发**
- **我该做什么**: 读取 `agents/audit_persona_profile.md` → spawn Audit Agent（Auditor）
- **输入**: worker 的输出路径（如 `teach_output.json`）+ `state.json`
- **输出**: `results/iteration_{N}/audit_report.json`
- **验收**:
  1. `os.path.exists(audit_report.json)` → 真
  2. `json.loads()` 无异常
  3. 必需字段存在：`iteration`, `timestamp`, `valid`, `issues`, `summary`, `metadata`
  4. `valid` 是 boolean
  5. 若 `valid == true`，`issues` 中无 `critical`/`major`
  6. 若 `valid == false`，`issues` 中至少有一个 `critical` 或 `major`
  7. `metadata.issues_by_layer` 计数之和 == `len(issues)`
  8. `metadata.critical_count + major_count + minor_count` == `len(issues)`
  9. `summary` 非空且 ≥20 词
  10. 文件末尾或元数据包含 `[AUDIT_COMPLETE]` 信号
- **失败补救**:
  - audit 报告缺失 → 重新 spawn Audit Agent
  - `valid == false`（含 critical/major issues）→ **不标记 worker 完成**，根据 Orchestrator 返回的 `action` 处理：
    - `action == "fix"`（NEEDS_FIX）→ 将 `audit` 写入 `state.pending_fixes`，重新 spawn 对应 worker 修复
    - `action == "fix"`（REJECT）→ 记录 rejection 到 `state.rejections`，生成 `strategy_adjustment`，强制重新 spawn 对应 worker 并调整策略
- **详细 SOP**: `agents/audit_task_template.md`（子 agent 读取）

> **注意**: CHECKLIST 中的 `"audit"` 在 search 完成后即被标记完成，后续 worker 的审计是**隐式**的，不占用 CHECKLIST 步骤，但同样必须通过后 worker 才能被标记完成。

#### Step 4: Grow
- **何时触发**: audit 通过后（teach 的 audit 通过）
- **我该做什么**: 读取 `agents/grow_persona_profile.md` → spawn Grow Agent（Grow）
- **输入**: `audit_report.json` + `teach_output.json` + `state.json`（含 `previous_grow`）
- **输出**: `results/iteration_{N}/grow_output.json`
- **验收**:
  1. `os.path.exists(output_path)` → 真
  2. `json.loads()` 无异常
  3. 必需字段存在：`iteration`, `timestamp`, `gaps`, `strategy`, `metadata`
  4. 每个 gap 有非空 `gap_id`, `description`, `layer` ∈ {d1,d2,d3,d4}
  5. `strategy` 非空且 ≥30 词
  6. `metadata.gap_count` == `len(gaps)`
  7. `metadata.external_knowledge_count` == 需要搜索的缺口数量
  8. `teach_candidates` 与 `dependency_updates` 一一对应（若 teach_candidates 非空）
- **失败补救**:
  - 文件缺失 → 重新 spawn Grow Agent
  - Phase 0 搜索全部失败 → Grow Agent 标记 `confidence=0.5`，在 `strategy` 中说明搜索失败，继续执行（不阻塞 iteration）
- **详细 SOP**: `agents/grow_task_template.md`（子 agent 读取）

#### Step 5: Verify
- **何时触发**: grow 完成后
- **我该做什么**: 读取 `agents/verify_persona_profile.md` → spawn Verify Agent（Verify）
- **输入**: `grow_output.json` + `teach_output.json` + `audit_report.json` + `state.json`（含 `previous_verification`）
- **输出**: `results/iteration_{N}/verify_output.json`
- **验收**:
  1. `os.path.exists(output_path)` → 真
  2. `json.loads()` 无异常
  3. 必需字段存在：`iteration`, `timestamp`, `cross_time_consistent`, `independent_reproduction`, `external_sources`, `confidence`, `verification_details`, `metadata`
  4. `cross_time_consistent` 是 boolean
  5. `independent_reproduction` 是 boolean
  6. `confidence` 包含 `overall`, `d1`, `d2`, `d3`, `d4`，均为 [0.0, 1.0]
  7. `confidence.overall` 在 average(d1–d4) ±0.05 范围内
  8. `verification_details` 每个字段 ≥20 词
  9. `metadata.sources_checked` == `len(external_sources)`
  10. `metadata.contradictions_found` 为非负整数
- **失败补救**:
  - `confidence.overall < 0.90` → 下一 iteration 的 teach 输入中注入 `grow_output.gaps`，针对性修复
  - `confidence_collapse`（overall 下降 ≥0.2）→ 触发 Auto-Search（PRD §6.B），将 `grow_output` 中的 gaps 提升为 high-priority
- **详细 SOP**: `agents/verify_task_template.md`（子 agent 读取）

#### Step 6: Consolidate
- **何时触发**: verify 完成后
- **我该做什么**: 读取 `agents/consolidate_persona_profile.md` → spawn Consolidate Agent（Consolidate）
- **输入**: `teach_output.json` + `audit_report.json` + `grow_output.json` + `verify_output.json` + `state.json`
- **输出**: `results/iteration_{N}/consolidate_output.json`
- **验收**:
  1. `os.path.exists(output_path)` → 真
  2. `json.loads()` 无异常
  3. 必需字段存在：`concept_id`, `iteration`, `source_outputs`, `audit_status`, `verification_status`, `active_gaps`, `version_stack_entry`, `persistent_gaps`, `structural_residues`, `termination_status`, `metadata`, `new_concepts_created`, `concepts_merged`, `graphify_export_status`
  4. `metadata.dependency_graph_verified` 为 boolean
  5. `new_concepts_created` 每个条目有 `status` 和 `lattice_path`
  6. `concepts_merged` 每个条目有 `status`, `confidence`, `rationale`
  7. `graphify_export_status` 有 `triggered`, `success`, `error` 字段
- **失败补救**:
  - `graphify_export_status.success == false` → **不阻断**，记录失败原因到 `graphify_export_status.error`，继续完成 iteration
  - 合并 confidence < 0.85 → 标记 `status: "rejected"`，不执行合并，记录在 `concepts_merged` 中
  - 新节点已存在 → 跳过创建，记录 `error: "already_exists"`
- **详细 SOP**: `agents/consolidate_task_template.md`（子 agent 读取）

---

## 三、验收标准速查表

| 步骤 | 文件存在 | JSON 合法 | 字段齐全 | 数值约束 | 逻辑约束 |
|------|---------|----------|---------|---------|---------|
| **Search** | ✅ | ✅ | 5 个必需字段 | queries ≥3; high-rel ≥5; synthesis ≥50 词 | 无重复 query |
| **Teach** | ✅ | ✅ | 9 个必需字段 | D1: 20–150 词; D2: 3–10 步; D4: ≥3 边界; confidence ∈ [0,1] | D1–D4 无矛盾 |
| **Audit** | ✅ | ✅ | 6 个必需字段 | issues 计数与 metadata 一致; summary ≥20 词 | valid==true 时无 critical/major |
| **Grow** | ✅ | ✅ | 5 个必需字段 | strategy ≥30 词; gap_count 一致; teach_candidates 与 dependency_updates 一一对应 | layer ∈ {d1,d2,d3,d4} |
| **Verify** | ✅ | ✅ | 8 个必需字段 | confidence ∈ [0,1]; overall ∈ avg±0.05; details ≥20 词 | sources_checked 一致 |
| **Consolidate** | ✅ | ✅ | 13 个必需字段 | dependency_graph_verified 为 bool; graphify_export_status 完整 | — |

> **验收执行方式**: 对每个步骤，Orchestrator 的 `ingest_result()` 会自动加载 worker 输出并校验 `_pending` 标记。主 Agent 应在 spawn 子 agent 后等待其完成信号，再调用 `ingest_result()`。

---

## 四、异常处理决策树

```
┌─────────────────────────────────────────────────────────────────────┐
│ Worker 输出缺失（{task}_output.json 不存在）                        │
│   → 检查子 agent 是否完成（查看其 announce 或日志）                │
│   → 若 agent 崩溃/超时 → 重新 spawn，传入相同输入                  │
│   → 若 agent 静默失败 → 检查 {output_path}.failed 是否存在         │
│   → 若 .failed 存在 → 读取 failed_criterion 和 reason，决定重试策略│
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Audit 返回 valid == false（含 critical/major）                        │
│   → 读取 audit_report.json 的 issues 列表                            │
│   → 区分 REJECT vs NEEDS_FIX：                                       │
│     • REJECT（评分极低/根本性失败）                                   │
│       → 记录 rejection 到 state.rejections                            │
│       → 生成 strategy_adjustment（调整生成策略）                      │
│       → 重新 spawn 对应 worker，在输入中注入 strategy_adjustment    │
│     • NEEDS_FIX（可修复的质量问题）                                   │
│       → 记录 fix 到 state.pending_fixes                               │
│       → 重新 spawn 对应 worker，在输入中注入 revision_notes         │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Audit 报告缺失（audit_report.json 不存在）                           │
│   → Audit Agent 可能未正确写入 → 重新 spawn Audit Agent              │
│   → 检查 Audit Agent 输入是否包含正确的 worker_output 路径           │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Verify confidence < 0.90                                            │
│   → 下一 iteration 的 teach 输入中注入 grow_output.gaps              │
│   → 针对性修复，不开启新 concept                                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Verify confidence_collapse（overall 下降 ≥0.2）                     │
│   → 触发 Auto-Search（PRD §6.B）                                    │
│   → 将 gaps 提升为 high-priority，扩大搜索范围                      │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Consolidate graphify 导出失败                                        │
│   → 不阻断 iteration，记录 error 到 graphify_export_status.error   │
│   → 后续 iteration 继续尝试                                         │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Consolidate 合并 confidence < 0.85                                  │
│   → 标记 status: "rejected"，不执行合并                             │
│   → 记录理由到 concepts_merged[].rationale                          │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ 同一 Worker 连续 3 次失败（exceptions.json 中同 task ≥3 条记录）    │
│   → 调用 _analyze_failure_pattern()                                 │
│   → 相同 error → escalate：建议更换策略或 agent                     │
│   → 不同 agent 相同 error → 可能是输入问题，检查 state.json 完整性 │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Budget 耗尽（budget.remaining <= 0）                                │
│   → run_step() 返回 action: "terminated", reason: "BUDGET_EXHAUSTED"│
│   → 保存当前状态，向用户报告进度                                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ 收敛检测通过（_is_converged() == true）                              │
│   → run_step() 返回 action: "converged"                              │
│   → 执行 _finalize()，生成元摘要，退出循环                          │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 五、进度追踪

### state.json 关键字段速查

| 字段 | 类型 | 含义 | 何时更新 |
|------|------|------|---------|
| `concept_id` | string | 当前正在教的概念 ID | 用户指定或上一轮 grow 的 teach_candidates |
| `concept_name` | string | 概念人类可读名称 | 与 concept_id 同步 |
| `pending_fixes` | array | 待修复队列（audit 发现的问题） | audit 返回 NEEDS_FIX/REJECT 时追加 |
| `strategy_adjustments` | array | 策略调整记录（audit REJECT 触发） | audit REJECT 时追加 |
| `rejections` | array | 被 REJECT 的记录 | audit REJECT 时追加 |
| `new_concepts_created` | array | 本轮创建的新节点列表 | consolidate 完成后追加 |
| `concepts_merged` | array | 本轮合并的节点列表 | consolidate 完成后追加 |
| `user_notifications` | array | 需要通知用户的事件 | audit REJECT 等触发 |
| `fcms_alerts` | array | FCMS 健康检查告警（若启用） | 每轮 ingest_result 时生成 |
| `lattice_relations` | array | 依赖关系更新记录 | consolidate 时从 grow_output 提取 |

### progress.json 关键字段速查

| 字段 | 类型 | 含义 | 示例值 |
|------|------|------|--------|
| `current_iteration` | int | 当前迭代号 | `1` |
| `completed_steps` | array | 已完成的 CHECKLIST 步骤 | `["search", "audit"]` |
| `next_step` | string\|null | 下一个 CHECKLIST 步骤；null 表示 iteration 完成 | `"teach"` |
| `last_task_completed` | ISO-8601 | 最后完成步骤的时间戳 | `"2026-05-05T12:00:00Z"` |
| `rejected_tasks` | array | 被 REJECT 的步骤（历史） | `["teach"]` |

### budget.json 关键字段速查

| 字段 | 类型 | 含义 |
|------|------|------|
| `total` | int | 总预算（最大 spawn 次数） |
| `remaining` | int | 剩余预算 |
| `consumed` | int | 已消耗预算 |

> **预算检查**: `run_step()` 在返回任何任务前检查 `budget.remaining > 0`。若耗尽，返回 `action: "terminated"`。

---

## 六、注入依赖关系图

### 核心依赖（每个 Step 的输入来源）

```
state.json ─────┬──→ Search ───→ search_output.json
                │
                ├──→ Teach ───→ teach_output.json
                │       ↑
                │       └──── search_output.json
                │
                ├──→ Audit ───→ audit_report.json
                │       ↑
                │       └──── teach_output.json / grow_output.json / verify_output.json / consolidate_output.json
                │       └──── state.json (lattice_context, concept_id)
                │
                ├──→ Grow ───→ grow_output.json
                │       ↑
                │       └──── audit_report.json
                │       └──── teach_output.json
                │       └──── state.json
                │
                ├──→ Verify ──→ verify_output.json
                │       ↑
                │       └──── grow_output.json
                │       └──── teach_output.json
                │       └──── audit_report.json
                │       └──── state.json (previous_verification)
                │
                └──→ Consolidate → consolidate_output.json
                        ↑
                        └──── teach_output.json
                        └──── audit_report.json
                        └──── grow_output.json
                        └──── verify_output.json
                        └──── state.json
```

### 跨 Iteration 依赖

```
iteration N ──→ iteration N+1
    │               │
    ├─ teach_output.json ──→ previous_explanations (Teach 输入)
    ├─ audit_report.json ───→ previous_audit (Audit 输入)
    ├─ grow_output.json ───→ previous_grow (Grow 输入)
    ├─ verify_output.json ─→ previous_verification (Verify 输入)
    └─ consolidate_output ─→ previous_consolidate (Consolidate 输入，用于 persistent_gaps 检测)
```

### 子 Agent 注入规范

| 被 Spawn 的 Agent | 主 Agent 必须注入的文件 | 子 Agent 自行读取的文件 |
|-------------------|------------------------|------------------------|
| Search Agent | `state.json`（作为输入路径） | `search_task_template.md`, `search_persona_profile.md` |
| Teach Agent | `state.json`（含 search_results 路径） | `teach_task_template.md`, `teach_persona_profile.md` |
| Audit Agent | worker 输出路径 + `state.json` | `audit_task_template.md`, `audit_persona_profile.md` |
| Grow Agent | `state.json`（含 audit/teach 路径） | `grow_task_template.md`, `grow_persona_profile.md` |
| Verify Agent | `state.json`（含 grow/teach/audit 路径） | `verify_task_template.md`, `verify_persona_profile.md` |
| Consolidate Agent | `state.json`（含所有前序输出路径） | `consolidate_task_template.md`, `consolidate_persona_profile.md` |

> **注入纪律**: Orchestrator 的 `run_step()` 返回 `input_path = state.json`，`output_path = results/iteration_{N}/{task}_output.json`。主 Agent  spawn 子 agent 时，必须传递这两个路径，由子 agent 从 `state.json` 中解析所需的前序输出路径。

---

## 附录：Orchestrator 返回的 Action 类型速查

| `action` | 触发条件 | 主 Agent 应执行的操作 |
|----------|---------|----------------------|
| `"spawn"` | 正常 worker 任务 | spawn 对应子 agent，传入 `input_path` 和 `output_path` |
| `"audit"` | worker 完成后 | spawn Audit Agent，传入 `worker_output` 和 `audit_path` |
| `"fix"` | audit 未通过 | 重新 spawn 对应 worker，在输入中注入 `revision_notes` 或 `strategy_adjustment` |
| `"parallel_spawn"` | 存在多个独立 teach candidates | 并行 spawn 多个 Teach Agent，完成后统一 audit |
| `"converged"` | 收敛检测通过 | 停止循环，向用户汇报最终成果 |
| `"terminated"` | 预算耗尽或终止条件触发 | 保存状态，向用户汇报进度和原因 |
| `"continue"` | audit 通过，worker 完成 | 调用 `run_step()` 获取下一个任务 |

---

> **版本**: v3.5
> **最后更新**: 2026-05-05
> **对应代码**: `harness/orchestrator.py`, `harness/state_manager.py`
> **模板目录**: `harness/agents/`
> **输出目录**: `harness/results/iteration_{N}/`
