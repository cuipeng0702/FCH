#!/usr/bin/env python3
"""
Dream Engine — nightly global knowledge-graph integration scan.

Operates on the ENTIRE concept lattice as a knowledge graph.
It is the AI's "dreaming" mechanism: not review, but global structure scan +
cross-concept insight generation.

Four-layer scan:
  1. Pattern discovery — common analogies, common formal structures
  2. Global contradiction audit — unresolved cross-concept conflicts
  3. MECE check — coverage gaps, overlaps
  4. Structure optimization — orphans, hub overload, cycles

Usage:
    python3 harness/dream_engine.py --scan-all
"""

import argparse
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


class DreamEngine:
    """
    Layer 6 v3.5: Global knowledge-graph integrator.

    Loads all concept-lattice nodes from the harness results directory,
    performs a 4-layer scan, and produces a dream_report.json.
    """

    def __init__(self, harness_dir: str, config: dict = None):
        self.harness_dir = Path(harness_dir)
        self.config = config or {}
        self.dream_cfg = self.config.get("modules", {}).get("dream", {})
        self.results_dir = self.harness_dir / "results"
        self.dreams_dir = self.harness_dir / self.dream_cfg.get("output_path", "dreams")
        self.dreams_dir.mkdir(parents=True, exist_ok=True)

        # Minimum concepts required for meaningful cross-concept analysis
        self.min_concepts = self.dream_cfg.get("min_concepts_for_scan", 5)

        # Layer toggles
        layers = self.dream_cfg.get("layers", {})
        self.layer_pattern = layers.get("pattern_discovery", True)
        self.layer_contradiction = layers.get("contradiction_audit", True)
        self.layer_mece = layers.get("mece_check", True)
        self.layer_structure = layers.get("structure_optimization", True)

        # Keyword sets for contradiction detection
        self.contradiction_keywords = [
            "cannot", "impossible", "never", "always", "only", "must not",
            "violate", "break", "contradict", "incompatible", "mutually exclusive",
        ]

        # Keyword sets for bridge discovery
        self.bridge_keywords = [
            "requires", "depends on", "builds upon", "derived from",
            "is a special case of", "generalizes", "extends", "is equivalent to",
            "similar to", "analogous to", "inspired by",
        ]

        # Common analogy words for pattern detection
        self.analogy_markers = [
            "like", "analogous to", "similar to", "metaphor", "as if",
            "just as", "comparable to", "parallel to", "equivalent to",
        ]

    # ==================== Public API ====================

    def scan_all(self) -> dict:
        """Full 4-layer scan. Returns dream_report dict."""
        concepts = self._load_all_concepts()
        now = self._now()
        dream_id = f"dream_{now.strftime('%Y%m%d_%H%M%S')}"

        report: dict = {
            "dream_id": dream_id,
            "timestamp": now.isoformat(),
            "concepts_scanned": len(concepts),
            "min_concepts_required": self.min_concepts,
            "layers_enabled": {
                "pattern_discovery": self.layer_pattern,
                "contradiction_audit": self.layer_contradiction,
                "mece_check": self.layer_mece,
                "structure_optimization": self.layer_structure,
            },
            "patterns": [],
            "contradictions": [],
            "coverage_gaps": [],
            "structure_issues": [],
            "proposed_tasks": [],
        }

        if len(concepts) < self.min_concepts:
            report["status"] = "insufficient_data"
            report["message"] = (
                f"Only {len(concepts)} concept(s) found, "
                f"need ≥{self.min_concepts} for cross-concept analysis."
            )
            return report

        report["status"] = "complete"

        # Layer 1: Pattern discovery
        if self.layer_pattern:
            report["patterns"] = self._layer1_pattern_discovery(concepts)

        # Layer 2: Global contradiction audit
        if self.layer_contradiction:
            report["contradictions"] = self._layer2_contradiction_audit(concepts)

        # Layer 3: MECE check
        if self.layer_mece:
            mece_gaps, mece_overlaps = self._layer3_mece_check(concepts)
            report["coverage_gaps"] = mece_gaps
            # Overlaps are informational, not gaps
            report["overlaps"] = mece_overlaps

        # Layer 4: Structure optimization
        if self.layer_structure:
            report["structure_issues"] = self._layer4_structure_optimization(concepts)

        # Derive proposed tasks from findings
        report["proposed_tasks"] = self._derive_proposed_tasks(
            report["coverage_gaps"],
            report["contradictions"],
            report["structure_issues"],
        )

        return report

    def save_report(self, report: dict) -> str:
        """Save to dreams/dream_YYYYMMDD_HHMMSS.json atomically."""
        dream_id = report.get("dream_id", f"dream_{self._now().strftime('%Y%m%d_%H%M%S')}")
        path = self.dreams_dir / f"{dream_id}.json"
        self._atomic_write(path, report)
        return str(path)

    @staticmethod
    def run_from_cli():
        """Entry point for cron: python3 dream_engine.py --scan-all"""
        parser = argparse.ArgumentParser(
            description="FCH Dream Engine — nightly knowledge-graph scan"
        )
        parser.add_argument(
            "--harness-dir",
            default=os.environ.get("FCH_HARNESS_DIR", "."),
            help="Path to harness directory (default: FCH_HARNESS_DIR env var or current dir)",
        )
        parser.add_argument(
            "--scan-all",
            action="store_true",
            required=True,
            help="Run full 4-layer scan (required flag)",
        )
        parser.add_argument(
            "--config",
            default=None,
            help="Optional path to config YAML (default: harness/config.yaml)",
        )
        args = parser.parse_args()

        harness_dir = Path(args.harness_dir).resolve()
        if not harness_dir.exists():
            print(f"ERROR: harness directory not found: {harness_dir}", file=sys.stderr)
            sys.exit(1)

        # Load config
        config: dict = {}
        config_path = args.config or (harness_dir / "config.yaml")
        if Path(config_path).exists():
            try:
                import yaml
                with open(config_path, "r", encoding="utf-8") as f:
                    config = yaml.safe_load(f) or {}
            except ImportError:
                print("WARNING: PyYAML not installed; config loading skipped.", file=sys.stderr)
            except Exception as exc:
                print(f"WARNING: Failed to load config: {exc}", file=sys.stderr)

        dream_cfg = config.get("modules", {}).get("dream", {})
        if not dream_cfg.get("enabled", True):
            print("Dream engine disabled in config. Exiting.")
            sys.exit(0)

        engine = DreamEngine(str(harness_dir), config)
        report = engine.scan_all()
        saved_path = engine.save_report(report)

        # Summary stdout for cron logs
        status = report.get("status", "unknown")
        print(f"Dream scan complete: {report['dream_id']}")
        print(f"  Status: {status}")
        print(f"  Concepts scanned: {report['concepts_scanned']}")
        print(f"  Patterns found: {len(report['patterns'])}")
        print(f"  Contradictions found: {len(report['contradictions'])}")
        print(f"  Coverage gaps: {len(report['coverage_gaps'])}")
        print(f"  Structure issues: {len(report['structure_issues'])}")
        print(f"  Proposed tasks: {len(report['proposed_tasks'])}")
        print(f"  Report saved: {saved_path}")

        if status != "complete":
            sys.exit(2)

    # ==================== Concept Loading ====================

    def _load_all_concepts(self) -> List[Dict]:
        """Load all concepts from the results directory."""
        concepts: List[Dict] = []
        if not self.results_dir.exists():
            return concepts

        for concept_dir in sorted(self.results_dir.iterdir()):
            if not concept_dir.is_dir():
                continue
            cid = concept_dir.name
            concept = self._load_concept(cid, concept_dir)
            if concept:
                concepts.append(concept)

        return concepts

    def _load_concept(self, cid: str, concept_dir: Path) -> Optional[Dict]:
        """Load a single concept from its result directory."""
        d1 = self._read_md(concept_dir / "d1_intuition.md")
        d2 = self._read_md(concept_dir / "d2_structure.md")
        d3 = self._read_md(concept_dir / "d3_formal.md")
        d4 = self._read_md(concept_dir / "d4_meta.md")
        gaps = self._read_json(concept_dir / "gaps.json", {})
        network = self._read_md(concept_dir / "cognitive_network.md")

        # Build dependency lists from cognitive_network.md if available
        deps: List[str] = []
        downstream: List[str] = []
        if network:
            deps, downstream = self._extract_deps_from_network(network, cid)

        # Also scan D4 for explicit mentions of other concepts as downstream
        all_concepts = {p.name for p in self.results_dir.iterdir() if p.is_dir()}
        for other in all_concepts:
            if other == cid:
                continue
            if other.replace("-", " ").lower() in (d4 + d3).lower():
                if other not in downstream:
                    downstream.append(other)

        # Parse gaps for open problems
        open_problems: List[str] = []
        for gap in gaps.get("gaps", []):
            desc = gap.get("description", "")
            if desc:
                open_problems.append(desc)

        has_content = any(
            len(v) >= 50 for v in [d1, d2, d3, d4]
        )

        return {
            "concept_id": cid,
            "d1": d1,
            "d2": d2,
            "d3": d3,
            "d4": d4,
            "gaps": gaps,
            "open_problems": open_problems,
            "dependencies": deps,
            "downstream": downstream,
            "has_content": has_content,
            "network": network,
        }

    def _read_md(self, path: Path) -> str:
        """Read a markdown file; return empty string if missing."""
        if not path.exists():
            return ""
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return ""

    def _read_json(self, path: Path, default: Any) -> Any:
        """Read a JSON file; return default if missing or corrupt."""
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default

    def _extract_deps_from_network(self, network_md: str, cid: str) -> Tuple[List[str], List[str]]:
        """Roughly extract dependency links from cognitive_network markdown."""
        deps: List[str] = []
        downstream: List[str] = []
        # Look for explicit mentions like "→ concept-id" or "concept-id →"
        # This is heuristic; v3.5 network is human-readable markdown.
        all_concepts = {p.name for p in self.results_dir.iterdir() if p.is_dir()}
        for other in all_concepts:
            if other == cid:
                continue
            # Simple heuristic: if other concept id appears near arrow symbols
            pattern = re.escape(other).replace(r"\-", r"[-_]")
            if re.search(rf"→\s*{pattern}", network_md):
                downstream.append(other)
            if re.search(rf"{pattern}\s*→", network_md):
                deps.append(other)
        return deps, downstream

    # ==================== Layer 1: Pattern Discovery ====================

    def _layer1_pattern_discovery(self, concepts: List[Dict]) -> List[Dict]:
        """
        Detect cross-concept patterns:
        - Common analogies in D1
        - Common formal structures in D3
        """
        patterns: List[Dict] = []
        patterns.extend(self._detect_analogy_patterns(concepts))
        patterns.extend(self._detect_formal_patterns(concepts))
        return patterns

    def _detect_analogy_patterns(self, concepts: List[Dict]) -> List[Dict]:
        """Find analogies used by multiple concepts."""
        analogy_map: Dict[str, List[str]] = {}
        for c in concepts:
            d1 = c.get("d1", "").lower()
            for marker in self.analogy_markers:
                if marker in d1:
                    # Extract a window around the marker
                    idx = d1.find(marker)
                    window = d1[max(0, idx - 40): idx + 80]
                    # Use the marker as the key, or try to extract the analogy target
                    key = marker
                    analogy_map.setdefault(key, []).append(c["concept_id"])

        patterns: List[Dict] = []
        for analogy, cids in analogy_map.items():
            if len(cids) >= 3:
                patterns.append({
                    "type": "analogy_pattern",
                    "description": f"{len(cids)} concepts use '{analogy}' analogy",
                    "concepts": cids,
                    "insight": f"Potential meta-concept: shared {analogy}-based reasoning",
                    "confidence": min(0.95, 0.5 + 0.15 * len(cids)),
                })
            elif len(cids) == 2:
                patterns.append({
                    "type": "analogy_bridge",
                    "description": f"2 concepts share '{analogy}' analogy",
                    "concepts": cids,
                    "insight": f"Possible hidden connection via {analogy}",
                    "confidence": 0.60,
                })
        return patterns

    def _detect_formal_patterns(self, concepts: List[Dict]) -> List[Dict]:
        """Find common formal structures in D3."""
        # Heuristic: look for common math/CS keywords in D3
        formal_keywords = [
            "optimization", "gradient", "matrix", "equation", "theorem",
            "proof", "algorithm", "complexity", "convergence", "probability",
            "distribution", "model", "function", "derivative", "integral",
            "linear algebra", "graph", "network", "differential", "stochastic",
        ]
        keyword_map: Dict[str, List[str]] = {}
        for c in concepts:
            d3 = c.get("d3", "").lower()
            for kw in formal_keywords:
                if kw in d3:
                    keyword_map.setdefault(kw, []).append(c["concept_id"])

        patterns: List[Dict] = []
        for kw, cids in keyword_map.items():
            if len(cids) >= 3:
                patterns.append({
                    "type": "formal_structure_pattern",
                    "description": f"{len(cids)} concepts involve '{kw}' in formal definition",
                    "concepts": cids,
                    "insight": f"Potential meta-concept: {kw} as unifying formal structure",
                    "confidence": min(0.90, 0.5 + 0.12 * len(cids)),
                })
        return patterns

    # ==================== Layer 2: Contradiction Audit ====================

    def _layer2_contradiction_audit(self, concepts: List[Dict]) -> List[Dict]:
        """
        Detect unresolved cross-concept conflicts:
        - Explicit contradictions from gaps.json
        - Implicit: D4 boundary of A conflicts with D2/D3 of B
        """
        findings: List[Dict] = []
        n = len(concepts)

        # Explicit contradictions from gaps
        for c in concepts:
            for gap in c.get("gaps", {}).get("gaps", []):
                if "contradict" in gap.get("description", "").lower():
                    findings.append({
                        "type": "explicit_contradiction",
                        "severity": gap.get("severity", "medium"),
                        "concept_a": c["concept_id"],
                        "description": gap["description"],
                    })

        # Implicit cross-concept contradictions
        for i in range(n):
            for j in range(i + 1, n):
                a, b = concepts[i], concepts[j]
                if not a["has_content"] or not b["has_content"]:
                    continue
                pair_contradictions = self._check_pair_contradiction(a, b)
                findings.extend(pair_contradictions)

        return findings

    def _check_pair_contradiction(self, a: Dict, b: Dict) -> List[Dict]:
        """Check if concept A's D4 contradicts concept B's D2/D3."""
        findings: List[Dict] = []
        d4_a = a.get("d4", "").lower()
        d2_b = b.get("d2", "").lower()
        d3_b = b.get("d3", "").lower()

        if not d4_a or (not d2_b and not d3_b):
            return findings

        negation_indicators = [
            "cannot", "impossible", "never", "only", "must not",
            "violate", "break", "incompatible", "not possible",
        ]

        b_claims = self._extract_claims(b.get("d2", "") + " " + b.get("d3", ""))

        for claim in b_claims:
            claim_lower = claim.lower()
            for neg in negation_indicators:
                if neg in d4_a:
                    claim_keywords = set(claim_lower.split()) - {
                        "the", "a", "an", "is", "are", "to", "of", "in", "and", "or",
                        "for", "with", "on", "at", "by", "as", "be", "this", "that",
                    }
                    d4_context = self._get_context_around(d4_a, neg, window=20)
                    overlap = claim_keywords & set(d4_context.split())
                    if len(overlap) >= 2:
                        findings.append({
                            "type": "boundary_violation",
                            "severity": "medium",
                            "concept_a": a["concept_id"],
                            "concept_b": b["concept_id"],
                            "description": (
                                f"D4 of '{a['concept_id']}' states '{neg}' near "
                                f"concepts also in D2/D3 of '{b['concept_id']}' "
                                f"(keywords: {overlap}). Possible cross-concept contradiction."
                            ),
                        })
                        # One finding per claim is enough
                        break

        return findings

    # ==================== Layer 3: MECE Check ====================

    def _layer3_mece_check(self, concepts: List[Dict]) -> Tuple[List[Dict], List[Dict]]:
        """
        Check coverage gaps and overlaps.
        Returns (gaps, overlaps).
        """
        gaps: List[Dict] = []
        overlaps: List[Dict] = []

        # Collect all open problems across concepts as proxy for coverage gaps
        domain_map: Dict[str, List[str]] = {}
        for c in concepts:
            for problem in c.get("open_problems", []):
                # Try to guess domain from problem description
                domain = self._infer_domain(problem)
                domain_map.setdefault(domain, []).append(c["concept_id"])

        # Report domains with known gaps
        for domain, cids in domain_map.items():
            gaps.append({
                "domain": domain,
                "affected_concepts": cids,
                "missing_concepts": [],  # We don't know what we don't know
                "suggested_priority": "low",
                "reason": "open problems indicate incomplete coverage",
            })

        # Detect overlaps: concepts with very similar D2 content
        n = len(concepts)
        for i in range(n):
            for j in range(i + 1, n):
                a, b = concepts[i], concepts[j]
                sim = self._jaccard_similarity(a.get("d2", ""), b.get("d2", ""))
                if sim >= 0.7:
                    overlaps.append({
                        "type": "overlap",
                        "concept_a": a["concept_id"],
                        "concept_b": b["concept_id"],
                        "similarity": round(sim, 3),
                        "description": (
                            f"D2 content of '{a['concept_id']}' and '{b['concept_id']}' "
                            f"are highly similar (Jaccard={sim:.2f}). Consider merging or differentiating."
                        ),
                    })

        return gaps, overlaps

    def _infer_domain(self, text: str) -> str:
        """Infer a domain label from a text snippet."""
        text_lower = text.lower()
        domain_keywords = {
            "optimization": ["optimization", "gradient", "convergence", "minimum", "maximum"],
            "machine learning": ["neural", "model", "training", "inference", "dataset"],
            "finance": ["valuation", "stock", "market", "portfolio", "risk", "return"],
            "physics": ["force", "energy", "momentum", "wave", "quantum"],
            "math": ["theorem", "proof", "equation", "matrix", "vector"],
            "cs": ["algorithm", "complexity", "data structure", "computation"],
        }
        best_domain = "general"
        best_score = 0
        for domain, kws in domain_keywords.items():
            score = sum(1 for kw in kws if kw in text_lower)
            if score > best_score:
                best_score = score
                best_domain = domain
        return best_domain

    # ==================== Layer 4: Structure Optimization ====================

    def _layer4_structure_optimization(self, concepts: List[Dict]) -> List[Dict]:
        """
        Detect structural issues:
        - Orphans (no deps, no downstream)
        - Hub overload (too many downstream)
        - Cycles in dependency graph
        """
        findings: List[Dict] = []
        findings.extend(self._detect_orphans(concepts))
        findings.extend(self._detect_hub_overload(concepts))
        findings.extend(self._detect_cycles(concepts))
        findings.extend(self._detect_missing_bridges(concepts))
        return findings

    def _detect_orphans(self, concepts: List[Dict]) -> List[Dict]:
        """Detect concepts with no dependencies and no downstream."""
        findings: List[Dict] = []
        for c in concepts:
            if not c.get("dependencies") and not c.get("downstream"):
                findings.append({
                    "type": "orphan_concept",
                    "severity": "low",
                    "concept_id": c["concept_id"],
                    "description": (
                        f"'{c['concept_id']}' has no dependencies and no downstream concepts. "
                        f"Consider linking it to related concepts."
                    ),
                })
        return findings

    def _detect_hub_overload(self, concepts: List[Dict]) -> List[Dict]:
        """Detect concepts that are overly central (too many downstream)."""
        findings: List[Dict] = []
        threshold = 5  # Configurable in future
        for c in concepts:
            downstream = c.get("downstream", [])
            if len(downstream) >= threshold:
                findings.append({
                    "type": "hub_overload",
                    "severity": "medium",
                    "concept_id": c["concept_id"],
                    "description": (
                        f"'{c['concept_id']}' is a hub with {len(downstream)} downstream concepts. "
                        f"Its changes will cascade heavily. Consider splitting."
                    ),
                    "downstream_count": len(downstream),
                })
        return findings

    def _detect_cycles(self, concepts: List[Dict]) -> List[Dict]:
        """Detect dependency cycles in the concept graph."""
        # Build adjacency list
        graph: Dict[str, Set[str]] = {}
        all_ids = {c["concept_id"] for c in concepts}
        for c in concepts:
            graph[c["concept_id"]] = set(c.get("dependencies", [])) & all_ids

        findings: List[Dict] = []
        visited: Set[str] = set()
        rec_stack: Set[str] = set()

        def dfs(node: str, path: List[str]) -> bool:
            visited.add(node)
            rec_stack.add(node)
            for neighbor in graph.get(node, set()):
                if neighbor not in visited:
                    if dfs(neighbor, path + [neighbor]):
                        return True
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    cycle = path[cycle_start:] + [neighbor]
                    findings.append({
                        "type": "dependency_cycle",
                        "severity": "high",
                        "concepts": cycle,
                        "description": (
                            f"Dependency cycle detected: {' → '.join(cycle)}. "
                            f"Cyclic dependencies prevent clean topological ordering."
                        ),
                    })
                    return True
            rec_stack.remove(node)
            return False

        for c in concepts:
            if c["concept_id"] not in visited:
                dfs(c["concept_id"], [c["concept_id"]])

        return findings

    def _detect_missing_bridges(self, concepts: List[Dict]) -> List[Dict]:
        """Discover implicit connections: concept A mentions B but no explicit dependency."""
        findings: List[Dict] = []
        all_ids = {c["concept_id"].lower(): c["concept_id"] for c in concepts}

        for a in concepts:
            if not a["has_content"]:
                continue
            d4_text = (a.get("d4", "") + " " + a.get("d3", "")).lower()
            explicit_deps = {d.lower() for d in a.get("dependencies", [])}

            for b in concepts:
                if b["concept_id"] == a["concept_id"]:
                    continue
                b_id = b["concept_id"].lower()
                b_name = b["concept_id"].replace("-", " ").lower()

                if b_name in d4_text or b_id in d4_text:
                    if b_id not in explicit_deps:
                        findings.append({
                            "type": "missing_bridge",
                            "severity": "low",
                            "from": a["concept_id"],
                            "to": b["concept_id"],
                            "description": (
                                f"'{b['concept_id']}' is mentioned in D3/D4 of "
                                f"'{a['concept_id']}' but not in dependency list."
                            ),
                        })
        return findings

    # ==================== Task Derivation ====================

    def _derive_proposed_tasks(
        self,
        coverage_gaps: List[Dict],
        contradictions: List[Dict],
        structure_issues: List[Dict],
    ) -> List[Dict]:
        """Convert findings into proposed research/teach tasks."""
        tasks: List[Dict] = []
        seen_concepts: Set[str] = set()

        # From contradictions → high-priority teach tasks
        for c in contradictions:
            if c.get("severity") == "high":
                for concept_key in ["concept_a", "concept_b"]:
                    cid = c.get(concept_key)
                    if cid and cid not in seen_concepts:
                        seen_concepts.add(cid)
                        tasks.append({
                            "task_type": "teach",
                            "concept": cid,
                            "reason": f"contradiction detected: {c.get('description', '')[:100]}",
                            "priority": "high",
                        })

        # From coverage gaps → low-priority research tasks
        for g in coverage_gaps:
            for cid in g.get("affected_concepts", []):
                if cid not in seen_concepts:
                    seen_concepts.add(cid)
                    tasks.append({
                        "task_type": "research",
                        "concept": cid,
                        "reason": f"coverage gap in domain '{g.get('domain', 'unknown')}'",
                        "priority": g.get("suggested_priority", "low"),
                    })

        # From structure issues (orphans, missing bridges)
        for s in structure_issues:
            if s["type"] in ("orphan_concept", "missing_bridge"):
                cid = s.get("concept_id") or s.get("from")
                if cid and cid not in seen_concepts:
                    seen_concepts.add(cid)
                    tasks.append({
                        "task_type": "consolidate",
                        "concept": cid,
                        "reason": s.get("description", "")[:120],
                        "priority": "low",
                    })

        # Limit to avoid overwhelming
        return tasks[:20]

    # ==================== Helpers ====================

    def _extract_claims(self, text: str) -> List[str]:
        """Extract sentences/claims from text."""
        if not text:
            return []
        sentences = re.split(r'[.!?\n]+', text)
        return [s.strip() for s in sentences if len(s.strip()) > 20]

    def _get_context_around(self, text: str, keyword: str, window: int = 20) -> str:
        """Get text around a keyword with a word window."""
        words = text.split()
        for i, w in enumerate(words):
            if keyword in w:
                start = max(0, i - window)
                end = min(len(words), i + window + 1)
                return " ".join(words[start:end])
        return ""

    def _jaccard_similarity(self, text_a: str, text_b: str) -> float:
        """Compute Jaccard similarity between two texts."""
        def tokens(t: str) -> Set[str]:
            return set(re.findall(r"\b\w{3,}\b", t.lower()))

        a = tokens(text_a)
        b = tokens(text_b)
        if not a or not b:
            return 0.0
        intersection = a & b
        union = a | b
        return len(intersection) / len(union)

    def _atomic_write(self, path: Path, data: dict) -> None:
        """Write JSON atomically via a temp file."""
        tmp = tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".json",
            prefix="tmp_",
            dir=str(path.parent),
            delete=False,
        )
        try:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, path)

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)


if __name__ == "__main__":
    DreamEngine.run_from_cli()
