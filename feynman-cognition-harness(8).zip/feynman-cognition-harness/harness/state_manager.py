"""StateManager — atomic file-system I/O for FCH harness state.

All reads/writes are JSON-based. Writes are atomic (temp file + rename).
"""

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class StateManager:
    """Manages state.json, progress.json, and budget.json with atomic writes."""

    def __init__(self, harness_dir: str):
        self.harness_dir = Path(harness_dir)
        self.state_path = self.harness_dir / "state.json"
        self.progress_path = self.harness_dir / "progress.json"
        self.budget_path = self.harness_dir / "budget.json"
        # v3.5: new persistence paths (inactive when modules disabled)
        self.history_path = self.harness_dir / "history.jsonl"
        self.thresholds_path = self.harness_dir / "thresholds.json"
        self.routing_log_path = self.harness_dir / "routing_decision_log.jsonl"
        self.analogy_dir = self.harness_dir / "analogy_matrix"
        self.analogy_dir.mkdir(parents=True, exist_ok=True)
        # v3.5: cascade queue persistence
        self.cascade_queue_path = self.harness_dir / "cascade_queue.json"

    # ── generic helpers ──────────────────────────────────────────────

    @staticmethod
    def _atomic_write(path: Path, data: dict) -> None:
        """Write JSON atomically via a temp file."""
        tmp = tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".json",
            prefix="tmp_",
            dir=str(path.parent),
            delete=False,
        )
        try:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, path)

    @staticmethod
    def _load_json(path: Path, default: dict) -> dict:
        """Load JSON from path; return default if missing or corrupt."""
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default

    # ── state.json ───────────────────────────────────────────────────

    def load_state(self) -> dict:
        """Load runtime state: concepts, confidence, contradictions, gaps."""
        default = {
            "current_concept": None,
            "concept_history": [],
            "confidence": {},
            "contradictions": [],
            "pending_fixes": [],
            "strategy_adjustments": [],
            "last_updated": self._now(),
        }
        return self._load_json(self.state_path, default)

    def save_state(self, state: dict) -> None:
        """Persist runtime state with fresh timestamp."""
        state["last_updated"] = self._now()
        self._atomic_write(self.state_path, state)

    # ── progress.json ────────────────────────────────────────────────

    def load_progress(self) -> dict:
        """Load execution progress: current iteration, completed steps, todo."""
        default = {
            "current_iteration": 1,
            "completed_steps": [],
            "next_step": "teach",
            "last_agent_spawned": None,
            "last_task_completed": None,
        }
        return self._load_json(self.progress_path, default)

    def save_progress(self, progress: dict) -> None:
        """Persist execution progress."""
        self._atomic_write(self.progress_path, progress)

    # ── budget.json ──────────────────────────────────────────────────

    def load_budget(self) -> dict:
        """Load spawn budget: remaining quota and used count."""
        default = {
            "max_spawn": 50,
            "remaining": 50,
            "used": 0,
        }
        return self._load_json(self.budget_path, default)

    def save_budget(self, budget: dict) -> None:
        """Persist budget counters."""
        self._atomic_write(self.budget_path, budget)

    # ── task queue ───────────────────────────────────────────────────

    CHECKLIST = ["search", "teach", "audit", "grow", "verify", "consolidate"]

    def get_next_task(self, progress: dict) -> str | None:
        """Return the next uncompleted step for the current iteration.

        Returns None when all steps in the current iteration are done.
        """
        completed = set(progress.get("completed_steps", []))
        for step in self.CHECKLIST:
            if step not in completed:
                return step
        return None

    def mark_task_done(self, progress: dict, task: str) -> dict:
        """Mark a step as completed and update next_step."""
        completed = set(progress.get("completed_steps", []))
        completed.add(task)
        progress["completed_steps"] = sorted(completed, key=self.CHECKLIST.index)
        next_task = self.get_next_task(progress)
        progress["next_step"] = next_task
        progress["last_task_completed"] = self._now()
        return progress

    # ── exceptions ───────────────────────────────────────────────────

    def record_exception(self, iteration: int, exc: dict) -> None:
        """Append an exception record to the iteration's exceptions.json."""
        exc_dir = self.harness_dir / "results" / f"iteration_{iteration}"
        exc_dir.mkdir(parents=True, exist_ok=True)
        exc_path = exc_dir / "exceptions.json"
        data = self._load_json(exc_path, {"records": []})
        record = {
            "time": self._now(),
            **exc,
        }
        data["records"].append(record)
        self._atomic_write(exc_path, data)

    def get_recent_exceptions(self, iteration: int, limit: int = 3) -> list:
        """Return the last `limit` exception records for an iteration."""
        exc_path = self.harness_dir / "results" / f"iteration_{iteration}" / "exceptions.json"
        data = self._load_json(exc_path, {"records": []})
        return data["records"][-limit:]

    # ── v3.5 history persistence (inactive when modules disabled) ──

    def append_history_record(self, record: dict) -> None:
        """Atomic append to history.jsonl."""
        line = json.dumps(record, ensure_ascii=False) + "\n"
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".jsonl", prefix="tmp_",
            dir=str(self.history_path.parent), delete=False,
        )
        try:
            if self.history_path.exists():
                with open(self.history_path, "r", encoding="utf-8") as f:
                    tmp.write(f.read())
            tmp.write(line)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, self.history_path)

    def load_history(self) -> list[dict]:
        """Read all valid JSON lines from history.jsonl; skip corrupt."""
        if not self.history_path.exists():
            return []
        records = []
        with open(self.history_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    # ── v3.5 threshold persistence (inactive when modules disabled) ──

    def save_thresholds(self, thresholds: dict) -> None:
        """Atomic write to thresholds.json."""
        self._atomic_write(self.thresholds_path, thresholds)

    def load_thresholds(self) -> dict:
        """Load thresholds.json; return cold-start defaults if missing."""
        default = {
            "audit_aggregate": {
                "point_estimate": 0.85,
                "ci_low": 0.80,
                "ci_high": 0.90,
                "sample_size": 0,
            },
            "bdd_confidence": {
                "point_estimate": 0.75,
                "ci_low": 0.70,
                "ci_high": 0.80,
                "sample_size": 0,
            },
        }
        return self._load_json(self.thresholds_path, default)

    # ── v3.5 routing log (inactive when modules disabled) ────────────

    def append_routing_decision(self, decision: dict) -> None:
        """Atomic append to routing_decision_log.jsonl."""
        line = json.dumps(decision, ensure_ascii=False) + "\n"
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".jsonl", prefix="tmp_",
            dir=str(self.routing_log_path.parent), delete=False,
        )
        try:
            if self.routing_log_path.exists():
                with open(self.routing_log_path, "r", encoding="utf-8") as f:
                    tmp.write(f.read())
            tmp.write(line)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, self.routing_log_path)

    def load_routing_log(self) -> list[dict]:
        """Read all valid JSON lines from routing_decision_log.jsonl."""
        if not self.routing_log_path.exists():
            return []
        records = []
        with open(self.routing_log_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    # ── v3.5 analogy matrix persistence (inactive when modules disabled) ──

    def save_analogy_matrix(self, concept_id: str, matrix: dict) -> None:
        """Write analogy matrix JSON for a concept."""
        path = self.analogy_dir / f"{concept_id}_analogy_matrix.json"
        self._atomic_write(path, matrix)

    def load_analogy_matrix(self, concept_id: str) -> dict:
        """Load analogy matrix JSON for a concept; return empty dict if missing."""
        path = self.analogy_dir / f"{concept_id}_analogy_matrix.json"
        return self._load_json(path, {})

    # ── v3.5 BDD extraction helpers (inactive when modules disabled) ──

    def extract_bdd_history(self, state: dict) -> list[dict]:
        """Extract BDD-relevant records from history for termination checker."""
        history = self.load_history()
        return [
            rec for rec in history
            if rec.get("task") == "bdd" or rec.get("routed_to") == "bdd"
        ]

    def extract_current_bdd_state(self, iteration: int) -> dict:
        """Build current BDD state snapshot for termination checker."""
        bdd_output_path = (
            self.harness_dir / "results" / f"iteration_{iteration}" / "bdd_output.json"
        )
        bdd_data = self._load_json(bdd_output_path, {})
        return {
            "iteration": iteration,
            "timestamp": self._now(),
            "bdd_output_exists": bdd_output_path.exists(),
            "confidence": bdd_data.get("confidence", {}),
            "gaps_addressed": bdd_data.get("gaps_addressed", []),
        }

    # ── v3.5 cascade queue ───────────────────────────────────────────

    def add_to_cascade_queue(self, concept_ids: list[str], reason: str, trigger_concept: str) -> None:
        """Mark concepts as needing re-audit due to upstream cascade."""
        queue = self._load_json(self.cascade_queue_path, [])
        for cid in concept_ids:
            queue.append({
                "concept_id": cid,
                "reason": reason,
                "trigger_concept": trigger_concept,
                "added_at": self._now(),
                "priority": "high" if reason == "dependency_drift" else "medium",
            })
        self._atomic_write(self.cascade_queue_path, queue)

    def get_cascade_queue(self) -> list[dict]:
        """Get pending cascade queue entries."""
        return self._load_json(self.cascade_queue_path, [])

    def clear_cascade_queue(self) -> None:
        """Clear the cascade queue."""
        self._atomic_write(self.cascade_queue_path, [])

    # ── v3.5 FCMS (FCH Cognitive Metacognition System) ──────────────

    # FCMS base directory
    @property
    def fcms_dir(self) -> Path:
        return self.harness_dir / "fcms"

    def fcms_save_signal(self, signal: dict, iteration: int, mode: str = "realtime") -> None:
        """Save a single FCMS signal.

        mode: realtime | hourly | daily
        """
        iter_dir = self.fcms_dir / "signals" / mode / f"iter_{iteration:03d}"
        iter_dir.mkdir(parents=True, exist_ok=True)
        sig_type = signal.get("type", "unknown")
        path = iter_dir / f"{sig_type}.json"
        self._atomic_write(path, signal)

    def fcms_load_signals(self, n: int = 3, mode: str = "realtime") -> list[dict]:
        """Load the most recent n iterations of signals."""
        signals_dir = self.fcms_dir / "signals" / mode
        if not signals_dir.exists():
            return []

        all_dirs = sorted(signals_dir.glob("iter_*"), key=lambda p: p.name)
        target_dirs = all_dirs[-n:]

        results = []
        for d in target_dirs:
            if not d.exists():
                continue
            for f in d.glob("*.json"):
                if f.name.startswith("_"):
                    continue
                try:
                    with open(f, "r", encoding="utf-8") as fh:
                        results.append(json.load(fh))
                except (json.JSONDecodeError, OSError):
                    continue
        return results

    def fcms_save_diagnosis(self, diagnosis: dict, iteration: int) -> None:
        """Save L2 diagnosis report."""
        diag_dir = self.fcms_dir / "diagnosis"
        diag_dir.mkdir(parents=True, exist_ok=True)
        path = diag_dir / f"d_{iteration:03d}.json"
        self._atomic_write(path, diagnosis)

    def fcms_load_latest_diagnosis(self) -> dict | None:
        """Load the most recent diagnosis report, or None if none exists."""
        diag_dir = self.fcms_dir / "diagnosis"
        if not diag_dir.exists():
            return None
        all_files = sorted(diag_dir.glob("d_*.json"), key=lambda p: p.name)
        if not all_files:
            return None
        latest = all_files[-1]
        try:
            with open(latest, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (json.JSONDecodeError, OSError):
            return None

    def fcms_save_reflection(self, reflection: dict, iteration: int,
                              mode: str = "immediate") -> None:
        """Save L3 reflection report.

        mode: immediate | batch | dream
        """
        refl_dir = self.fcms_dir / "reflections" / mode
        refl_dir.mkdir(parents=True, exist_ok=True)
        path = refl_dir / f"r_{iteration:03d}.json"
        self._atomic_write(path, reflection)

    def fcms_load_reflections(self, n: int = 3, mode: str = "immediate") -> list[dict]:
        """Load the last n reflections of a given mode."""
        refl_dir = self.fcms_dir / "reflections" / mode
        if not refl_dir.exists():
            return []
        all_files = sorted(refl_dir.glob("r_*.json"), key=lambda p: p.name)
        results = []
        for f in all_files[-n:]:
            try:
                with open(f, "r", encoding="utf-8") as fh:
                    results.append(json.load(fh))
            except (json.JSONDecodeError, OSError):
                continue
        return results

    def fcms_save_regulation(self, regulation: dict) -> None:
        """Append a regulation record to regulation_log.jsonl."""
        log_path = self.fcms_dir / "regulation" / "regulation_log.jsonl"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(regulation, ensure_ascii=False) + "\n"
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".jsonl", prefix="tmp_",
            dir=str(log_path.parent), delete=False,
        )
        try:
            if log_path.exists():
                with open(log_path, "r", encoding="utf-8") as f:
                    tmp.write(f.read())
            tmp.write(line)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, log_path)

    def fcms_load_regulation_log(self) -> list[dict]:
        """Read all regulation records."""
        log_path = self.fcms_dir / "regulation" / "regulation_log.jsonl"
        if not log_path.exists():
            return []
        records = []
        with open(log_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    def fcms_save_self_awareness(self, report: dict, iteration: int) -> None:
        """Save self-awareness coach report."""
        self_dir = self.fcms_dir / "self"
        self_dir.mkdir(parents=True, exist_ok=True)
        path = self_dir / f"sa_{iteration:03d}.json"
        self._atomic_write(path, report)

    def fcms_save_self_signal(self, signal: dict) -> None:
        """Append a self-referential signal to {type}_log.jsonl."""
        self_dir = self.fcms_dir / "self"
        self_dir.mkdir(parents=True, exist_ok=True)
        sig_type = signal.get("type", "unknown")
        log_path = self_dir / f"{sig_type}_log.jsonl"
        line = json.dumps(signal, ensure_ascii=False) + "\n"
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".jsonl", prefix="tmp_",
            dir=str(log_path.parent), delete=False,
        )
        try:
            if log_path.exists():
                with open(log_path, "r", encoding="utf-8") as f:
                    tmp.write(f.read())
            tmp.write(line)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, log_path)

    def fcms_load_self_awareness(self, n: int = 3) -> list[dict]:
        """Load the last n self-awareness reports."""
        self_dir = self.fcms_dir / "self"
        if not self_dir.exists():
            return []
        all_files = sorted(self_dir.glob("sa_*.json"), key=lambda p: p.name)
        results = []
        for f in all_files[-n:]:
            try:
                with open(f, "r", encoding="utf-8") as fh:
                    results.append(json.load(fh))
            except (json.JSONDecodeError, OSError):
                continue
        return results

    # ── utility ──────────────────────────────────────────────────────

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()
