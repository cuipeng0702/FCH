#!/usr/bin/env python3
"""End-to-end 验证：mock lattice → export → graphify query → 结果解析。"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# ── 1. 准备 mock lattice（符合 LatticeManager 期望格式） ───────────

workspace = Path(tempfile.mkdtemp(prefix="fch_graphify_test_"))
knowledge_lattice = workspace / "knowledge-lattice"
concepts_dir = knowledge_lattice / "concepts"
concepts_dir.mkdir(parents=True)

# 创建两个 mock concept 节点（必须有 core_id, dependencies 等字段）
concept_a = {
    "core_id": "concept_test_alpha",
    "confidence": 0.85,
    "dependencies": [],
    "downstream_concepts": ["concept_test_beta"],
    "version_stack": [
        {"level": "D3", "content": "Alpha is the first letter.", "confidence": 0.9}
    ],
    "open_problems": [],
    "contradictions": [],
    "audit_history": [],
    "cascade_flag": False,
}
concept_b = {
    "core_id": "concept_test_beta",
    "confidence": 0.75,
    "dependencies": ["concept_test_alpha"],
    "downstream_concepts": [],
    "version_stack": [
        {"level": "D3", "content": "Beta follows Alpha.", "confidence": 0.8}
    ],
    "open_problems": [],
    "contradictions": [],
    "audit_history": [],
    "cascade_flag": False,
}

(concepts_dir / "concept_test_alpha.json").write_text(json.dumps(concept_a, indent=2), encoding="utf-8")
(concepts_dir / "concept_test_beta.json").write_text(json.dumps(concept_b, indent=2), encoding="utf-8")

# 创建 index.json（LatticeManager 格式：dict-of-dicts）
index = {
    "concept_test_alpha": {"concept_id": "concept_test_alpha", "label": "Alpha Concept"},
    "concept_test_beta": {"concept_id": "concept_test_beta", "label": "Beta Concept"},
}
(concepts_dir / "index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")

# ── 2. 运行 export_to_graphify.py ─────────────────────────────────

graphify_out = workspace / "graphify-out"
graphify_out.mkdir()

script = Path(__file__).resolve().parent.parent / "scripts" / "export_to_graphify.py"
if not script.exists():
    script = Path("/root/.openclaw/workspace/skills/feynman-cognition-harness/scripts/export_to_graphify.py")

result = subprocess.run(
    ["python3", str(script), "--input-dir", str(knowledge_lattice), "--output-dir", str(graphify_out)],
    capture_output=True, text=True, timeout=60
)
print(f"[export] returncode={result.returncode}")
if result.returncode != 0:
    print(f"[export] stderr={result.stderr}")
    sys.exit(1)

# 验证 graph.json 已生成
graph_json = graphify_out / "graph.json"
assert graph_json.exists(), f"graph.json not generated at {graph_json}"
print(f"[export] graph.json exists: {graph_json}")

# ── 3. 用 GraphifyMCPClient 查询 ──────────────────────────────────

sys.path.insert(0, str(Path(__file__).resolve().parent))
from graphify_client import GraphifyMCPClient

client = GraphifyMCPClient(str(graphify_out))

# 3a. query
q = client.query("Alpha", mode="bfs", depth=2)
print(f"[query] mode={q.get('mode')}, nodes={len(q.get('nodes', []))}, edges={len(q.get('edges', []))}")
assert "nodes" in q, "query result missing 'nodes'"
assert len(q["nodes"]) > 0, "query returned no nodes"

# 3b. path (edge direction: beta depends_on alpha, so search beta -> alpha)
p = client.path("Beta Concept", "Alpha Concept")
print(f"[path] hops={p.get('hops')}, text={p.get('text', '')[:80]}...")
assert p.get("hops", 0) > 0, "path should have hops > 0"

# 3c. explain (export 脚本将 core_id title-case 为 label)
e = client.explain("Concept Test Alpha")
print(f"[explain] label={e.get('node', {}).get('label')}, neighbors={len(e.get('neighbors', []))}")
assert e.get("node", {}).get("label") == "Concept Test Alpha", "explain returned wrong node"

# 3d. query_knowledge 决策路由（通过 orchestrator 的 query_knowledge 方法）
# 由于 orchestrator 需要完整 harness 环境，这里仅验证 graphify_client 独立可用。

# ── 4. 清理 ─────────────────────────────────────────────────────────

shutil.rmtree(workspace)

print("\n✅ 端到端验证全部通过。")
