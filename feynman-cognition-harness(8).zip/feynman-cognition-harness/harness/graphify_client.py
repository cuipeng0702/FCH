#!/usr/bin/env python3
"""轻量级 graphify 查询客户端。

直接导入 graphify 内部模块操作 graph.json，
避免对 CLI --json 标志的依赖（graphify CLI 目前仅输出纯文本）。
"""

import json
from pathlib import Path

import networkx as nx
from networkx.readwrite import json_graph


class GraphifyMCPClient:
    """轻量级 graphify 查询客户端。

    直接加载 graph.json 并通过 graphify 的内部遍历逻辑执行
    query / path / explain 查询。所有调用均为 best-effort：
    失败返回空结果，绝不抛异常阻断主流程。
    """

    def __init__(self, graph_dir: str):
        self.graph_dir = Path(graph_dir)
        self.graph_path = self.graph_dir / "graph.json"
        self._G = None  # cached graph

    # ── internal helpers ──────────────────────────────────────────

    def _load_graph(self) -> nx.Graph | None:
        """懒加载并缓存 graph.json。"""
        if self._G is not None:
            return self._G
        if not self.graph_path.exists():
            return None
        try:
            data = json.loads(self.graph_path.read_text(encoding="utf-8"))
            try:
                self._G = json_graph.node_link_graph(data, edges="links")
            except TypeError:
                self._G = json_graph.node_link_graph(data)
            return self._G
        except Exception:
            return None

    def _score_nodes(self, G: nx.Graph, terms: list[str]) -> list[tuple[float, str]]:
        """节点相关性打分（复刻 graphify.serve._score_nodes）。"""
        from graphify.serve import _score_nodes as _gn_score
        return _gn_score(G, terms)

    def _find_node(self, G: nx.Graph, label: str) -> list[str]:
        from graphify.serve import _find_node as _gn_find
        return _gn_find(G, label)

    # ── public API ───────────────────────────────────────────────

    def query(self, question: str, mode: str = "bfs", depth: int = 3, token_budget: int = 2000) -> dict:
        """图语义查询。

        Returns:
            dict: {
                "mode": str,
                "start_nodes": list[str],
                "nodes": list[dict],
                "edges": list[dict],
                "text": str,   # 原始文本摘要（可用于注入 context）
            }
        """
        G = self._load_graph()
        if G is None:
            return {}
        try:
            from graphify.serve import _bfs, _dfs, _subgraph_to_text

            terms = [t.lower() for t in question.split() if len(t) > 2]
            scored = self._score_nodes(G, terms)
            start_nodes = [nid for _, nid in scored[:3]]
            if not start_nodes:
                return {"mode": mode, "start_nodes": [], "nodes": [], "edges": [], "text": "No matching nodes found."}

            nodes, edges = (_dfs if mode == "dfs" else _bfs)(G, start_nodes, depth=depth)
            text = _subgraph_to_text(G, nodes, edges, token_budget)

            node_list = []
            for nid in nodes:
                d = G.nodes[nid]
                node_list.append({
                    "id": nid,
                    "label": d.get("label", nid),
                    "source_file": d.get("source_file", ""),
                    "community": d.get("community", ""),
                })

            edge_list = []
            for u, v in edges:
                if u in nodes and v in nodes:
                    d = G.edges[u, v]
                    edge_list.append({
                        "source": u,
                        "target": v,
                        "relation": d.get("relation", ""),
                        "confidence": d.get("confidence", ""),
                    })

            return {
                "mode": mode,
                "start_nodes": [G.nodes[n].get("label", n) for n in start_nodes],
                "nodes": node_list,
                "edges": edge_list,
                "text": text,
            }
        except Exception:
            return {}

    def path(self, source: str, target: str, max_hops: int = 8) -> dict:
        """两节点最短路径。

        Returns:
            dict: {
                "hops": int,
                "path": list[dict],  # 每段包含 node, relation, confidence
                "text": str,
            }
        """
        G = self._load_graph()
        if G is None:
            return {}
        try:
            src_scored = self._score_nodes(G, [t.lower() for t in source.split()])
            tgt_scored = self._score_nodes(G, [t.lower() for t in target.split()])
            if not src_scored or not tgt_scored:
                return {"hops": 0, "path": [], "text": f"No matching nodes for '{source}' or '{target}'."}

            src_nid, tgt_nid = src_scored[0][1], tgt_scored[0][1]
            try:
                path_nodes = nx.shortest_path(G, src_nid, tgt_nid)
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                return {"hops": 0, "path": [], "text": f"No path found between '{source}' and '{target}'."}

            hops = len(path_nodes) - 1
            if hops > max_hops:
                return {"hops": hops, "path": [], "text": f"Path exceeds max_hops={max_hops} ({hops} hops found)."}

            path_segments = []
            text_segments = []
            for i in range(len(path_nodes) - 1):
                u, v = path_nodes[i], path_nodes[i + 1]
                edata = G.edges[u, v]
                rel = edata.get("relation", "")
                conf = edata.get("confidence", "")
                path_segments.append({
                    "from": {"id": u, "label": G.nodes[u].get("label", u)},
                    "to": {"id": v, "label": G.nodes[v].get("label", v)},
                    "relation": rel,
                    "confidence": conf,
                })
                if i == 0:
                    text_segments.append(G.nodes[u].get("label", u))
                text_segments.append(f"--{rel} [{conf}]--> {G.nodes[v].get('label', v)}")

            return {
                "hops": hops,
                "path": path_segments,
                "text": f"Shortest path ({hops} hops): " + " ".join(text_segments),
            }
        except Exception:
            return {}

    def explain(self, node: str) -> dict:
        """节点自然语言解释。

        Returns:
            dict: {
                "node": dict,
                "neighbors": list[dict],
                "text": str,
            }
        """
        G = self._load_graph()
        if G is None:
            return {}
        try:
            matches = self._find_node(G, node)
            if not matches:
                return {"node": {}, "neighbors": [], "text": f"No node matching '{node}' found."}

            nid = matches[0]
            d = G.nodes[nid]
            node_info = {
                "id": nid,
                "label": d.get("label", nid),
                "source_file": d.get("source_file", ""),
                "type": d.get("file_type", ""),
                "community": d.get("community", ""),
                "degree": G.degree(nid),
            }

            neighbors = []
            lines = [
                f"Node: {node_info['label']}",
                f"  ID: {nid}",
                f"  Source: {node_info['source_file']}",
                f"  Type: {node_info['type']}",
                f"  Degree: {node_info['degree']}",
            ]
            for nb in sorted(G.neighbors(nid), key=lambda n: G.degree(n), reverse=True)[:20]:
                edata = G.edges[nid, nb]
                rel = edata.get("relation", "")
                conf = edata.get("confidence", "")
                neighbors.append({
                    "id": nb,
                    "label": G.nodes[nb].get("label", nb),
                    "relation": rel,
                    "confidence": conf,
                })
                lines.append(f"  --> {G.nodes[nb].get('label', nb)} [{rel}] [{conf}]")

            return {
                "node": node_info,
                "neighbors": neighbors,
                "text": "\n".join(lines),
            }
        except Exception:
            return {}

    # ── community queries (Yoneda / 大局观 v3.5) ──────────────────

    def _load_communities(self) -> dict:
        """加载 graphify 社区检测数据 (.graphify_communities_v2.json)。"""
        comm_path = self.graph_dir / ".graphify_communities_v2.json"
        if not comm_path.exists():
            return {}
        try:
            return json.loads(comm_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def get_community_for_node(self, node_id: str) -> dict:
        """获取节点所属社区信息。

        Returns:
            dict: {
                "node_id": str,
                "community_id": int | None,
                "community_size": int,
                "community_members": list[str],
                "god_node": str | None,
            }
        """
        comm_data = self._load_communities()
        communities = comm_data.get("communities", [])
        god_nodes = comm_data.get("god_nodes", [])

        for idx, members in enumerate(communities):
            if node_id in members:
                return {
                    "node_id": node_id,
                    "community_id": idx,
                    "community_size": len(members),
                    "community_members": members,
                    "god_node": god_nodes[idx] if idx < len(god_nodes) else None,
                }
        return {
            "node_id": node_id,
            "community_id": None,
            "community_size": 0,
            "community_members": [],
            "god_node": None,
        }

    def get_community_patterns(self, community_id: str | int) -> list[dict]:
        """获取社区内的高阶模式（共享特征、共同邻居等）。

        Returns:
            list[dict]: 模式列表，每个模式包含 pattern_type, description,
                        affected_concepts, confidence。
        """
        G = self._load_graph()
        comm_data = self._load_communities()
        communities = comm_data.get("communities", [])

        try:
            cid = int(community_id)
        except (ValueError, TypeError):
            return []

        if cid < 0 or cid >= len(communities):
            return []

        members = communities[cid]
        if not members or G is None:
            return []

        patterns = []

        # Pattern 1: shared_prerequisites — 社区内节点共享的共同邻居（入边）
        try:
            common_neighbors = set(G.predecessors(members[0])) if members[0] in G else set()
            for m in members[1:]:
                if m in G:
                    common_neighbors &= set(G.predecessors(m))
            if common_neighbors:
                patterns.append({
                    "pattern_type": "shared_prerequisites",
                    "description": f"社区内 {len(members)} 个概念共享 {len(common_neighbors)} 个共同前置概念",
                    "affected_concepts": list(common_neighbors)[:5],
                    "confidence": round(min(1.0, len(common_neighbors) / max(1, len(members))), 2),
                })
        except Exception:
            pass

        # Pattern 2: confidence_cluster — 社区内平均 degree 与 cohesion
        try:
            degrees = [G.degree(m) for m in members if m in G]
            if degrees:
                avg_deg = sum(degrees) / len(degrees)
                internal_edges = 0
                for m in members:
                    if m not in G:
                        continue
                    for nb in G.neighbors(m):
                        if nb in members:
                            internal_edges += 1
                internal_edges //= 2  # undirected
                max_internal = len(members) * (len(members) - 1) // 2
                cohesion = internal_edges / max_internal if max_internal > 0 else 0.0
                patterns.append({
                    "pattern_type": "confidence_cluster",
                    "description": f"社区内平均连接度 {avg_deg:.1f}，内部凝聚力 {cohesion:.2f}",
                    "affected_concepts": members[:5],
                    "confidence": round(cohesion, 2),
                })
        except Exception:
            pass

        return patterns[:2]  # 限制 2 条避免上下文爆炸

    def get_cross_community_bridges(self, concept_id: str) -> list[dict]:
        """获取跨社区桥梁概念。

        查找与 concept_id 有边连接但属于不同社区的节点。

        Returns:
            list[dict]: {
                "pattern_type": "cross_community_abstraction",
                "source_community": int,
                "target_community": int,
                "abstraction": str,
                "bridge_concepts": list[str],
                "confidence": float,
            }
        """
        G = self._load_graph()
        if G is None or concept_id not in G:
            return []

        my_comm = self.get_community_for_node(concept_id)
        my_cid = my_comm.get("community_id")
        if my_cid is None:
            return []

        # Find all neighbors in different communities
        bridges_by_target_comm: dict[int, list[tuple[str, str, float]]] = {}
        for nb in G.neighbors(concept_id):
            nb_comm = self.get_community_for_node(nb)
            nb_cid = nb_comm.get("community_id")
            if nb_cid is None or nb_cid == my_cid:
                continue
            edata = G.edges[concept_id, nb]
            rel = edata.get("relation", "")
            conf = edata.get("confidence", 0.0)
            bridges_by_target_comm.setdefault(nb_cid, []).append((nb, rel, conf))

        results = []
        for tgt_cid, bridge_list in bridges_by_target_comm.items():
            bridge_list.sort(key=lambda x: x[2], reverse=True)
            top_bridges = [b[0] for b in bridge_list[:3]]
            avg_conf = sum(b[2] for b in bridge_list) / len(bridge_list) if bridge_list else 0.0
            # Heuristic abstraction label: use most common relation
            relations = [b[1] for b in bridge_list if b[1]]
            abstraction = relations[0] if relations else "cross-community link"
            results.append({
                "pattern_type": "cross_community_abstraction",
                "source_community": my_cid,
                "target_community": tgt_cid,
                "abstraction": abstraction,
                "bridge_concepts": top_bridges,
                "confidence": round(avg_conf, 2),
            })

        return results[:2]  # 限制 2 条避免上下文爆炸
