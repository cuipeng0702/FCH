"""FCMS L2 评估层 — 认知健康度评估与盲区检测。"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class CognitiveHealthAssessor:
    """评估单次迭代的认知健康度。"""

    def __init__(self, thresholds: dict | None = None):
        self.thresholds = thresholds or {
            "task_success_rate": 0.80,
            "budget_efficiency": 0.70,
            "depth_score": 0.60,
            "breadth_score": 0.60,
            "consistency_score": 0.70,
        }

    def assess(self, signals: list[dict], history: list[dict] | None = None) -> dict:
        """评估认知健康度。

        Args:
            signals: 当前 iteration 的 L1 信号列表
            history: 最近 3 次 iteration 的信号历史

        Returns:
            诊断报告 dict，包含各维度得分和总体评估
        """
        # 1. 稳定性评估
        stability = self._assess_stability(signals)

        # 2. 效率评估
        efficiency = self._assess_efficiency(signals)

        # 3. 深度评估
        depth = self._assess_depth(signals)

        # 4. 广度评估
        breadth = self._assess_breadth(signals)

        # 5. 一致性评估
        consistency = self._assess_consistency(signals, history)

        # 综合评分
        overall = self._compute_overall(stability, efficiency, depth, breadth, consistency)

        return {
            "type": "diagnosis",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "assessment_version": "1.0",
            "dimension_scores": {
                "stability": stability,
                "efficiency": efficiency,
                "depth": depth,
                "breadth": breadth,
                "consistency": consistency,
            },
            "overall_score": overall,
            "health_status": self._classify_health(overall),
            "alerts": self._generate_alerts(stability, efficiency, depth, breadth, consistency),
            "recommended_adjustments": self._generate_adjustments(
                stability, efficiency, depth, breadth, consistency
            ),
        }

    def _assess_stability(self, signals: list[dict]) -> float:
        """稳定性: 任务成功率、异常频率。

        修复后: 区分"破坏性变更"和"扩展性变更"。
        - 任务失败/异常 -> 降低稳定性
        - 新增任务（如 bridge concepts）-> 不降低稳定性（扩展性变更）
        """
        # 检查任务失败信号
        failed_tasks = [s for s in signals if s.get("type") == "task_failed"]
        if failed_tasks:
            return max(0.3, 1.0 - len(failed_tasks) * 0.2)

        # 检查异常信号
        exception_signals = [s for s in signals if s.get("type") == "exception"]
        if exception_signals:
            return max(0.5, 1.0 - len(exception_signals) * 0.15)

        # 任务成功完成 -> 高稳定性（扩展性变更不扣分）
        task_signals = [s for s in signals if s.get("type") == "task_completed"]
        if task_signals:
            return 1.0

        return 0.5

    def _assess_efficiency(self, signals: list[dict]) -> float:
        """效率: budget/产出比。

        修复后: 消耗率过低(0.05-0.15)不应严重扣分——可能表示高产出/低消耗。
        理想消耗率 0.15-0.40 之间。"""
        budget_signals = [s for s in signals if s.get("type") == "budget_consumed"]
        if not budget_signals:
            return 0.5
        rate = budget_signals[0]["data"].get("consumption_rate", 0.5)
        # 理想消耗率在 0.15-0.40 之间
        if 0.15 <= rate <= 0.40:
            return 0.85
        elif 0.05 <= rate < 0.15:
            return 0.75  # 低消耗但可接受（高产出/低消耗）
        elif rate < 0.05:
            return 0.65  # 消耗过慢，可能任务过于简单
        else:
            return max(0.3, 1.0 - rate)  # 消耗太快

    def _assess_depth(self, signals: list[dict]) -> float:
        """深度: D4 得分趋势"""
        audit_signals = [s for s in signals if s.get("type") == "audit_score"]
        if not audit_signals:
            return 0.5
        scores = audit_signals[0]["data"]
        # D4 是关键深度指标
        d4 = scores.get("d4", 0.5)
        return max(0.0, min(1.0, d4))

    def _assess_breadth(self, signals: list[dict]) -> float:
        """广度: 概念覆盖率、盲区数量。

        修复后算法：
        - 考虑 gap 的 severity 权重（critical=2, warning=1, info=0.5）
        - 考虑 resolved gaps（解决一个 gap 抵消 0.5 个新 gap）
        - 净 severity 分数用于计算 breadth
        """
        gap_produced = [s for s in signals if s.get("type") == "gap_produced"]
        gap_closed = [s for s in signals if s.get("type") == "gap_closed"]

        new_gaps = 0
        severity_weight = 0.0
        if gap_produced:
            data = gap_produced[0]["data"]
            new_gaps = data.get("count", 0)
            # 如果有 severity 分布，使用它
            by_layer = data.get("by_layer", {})
            # 简化: 假设每个 gap 的 severity 可通过层推断
            # 或用默认权重: 每个新 gap 至少 0.5
            severity_weight = new_gaps * 0.5

        resolved = 0
        if gap_closed:
            resolved = gap_closed[0]["data"].get("count", 0)

        # 净 gap 分数 = 新 gap 权重 - 已解决 * 0.5
        net_severity = max(0.0, severity_weight - resolved * 0.5)

        # 基于净 severity 计算 breadth
        # net=0 -> breadth=1.0, net>=5 -> breadth=0.1
        breadth = max(0.1, min(1.0, 1.0 - net_severity * 0.18))
        return round(breadth, 2)

    def _assess_consistency(self, signals: list[dict], history: list[dict] | None) -> float:
        """一致性: 级联频率、依赖漂移"""
        cascade_signals = [s for s in signals if s.get("type") == "cascade_triggered"]
        if not cascade_signals:
            return 0.8  # 无级联 = 高一致性
        # 级联越频繁，一致性越低（说明变更传播过多）
        depth = cascade_signals[0]["data"].get("depth", 0)
        return max(0.3, 1.0 - depth * 0.2)

    def _compute_overall(self, stability: float, efficiency: float,
                          depth: float, breadth: float, consistency: float) -> float:
        """计算综合评分，加权平均"""
        weights = {"stability": 0.20, "efficiency": 0.20, "depth": 0.25,
                   "breadth": 0.20, "consistency": 0.15}
        score = (stability * weights["stability"] +
                 efficiency * weights["efficiency"] +
                 depth * weights["depth"] +
                 breadth * weights["breadth"] +
                 consistency * weights["consistency"])
        return round(score, 2)

    def _classify_health(self, overall: float) -> str:
        """分类健康状态"""
        if overall >= 0.80:
            return "healthy"
        elif overall >= 0.60:
            return "warning"
        else:
            return "critical"

    def _generate_alerts(self, stability: float, efficiency: float,
                          depth: float, breadth: float, consistency: float) -> list[dict]:
        """生成异常警报"""
        alerts = []
        dimensions = [
            ("stability", stability, 0.70),
            ("efficiency", efficiency, 0.70),
            ("depth", depth, 0.60),
            ("breadth", breadth, 0.60),
            ("consistency", consistency, 0.60),
        ]
        for name, score, threshold in dimensions:
            if score < threshold:
                alerts.append({
                    "dimension": name,
                    "severity": "warning" if score >= threshold * 0.8 else "critical",
                    "current_score": score,
                    "threshold": threshold,
                    "message": f"{name} score ({score:.2f}) below threshold ({threshold})",
                })
        return alerts

    def _generate_adjustments(self, stability: float, efficiency: float,
                               depth: float, breadth: float, consistency: float) -> list[dict]:
        """生成调整建议"""
        adjustments = []
        if efficiency < 0.60:
            adjustments.append({
                "target": "budget.json",
                "action": "reallocate",
                "parameter": {"search_budget_ratio": 0.15},
                "expected_improvement": "efficiency +0.10",
                "auto_apply": True,
            })
        if depth < 0.60:
            adjustments.append({
                "target": "thresholds.json",
                "action": "lower_audit_threshold",
                "parameter": {"audit_aggregate": "0.80"},
                "expected_improvement": "depth +0.15",
                "auto_apply": False,  # 阈值调整需确认
            })
        if consistency < 0.60:
            adjustments.append({
                "target": "orchestrator.cascade_depth",
                "action": "limit_cascade_depth",
                "parameter": {"max_depth": 1},
                "expected_improvement": "consistency +0.20",
                "auto_apply": True,
            })
        return adjustments


class BlindSpotDetector:
    """检测认知盲区——系统无法自我发现的问题。"""

    def __init__(self):
        self.known_blind_spot_patterns = [
            "repeated_gap_reappearance",
            "teach_candidate_ignored",
            "audit_score_stagnation",
            "context_redundancy_spike",
            "subagent_failure_cluster",
        ]

    def detect(self, signals: list[dict], history: list[dict] | None = None) -> list[dict]:
        """检测盲区。

        Returns:
            盲区列表，每个盲区包含: type, description, evidence, severity
        """
        blind_spots = []

        # 1. 重复 gap 检测
        blind_spots.extend(self._detect_repeated_gaps(signals, history))

        # 2. teach candidate 被忽略检测
        blind_spots.extend(self._detect_ignored_candidates(signals, history))

        # 3. 审计得分停滞检测
        blind_spots.extend(self._detect_audit_stagnation(signals, history))

        # 4. 上下文冗余激增检测
        blind_spots.extend(self._detect_context_redundancy(signals, history))

        return blind_spots

    def _detect_repeated_gaps(self, signals: list[dict], history: list[dict] | None) -> list[dict]:
        """检测重复出现的 gap"""
        if not history:
            return []
        # 简化: 检查最近 3 次 iteration 的 gap 是否有重叠
        recent_gaps = []
        for h in history[-3:]:
            gap_signals = [s for s in h if s.get("type") == "gap_produced"]
            for gs in gap_signals:
                recent_gaps.extend(gs["data"].get("gaps", []))
        # 统计重复
        gap_counts = {}
        for gap in recent_gaps:
            gid = gap.get("gap_id", gap.get("id", str(hash(str(gap)))))
            gap_counts[gid] = gap_counts.get(gid, 0) + 1
        repeated = [gid for gid, count in gap_counts.items() if count >= 2]
        if repeated:
            return [{
                "type": "repeated_gap_reappearance",
                "description": f"Gaps {repeated} appeared in multiple iterations",
                "evidence": ["gap_produced signals from last 3 iterations"],
                "severity": "warning",
                "recommended_action": "Modify grow_task_template to force resolved_by_new_node",
            }]
        return []

    def _detect_ignored_candidates(self, signals: list[dict], history: list[dict] | None) -> list[dict]:
        """检测 teach_candidates 被系统忽略"""
        # 简化: 检查 grow 信号中是否有 teach_candidates 但后续无 teach 信号
        grow_signals = [s for s in signals if s.get("type") == "gap_produced"]
        if not grow_signals:
            return []
        candidates = grow_signals[0]["data"].get("teach_candidates", [])
        if candidates and not any(s.get("type") == "task_completed" and "teach" in s["data"].get("tasks", [])
                                  for s in signals):
            return [{
                "type": "teach_candidate_ignored",
                "description": f"{len(candidates)} teach candidates were generated but no teach task was spawned",
                "evidence": ["grow_output.json teach_candidates"],
                "severity": "critical",
                "recommended_action": "Check orchestrator routing logic for teach_candidates",
            }]
        return []

    def _detect_audit_stagnation(self, signals: list[dict], history: list[dict] | None) -> list[dict]:
        """检测审计得分停滞"""
        if not history or len(history) < 2:
            return []
        # 比较最近两次的 audit_score
        recent_scores = []
        for h in history[-2:]:
            audit_signals = [s for s in h if s.get("type") == "audit_score"]
            if audit_signals:
                scores = audit_signals[0]["data"]
                avg = sum(scores.values()) / len(scores) if scores else 0
                recent_scores.append(avg)
        if len(recent_scores) >= 2 and abs(recent_scores[-1] - recent_scores[0]) < 0.05:
            return [{
                "type": "audit_score_stagnation",
                "description": "Audit scores have not improved over last 2 iterations",
                "evidence": [f"scores: {recent_scores}"],
                "severity": "warning",
                "recommended_action": "Switch teaching strategy or lower audit threshold",
            }]
        return []

    def _detect_context_redundancy(self, signals: list[dict], history: list[dict] | None) -> list[dict]:
        """检测上下文冗余激增"""
        # 简化: 检查 state 大小变化
        return []  # 需要更复杂的上下文分析


class ConvergenceQualityEvaluator:
    """评估收敛质量——判断当前收敛是真实的还是虚假的。"""

    def evaluate(self, current_signals: list[dict], history: list[dict]) -> dict:
        """评估收敛质量。

        虚假收敛标志:
        - gap 数量减少但 teach_candidates 未执行
        - audit 分数提高但 mapping_failures 未减少
        - 多次 iteration 后相同 gap 以不同措辞出现
        """
        false_convergence_flags = []

        # 检查 1: gap 减少但 candidate 未执行
        gap_signals = [s for s in current_signals if s.get("type") == "gap_produced"]
        if gap_signals:
            gap_count = gap_signals[0]["data"].get("count", 0)
            if gap_count == 0:
                # 检查是否有未执行的 teach_candidates
                # (需要历史数据)
                pass

        # 检查 2: audit 分数 vs mapping failures
        audit_signals = [s for s in current_signals if s.get("type") == "audit_score"]
        # 简化实现

        return {
            "converged": False,
            "confidence": 0.5,
            "false_convergence_flags": false_convergence_flags,
            "recommendation": "continue",
        }
