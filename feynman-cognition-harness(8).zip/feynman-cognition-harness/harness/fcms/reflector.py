"""FCMS L3 反思层 — 即时反思、批次反思、DREAM 整合。

反思不是"思考更多"，而是"从不同角度审视已发生的事件"。
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ImmediateReflector:
    """即时反思 — 异常触发时立即运行。

    输入: 单次迭代的 L2 诊断报告
    输出: 根因分析 + 即时建议
    """

    def reflect(self, diagnosis: dict) -> dict:
        """执行即时反思。

        触发条件: diagnosis.health_status in ["warning", "critical"]
        """
        health = diagnosis.get("health_status", "unknown")
        if health == "healthy":
            return {"type": "reflection", "mode": "immediate", "triggered": False}

        alerts = diagnosis.get("alerts", [])
        adjustments = diagnosis.get("recommended_adjustments", [])

        # 根因分析
        root_causes = self._analyze_root_causes(alerts)

        # 建议调整（去重和排序）
        prioritized_adjustments = self._prioritize_adjustments(adjustments)

        return {
            "type": "reflection",
            "mode": "immediate",
            "triggered": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "trigger_reason": f"Health status: {health}",
            "root_causes": root_causes,
            "recommended_adjustments": prioritized_adjustments,
            "expected_improvement": self._estimate_improvement(prioritized_adjustments),
        }

    def _analyze_root_causes(self, alerts: list[dict]) -> list[dict]:
        """从警报中分析根因。"""
        root_causes = []
        for alert in alerts:
            dim = alert.get("dimension", "unknown")
            severity = alert.get("severity", "warning")
            if dim == "efficiency" and severity == "critical":
                root_causes.append({
                    "type": "resource_misallocation",
                    "description": "Budget consumed too fast — likely due to redundant search or excessive subagent spawning",
                    "evidence": [alert],
                })
            elif dim == "depth" and severity in ["warning", "critical"]:
                root_causes.append({
                    "type": "teaching_strategy_mismatch",
                    "description": "D4 score low — teaching strategy may not be building deep understanding",
                    "evidence": [alert],
                })
            elif dim == "consistency":
                root_causes.append({
                    "type": "cascade_churn",
                    "description": "Frequent cascades indicate unstable concept definitions",
                    "evidence": [alert],
                })
            elif dim == "breadth":
                root_causes.append({
                    "type": "incomplete_coverage",
                    "description": "Too many gaps remain — concept not fully decomposed",
                    "evidence": [alert],
                })
        return root_causes

    def _prioritize_adjustments(self, adjustments: list[dict]) -> list[dict]:
        """按预期改善幅度排序调整建议。"""
        def improvement_key(adj):
            imp = adj.get("expected_improvement", "0.00")
            try:
                return float(imp.split()[0].replace("+", ""))
            except:
                return 0.0
        return sorted(adjustments, key=improvement_key, reverse=True)

    def _estimate_improvement(self, adjustments: list[dict]) -> str:
        """估算总体改善幅度。"""
        total = 0.0
        for adj in adjustments:
            imp = adj.get("expected_improvement", "0.00")
            try:
                total += float(imp.split()[0].replace("+", ""))
            except:
                pass
        return f"overall +{total:.2f}"


class BatchReflector:
    """批次反思 — 每 5 次迭代运行一次。

    输入: 最近 5 次迭代的诊断报告列表
    输出: 模式识别 + 趋势分析 + 策略建议
    """

    BATCH_SIZE = 5

    def reflect(self, diagnoses: list[dict]) -> dict:
        """执行批次反思。

        Args:
            diagnoses: 最近 N 次迭代的诊断报告
        """
        if len(diagnoses) < 2:
            return {"type": "reflection", "mode": "batch", "triggered": False, "reason": "insufficient data"}

        # 1. 趋势分析
        trends = self._analyze_trends(diagnoses)

        # 2. 模式识别
        patterns = self._identify_patterns(diagnoses)

        # 3. 策略建议
        strategy_recommendations = self._generate_strategy_recommendations(trends, patterns)

        return {
            "type": "reflection",
            "mode": "batch",
            "triggered": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "scope": f"last {len(diagnoses)} iterations",
            "trends": trends,
            "patterns": patterns,
            "strategy_recommendations": strategy_recommendations,
            "confidence": self._compute_confidence(diagnoses),
        }

    def _analyze_trends(self, diagnoses: list[dict]) -> dict:
        """分析各维度的趋势。"""
        scores = {dim: [] for dim in ["stability", "efficiency", "depth", "breadth", "consistency"]}
        for d in diagnoses:
            dims = d.get("dimension_scores", {})
            for dim in scores:
                scores[dim].append(dims.get(dim, 0.5))

        trends = {}
        for dim, vals in scores.items():
            if len(vals) >= 2:
                delta = vals[-1] - vals[0]
                trends[dim] = {
                    "direction": "improving" if delta > 0.05 else "degrading" if delta < -0.05 else "stable",
                    "delta": round(delta, 2),
                    "latest": round(vals[-1], 2),
                }
        return trends

    def _identify_patterns(self, diagnoses: list[dict]) -> list[dict]:
        """识别重复出现的模式。"""
        patterns = []

        # 模式 1: 持续 warning
        warning_count = sum(1 for d in diagnoses if d.get("health_status") == "warning")
        if warning_count >= 3:
            patterns.append({
                "type": "persistent_warning",
                "description": f"Health status remained warning for {warning_count} consecutive iterations",
                "severity": "warning",
                "recommendation": "Consider lowering audit thresholds or switching teaching strategy",
            })

        # 模式 2: 深度停滞
        depths = [d.get("dimension_scores", {}).get("depth", 0.5) for d in diagnoses]
        if len(depths) >= 3 and max(depths) - min(depths) < 0.1:
            patterns.append({
                "type": "depth_stagnation",
                "description": "Depth scores have plateaued — D4 understanding is not deepening",
                "severity": "critical",
                "recommendation": "Force analogy re-selection or add counter-example exploration",
            })

        # 模式 3: 效率下降
        effs = [d.get("dimension_scores", {}).get("efficiency", 0.5) for d in diagnoses]
        if len(effs) >= 3 and effs[-1] < effs[0] - 0.15:
            patterns.append({
                "type": "efficiency_decline",
                "description": "Efficiency has declined significantly — budget is being wasted",
                "severity": "warning",
                "recommendation": "Review subagent spawn strategy and reduce redundant searches",
            })

        return patterns

    def _generate_strategy_recommendations(self, trends: dict, patterns: list[dict]) -> list[dict]:
        """生成策略级建议。"""
        recommendations = []

        # 基于趋势的建议
        depth_trend = trends.get("depth", {})
        if depth_trend.get("direction") == "degrading":
            recommendations.append({
                "level": "strategy",
                "target": "teaching_strategy",
                "current": "unknown",
                "recommended": "formal-first",
                "reason": "Depth is degrading — formal-first may build stronger foundations",
                "confidence": 0.70,
            })

        # 基于模式的建议
        for pattern in patterns:
            if pattern["type"] == "persistent_warning":
                recommendations.append({
                    "level": "parameter",
                    "target": "thresholds.json",
                    "action": "lower_audit_threshold",
                    "value": 0.80,
                    "reason": "Persistent warnings suggest thresholds are too strict",
                })

        return recommendations

    def _compute_confidence(self, diagnoses: list[dict]) -> float:
        """计算反思结论的置信度。"""
        # 数据越多越可信
        n = len(diagnoses)
        base = min(1.0, 0.5 + n * 0.05)
        # 如果数据一致性好，置信度更高
        return round(base, 2)


class DREAMIntegrator:
    """DREAM 整合器 — 将 DREAM 深度扫描结果整合到 FCMS。

    DREAM 是 L3 的批量深度模式，不是独立模块。
    """

    def integrate(self, dream_report: dict, current_state: dict) -> dict:
        """将 DREAM 报告整合到 FCMS 反思输出。

        Args:
            dream_report: DREAM 引擎的夜间扫描报告
            current_state: 当前系统状态

        Returns:
            整合后的 L3 反思输出
        """
        # 提取 DREAM 洞察
        patterns = dream_report.get("patterns", [])
        contradictions = dream_report.get("contradictions", [])
        coverage_gaps = dream_report.get("coverage_gaps", [])
        structure_issues = dream_report.get("structure_issues", [])

        # 映射到 FCMS 格式
        return {
            "type": "reflection",
            "mode": "dream",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "dream_id": dream_report.get("dream_id", "unknown"),
            "insights": {
                "patterns": patterns,
                "contradictions": contradictions,
                "coverage_gaps": coverage_gaps,
                "structure_issues": structure_issues,
            },
            "cross_concept_recommendations": self._extract_cross_concept_insights(patterns),
            "regulation_recommendations": dream_report.get("regulation_recommendations", []),
        }

    def _extract_cross_concept_insights(self, patterns: list[dict]) -> list[dict]:
        """提取跨概念洞察。"""
        cross_insights = []
        for pattern in patterns:
            if "cross-concept" in pattern.get("type", "") or "analogy" in pattern.get("type", ""):
                cross_insights.append(pattern)
        return cross_insights
