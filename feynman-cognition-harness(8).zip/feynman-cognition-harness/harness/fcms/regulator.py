"""FCMS L4 调控层 — 自适应参数调整与预算重分配。"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class AdaptiveThresholdAdjuster:
    """根据 L2 诊断动态调整审计阈值。"""

    def __init__(self, safety_bounds: dict | None = None):
        self.safety_bounds = safety_bounds or {
            "audit_aggregate": {"min": 0.60, "max": 0.95, "default": 0.85},
            "cold_start_audit": {"min": 0.60, "max": 0.95, "default": 0.85},
            "cold_start_bdd": {"min": 0.50, "max": 0.90, "default": 0.75},
        }
        self.history = []  # 记录每次调整

    def adjust(self, diagnosis: dict, current_thresholds: dict) -> tuple[dict, list[dict]]:
        """根据诊断报告调整阈值。

        Args:
            diagnosis: L2 诊断报告
            current_thresholds: 当前 thresholds.json 内容

        Returns:
            (调整后的阈值 dict, 调整记录列表)
        """
        adjusted = dict(current_thresholds)
        adjustments = []

        depth_score = diagnosis.get("dimension_scores", {}).get("depth", 0.5)
        stability_score = diagnosis.get("dimension_scores", {}).get("stability", 0.5)
        overall = diagnosis.get("overall_score", 0.5)

        # 规则 1: 深度得分持续低 → 降低审计阈值（让系统更容易通过）
        if depth_score < 0.60:
            key = "audit_aggregate"
            current = adjusted.get(key, self.safety_bounds[key]["default"])
            new_val = max(self.safety_bounds[key]["min"], current - 0.05)
            if new_val != current:
                adjusted[key] = round(new_val, 2)
                adjustments.append({
                    "target": key,
                    "old": current,
                    "new": adjusted[key],
                    "reason": f"depth score ({depth_score:.2f}) below threshold, lowering to allow more teach iterations",
                })

        # 规则 2: 稳定性低 → 提高审计阈值（更严格，减少错误通过）
        if stability_score < 0.60:
            key = "audit_aggregate"
            current = adjusted.get(key, self.safety_bounds[key]["default"])
            new_val = min(self.safety_bounds[key]["max"], current + 0.03)
            if new_val != current:
                adjusted[key] = round(new_val, 2)
                adjustments.append({
                    "target": key,
                    "old": current,
                    "new": adjusted[key],
                    "reason": f"stability score ({stability_score:.2f}) low, raising to catch more errors",
                })

        # 规则 3: 整体健康度 critical → 回到默认值
        if overall < 0.40:
            for key, bounds in self.safety_bounds.items():
                if adjusted.get(key) != bounds["default"]:
                    old = adjusted[key]
                    adjusted[key] = bounds["default"]
                    adjustments.append({
                        "target": key,
                        "old": old,
                        "new": adjusted[key],
                        "reason": f"overall health critical ({overall:.2f}), resetting to default",
                    })

        # 记录历史
        if adjustments:
            self.history.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "trigger_diagnosis": diagnosis,
                "adjustments": adjustments,
            })

        return adjusted, adjustments

    def get_adjustment_history(self) -> list[dict]:
        """获取调整历史。"""
        return self.history


class BudgetReallocator:
    """根据 L2 诊断在任务间重分配 budget。"""

    def __init__(self, reserve_ratio: float = 0.20):
        self.reserve_ratio = reserve_ratio

    def reallocate(self, diagnosis: dict, current_budget: dict) -> dict:
        """根据诊断重分配 budget。

        策略:
        - 深度得分低 → 增加 search + teach budget
        - 广度得分低 → 增加 grow budget
        - 效率得分低 → 减少 search budget，增加 consolidate budget
        - 始终保留 20% 应急储备

        Args:
            diagnosis: L2 诊断报告
            current_budget: 当前 budget.json 内容

        Returns:
            调整后的 budget dict
        """
        adjusted = dict(current_budget)
        total = adjusted.get("max_spawn", 100)
        remaining = adjusted.get("remaining", total)
        reserve = int(total * self.reserve_ratio)
        available = max(0, remaining - reserve)

        if available <= 0:
            return adjusted

        # 读取当前分配
        allocations = adjusted.get("task_allocations", {})
        depth = diagnosis.get("dimension_scores", {}).get("depth", 0.5)
        breadth = diagnosis.get("dimension_scores", {}).get("breadth", 0.5)
        efficiency = diagnosis.get("dimension_scores", {}).get("efficiency", 0.5)

        # 规则 1: 深度低 → 增加 search 预算
        if depth < 0.60:
            search_budget = int(available * 0.25)
            allocations["search"] = allocations.get("search", 0) + search_budget
            available -= search_budget

        # 规则 2: 广度低 → 增加 grow 预算
        if breadth < 0.60:
            grow_budget = int(available * 0.20)
            allocations["grow"] = allocations.get("grow", 0) + grow_budget
            available -= grow_budget

        # 规则 3: 效率低 → 减少 search，增加 consolidate
        if efficiency < 0.60:
            search_cut = int(allocations.get("search", 0) * 0.20)
            allocations["search"] = max(0, allocations.get("search", 0) - search_cut)
            allocations["consolidate"] = allocations.get("consolidate", 0) + search_cut

        # 剩余 budget 保留在 reserve
        adjusted["task_allocations"] = allocations
        adjusted["reserve"] = reserve + available

        return adjusted


class RouteOptimizer:
    """根据 L2 诊断优化任务路由策略。"""

    def optimize(self, diagnosis: dict, current_routing: dict) -> dict:
        """优化路由。

        策略:
        - 一致性低 → 限制 cascade 深度
        - 效率低 → 启用 lightweight audit
        - 深度低 → 强制 analogy-first strategy
        """
        optimized = dict(current_routing)
        consistency = diagnosis.get("dimension_scores", {}).get("consistency", 0.5)
        efficiency = diagnosis.get("dimension_scores", {}).get("efficiency", 0.5)
        depth = diagnosis.get("dimension_scores", {}).get("depth", 0.5)

        # 限制 cascade 深度
        if consistency < 0.60:
            optimized["max_cascade_depth"] = 1

        # 启用 lightweight audit
        if efficiency < 0.60:
            optimized["lightweight_audit"] = True

        # 强制 analogy-first
        if depth < 0.60:
            optimized["preferred_strategy"] = "analogy-first"

        return optimized


class RegulationSafetyChecker:
    """调控安全边界检查器。"""

    def __init__(self):
        self.rules = [
            {
                "name": "threshold_bounds",
                "check": lambda adj: all(
                    0.5 <= v <= 0.95 for k, v in adj.items() if k.endswith("_threshold")
                ),
                "message": "Threshold values must be within [0.5, 0.95]",
            },
            {
                "name": "budget_reserve",
                "check": lambda budget: budget.get("reserve", 0) >= budget.get("max_spawn", 100) * 0.15,
                "message": "Budget reserve must be at least 15% of total",
            },
            {
                "name": "no_negative_allocations",
                "check": lambda budget: all(
                    v >= 0 for v in budget.get("task_allocations", {}).values()
                ),
                "message": "Task allocations must be non-negative",
            },
        ]

    def check(self, regulation: dict) -> dict:
        """检查调控是否安全。"""
        failures = []
        for rule in self.rules:
            try:
                if not rule["check"](regulation):
                    failures.append({
                        "rule": rule["name"],
                        "message": rule["message"],
                    })
            except Exception as e:
                failures.append({
                    "rule": rule["name"],
                    "message": f"Check failed with error: {e}",
                })

        return {
            "safe": len(failures) == 0,
            "failures": failures,
        }


class PitfallGuideGenerator:
    """从 L2 诊断 + L3 反思生成结构化避坑指南。

    输出按任务隔离（teach / grow / search / audit），
    每条指南 ≤100 字，极简 actionable。
    """

    TASK_KEYS = ["teach", "grow", "search", "audit", "verify", "consolidate"]

    def __init__(self, max_length: int = 100):
        self.max_length = max_length

    def generate(self, diagnosis: dict, reflection: dict | None = None) -> dict:
        """根据诊断和反思生成 pitfall_guides dict。

        Returns:
            {"teach_pitfalls": ["..."], "grow_pitfalls": ["..."], ...}
        """
        guides: dict[str, list[str]] = {f"{k}_pitfalls": [] for k in self.TASK_KEYS}
        dim = diagnosis.get("dimension_scores", {})
        issues = diagnosis.get("issues", [])
        refl_issues = (reflection or {}).get("issues", [])

        # --- Teach pitfalls ---
        if dim.get("depth", 1.0) < 0.60:
            guides["teach_pitfalls"].append(
                "D3 定义深度不足，建议增加形式化记号与边界条件"
            )
        if dim.get("consistency", 1.0) < 0.60:
            guides["teach_pitfalls"].append(
                "跨层映射不一致，建议生成 D1-D4 后自检对应关系"
            )
        # Detect analogy overload from issues
        for issue in issues:
            desc = issue.get("description", "")
            if "analogy" in desc.lower() and "overload" in desc.lower():
                guides["teach_pitfalls"].append(
                    "连续多轮 D1 类比超载，建议换域或命名空间隔离"
                )
            if "abstract" in desc.lower() and "d3" in desc.lower():
                guides["teach_pitfalls"].append(
                    "上一轮 D3 定义过于抽象导致 audit 不通过，建议从具体实例出发"
                )

        # --- Grow pitfalls ---
        if dim.get("breadth", 1.0) < 0.60:
            guides["grow_pitfalls"].append(
                "gap 诊断广度不足，建议提高步骤分解粒度至 ≥5 步"
            )
        for issue in issues:
            desc = issue.get("description", "")
            if "gap" in desc.lower() and "d2" in desc.lower():
                guides["grow_pitfalls"].append(
                    "连续两轮 gap 集中在 D2，建议检查 D1→D2 映射完整性"
                )

        # --- Search pitfalls ---
        if dim.get("efficiency", 1.0) < 0.60:
            guides["search_pitfalls"].append(
                "搜索结果重复率高，建议变换查询词或引入学术源"
            )

        # --- Audit pitfalls ---
        if dim.get("stability", 1.0) < 0.60:
            guides["audit_pitfalls"].append(
                "audit 评分波动大，建议固定评分维度权重"
            )

        # --- Verify / Consolidate (from reflection) ---
        if reflection:
            r_depth = reflection.get("depth", {})
            if r_depth.get("cross_time", 1.0) < 0.60:
                guides["verify_pitfalls"].append(
                    "跨时间一致性下降，建议回溯最早通过的 D3 定义"
                )
            if r_depth.get("confidence_collapse", False):
                guides["consolidate_pitfalls"].append(
                    "置信度崩溃信号，建议标记当前 lattice 为 unstable"
                )

        # Deduplicate and truncate
        for key in guides:
            seen = set()
            deduped = []
            for g in guides[key]:
                if g not in seen:
                    seen.add(g)
                    # Truncate to max_length
                    if len(g) > self.max_length:
                        g = g[: self.max_length - 1] + "…"
                    deduped.append(g)
            guides[key] = deduped

        return guides


class BatchReflector:
    """跨轮认知模式合并器。

    去重 → 聚类 → 生成通用规则。
    每 5 轮由 orchestrator 触发调用。
    """

    def __init__(self, similarity_threshold: float = 0.75):
        self.similarity_threshold = similarity_threshold

    def merge_across_rounds(self, patterns: list[dict]) -> list[dict]:
        """Merge pattern entries across iterations.

        Args:
            patterns: List of {"iteration": int, "patterns": dict}

        Returns:
            List of merged pattern entries, deduplicated and clustered.
        """
        if not patterns:
            return []

        import hashlib

        def _hash(text: str) -> str:
            return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]

        # Flatten all pattern texts with provenance
        flat: list[dict] = []
        for entry in patterns:
            iteration = entry.get("iteration", 0)
            pdict = entry.get("patterns", {})
            for category, texts in pdict.items():
                if isinstance(texts, str):
                    texts = [texts]
                for text in texts:
                    flat.append({
                        "text": text,
                        "category": category,
                        "iteration": iteration,
                        "hash": _hash(text),
                    })

        # Deduplicate by hash
        by_hash: dict[str, dict] = {}
        for item in flat:
            h = item["hash"]
            if h not in by_hash:
                by_hash[h] = {
                    "text": item["text"],
                    "category": item["category"],
                    "iterations": [item["iteration"]],
                    "hash": h,
                }
            else:
                by_hash[h]["iterations"].append(item["iteration"])
                by_hash[h]["iterations"] = list(set(by_hash[h]["iterations"]))

        # Simple clustering: group by category + shared keywords
        clusters: dict[str, list[dict]] = {}
        for item in by_hash.values():
            cat = item["category"]
            key = self._cluster_key(item["text"], cat)
            clusters.setdefault(key, []).append(item)

        # Generate merged entries
        merged: list[dict] = []
        for key, items in clusters.items():
            if len(items) == 1:
                merged.append({
                    "iteration_range": items[0]["iterations"],
                    "patterns": {items[0]["category"]: [items[0]["text"]]},
                })
            else:
                # Multi-item cluster: generate general rule
                cat = items[0]["category"]
                texts = [i["text"] for i in items]
                all_iters = sorted(set(
                    it for i in items for it in i["iterations"]
                ))
                general = self._generalize(texts, cat)
                merged.append({
                    "iteration_range": all_iters,
                    "patterns": {cat: [general]},
                    "merged_from": len(items),
                })

        return merged

    def _cluster_key(self, text: str, category: str) -> str:
        """Generate a simple clustering key from text keywords."""
        import re
        # Extract key nouns/verbs (simple heuristic)
        words = re.findall(r"[\u4e00-\u9fa5]{2,}|[a-zA-Z]{4,}", text.lower())
        # Use top 3 longest words + category
        top = sorted(set(words), key=len, reverse=True)[:3]
        return f"{category}::{':'.join(top)}"

    def _generalize(self, texts: list[str], category: str) -> str:
        """Generate a general rule from clustered texts.

        Simple implementation: find longest common substring heuristic
        or fall back to a synthesized sentence.
        """
        import re
        # Try to find common keywords across all texts
        word_sets = []
        for t in texts:
            words = set(re.findall(r"[\u4e00-\u9fa5]{2,}|[a-zA-Z]{4,}", t.lower()))
            word_sets.append(words)

        if word_sets:
            common = word_sets[0]
            for ws in word_sets[1:]:
                common &= ws
        else:
            common = set()

        if common:
            common_str = "、".join(list(common)[:3])
            return f"跨轮重复模式（{category}）：{common_str} — 建议建立通用检查清单"
        else:
            return f"跨轮重复模式（{category}）：共 {len(texts)} 条经验，建议抽象为规则"


def demo():
    """快速验证各组件可独立运行。"""
    print("=== FCMS L4 Regulator Demo ===\n")

    # 1. AdaptiveThresholdAdjuster
    adjuster = AdaptiveThresholdAdjuster()
    diagnosis = {
        "overall_score": 0.35,
        "dimension_scores": {"depth": 0.55, "stability": 0.50, "breadth": 0.70, "efficiency": 0.60, "consistency": 0.65},
        "health_status": "degraded",
    }
    current_thresholds = {"audit_aggregate": 0.85, "cold_start_audit": 0.85, "cold_start_bdd": 0.75}
    adjusted, adjustments = adjuster.adjust(diagnosis, current_thresholds)
    print("[AdaptiveThresholdAdjuster]")
    print(f"  adjustments: {len(adjustments)}")
    for a in adjustments:
        print(f"    - {a['target']}: {a['old']} -> {a['new']} | {a['reason']}")
    print()

    # 2. BudgetReallocator
    realloc = BudgetReallocator(reserve_ratio=0.20)
    budget = {"max_spawn": 100, "remaining": 80, "task_allocations": {"search": 10, "grow": 10, "consolidate": 5}}
    new_budget = realloc.reallocate(diagnosis, budget)
    print("[BudgetReallocator]")
    print(f"  reserve: {new_budget.get('reserve')}")
    print(f"  allocations: {new_budget.get('task_allocations')}")
    print()

    # 3. RouteOptimizer
    optimizer = RouteOptimizer()
    routing = {"max_cascade_depth": 3, "lightweight_audit": False, "preferred_strategy": "auto"}
    new_routing = optimizer.optimize(diagnosis, routing)
    print("[RouteOptimizer]")
    print(f"  max_cascade_depth: {new_routing.get('max_cascade_depth')}")
    print(f"  lightweight_audit: {new_routing.get('lightweight_audit')}")
    print(f"  preferred_strategy: {new_routing.get('preferred_strategy')}")
    print()

    # 4. RegulationSafetyChecker
    checker = RegulationSafetyChecker()
    regulation = {"audit_aggregate_threshold": 0.88, "budget": new_budget}
    result = checker.check(regulation)
    print("[RegulationSafetyChecker]")
    print(f"  safe: {result['safe']}")
    print(f"  failures: {result['failures']}")
    print()

    print("=== Demo completed ===")


if __name__ == "__main__":
    demo()
