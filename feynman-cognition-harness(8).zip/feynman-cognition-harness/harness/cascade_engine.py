"""Cascade Engine v3.5 — downstream concept impact detector.

Triggered automatically after Consolidate phase in the Ralph Loop.
Detects when a concept's D1-D4 definition changes enough to affect
concepts that depend on it.
"""

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class SemanticDiff:
    """Detect meaningful semantic changes in concept definitions.

    Uses Jaccard similarity on token sets as a lightweight proxy.
    Inherits logic from v2.1 cascade.py.
    """

    def __init__(self, threshold: float = 0.3):
        """Args:
            threshold: Jaccard distance above which change is considered "core".
                       Default 0.3 means <70% overlap = core change.
        """
        self.threshold = threshold

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        """Extract clean tokens from text."""
        if not text:
            return set()
        text = text.lower()
        text = re.sub(r"[^a-z0-9_\s]", " ", text)
        tokens = {t.strip("_") for t in text.split() if len(t.strip("_")) > 2}
        return tokens

    def _jaccard_distance(self, old_text: str, new_text: str) -> float:
        """Calculate Jaccard distance between two texts."""
        old_tokens = self._tokenize(old_text)
        new_tokens = self._tokenize(new_text)
        if not old_tokens and not new_tokens:
            return 0.0
        if not old_tokens or not new_tokens:
            return 1.0
        intersection = old_tokens & new_tokens
        union = old_tokens | new_tokens
        return 1.0 - len(intersection) / len(union)

    def is_core_change(self, old_text: str, new_text: str) -> bool:
        """Determine if text change is a "core definition change" worthy of cascade."""
        return self._jaccard_distance(old_text, new_text) > self.threshold

    def compare_outputs(self, old_output: dict, new_output: dict) -> dict:
        """Full teach-output comparison across D1-D4 + dependency chain.

        Returns detailed diff report.
        """
        level_changes = {}
        any_level_changed = False

        for level in ["d1", "d2", "d3", "d4"]:
            old_raw = old_output.get(level, "")
            new_raw = new_output.get(level, "")
            # Normalize: dict -> json string for comparison
            old_content = old_raw if isinstance(old_raw, str) else json.dumps(old_raw, sort_keys=True)
            new_content = new_raw if isinstance(new_raw, str) else json.dumps(new_raw, sort_keys=True)
            changed = self.is_core_change(old_content, new_content)
            level_changes[level] = {
                "changed": changed,
                "jaccard_distance": self._jaccard_distance(old_content, new_content),
            }
            if changed:
                any_level_changed = True

        # Confidence comparison
        old_conf = old_output.get("confidence", {})
        new_conf = new_output.get("confidence", {})
        # Compute average confidence delta
        levels = ["d1", "d2", "d3", "d4"]
        old_avg = sum(old_conf.get(l, 0.0) for l in levels) / len(levels) if old_conf else 0.0
        new_avg = sum(new_conf.get(l, 0.0) for l in levels) / len(levels) if new_conf else 0.0
        confidence_delta = new_avg - old_avg

        # Dependency comparison
        old_deps = set(self._extract_deps(old_output))
        new_deps = set(self._extract_deps(new_output))
        deps_added = list(new_deps - old_deps)
        deps_removed = list(old_deps - new_deps)

        return {
            "d1_changed": level_changes.get("d1", {}).get("changed", False),
            "any_level_changed": any_level_changed,
            "level_changes": level_changes,
            "confidence_delta": confidence_delta,
            "deps_added": deps_added,
            "deps_removed": deps_removed,
            "is_core_change": any_level_changed or bool(deps_added) or bool(deps_removed),
        }

    @staticmethod
    def _extract_deps(output: dict) -> list[str]:
        """Extract dependency concept IDs from a teach output."""
        deps = output.get("dependency_chain", [])
        if isinstance(deps, list):
            return deps
        # Fallback: try common field names
        for key in ("dependencies", "deps", "prerequisites"):
            if key in output:
                val = output[key]
                if isinstance(val, list):
                    return val
                elif isinstance(val, str):
                    return [val]
        return []


class CascadeEngine:
    """v3.5 Cascade Engine — detects downstream impact of definition changes."""

    def __init__(self, harness_dir: str, max_depth: int = 2, semantic_threshold: float = 0.3):
        self.harness_dir = Path(harness_dir)
        self.max_depth = max_depth
        self.semantic_diff = SemanticDiff(threshold=semantic_threshold)

    def analyze(
        self,
        concept_id: str,
        old_output: dict,
        new_output: dict,
        state_manager: Any,
    ) -> dict:
        """Analyze whether a concept change triggers cascade effects.

        Detects downstream, upstream, and indirect impacts when a concept's
        D1-D4 definition changes. Returns structured gap list for orchestrator.

        Args:
            concept_id: The concept that was updated.
            old_output: Previous teach output for this concept.
            new_output: Current teach output for this concept.
            state_manager: StateManager instance for accessing persisted state.

        Returns:
            cascade_report dict with keys:
                concept_id, core_change, change_summary, cascade_gaps, timestamp
        """
        diff = self.semantic_diff.compare_outputs(old_output, new_output)
        core_change = diff["is_core_change"]
        confidence_decline = diff["confidence_delta"] < -0.1

        cascade_gaps = []

        if core_change or confidence_decline:
            # Downstream
            affected_downstream = self._find_downstream_dependents(concept_id, self.max_depth)
            for item in affected_downstream:
                dep_id = item["concept_id"]
                dep_output = item.get("teach_output", {})
                refs_changed = self._references_concept(dep_output, concept_id)

                # Determine affected layers
                affected_layers = []
                for level in ("d2", "d3"):
                    content = dep_output.get(level, "")
                    text = content if isinstance(content, str) else json.dumps(content)
                    if concept_id in text:
                        affected_layers.append(level)
                if not affected_layers:
                    affected_layers = ["d2"]  # default assumption

                cascade_gaps.append({
                    "id": f"cascade_{concept_id}_{dep_id}_{item['depth']}",
                    "target_concept": dep_id,
                    "source_concept": concept_id,
                    "impact_direction": "downstream",
                    "gap_description": f"{dep_id} 引用了 {concept_id}，后者发生了核心变更",
                    "affected_layers": affected_layers,
                    "trigger_reason": "dependency_drift" if refs_changed else "indirect_impact",
                    "depth": item["depth"],
                    "priority": 0.9 if item["depth"] == 1 else 0.7,
                })

            # Upstream
            affected_upstream = self._find_upstream_dependencies(concept_id, self.max_depth)
            for item in affected_upstream:
                dep_id = item["concept_id"]
                dep_output = item.get("teach_output", {})

                cascade_gaps.append({
                    "id": f"cascade_{concept_id}_{dep_id}_up",
                    "target_concept": dep_id,
                    "source_concept": concept_id,
                    "impact_direction": "upstream",
                    "gap_description": f"{dep_id} 是 {concept_id} 的上游依赖。{concept_id} 发生变更后，{dep_id} 可能需要更新其 downstream 引用或定义以保持一致性。",
                    "affected_layers": ["d1", "d2", "d3"],  # all layers potentially
                    "trigger_reason": "upstream_knowledge_update",
                    "depth": item["depth"],
                    "priority": 0.6,
                })

            # Indirect
            indirect = self._find_indirect_impacts(concept_id, self.max_depth)
            for item in indirect:
                cascade_gaps.append({
                    "id": f"cascade_{concept_id}_{item['concept_id']}_indirect",
                    "target_concept": item["concept_id"],
                    "source_concept": concept_id,
                    "impact_direction": "indirect",
                    "gap_description": f"{item['concept_id']} 与 {concept_id} 共享依赖 {', '.join(item['shared_dependencies'])}",
                    "affected_layers": ["d2", "d3"],
                    "trigger_reason": "shared_dependency_drift",
                    "depth": item["depth"],
                    "priority": 0.5,
                })

        change_summary = {
            "d1_changed": diff["d1_changed"],
            "d3_changed": diff["level_changes"].get("d3", {}).get("changed", False),
            "any_level_changed": diff["any_level_changed"],
            "deps_added": diff["deps_added"],
            "deps_removed": diff["deps_removed"],
            "confidence_delta": diff["confidence_delta"],
        }

        return {
            "concept_id": concept_id,
            "core_change": core_change,
            "change_summary": change_summary,
            "cascade_gaps": cascade_gaps,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _find_downstream_dependents(self, concept_id: str, max_depth: int) -> list[dict]:
        """BFS to find all concepts that depend on concept_id.

        Scans all iteration teach_output.json files to build dependency graph.
        """
        visited = {concept_id: 0}
        queue = [(concept_id, 0)]
        affected = []
        all_concepts = self._scan_all_concepts()

        # Build reverse dependency map: concept -> list of dependents
        dependents_map: dict[str, list[str]] = {}
        concept_outputs: dict[str, dict] = {}
        for cid, teach_out in all_concepts.items():
            concept_outputs[cid] = teach_out
            deps = set(SemanticDiff._extract_deps(teach_out))
            for dep in deps:
                dependents_map.setdefault(dep, []).append(cid)

        while queue:
            current_id, current_depth = queue.pop(0)
            if current_depth >= max_depth:
                continue

            for dep_id in dependents_map.get(current_id, []):
                if dep_id not in visited:
                    visited[dep_id] = current_depth + 1
                    queue.append((dep_id, current_depth + 1))
                    affected.append({
                        "concept_id": dep_id,
                        "depth": current_depth + 1,
                        "triggered_by": current_id,
                        "teach_output": concept_outputs.get(dep_id, {}),
                    })

        return sorted(affected, key=lambda x: x["depth"])

    def _find_upstream_dependencies(self, concept_id: str, max_depth: int) -> list[dict]:
        """BFS to find all concepts that concept_id depends on.

        当 concept_id 被新增/编辑时，检查它的上游依赖是否需要更新。
        例如：transformer 教完后，检查 transformer 依赖的 attention_mechanism
        是否已经存在且知识足够支撑 transformer 的 D2/D3。
        """
        visited = {concept_id: 0}
        queue = [(concept_id, 0)]
        affected = []
        all_concepts = self._scan_all_concepts()

        # Build direct dependency map: concept -> list of its dependencies
        dependency_map: dict[str, list[str]] = {}
        for cid, teach_out in all_concepts.items():
            deps = set(SemanticDiff._extract_deps(teach_out))
            dependency_map[cid] = list(deps)

        while queue:
            current_id, current_depth = queue.pop(0)
            if current_depth >= max_depth:
                continue

            for dep_id in dependency_map.get(current_id, []):
                if dep_id not in visited:
                    visited[dep_id] = current_depth + 1
                    queue.append((dep_id, current_depth + 1))
                    affected.append({
                        "concept_id": dep_id,
                        "depth": current_depth + 1,
                        "triggered_by": current_id,
                        "impact_direction": "upstream",
                        "teach_output": all_concepts.get(dep_id, {}),
                    })

        return sorted(affected, key=lambda x: x["depth"])

    def _find_indirect_impacts(self, concept_id: str, max_depth: int) -> list[dict]:
        """Find concepts that share common dependencies with concept_id.

        当 concept_id 变化时，通过共同依赖检测间接影响。
        例如：A 和 B 都依赖 C，C 被编辑后 A 和 B 的相对关系可能变化。
        """
        all_concepts = self._scan_all_concepts()

        # Get concept_id's dependencies
        target_deps = set(SemanticDiff._extract_deps(all_concepts.get(concept_id, {})))
        if not target_deps:
            return []

        indirect = []
        for cid, teach_out in all_concepts.items():
            if cid == concept_id:
                continue
            deps = set(SemanticDiff._extract_deps(teach_out))
            shared = deps & target_deps
            if shared:
                indirect.append({
                    "concept_id": cid,
                    "depth": 2,  # indirect = 2-hop
                    "triggered_by": concept_id,
                    "impact_direction": "indirect",
                    "shared_dependencies": list(shared),
                    "teach_output": teach_out,
                })

        return indirect

    def _scan_all_concepts(self) -> dict[str, dict]:
        """Scan results/iteration_*/teach_output.json to find all concepts.

        Returns dict mapping concept_id -> teach_output dict.
        """
        concepts: dict[str, dict] = {}
        results_dir = self.harness_dir / "results"
        if not results_dir.exists():
            return concepts

        for iter_dir in sorted(results_dir.iterdir()):
            if not iter_dir.is_dir() or not iter_dir.name.startswith("iteration_"):
                continue
            teach_path = iter_dir / "teach_output.json"
            if not teach_path.exists():
                continue
            try:
                with open(teach_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                cid = data.get("concept_id")
                if cid and cid not in concepts:
                    # Keep the latest iteration's teach output for each concept
                    concepts[cid] = data
            except (json.JSONDecodeError, OSError):
                continue

        return concepts

    @staticmethod
    def _references_concept(teach_output: dict, concept_id: str) -> bool:
        """Check if a teach output's D2/D3 explicitly references another concept."""
        if not teach_output:
            return False
        # Search in D2 and D3 content
        for level in ("d2", "d3"):
            content = teach_output.get(level, "")
            text = content if isinstance(content, str) else json.dumps(content)
            if concept_id in text:
                return True
        # Also check dependency chain
        deps = SemanticDiff._extract_deps(teach_output)
        if concept_id in deps:
            return True
        return False
