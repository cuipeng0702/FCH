---
tag: [REFERENCE]
load_when: "通用认知循环定义"
---

# UCC (Unified Cognition Cycle)

UCC is the atomic unit of a single Ralph Loop iteration. Every time the coordinator completes one full cycle of Search → Teach → Audit → Grow → Verify → Consolidate → Quality Audit → Termination, it generates one `HistoricalUCCRecord`.

These records feed the **Calibration Engine**, which replaces hardcoded thresholds (e.g., 0.90) with statistically calibrated values derived from actual historical performance.

---

## HistoricalUCCRecord — 12 Fields

| Field | Type | Description |
|-------|------|-------------|
| `ucc_id` | str | Unique identifier for this UCC instance (e.g., `"ucc_2026-05-01T12:00:00Z_transformer_attention_3"`) |
| `timestamp` | str | ISO 8601 UTC timestamp when the UCC completed |
| `concept_id` | str | The concept being processed |
| `audit_aggregate` | float | Weighted aggregate score from the Audit phase (0.0–1.0) |
| `audit_threshold_used` | float | The audit aggregate threshold applied during this UCC |
| `audit_passed` | bool | Whether `audit_aggregate >= audit_threshold_used` |
| `final_quality` | str | Post-termination quality label: `"GOOD"`, `"ACCEPTABLE"`, `"POOR"`, `"UNKNOWN"` |
| `final_quality_source` | str | Who assigned the quality label: `"quality_audit"`, `"user_override"`, `"pending"` |
| `audit_scores` | dict[str, float] | Per-check audit scores (term_penetration, boundary_consistency, etc.) |
| `bdd_confidence` | float or null | BDD (Boundary-Driven Deepening) confidence score, if BDD was attempted |
| `bdd_decision` | str or null | BDD routing decision: `"ROUTED_TO_BDD"`, `"FCH_SUCCEEDED"`, `"FCH_FAILED"`, null if not routed |
| `gap_count` | int | Number of gaps identified in the Audit phase |
| `converged` | bool | Whether the concept met convergence criteria (Ming Wu + novelty) |
| `budget_used` | int | Number of subagent spawns consumed in this UCC |
| `routing` | str | Routing label: `"FCH"`, `"BDD"`, `"HYBRID"` |

---

## Cold-Start Defaults

When fewer than `min_samples` (default: 5) historical UCC records exist, the Calibration Engine falls back to heuristic defaults:

### audit_aggregate_threshold

```json
{
  "point_estimate": 0.85,
  "confidence_interval": [0.70, 1.0],
  "confidence_level": 0.95,
  "sample_size": 0,
  "method": "heuristic_default",
  "cold_start": true,
  "rationale": "Default chosen based on UCC 1 (0.82) and UCC 3 (aggregate ~0.83). 0.85 balances false-positive and false-negative risk with no data."
}
```

### bdd_confidence_threshold

```json
{
  "point_estimate": 0.75,
  "confidence_interval": [0.60, 0.90],
  "confidence_level": 0.95,
  "sample_size": 0,
  "method": "heuristic_default",
  "cold_start": true,
  "rationale": "UCC 2 scored 0.78 and produced HoTT (a valid new concept). 0.75 allows exploration while still requiring meaningful confidence."
}
```

**Rationale for these values**:
- UCC 1 scored 0.82 on audit aggregate
- UCC 2 scored 0.78 on BDD confidence and successfully produced a valid new concept (HoTT)
- UCC 3 scored ~0.83 on audit aggregate
- The cold-start defaults are set slightly above observed early-UCC performance to avoid premature convergence, while remaining achievable.

---

## Relationship with Calibration Engine

`harness/calibration_engine.py` consumes UCC records and produces calibrated thresholds:

1. **Load** — `CalibrationEngine.load_history()` reads `HistoricalUCCRecord` instances from a JSONL file or list
2. **Prepare datasets** — `_prepare_audit_dataset()` and `_prepare_bdd_dataset()` extract `(score, outcome)` pairs, where `outcome = 1` if `final_quality == "GOOD"`
3. **Calibrate** — With ≥ 5 samples:
   - Isotonic regression (small N, non-parametric monotonic fit)
   - Logistic regression with bootstrap CI (larger N)
4. **Output** — `ThresholdOutput` with point estimate, confidence interval, method, and sample size
5. **Fallback** — With < 5 samples or missing numpy/sklearn, return `COLD_START_DEFAULTS`

The orchestrator reads the calibrated thresholds before each new UCC to determine:
- Whether `audit_aggregate` is high enough to pass
- Whether BDD confidence justifies routing to formal deepening

---

## Record Trigger Timing

A `HistoricalUCCRecord` is written **once per Ralph Loop iteration**, immediately after the Termination phase completes:

```
Ralph Loop Iteration N:
  1. Search
  2. Teach
  3. Audit
  4. Grow
  5. Verify
  6. Consolidate
  7. Quality Audit
  8. Termination ← UCC record generated here
```

The record captures the **final state** of the iteration, not intermediate snapshots. If the loop continues (not converged), the next iteration produces a new UCC record with a new `ucc_id`.

---

## Storage

Default path: `~/.openclaw/workspace/knowledge-lattice/ucc-history.jsonl`

Format: one JSON object per line (JSONL), append-only.

---

*Document version: 1.0*
*Aligned with: `calibration_engine.py` v3.5*
