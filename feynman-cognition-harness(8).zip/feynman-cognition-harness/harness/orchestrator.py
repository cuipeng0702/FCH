#!/usr/bin/env python3
"""FCH Ralph-Style Orchestrator — pure coordinator, does NO work itself.

Ralph loop:
  1. LOAD STATE
  2. CHECK BUDGET
  3. PICK NEXT TASK
  4. SPAWN WORKER
  5. SPAWN AUDITOR
  6. UPDATE PROGRESS
  7. CHECK CONVERGENCE
  8. SAVE STATE
  9. LOOP or EXIT

Each iteration performs exactly ONE task + ONE audit.
"""

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from state_manager import StateManager

# v3.5 conditional module imports — inactive when modules are disabled in config
try:
    from calibration_engine import CalibrationEngine
except Exception:
    CalibrationEngine = None
try:
    from analogy_selector import AnalogySelector
except Exception:
    AnalogySelector = None
try:
    from t3_executor import T3Executor
except Exception:
    T3Executor = None
try:
    from termination_checker import TerminationEvaluator
except Exception:
    TerminationEvaluator = None
try:
    from routing_classifier import HybridRouter
except Exception:
    HybridRouter = None
try:
    from fcms.evaluator import CognitiveHealthAssessor
except Exception:
    CognitiveHealthAssessor = None
try:
    from fcms.reflector import MetacognitiveReflector
except Exception:
    MetacognitiveReflector = None
try:
    from fcms.regulator import CognitiveRegulator
except Exception:
    CognitiveRegulator = None
try:
    from fcms.regulator import RegulationSafetyChecker
except Exception:
    RegulationSafetyChecker = None
try:
    from cascade_engine import SemanticDiff, CascadeEngine
except Exception:
    SemanticDiff = None
    CascadeEngine = None


class FeynmanOrchestrator:
    """Pure-coordinator orchestrator for the Feynman Cognition Harness.

    v3.5+: Operates as a state-machine library driven by an external agent.
    Use `run_step()` to get the next action, execute it externally,
    then call `ingest_result()` to feed the result back.
    """

    def __init__(self, harness_dir: str):
        self.harness_dir = Path(harness_dir)
        self.results_dir = self.harness_dir / "results"
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.sm = StateManager(str(self.harness_dir))
        # v3.5: load unified config for conditional module enabling
        self.config = self._load_config()
        # v3.5 LQL: lattice cache — refreshed per iteration
        self._lattice_cache: dict = {}

    # ── v3.5 wiring helpers ──────────────────────────────────────────

    def _build_dependencies(self, task: str, iteration: int) -> dict:
        """Build dependency map for current task based on task template input schema."""
        deps = {}
        iter_dir = self._iter_dir(iteration)
        # search: no file dependencies (loop first step)
        if task == "teach":
            deps["search_results"] = str(iter_dir / "search_output.json")
        elif task == "audit":
            deps["previous_teach"] = str(iter_dir / "teach_output.json")
        elif task == "grow":
            deps["previous_teach"] = str(iter_dir / "teach_output.json")
            deps["previous_audit"] = str(iter_dir / "audit_output.json")
        elif task == "verify":
            deps["previous_teach"] = str(iter_dir / "teach_output.json")
            deps["previous_audit"] = str(iter_dir / "audit_output.json")
            deps["previous_grow"] = str(iter_dir / "grow_output.json")
        elif task == "consolidate":
            deps["previous_teach"] = str(iter_dir / "teach_output.json")
            deps["previous_audit"] = str(iter_dir / "audit_output.json")
            deps["previous_grow"] = str(iter_dir / "grow_output.json")
            deps["previous_verify"] = str(iter_dir / "verify_output.json")
        return deps

    def _estimate_task_cost(self, task: str) -> dict:
        """Return rough cost estimate for a task (tokens, time, spawn count)."""
        estimates = {
            "search": {"tokens": 2000, "time_sec": 60, "spawns": 1},
            "teach": {"tokens": 8000, "time_sec": 120, "spawns": 1},
            "audit": {"tokens": 4000, "time_sec": 60, "spawns": 1},
            "grow": {"tokens": 6000, "time_sec": 90, "spawns": 1},
            "verify": {"tokens": 4000, "time_sec": 60, "spawns": 1},
            "consolidate": {"tokens": 3000, "time_sec": 45, "spawns": 1},
        }
        return estimates.get(task, {"tokens": 5000, "time_sec": 60, "spawns": 1})

    def _collect_self_awareness_input(self, state: dict, iteration: int,
                                      progress: dict, budget: dict) -> dict:
        """Collect all data needed for self-awareness coach input."""
        # 1. cognitive_tasks: from state outputs
        cognitive_tasks = []
        for task_name in self.sm.CHECKLIST:
            outputs = state.get(f"{task_name}_outputs", [])
            for out in outputs:
                if out.get("iteration") == iteration:
                    cognitive_tasks.append({
                        "task_name": task_name,
                        "duration_sec": out.get("duration_sec", 0),
                        "tools_used": out.get("tools_used", []),
                        "output_quality": out.get("quality", "sufficient"),
                        "anomalies": out.get("anomalies", [])
                    })

        # 2. subagents_spawned: from state log
        subagents = state.get("subagent_spawn_log", {}).get(str(iteration), [])

        # 3. tools_usage: aggregate from history.jsonl
        history = self.sm.load_history()
        tools_usage = self._aggregate_tools_by_iteration(history, iteration)

        # 4. context_state: snapshot
        context_state = {
            "total_tokens": state.get("context_tokens", 0),
            "critical_info_retention": state.get("info_retention", 1.0),
            "redundancy_ratio": state.get("redundancy_ratio", 0.0),
            "user_corrections_this_iter": len([
                u for u in state.get("user_interactions", [])
                if u.get("iteration") == iteration
            ]),
            "user_corrections_total": len(state.get("user_interactions", [])),
            "pending_gaps_count": len(state.get("pending_gaps", [])),
            "convergence_score": state.get("convergence_score", 0.0),
        }

        # 5. user_interactions
        user_interactions = [
            u for u in state.get("user_interactions", [])
            if u.get("iteration") == iteration
        ]

        # 6. previous_adjustments
        prev_reports = self.sm.fcms_load_self_awareness(n=1)
        previous_adjustments = {}
        if prev_reports:
            prev = prev_reports[0]
            previous_adjustments = {
                "from_iteration": prev.get("iteration"),
                "adjustments_applied": prev.get("recommended_adjustments", []),
                "effectiveness": prev.get("overall_score", 0.0),
            }

        # 7. fcms_signals
        fcms_path = self.harness_dir / "fcms" / f"fcms_iter_{iteration}.json"
        fcms_report = self._load_json_safe(fcms_path, {})
        fcms_signals = {
            "health_score": fcms_report.get("health_score", 0.0),
            "alerts": fcms_report.get("alerts", []),
            "cognitive_patterns": fcms_report.get("cognitive_patterns", {}),
        }

        return {
            "iteration": iteration,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": state.get("session_id", ""),
            "cognitive_tasks": cognitive_tasks,
            "subagents_spawned": subagents,
            "tools_usage": tools_usage,
            "context_state": context_state,
            "user_interactions": user_interactions,
            "previous_adjustments": previous_adjustments,
            "fcms_signals": fcms_signals,
        }

    def _aggregate_tools_by_iteration(self, history: list[dict], iteration: int) -> list[dict]:
        """Aggregate tool usage from history for a specific iteration."""
        from collections import defaultdict
        stats = defaultdict(lambda: {"call_count": 0, "success_count": 0, "latencies": []})
        for rec in history:
            if rec.get("iteration") != iteration:
                continue
            tool = rec.get("tool", "unknown")
            stats[tool]["call_count"] += 1
            if rec.get("success", True):
                stats[tool]["success_count"] += 1
            lat = rec.get("latency_ms", 0)
            if lat:
                stats[tool]["latencies"].append(lat)
        results = []
        for tool, data in stats.items():
            count = data["call_count"]
            successes = data["success_count"]
            latencies = data["latencies"]
            avg_lat = sum(latencies) / len(latencies) if latencies else 0
            results.append({
                "tool_name": tool,
                "call_count": count,
                "success_rate": round(successes / count, 2) if count else 1.0,
                "avg_latency_ms": round(avg_lat, 0),
            })
        return results

    def _apply_adjustment(self, adj: dict, state: dict, budget: dict) -> None:
        """Apply a single self-awareness adjustment to state or budget."""
        target = adj.get("target", "")
        action = adj.get("action", "")
        parameter = adj.get("parameter", {})
        if target == "orchestrator.spawn_strategy":
            state["spawn_strategy_override"] = parameter
        elif target == "tool_usage.policy":
            state["tool_policy_override"] = parameter
        elif target == "context.compression_threshold":
            state["compression_threshold"] = parameter.get("threshold", 0.25)
        elif target == "budget.reallocation":
            budget.update(parameter)
        else:
            state.setdefault("adjustment_apply_failures", []).append({
                "target": target,
                "action": action,
                "reason": "unrecognized_target",
            })

    # ── v3.5 config helpers ──────────────────────────────────────────

    def _load_config(self) -> dict:
        """Load v3.5 config.yaml if present; return empty dict if absent."""
        config_path = self.harness_dir / "config.yaml"
        if not config_path.exists():
            return {}
        try:
            import yaml
            with open(config_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    def _module_enabled(self, module_name: str) -> bool:
        """Check if a v3.5 module is enabled in config."""
        return self.config.get("modules", {}).get(module_name, {}).get("enabled", False)

    # ── v3.5 LQL (Lattice Query Layer) ─────────────────────────────

    def _load_lattice_index(self) -> dict:
        """Load the knowledge-lattice index and all concept files into memory cache."""
        lattice_dir = self._lattice_concepts_dir()
        if not lattice_dir.exists():
            return {}
        index_path = lattice_dir / "index.json"
        raw_index = self._load_json_safe(index_path, {})
        # Normalize: handle both dict-of-dicts and list-of-entries
        if isinstance(raw_index, list):
            cache = {}
            for entry in raw_index:
                if isinstance(entry, dict) and "concept_id" in entry:
                    cid = entry["concept_id"]
                    cache[cid] = entry
            return cache
        if not isinstance(raw_index, dict):
            return {}
        cache = {}
        for concept_id, meta in raw_index.items():
            if not isinstance(meta, dict):
                continue
            path_hint = meta.get("path", "")
            if path_hint and Path(path_hint).exists():
                concept_path = Path(path_hint)
            else:
                concept_path = lattice_dir / f"{concept_id}.json"
            data = self._load_json_safe(concept_path, {})
            if data:
                cache[concept_id] = data
        # Also scan "concepts" list (created by _create_new_concepts / _update_index_relations)
        for concept_id in raw_index.get("concepts", []):
            if concept_id in cache:
                continue
            concept_path = lattice_dir / f"{concept_id}.json"
            data = self._load_json_safe(concept_path, {})
            if data:
                cache[concept_id] = data
        return cache

    def _query_lattice_for_concept(self, concept_id: str) -> dict:
        """读取 lattice 中单个概念的完整数据。"""
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()
        return self._lattice_cache.get(concept_id, {})

    def _find_prerequisites(self, concept_id: str) -> list[dict]:
        """查找 concept 的 prerequisite 概念（从 dependency_graph 反向查找）。"""
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()
        prereqs = []
        target_data = self._lattice_cache.get(concept_id, {})
        # Method 1: target concept's dependency_graph (depends_on / prerequisite_for)
        dep_graph = target_data.get("dependency_graph", {})
        for src_id, rel in dep_graph.items():
            rel_type = rel.get("relation", "") if isinstance(rel, dict) else ""
            if rel_type in ("depends_on", "prerequisite_for"):
                prereqs.append(self._make_prerequisite_entry(src_id))
        # Method 2: other concepts pointing TO us with prerequisite_for
        for other_id, other_data in self._lattice_cache.items():
            if other_id == concept_id:
                continue
            other_deps = other_data.get("dependency_graph", {})
            for tgt_id, rel in other_deps.items():
                if tgt_id == concept_id:
                    rel_type = rel.get("relation", "") if isinstance(rel, dict) else ""
                    if rel_type in ("prerequisite_for", "depends_on"):
                        prereqs.append(self._make_prerequisite_entry(other_id))
        # Method 3: fallback to old-style dependencies list
        old_deps = target_data.get("dependencies", [])
        for dep_id in old_deps:
            if dep_id not in {p["concept_id"] for p in prereqs}:
                prereqs.append(self._make_prerequisite_entry(dep_id))
        # Deduplicate and limit to 3
        seen = set()
        unique = []
        for p in prereqs:
            if p["concept_id"] not in seen:
                seen.add(p["concept_id"])
                unique.append(p)
        return unique[:3]

    def _make_prerequisite_entry(self, concept_id: str) -> dict:
        """Build a prerequisite entry with d3_summary and confidence."""
        data = self._lattice_cache.get(concept_id, {})
        d3_summary = self._extract_d3_summary_from_concept(data)
        version_stack = data.get("version_stack", [])
        confidences = []
        version_count = 0
        for entry in version_stack:
            if not isinstance(entry, dict):
                continue
            if "confidence" in entry:
                confidences.append(entry["confidence"])
                version_count += 1
            elif "versions" in entry and isinstance(entry["versions"], dict):
                d3_data = entry["versions"].get("D3", {})
                if isinstance(d3_data, dict) and "confidence" in d3_data:
                    confidences.append(d3_data["confidence"])
                    version_count += 1
        avg_conf = sum(confidences) / len(confidences) if confidences else 0.0
        return {
            "concept_id": concept_id,
            "d3_summary": (d3_summary[:200] if d3_summary else ""),
            "confidence": round(avg_conf, 2),
            "version_count": version_count,
        }

    def _find_analogies(self, concept_id: str) -> list[dict]:
        """查找与 concept 有 analogy_of 关系的概念。"""
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()
        analogies = []
        target_data = self._lattice_cache.get(concept_id, {})
        dep_graph = target_data.get("dependency_graph", {})
        for other_id, rel in dep_graph.items():
            rel_type = rel.get("relation", "") if isinstance(rel, dict) else ""
            if rel_type == "analogy_of":
                analogies.append(self._make_analogy_entry(other_id, rel))
        for other_id, other_data in self._lattice_cache.items():
            if other_id == concept_id:
                continue
            other_deps = other_data.get("dependency_graph", {})
            for tgt_id, rel in other_deps.items():
                if tgt_id == concept_id:
                    rel_type = rel.get("relation", "") if isinstance(rel, dict) else ""
                    if rel_type == "analogy_of":
                        analogies.append(self._make_analogy_entry(other_id, rel))
        seen = set()
        unique = []
        for a in analogies:
            if a["concept_id"] not in seen:
                seen.add(a["concept_id"])
                unique.append(a)
        return unique[:3]

    def _make_analogy_entry(self, concept_id: str, rel: dict) -> dict:
        """Build an analogy entry."""
        data = self._lattice_cache.get(concept_id, {})
        d1_text = self._extract_d1_summary_from_concept(data)
        confidence = rel.get("confidence", 0.0) if isinstance(rel, dict) else 0.0
        return {
            "concept_id": concept_id,
            "analogy_summary": (d1_text[:100] if d1_text else ""),
            "confidence": round(confidence, 2),
        }

    def _get_d3_summary(self, concept_id: str) -> str:
        """提取概念最新版本的 D3 定义摘要（≤200 字）。"""
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()
        data = self._lattice_cache.get(concept_id, {})
        summary = self._extract_d3_summary_from_concept(data)
        return summary[:200] if summary else ""

    def _extract_d3_summary_from_concept(self, data: dict) -> str:
        """Extract D3 definition text from a concept's lattice data."""
        if not data:
            return ""
        version_stack = data.get("version_stack", [])
        # New format first
        for entry in reversed(version_stack):
            if isinstance(entry, dict) and "versions" in entry:
                d3_data = entry["versions"].get("D3", {})
                if isinstance(d3_data, dict):
                    explanation = d3_data.get("explanation", "")
                    if explanation and explanation.strip():
                        return explanation.strip()
        # Old format
        for entry in reversed(version_stack):
            if isinstance(entry, dict) and entry.get("level") == "D3":
                content = entry.get("content", "")
                if content and content.strip() and not content.startswith("["):
                    return content.strip()
        # Fallback: direct d3 field
        d3 = data.get("d3", {})
        if isinstance(d3, dict):
            definition = d3.get("definition", "")
            if definition:
                return definition.strip()
        return ""

    def _extract_d1_summary_from_concept(self, data: dict) -> str:
        """Extract D1 analogy text from a concept's lattice data."""
        if not data:
            return ""
        version_stack = data.get("version_stack", [])
        for entry in reversed(version_stack):
            if isinstance(entry, dict) and "versions" in entry:
                d1_data = entry["versions"].get("D1", {})
                if isinstance(d1_data, dict):
                    explanation = d1_data.get("explanation", "")
                    if explanation and explanation.strip():
                        return explanation.strip()
        for entry in reversed(version_stack):
            if isinstance(entry, dict) and entry.get("level") == "D1":
                content = entry.get("content", "")
                if content and content.strip() and not content.startswith("["):
                    return content.strip()
        d1 = data.get("d1", "")
        if d1 and isinstance(d1, str):
            return d1.strip()
        return ""

    def _get_best_analogy(self, concept_id: str, target_domain: str = None) -> dict:
        """获取概念最成功的类比（按 version_stack 中 confidence 最高）。"""
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()
        data = self._lattice_cache.get(concept_id, {})
        version_stack = data.get("version_stack", [])
        best_conf = 0.0
        best_d1 = ""
        for entry in version_stack:
            if not isinstance(entry, dict):
                continue
            if "versions" in entry:
                d1_data = entry["versions"].get("D1", {})
                if isinstance(d1_data, dict):
                    conf = d1_data.get("confidence", 0.0)
                    expl = d1_data.get("explanation", "")
                    if conf > best_conf and expl and expl.strip():
                        best_conf = conf
                        best_d1 = expl.strip()
            elif entry.get("level") == "D1":
                conf = entry.get("confidence", 0.0)
                content = entry.get("content", "")
                if conf > best_conf and content and content.strip():
                    best_conf = conf
                    best_d1 = content.strip()
        # Also check direct d1 field
        direct_d1 = data.get("d1", "")
        direct_conf = data.get("confidence", 0.0)
        if isinstance(direct_d1, str) and direct_conf > best_conf and direct_d1.strip():
            best_conf = direct_conf
            best_d1 = direct_d1.strip()
        # Domain-matched analogies from related concepts
        related_analogies = []
        if target_domain:
            for other_id, other_data in self._lattice_cache.items():
                if other_id == concept_id:
                    continue
                dep_graph = other_data.get("dependency_graph", {})
                for tgt_id, rel in dep_graph.items():
                    if tgt_id == concept_id:
                        rel_type = rel.get("relation", "") if isinstance(rel, dict) else ""
                        if rel_type == "analogy_of":
                            rationale = rel.get("rationale", "") if isinstance(rel, dict) else ""
                            if target_domain.lower() in rationale.lower():
                                d1 = self._extract_d1_summary_from_concept(other_data)
                                conf = rel.get("confidence", 0.0) if isinstance(rel, dict) else 0.0
                                related_analogies.append({
                                    "concept_id": other_id,
                                    "analogy_summary": (d1[:100] if d1 else ""),
                                    "confidence": round(conf, 2),
                                    "domain_match": True,
                                })
        result = {
            "concept_id": concept_id,
            "best_analogy": (best_d1[:100] if best_d1 else ""),
            "confidence": round(best_conf, 2),
        }
        if related_analogies:
            related_analogies.sort(key=lambda x: x["confidence"], reverse=True)
            result["domain_match"] = related_analogies[0]
        return result

    def _find_similar_gaps(self, gap_description: str, concept_id: str = None) -> list[dict]:
        """在 lattice 中查找描述相似的已解决 gaps（跨概念借鉴修复策略）。"""
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()
        if not gap_description:
            return []
        gap_words = set(gap_description.lower().split())
        matches = []
        for other_id, other_data in self._lattice_cache.items():
            if other_id == concept_id:
                continue
            version_stack = other_data.get("version_stack", [])
            for entry in version_stack:
                if not isinstance(entry, dict):
                    continue
                metadata = entry.get("metadata", {})
                gaps = metadata.get("gaps", []) if isinstance(metadata, dict) else []
                for gap in gaps:
                    if not isinstance(gap, dict):
                        continue
                    desc = gap.get("description", "")
                    if not desc:
                        continue
                    status = gap.get("status", "")
                    if status not in ("resolved", "closed", "fixed"):
                        continue
                    other_words = set(desc.lower().split())
                    overlap = len(gap_words & other_words)
                    if overlap > 0:
                        score = overlap / max(len(gap_words), len(other_words))
                        if score >= 0.3:
                            matches.append({
                                "concept_id": other_id,
                                "gap_description": desc[:200],
                                "resolution": gap.get("resolution", ""),
                                "similarity_score": round(score, 2),
                            })
            # Also consider concepts that have converged (gap_count → 0)
            learning_curve = other_data.get("learning_curve", [])
            if learning_curve and len(learning_curve) >= 2:
                latest = learning_curve[-1]
                if latest.get("gap_count", 1) == 0:
                    d3_summary = self._extract_d3_summary_from_concept(other_data)
                    matches.append({
                        "concept_id": other_id,
                        "gap_description": "(all gaps resolved — general strategy)",
                        "resolution": "converged",
                        "similarity_score": 0.1,
                    })
        matches.sort(key=lambda x: x["similarity_score"], reverse=True)
        seen = set()
        unique = []
        for m in matches:
            key = (m["concept_id"], m["gap_description"][:50])
            if key not in seen:
                seen.add(key)
                unique.append(m)
        return unique[:3]

    def _get_learning_strategy(self, concept_id: str, layer: str) -> str:
        """获取某概念某层的收敛策略（从 grow_output 历史中提取）。"""
        strategies = []
        for iter_dir in sorted(self.results_dir.glob("iteration_*")):
            grow_path = iter_dir / "grow_output.json"
            if not grow_path.exists():
                continue
            data = self._load_json_safe(grow_path, {})
            if not data or data.get("concept_id") != concept_id:
                continue
            strategy = data.get("strategy", "")
            gaps = data.get("gaps", [])
            layer_strategies = []
            for gap in gaps:
                if isinstance(gap, dict) and gap.get("layer") == layer:
                    layer_strategies.append(gap.get("strategy", ""))
            if strategy or layer_strategies:
                strategies.append({
                    "strategy": (strategy[:100] if strategy else ""),
                    "layer_strategies": [s[:100] for s in layer_strategies if s],
                    "iteration": data.get("iteration", 0),
                })
        if not strategies:
            return ""
        latest = strategies[-1]
        combined = latest.get("strategy", "")
        if latest.get("layer_strategies"):
            combined += " | " + " | ".join(latest["layer_strategies"])
        return combined[:100]

    # ── v3.5 Yoneda (大局观) queries ───────────────────────────────

    def _get_concept_role_profile(self, concept_id: str) -> dict:
        """
        获取概念在网络中的角色画像（米田视角）。
        """
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()

        data = self._lattice_cache.get(concept_id, {})
        dep_graph = data.get("dependency_graph", {})

        # Centrality: in-degree + out-degree (normalized by max possible)
        in_degree = 0
        out_degree = len(dep_graph)
        for other_id, other_data in self._lattice_cache.items():
            if other_id == concept_id:
                continue
            other_deps = other_data.get("dependency_graph", {})
            if concept_id in other_deps:
                in_degree += 1

        total_concepts = max(1, len(self._lattice_cache))
        centrality = (in_degree + out_degree) / (2 * total_concepts)

        # Structural role classification
        if in_degree >= 3 and out_degree >= 3:
            structural_role = "hub"
        elif in_degree >= 2 and out_degree >= 2:
            structural_role = "bridge"
        elif in_degree >= 1 and out_degree == 0:
            structural_role = "leaf"
        elif in_degree == 0 and out_degree >= 2:
            structural_role = "core"
        else:
            structural_role = "normal"

        # Prerequisite counts
        prerequisite_for_count = in_degree
        depends_on_count = out_degree

        # Community detection (graphify优先，回退到简易检测)
        community_info = self._detect_community(concept_id)
        community_id = community_info.get("community_id", "")
        community_members = community_info.get("members", [])

        # Bridge concepts: cross-community connections
        bridge_concepts = []
        for other_id, rel in dep_graph.items():
            other_comm = self._detect_community(other_id)
            if other_comm.get("community_id") != community_id:
                bridge_concepts.append(other_id)

        return {
            "centrality": round(min(1.0, centrality), 2),
            "community_id": community_id,
            "community_members": community_members[:5],  # limit to avoid bloat
            "structural_role": structural_role,
            "prerequisite_for_count": prerequisite_for_count,
            "depends_on_count": depends_on_count,
            "bridge_concepts": bridge_concepts[:3],
        }

    def _detect_community(self, concept_id: str) -> dict:
        """检测概念所属社区。优先 graphify，回退到 lattice dependency_graph。"""
        # Try graphify first
        client = self._get_graphify_client()
        if client is not None:
            try:
                comm = client.get_community_for_node(concept_id)
                if comm.get("community_id") is not None:
                    return {
                        "community_id": f"graphify_comm_{comm['community_id']}",
                        "members": comm.get("community_members", []),
                        "source": "graphify",
                    }
            except Exception:
                pass

        # Fallback: simple community detection via dependency_graph BFS clustering
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()

        # Build adjacency from dependency_graph
        neighbors = set()
        data = self._lattice_cache.get(concept_id, {})
        dep_graph = data.get("dependency_graph", {})
        for other_id in dep_graph:
            neighbors.add(other_id)
        for other_id, other_data in self._lattice_cache.items():
            if other_id == concept_id:
                continue
            other_deps = other_data.get("dependency_graph", {})
            if concept_id in other_deps:
                neighbors.add(other_id)

        # Simple clustering: concept + direct neighbors = pseudo-community
        members = sorted(set([concept_id] + list(neighbors)))
        return {
            "community_id": f"lattice_cluster_{concept_id}",
            "members": members,
            "source": "lattice_fallback",
        }

    def _get_community_patterns(self, community_id: str = None, concept_id: str = None) -> list[dict]:
        """
        获取社区内的高阶模式。
        如果提供 community_id：返回该社区的共同特征
        如果提供 concept_id：先查社区，再返回模式
        """
        if community_id is None and concept_id:
            profile = self._get_concept_role_profile(concept_id)
            community_id = profile.get("community_id", "")

        if not community_id:
            return []

        # Try graphify first if community_id is from graphify
        if community_id.startswith("graphify_comm_"):
            try:
                cid = int(community_id.replace("graphify_comm_", ""))
            except ValueError:
                cid = None
            if cid is not None:
                client = self._get_graphify_client()
                if client is not None:
                    try:
                        patterns = client.get_community_patterns(cid)
                        return patterns[:2]  # limit to 2
                    except Exception:
                        pass

        # Fallback: lattice-based pattern detection
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()

        # Find members of this community
        members = []
        if concept_id:
            comm = self._detect_community(concept_id)
            members = comm.get("members", [])
        else:
            # Scan all concepts for matching community_id
            for cid, data in self._lattice_cache.items():
                comm = self._detect_community(cid)
                if comm.get("community_id") == community_id:
                    members.append(cid)

        if not members:
            return []

        patterns = []

        # Pattern: shared_prerequisites
        shared_prereqs = None
        for m in members:
            data = self._lattice_cache.get(m, {})
            deps = set(data.get("dependencies", []))
            dep_graph = data.get("dependency_graph", {})
            for did, rel in dep_graph.items():
                rel_type = rel.get("relation", "") if isinstance(rel, dict) else str(rel)
                if rel_type in ("depends_on", "prerequisite_for"):
                    deps.add(did)
            if shared_prereqs is None:
                shared_prereqs = deps
            else:
                shared_prereqs &= deps
        if shared_prereqs:
            patterns.append({
                "pattern_type": "shared_prerequisites",
                "description": f"社区内 {len(members)} 个概念共享前置依赖: {', '.join(list(shared_prereqs)[:3])}",
                "affected_concepts": members[:5],
                "confidence": round(min(1.0, len(shared_prereqs) / max(1, len(members))), 2),
            })

        # Pattern: confidence_cluster — check version_stack convergence rates
        converged_count = 0
        for m in members:
            data = self._lattice_cache.get(m, {})
            curve = data.get("learning_curve", [])
            if curve and len(curve) >= 2:
                latest = curve[-1]
                if latest.get("gap_count", 1) == 0:
                    converged_count += 1
        if converged_count > 0:
            patterns.append({
                "pattern_type": "confidence_cluster",
                "description": f"社区内 {converged_count}/{len(members)} 个概念已完成收敛",
                "affected_concepts": members[:5],
                "confidence": round(converged_count / max(1, len(members)), 2),
            })

        return patterns[:2]  # limit to 2 to avoid context explosion

    def _get_cross_community_patterns(self, concept_id: str) -> list[dict]:
        """
        获取与 concept 相关的跨社区高阶模式。
        """
        profile = self._get_concept_role_profile(concept_id)

        # Try graphify bridges first
        client = self._get_graphify_client()
        if client is not None:
            try:
                bridges = client.get_cross_community_bridges(concept_id)
                if bridges:
                    return bridges[:2]  # limit to 2
            except Exception:
                pass

        # Fallback: lattice-based cross-community detection
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()

        data = self._lattice_cache.get(concept_id, {})
        dep_graph = data.get("dependency_graph", {})
        my_comm = self._detect_community(concept_id)
        my_cid = my_comm.get("community_id", "")

        bridges_by_target = {}
        for other_id, rel in dep_graph.items():
            other_comm = self._detect_community(other_id)
            other_cid = other_comm.get("community_id", "")
            if not other_cid or other_cid == my_cid:
                continue
            rel_type = rel.get("relation", "") if isinstance(rel, dict) else str(rel)
            bridges_by_target.setdefault(other_cid, []).append({
                "concept": other_id,
                "relation": rel_type,
            })

        patterns = []
        for tgt_cid, bridge_list in bridges_by_target.items():
            concepts = [b["concept"] for b in bridge_list[:3]]
            relations = [b["relation"] for b in bridge_list if b["relation"]]
            abstraction = relations[0] if relations else "cross-community link"
            patterns.append({
                "pattern_type": "cross_community_abstraction",
                "source_community": my_cid,
                "target_community": tgt_cid,
                "abstraction": abstraction,
                "bridge_concepts": concepts,
                "confidence": round(min(1.0, len(bridge_list) / 3.0), 2),
            })

        return patterns[:2]

    def _get_historical_convergence_pattern(self, concept_id: str, layer: str) -> dict:
        """
        获取概念在某层（D1/D2/D3/D4）上的历史收敛模式。
        """
        if not self._lattice_cache:
            self._lattice_cache = self._load_lattice_index()

        data = self._lattice_cache.get(concept_id, {})
        version_stack = data.get("version_stack", [])

        # Extract layer-specific versions
        layer_versions = []
        for entry in version_stack:
            if not isinstance(entry, dict):
                continue
            if "versions" in entry:
                layer_data = entry["versions"].get(layer.upper(), {})
                if isinstance(layer_data, dict):
                    layer_versions.append({
                        "confidence": layer_data.get("confidence", 0.0),
                        "iteration": entry.get("iteration", 0),
                    })
            elif entry.get("level", "").upper() == layer.upper():
                layer_versions.append({
                    "confidence": entry.get("confidence", 0.0),
                    "iteration": entry.get("iteration", 0),
                })

        if not layer_versions:
            return {
                "convergence_strategy": "unknown",
                "typical_iterations": 3,
                "common_pitfalls": [],
                "success_rate": 0.0,
            }

        # Detect convergence strategy from confidence trajectory
        confidences = [v["confidence"] for v in layer_versions]
        iterations = len(confidences)

        if iterations >= 2:
            first, last = confidences[0], confidences[-1]
            if first < 0.5 and last >= 0.8:
                strategy = "analogy-first then formal"
            elif first >= 0.7 and last >= 0.9:
                strategy = "incremental refinement"
            elif first >= 0.6 and last < first:
                strategy = "over-correction detected"
            else:
                strategy = "mixed exploration"
        else:
            strategy = "initial draft"

        # Common pitfalls from fcms history
        pitfalls = []
        state = self.sm.load_state()
        fcms_patterns = state.get("fcms_cognitive_patterns", [])
        for p in fcms_patterns:
            pat = p.get("patterns", {})
            task_pitfalls = pat.get("pitfalls", {})
            for task_name, issues in task_pitfalls.items():
                if task_name in ("teach", "audit") and layer.upper() in str(issues).upper():
                    for issue in (issues if isinstance(issues, list) else [issues]):
                        if isinstance(issue, str) and issue not in pitfalls:
                            pitfalls.append(issue)

        # Heuristic common pitfalls per layer
        layer_pitfalls = {
            "d1": ["analogy too abstract", "domain mismatch with learner"],
            "d2": ["missing success criteria", "step ordering unclear"],
            "d3": ["over-formalization", "circular definition", "missing boundary conditions"],
            "d4": ["counter-example too trivial", "failure mechanism not explained"],
        }
        for pit in layer_pitfalls.get(layer.lower(), []):
            if pit not in pitfalls:
                pitfalls.append(pit)

        # Success rate
        success_rate = round(confidences[-1] if confidences else 0.0, 2)

        return {
            "convergence_strategy": strategy,
            "typical_iterations": iterations,
            "common_pitfalls": pitfalls[:3],  # limit
            "success_rate": success_rate,
        }

    def _inject_lattice_context(self, task: str, state: dict, concept_id: str) -> dict:
        """Inject lattice_context into state based on task type."""
        lattice_context = {}
        if task == "search":
            prereqs = self._find_prerequisites(concept_id) if concept_id else []
            analogies = self._find_analogies(concept_id) if concept_id else []
            lattice_context = {
                "prerequisites": prereqs,
                "related_concepts": analogies,
            }
        elif task == "teach":
            d3_summary = self._get_d3_summary(concept_id) if concept_id else ""
            best_analogy = self._get_best_analogy(concept_id) if concept_id else {}
            prereqs = self._find_prerequisites(concept_id) if concept_id else []
            lattice_context = {
                "d3_references": [{"concept_id": concept_id, "d3_summary": d3_summary}] if d3_summary else [],
                "analogy_references": ([best_analogy] if best_analogy and best_analogy.get("best_analogy") else []),
                "prerequisites": prereqs,
            }
            # v3.5 Yoneda injection for teach
            if concept_id:
                yoneda = self._build_yoneda_context(concept_id, task)
                if yoneda:
                    lattice_context["yoneda"] = yoneda
        elif task == "grow":
            current_gaps = state.get("pending_gaps", [])
            gap_desc = ""
            if current_gaps and isinstance(current_gaps, list):
                gap_desc = current_gaps[0].get("description", "") if isinstance(current_gaps[0], dict) else str(current_gaps[0])
            peer_gaps = self._find_similar_gaps(gap_desc, concept_id) if gap_desc else []
            strategies = []
            for layer in ["d1", "d2", "d3", "d4"]:
                strategy = self._get_learning_strategy(concept_id, layer) if concept_id else ""
                if strategy:
                    strategies.append({
                        "strategy": strategy,
                        "success_rate": 0.0,  # placeholder; could be computed from learning_curve
                        "source_concept": concept_id,
                    })
            lattice_context = {
                "peer_gaps": peer_gaps,
                "proven_strategies": strategies[:3],
            }
            # v3.5 Yoneda injection for grow
            if concept_id:
                yoneda = self._build_yoneda_context(concept_id, task)
                if yoneda:
                    lattice_context["yoneda"] = yoneda
        elif task == "audit":
            if not self._lattice_cache:
                self._lattice_cache = self._load_lattice_index()
            cross_concepts = []
            for other_id in list(self._lattice_cache.keys())[:5]:
                if other_id == concept_id:
                    continue
                d3 = self._get_d3_summary(other_id)
                if d3:
                    cross_concepts.append({
                        "concept_id": other_id,
                        "d3_summary": d3,
                    })
            lattice_context = {
                "cross_concept_definitions": cross_concepts[:3],
            }
            # v3.5 Yoneda injection for audit
            if concept_id:
                yoneda = self._build_yoneda_context(concept_id, task)
                if yoneda:
                    lattice_context["yoneda"] = yoneda
        if lattice_context:
            state["lattice_context"] = lattice_context
            self.sm.save_state(state)
        return lattice_context

    def _build_yoneda_context(self, concept_id: str, task: str) -> dict:
        """Build minimal Yoneda context for a given task."""
        try:
            role_profile = self._get_concept_role_profile(concept_id)
            community_patterns = self._get_community_patterns(concept_id=concept_id)
            cross_patterns = self._get_cross_community_patterns(concept_id)

            yoneda = {
                "role_profile": {
                    "structural_role": role_profile.get("structural_role", "normal"),
                    "centrality": role_profile.get("centrality", 0.0),
                    "prerequisite_for_count": role_profile.get("prerequisite_for_count", 0),
                    "community": role_profile.get("community_id", ""),
                },
                "community_patterns": community_patterns[:2],
                "cross_community_patterns": cross_patterns[:2],
            }

            # Historical convergence only for audit and grow (not teach)
            if task in ("audit", "grow"):
                # Determine which layer to query based on state
                state = self.sm.load_state()
                pending = state.get("pending_gaps", [])
                layer = "d3"  # default
                if pending and isinstance(pending[0], dict):
                    layer = pending[0].get("layer", "d3")
                historical = self._get_historical_convergence_pattern(concept_id, layer)
                yoneda["historical_convergence"] = {
                    "convergence_strategy": historical.get("convergence_strategy", "unknown"),
                    "typical_iterations": historical.get("typical_iterations", 3),
                    "common_pitfalls": historical.get("common_pitfalls", []),
                    "success_rate": historical.get("success_rate", 0.0),
                }

            return yoneda
        except Exception:
            # Yoneda is advisory — failures should not break the loop
            return {}

    # ── core Ralph loop (decision engine only) ─────────────────────

    def _self_test(self) -> None:
        """One-time startup health check. NOT part of iteration loop."""
        # Verify state_manager import (already done at module level, but check it's usable)
        if StateManager is None:
            raise RuntimeError("StateManager import failed")
        # Verify harness_dir exists and is writable
        if not self.harness_dir.exists():
            raise RuntimeError(f"Harness directory does not exist: {self.harness_dir}")
        if not os.access(self.harness_dir, os.W_OK):
            raise RuntimeError(f"Harness directory is not writable: {self.harness_dir}")
        # Verify results_dir can be created
        try:
            self.results_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise RuntimeError(f"Cannot create results directory: {exc}")
        # Verify PRD.md and agent templates exist
        prd_path = self.harness_dir.parent / "references" / "design" / "PRD.md"
        if not prd_path.exists():
            raise RuntimeError(f"PRD.md not found: {prd_path}")
        for task_name in self.sm.CHECKLIST:
            template_path = self.harness_dir / "agents" / f"{task_name}_task_template.md"
            if not template_path.exists():
                raise RuntimeError(f"Agent template not found: {template_path}")

    def run_v3(self, concept: str = "") -> dict:
        """Entry point matching SKILL.md declaration.

        v3.5+ state-machine mode: returns an action dict for external execution.
        """
        self._self_test()
        return self.run_step(concept)

    def run_step(self, concept: str = "") -> dict:
        """Execute one step of the Ralph loop and return the next action.

        Returns an action dict with keys:
        - action: "spawn" | "ingest" | "converged" | "terminated" | "audit" | "fix"
        - task: task name (e.g. "teach", "audit", "search")
        - iteration: current iteration number
        - input_path / output_path: file paths for the agent
        - template: path to task template
        - reason: human-readable description
        - state: current state dict (for external bookkeeping)

        Call ingest_result() after the external agent finishes.
        """
        state = self.sm.load_state()
        progress = self.sm.load_progress()
        budget = self.sm.load_budget()

        # v3.5 wiring: Apply pending self-awareness adjustments from previous iteration
        iteration = progress.get("current_iteration", 1)
        if iteration > 1 and self._module_enabled("self_awareness"):
            adj_path = self.harness_dir / "fcms" / "self" / f"adj_{iteration-1:03d}.json"
            if adj_path.exists():
                adj_data = self._load_json_safe(adj_path, {})
                for adj in adj_data.get("adjustments", []):
                    if adj.get("auto_apply", False):
                        self._apply_adjustment(adj, state, budget)

        # v3.5 LQL: refresh lattice cache at start of each iteration
        completed_steps = progress.get("completed_steps", [])
        if not completed_steps:
            self._lattice_cache = self._load_lattice_index()

        # Check budget
        if budget.get("remaining", 0) <= 0:
            return {"action": "terminated", "reason": "BUDGET_EXHAUSTED", "state": state}

        # Pick next task
        task = self.sm.get_next_task(progress)
        if task is None:
            # iteration complete → check convergence
            if self._is_converged(state, iteration):
                self._finalize(state, progress, budget)
                return {"action": "converged", "reason": "CONVERGED", "state": state}
            # start next iteration
            iteration += 1
            progress["current_iteration"] = iteration
            progress["completed_steps"] = []
            progress["next_step"] = "teach"
            task = "teach"

        # v3.5: compress pitfalls at start of every iteration, compress patterns every 5 rounds
        if self._module_enabled("fcms"):
            self._compress_pitfalls(state, iteration)
            self._compress_patterns(state, iteration)

        # v3.5: hybrid routing override
        if self._module_enabled("hybrid_routing") and HybridRouter is not None:
            override_task = self._get_task_sequence(progress, state)
            if override_task:
                task = override_task

        # Before teach, always run search first
        if task == "teach" and not self._search_completed_for_iteration(iteration):
            task = "search"

        # v3.5 parallel teach: check for multiple independent teach candidates
        if task == "teach" and self._search_completed_for_iteration(iteration):
            candidates = self._get_grow_candidates(iteration, state)
            if candidates:
                independent, dependent = self._check_parallelizable(candidates)
                if len(independent) > 1:
                    # Store all candidates in state for dependency tracking
                    state["grow_candidates"] = candidates
                    self.sm.save_state(state)
                    return {
                        "action": "parallel_spawn",
                        "tasks": [
                            {
                                "task": "teach",
                                "concept": c["concept"],
                                "concept_id": c["concept_id"],
                                "mode": c.get("mode", "fresh"),
                                "input_path": str(self._iter_dir(iteration) / f"teach_{c['concept_id']}_input.json"),
                                "output_path": str(self._iter_dir(iteration) / f"teach_{c['concept_id']}_output.json"),
                                "template": str(self.harness_dir / "agents" / "teach_task_template.md"),
                            }
                            for c in independent
                        ],
                        "iteration": iteration,
                        "state": state,
                        "progress": progress,
                        "budget": budget,
                    }
                # If only 1 independent candidate or only dependent ones,
                # fall through to normal serial spawn. Dependent candidates
                # will be handled in subsequent iterations.

        # Build paths
        input_path = str(self.harness_dir / "state.json")
        out_dir = self._iter_dir(iteration)
        out_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(out_dir / f"{task}_output.json")
        task_template = str(self.harness_dir / "agents" / f"{task}_task_template.md")

        # v3.5: inject adaptive threshold into audit template
        if task == "audit" and self._module_enabled("threshold_calibration"):
            task_template = self._inject_threshold_into_template(task_template)

        # v3.5: inject task-specific pitfalls into state for template consumption
        if self._module_enabled("fcms"):
            self._inject_pitfalls_for_task(state, task)
            self._save_all(state, progress, budget)

        # v3.5 LQL: inject lattice context before returning action
        current_concept = concept or state.get("current_concept", "")
        self._inject_lattice_context(task, state, current_concept)

        # v3.5 wiring: persona_profile + summary paths
        persona_profile_path = self.harness_dir / "agents" / f"{task}_persona_profile.md"
        summary_path = self.harness_dir / "agents" / f"{task}_task_template_SUMMARY.md"

        # v3.5 wiring: dependencies for subagent input injection
        dependencies = self._build_dependencies(task, iteration)

        # v3.5 wiring: checklist progress for main agent visibility
        completed_steps = progress.get("completed_steps", [])
        remaining_steps = [s for s in self.sm.CHECKLIST if s not in completed_steps and s != task]
        if task not in completed_steps:
            remaining_steps.insert(0, task)

        return {
            "action": "spawn",
            "task": task,
            "iteration": iteration,
            "concept": concept or state.get("current_concept", ""),
            "input_path": input_path,
            "output_path": output_path,
            "template": task_template,
            "persona_profile": str(persona_profile_path) if persona_profile_path.exists() else None,
            "summary": str(summary_path) if summary_path.exists() else None,
            "dependencies": dependencies,
            "estimated_cost": self._estimate_task_cost(task),
            "checklist_progress": {
                "completed": completed_steps,
                "remaining": remaining_steps,
                "current": task,
            },
            "reason": f"Next task: {task} (iteration {iteration})",
            "state": state,
            "progress": progress,
            "budget": budget,
        }

    def ingest_result(self, task_name: str, iteration: int,
                      output_path: str, state: dict, progress: dict, budget: dict) -> dict:
        """Ingest a completed worker output and decide next action.

        Returns an action dict:
        - action: "audit" → spawn auditor
        - action: "continue" → task passed, proceed to next
        - action: "fix" → needs fix, re-spawn worker
        - action: "rejected" → task rejected
        - action: "terminated" / "converged"
        """
        # Load worker output
        data = self._load_json_safe(Path(output_path), {})

        # Check for pending marker (worker failed to write real output)
        if data.get("_pending"):
            return {"action": "fix", "reason": "Worker output is pending placeholder", "state": state}

        # Merge into state
        self._ingest_worker_output(task_name, iteration, state)

        # v3.5: Grow only plans — dependency_updates are processed in consolidate
        # (Consolidate is the knowledge solidification executor)

        # v3.5 Consolidate: knowledge solidification — create nodes, merge nodes,
        # update dependencies, trigger graphify export
        if task_name == "consolidate":
            consolidate_data = data
            # Resolve grow_output path from consolidate output references
            grow_output_path = consolidate_data.get("source_outputs", {}).get("grow_output", "")
            grow_data = self._load_json_safe(Path(grow_output_path), {})

            # 1. Execute dependency updates from grow_output
            dependency_updates = grow_data.get("dependency_updates", [])
            if dependency_updates:
                state.setdefault("lattice_relations", []).extend(dependency_updates)
                self._update_lattice_relations(dependency_updates)
                self._update_index_relations(dependency_updates)

            # 2. Handle new concepts
            new_concepts = self._create_new_concepts(grow_data)
            if new_concepts:
                state.setdefault("new_concepts_created", []).extend(new_concepts)

            # 3. Handle merged concepts
            merged_concepts = self._merge_concepts(grow_data)
            if merged_concepts:
                state.setdefault("concepts_merged", []).extend(merged_concepts)

            # 4. graphify export 延迟到 audit 通过后执行
            #    （由 _refresh_graphify_export 在 ingest_result 中触发）

            # Record consolidate solidification results back into the output for audit
            consolidate_data["new_concepts_created"] = new_concepts
            consolidate_data["concepts_merged"] = merged_concepts
            self._atomic_write(Path(output_path), consolidate_data)

        # v3.5: FCMS health check on each iteration
        if self._module_enabled("fcms") and CognitiveHealthAssessor is not None:
            self._run_fcms_check(state, iteration, progress, budget)

        # v3.5: analogy matrix update after teach
        if task_name == "teach" and self._module_enabled("analogy_matrix") and AnalogySelector is not None:
            self._update_analogy_matrix(state, iteration, data)

        # v3.5: cascade analysis after teach — detect downstream/upstream/indirect impacts
        if task_name == "teach" and self._module_enabled("cascade") and CascadeEngine is not None:
            self._run_cascade(state, iteration, data)

        # v3.5: after verify, route gaps
        if task_name == "verify" and self._module_enabled("hybrid_routing") and HybridRouter is not None:
            self._route_gaps(state, iteration, data)

        # Spawn auditor (if not already done)
        if task_name != "audit":
            prd_path = str(self.harness_dir.parent / "references" / "design" / "PRD.md")
            audit_path = self._spawn_auditor(output_path, str(self.harness_dir / "agents" / f"{task_name}_task_template.md"), prd_path)
            # Record which worker task is pending audit so we can mark it done after audit passes
            state["_pending_audit_for"] = task_name
            return {
                "action": "audit",
                "task": task_name,
                "iteration": iteration,
                "worker_output": output_path,
                "audit_path": audit_path,
                "template": str(self.harness_dir / "agents" / f"{task_name}_task_template.md"),
                "prd_path": prd_path,
                "state": state,
                "progress": progress,
                "budget": budget,
            }

        # Handle audit result
        audit_action = self._handle_audit_result(output_path, task_name)

        if audit_action == "continue":
            # Mark the original worker task as done (if there was a pending audit)
            pending_worker_task = state.pop("_pending_audit_for", None)
            if pending_worker_task:
                progress = self.sm.mark_task_done(progress, pending_worker_task)
            progress = self.sm.mark_task_done(progress, task_name)
            # Consolidate 完成后自动刷新 graphify 可视化
            if task_name == "consolidate":
                self._refresh_graphify_export(state)
            self._save_all(state, progress, budget)

            # v3.5: termination check
            if self._module_enabled("termination") and TerminationEvaluator is not None:
                term_result = self._check_termination(state, iteration)
                if term_result.get("terminate"):
                    self._finalize_with_meta_summary(state, progress, budget, term_result)
                    return {"action": "terminated", "reason": term_result.get("reason", "TERMINATED"), "state": state}

            # v3.5: convergence check
            if self._is_converged(state, iteration):
                self._finalize(state, progress, budget)
                return {"action": "converged", "reason": "CONVERGED", "state": state}

            # v3.5 wiring: self_awareness trigger after consolidate audit passes
            if task_name == "consolidate" and self._module_enabled("self_awareness"):
                sa_input = self._collect_self_awareness_input(state, iteration, progress, budget)
                self_dir = self.harness_dir / "fcms" / "self"
                self_dir.mkdir(parents=True, exist_ok=True)
                input_path = self_dir / f"iteration_{iteration:03d}_input.json"
                self._atomic_write(input_path, sa_input)
                sa_output_path = str(self_dir / f"sa_{iteration:03d}.json")
                adj_output_path = str(self_dir / f"adj_{iteration:03d}.json")
                sa_template = str(self.harness_dir / "agents" / "self_aware_agent_template.md")
                state["_pending_self_aware"] = {
                    "iteration": iteration,
                    "input_path": str(input_path),
                    "output_path": sa_output_path,
                    "adjustments_path": adj_output_path,
                    "template": sa_template,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                self.sm.save_state(state)
                return {
                    "action": "self_aware",
                    "reason": f"Iteration {iteration} complete — triggering self-awareness coach",
                    "state": state,
                    "progress": progress,
                    "budget": budget,
                }

            return {"action": "continue", "reason": f"{task_name} passed", "state": state, "progress": progress, "budget": budget}

        elif audit_action == "needs_fix":
            audit = self._load_json_safe(Path(output_path), {})
            self._enqueue_fix(task_name, iteration, audit, state)
            self._save_all(state, progress, budget)
            return {"action": "fix", "reason": f"{task_name} needs fix", "state": state, "progress": progress, "budget": budget}

        elif audit_action == "rejected":
            audit = self._load_json_safe(Path(output_path), {})
            self._handle_rejection(task_name, iteration, audit, state, progress)
            self._save_all(state, progress, budget)
            # REJECT → treat as fix: executor must adjust strategy and retry
            return {"action": "fix", "reason": f"{task_name} REJECTED — strategy adjustment required, retry mandatory", "state": state, "progress": progress, "budget": budget}

        return {"action": "continue", "reason": "unknown audit status", "state": state}

    def ingest_parallel_results(self, results: list[dict], iteration: int,
                                state: dict, progress: dict, budget: dict) -> dict:
        """Ingest multiple parallel worker outputs.

        results: list of dicts with keys:
          - task: task name (e.g. "teach")
          - output_path: path to worker output file
        """
        for result in results:
            self._ingest_worker_output(
                result["task"], iteration, state,
                output_path=result.get("output_path")
            )

        # All parallel teaches complete → trigger unified audit
        return {
            "action": "audit",
            "task": "teach",
            "iteration": iteration,
            "state": state,
            "progress": progress,
            "budget": budget,
        }

    def _run_fcms_check(self, state: dict, iteration: int, progress: dict, budget: dict) -> None:
        """Run FCMS cognitive health assessment + apply instant regulation."""
        if CognitiveHealthAssessor is None:
            return
        try:
            assessor = CognitiveHealthAssessor()
            report = assessor.assess(
                state=state,
                progress=progress,
                budget=budget,
                iteration=iteration,
            )
            # Save FCMS report
            fcms_dir = self.harness_dir / "fcms"
            fcms_dir.mkdir(parents=True, exist_ok=True)
            fcms_path = fcms_dir / f"fcms_iter_{iteration}.json"
            self._atomic_write(fcms_path, report)
            # If alerts exist, add to state
            if report.get("alerts"):
                state.setdefault("fcms_alerts", []).extend(report["alerts"])

            # === v3.5 FCMS instant regulation + pitfall isolation + pattern accumulation ===
            # 1. Apply instant regulation
            regulation = report.get("regulation", {})
            if regulation.get("thresholds"):
                state["thresholds"] = regulation["thresholds"]
            if regulation.get("budget"):
                budget.update(regulation["budget"])
            if regulation.get("routing"):
                state["routing_override"] = regulation["routing"]

            # 2. Generate and isolate pitfall guides (by task, no cross-contamination)
            pitfall_guides = report.get("pitfall_guides", {})
            for task_name, guides in pitfall_guides.items():
                state[f"fcms_pitfalls_{task_name}"] = guides

            # 3. Accumulate cognitive patterns
            patterns = report.get("cognitive_patterns", {})
            if patterns:
                state.setdefault("fcms_cognitive_patterns", []).append({
                    "iteration": iteration,
                    "patterns": patterns,
                })

            # 4. Safety check on regulation
            if self._module_enabled("fcms") and RegulationSafetyChecker is not None:
                checker = RegulationSafetyChecker()
                reg_check = checker.check({**regulation, "budget": budget})
                if not reg_check["safe"]:
                    state.setdefault("fcms_regulation_warnings", []).append({
                        "iteration": iteration,
                        "warnings": reg_check["failures"],
                    })

            self._save_all(state, progress, budget)
        except Exception:
            # FCMS is advisory — failures should not break the loop
            pass

    # === v3.5 FCMS pitfall injection + compression helpers ===

    def _inject_pitfalls_for_task(self, state: dict, task: str) -> dict:
        """Inject task-specific pitfalls into state['fcms_pitfalls'] for template consumption.

        Isolation rule: teach_pitfalls only go to teach executor, grow_pitfalls
        only to grow, etc. Never cross-contaminate.
        """
        task_pitfalls = state.get(f"fcms_pitfalls_{task}", [])
        state["fcms_pitfalls"] = task_pitfalls
        return state

    def _compress_pitfalls(self, state: dict, iteration: int) -> None:
        """Compress fcms_pitfalls_* at the start of each iteration.

        Retention rule: keep entries from last 3 iterations + entries that
        appear across >=2 rounds (deduplicated by content hash).
        """
        import hashlib

        def _hash(text: str) -> str:
            return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]

        for task in self.sm.CHECKLIST:
            key = f"fcms_pitfalls_{task}"
            guides = state.get(key, [])
            if not guides:
                continue

            # Each guide is a plain string; wrap with iteration metadata if not already
            wrapped = []
            for g in guides:
                if isinstance(g, dict) and "text" in g:
                    wrapped.append(g)
                else:
                    wrapped.append({"text": str(g), "first_seen": iteration, "rounds": [iteration]})

            # Keep recent 3 rounds (first_seen > iteration - 3)
            recent = [g for g in wrapped if g.get("first_seen", 0) > iteration - 3]

            # Keep cross-round recurrent entries (appear >=2 times)
            by_hash: dict[str, dict] = {}
            for g in wrapped:
                h = _hash(g["text"])
                if h not in by_hash:
                    by_hash[h] = g
                else:
                    existing = by_hash[h]
                    existing["rounds"] = list(set(existing.get("rounds", []) + g.get("rounds", [])))

            recurrent = [g for g in by_hash.values() if len(g.get("rounds", [])) >= 2]

            # Merge: recent + recurrent, deduplicate by hash
            merged_map: dict[str, dict] = {}
            for g in recent + recurrent:
                h = _hash(g["text"])
                if h not in merged_map:
                    merged_map[h] = g

            # Flatten back to plain strings for template consumption
            state[key] = [g["text"] for g in merged_map.values()]

    def _compress_patterns(self, state: dict, iteration: int) -> None:
        """Compress fcms_cognitive_patterns every 5 iterations using BatchReflector.

        Auto-archive patterns older than 20 iterations to fcms/archive/.
        """
        patterns = state.get("fcms_cognitive_patterns", [])
        if not patterns:
            return

        # Archive patterns older than 20 iterations
        archive_cutoff = iteration - 20
        to_archive = [p for p in patterns if p.get("iteration", 0) <= archive_cutoff]
        remaining = [p for p in patterns if p.get("iteration", 0) > archive_cutoff]

        if to_archive:
            archive_dir = self.harness_dir / "fcms" / "archive"
            archive_dir.mkdir(parents=True, exist_ok=True)
            archive_path = archive_dir / f"patterns_archive_iter_{iteration}.json"
            self._atomic_write(archive_path, {
                "archived_at_iteration": iteration,
                "pattern_count": len(to_archive),
                "patterns": to_archive,
            })
            state["fcms_cognitive_patterns"] = remaining

        # Every 5 iterations, run BatchReflector merge
        if iteration > 0 and iteration % 5 == 0:
            try:
                from fcms.regulator import BatchReflector
                reflector = BatchReflector()
                merged = reflector.merge_across_rounds(remaining)
                state["fcms_cognitive_patterns"] = merged
            except Exception:
                # BatchReflector is advisory; failures should not break the loop
                pass
        """Update analogy matrix with new teach output."""
        if AnalogySelector is None:
            return
        try:
            analogy_cfg = self.config.get("modules", {}).get("analogy_matrix", {})
            selector = AnalogySelector(
                harness_dir=str(self.harness_dir),
                default_strategy=analogy_cfg.get("default_strategy", "hybrid"),
                minimum_viable_score=analogy_cfg.get("minimum_viable_score", 0.70),
                reframe_threshold=analogy_cfg.get("reframe_threshold", 0.60),
                domains=analogy_cfg.get("domains", []),
            )
            concept = state.get("current_concept", "unknown")
            # Build analogy entry from teach output
            entry = {
                "concept_id": concept,
                "d1": teach_output.get("d1", ""),
                "d2": teach_output.get("d2", ""),
                "d3": teach_output.get("d3", ""),
                "d4": teach_output.get("d4", ""),
                "iteration": iteration,
            }
            selector.update_matrix(entry)
        except Exception:
            # Analogy is advisory — failures should not break the loop
            pass

    # ── stub implementations for missing methods ─────────────────────

    def _is_converged(self, state: dict, iteration: int) -> bool:
        """Check if learning has converged via Ming Wu conditions."""
        ming_wu = state.get("ming_wu_status", {})
        if ming_wu.get("all_passed"):
            return True
        # Novelty check
        novelty = state.get("novelty_ratio", 1.0)
        return novelty < 0.15 and iteration >= 3

    def _finalize(self, state: dict, progress: dict, budget: dict) -> None:
        """Finalize iteration: save state and write completion marker."""
        self._save_all(state, progress, budget)
        state["status"] = "converged"
        state["finalized_at"] = datetime.now(timezone.utc).isoformat()
        self.sm.save_state(state)

    def _finalize_with_meta_summary(self, state: dict, progress: dict, budget: dict, term_result: dict) -> None:
        """Finalize with termination metadata."""
        self._finalize(state, progress, budget)
        state["termination_reason"] = term_result.get("reason", "TERMINATED")
        self.sm.save_state(state)

    def _save_all(self, state: dict, progress: dict, budget: dict) -> None:
        """Atomically save state, progress, and budget."""
        self.sm.save_state(state)
        self.sm.save_progress(progress)
        self.sm.save_budget(budget)

    # ── graphify integration ─────────────────────────────────────────

    def _refresh_graphify_export(self, state: dict) -> None:
        """每次 Consolidate 后自动刷新 graphify 可视化。

        调用 scripts/export_to_graphify.py 将 knowledge-lattice 导出为
        graphify 格式。失败不阻断主流程。
        """
        try:
            # 定位 knowledge-lattice（从 harness 向上到 workspace 根）
            lattice_dir = self.harness_dir.parent.parent.parent / "knowledge-lattice"
            if not lattice_dir.exists():
                # fallback：兼容旧路径（若目录结构变化）
                lattice_dir = self.harness_dir.parent.parent / "knowledge-lattice"
            output_dir = self.harness_dir.parent / "graphify-out"
            script_path = self.harness_dir.parent / "scripts" / "export_to_graphify.py"

            result = subprocess.run(
                [
                    "python3", str(script_path),
                    "--input-dir", str(lattice_dir),
                    "--output-dir", str(output_dir),
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                state["graphify_last_export"] = datetime.now(timezone.utc).isoformat()
                self.sm.save_state(state)
        except Exception:
            pass  # graphify 是辅助功能，失败不阻断主流程

    def _get_graphify_client(self) -> object | None:
        """延迟初始化并返回 GraphifyMCPClient；失败返回 None。"""
        try:
            from graphify_client import GraphifyMCPClient
            graph_dir = str(self.harness_dir.parent / "graphify-out")
            return GraphifyMCPClient(graph_dir)
        except Exception:
            return None

    # ── query decision matrix: LQL vs graphify ───────────────────────

    QUERY_DECISION_MATRIX: dict[str, str] = {
        "single_concept": "lql",
        "path_between": "graphify",
        "fuzzy_semantic": "graphify",
        "node_explanation": "graphify",
        "cross_community": "graphify",
    }

    def choose_query_interface(self, query_need: str) -> str:
        """根据查询需求类型推荐接口：'lql' 或 'graphify'。

        决策矩阵：
        - single_concept     → lql      (快，结构化)
        - path_between       → graphify (路径分析)
        - fuzzy_semantic     → graphify (BFS/DFS 语义遍历)
        - node_explanation   → graphify (预生成解释文本)
        - cross_community    → graphify (社区检测强项)
        """
        return self.QUERY_DECISION_MATRIX.get(query_need, "lql")

    def query_knowledge(self, query_type: str, **kwargs) -> dict:
        """统一查询入口，根据 query_type 自动选择 LQL 直接读取或 graphify 增强查询。

        Args:
            query_type: single_concept | path_between | fuzzy_semantic |
                        node_explanation | cross_community
            **kwargs:
                - single_concept:   concept_id (str)
                - path_between:     source (str), target (str)
                - fuzzy_semantic:   question (str), mode (str, default "bfs")
                - node_explanation: node (str)
                - cross_community:  question (str), mode (str, default "dfs")

        Returns:
            dict: 统一格式的查询结果；失败返回空 dict。
        """
        interface = self.choose_query_interface(query_type)

        if interface == "lql":
            # LQL：直接读取 knowledge-lattice JSON（快，结构化）
            concept_id = kwargs.get("concept_id", "")
            if not concept_id:
                return {}
            # 复用已有 lattice 缓存
            if not self._lattice_cache:
                self._lattice_cache = self._load_lattice_index()
            return {"interface": "lql", "data": self._lattice_cache.get(concept_id, {})}

        # graphify 增强查询
        client = self._get_graphify_client()
        if client is None:
            return {}

        if query_type == "path_between":
            return client.path(kwargs.get("source", ""), kwargs.get("target", ""))
        elif query_type == "node_explanation":
            return client.explain(kwargs.get("node", ""))
        else:
            # fuzzy_semantic & cross_community 均使用 query
            mode = kwargs.get("mode", "dfs" if query_type == "cross_community" else "bfs")
            return client.query(kwargs.get("question", ""), mode=mode)

    def _ingest_worker_output(self, task_name: str, iteration: int, state: dict, output_path: str | None = None) -> None:
        """Merge worker output into state."""
        if output_path is None:
            out_dir = self._iter_dir(iteration)
            output_path = out_dir / f"{task_name}_output.json"
        else:
            output_path = Path(output_path)
        data = self._load_json_safe(output_path, {})
        if not data:
            return
        # Merge task output into state (unified — no double-append for teach)
        state.setdefault(f"{task_name}_outputs", []).append({
            "iteration": iteration,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        if task_name == "teach":
            state["current_concept"] = data.get("concept", state.get("current_concept", ""))
        self.sm.save_state(state)

    def _handle_audit_result(self, output_path: str, task_name: str) -> str:
        """Read audit report and return action."""
        audit = self._load_json_safe(Path(output_path), {})
        if not audit:
            return "needs_fix"
        status = audit.get("status", "NEEDS_FIX")
        if status == "PASS":
            return "continue"
        elif status in ("NEEDS_FIX", "FIX"):
            return "needs_fix"
        else:
            return "rejected"

    def _enqueue_fix(self, task_name: str, iteration: int, audit: dict, state: dict) -> None:
        """Record a fix request in state for retry."""
        fix = {
            "task": task_name,
            "iteration": iteration,
            "audit": audit,
            "enqueued_at": datetime.now(timezone.utc).isoformat(),
        }
        state.setdefault("pending_fixes", []).append(fix)
        self.sm.save_state(state)

    def _handle_rejection(self, task_name: str, iteration: int, audit: dict, state: dict, progress: dict) -> None:
        """Record rejection, generate strategy adjustment, and notify user.

        REJECT means the worker output fundamentally fails quality gates.
        The step MUST NOT be skipped or downgraded.
        The executor MUST adjust strategy and retry.
        """
        # Record rejection
        state.setdefault("rejections", []).append({
            "task": task_name,
            "iteration": iteration,
            "audit_score": audit.get("score", 0),
            "issues": [i.get("description", "") for i in audit.get("issues", [])],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        progress.setdefault("rejected_tasks", []).append(task_name)

        # Generate strategy adjustment recommendations
        recommendations = audit.get("recommendations", [])
        issues = audit.get("issues", [])
        critical_issues = [i for i in issues if i.get("severity") == "critical"]

        strategy_adjustment = {
            "iteration": iteration,
            "task": task_name,
            "trigger": "audit_reject",
            "reason": f"Quality gate failed: score={audit.get('score', 0)}, critical={len(critical_issues)}",
            "recommendations": recommendations,
            "critical_issues": critical_issues,
            "adjustment": "retry_with_strategy_change",
            "notification_required": True,
        }
        state.setdefault("strategy_adjustments", []).append(strategy_adjustment)

        # User notification marker
        state.setdefault("user_notifications", []).append({
            "type": "quality_gate_failed",
            "task": task_name,
            "iteration": iteration,
            "message": f"{task_name} 输出被 audit_quality_agent 判定为 REJECT（评分 {audit.get('score', 0)}）。必须调整策略后重试，不可跳过。",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        self.sm.save_state(state)
        self.sm.save_progress(progress)

    def _spawn_auditor(self, output_path: str, task_template: str, prd_path: str) -> str:
        """Return audit path. Actual spawn is done by the coordinating agent."""
        # This method is a stub — the actual audit spawn is performed by the main agent
        # per the Ralph Loop coordination protocol.
        out_dir = Path(output_path).parent
        audit_path = out_dir / "audit_report.json"
        return str(audit_path)

    def _check_termination(self, state: dict, iteration: int) -> dict:
        """Check termination conditions."""
        return {"terminate": False, "reason": "CONTINUE"}

    def _get_task_sequence(self, progress: dict, state: dict) -> str | None:
        """Hybrid routing override. Returns None to use default sequence."""
        return None

    def _inject_threshold_into_template(self, task_template: str) -> str:
        """Inject adaptive threshold into audit template. Stub — returns original."""
        return task_template

    def _route_gaps(self, state: dict, iteration: int, verify_output: dict) -> None:
        """Route gaps after verify. Stub — no-op."""
        pass

    def _run_cascade(self, state: dict, iteration: int, teach_output: dict) -> None:
        """Run cascade analysis after teach to detect downstream/upstream/indirect impacts.

        Triggered after teach output is ingested. Compares old vs new teach output
        for updates, or analyzes upstream/indirect impacts for new concepts.
        Cascade gaps are stored in state["pending_cascade_gaps"] for grow to process.
        """
        if CascadeEngine is None:
            return
        try:
            cascade_cfg = self.config.get("modules", {}).get("cascade", {})
            if not cascade_cfg.get("enabled", False):
                return

            engine = CascadeEngine(
                harness_dir=str(self.harness_dir),
                max_depth=cascade_cfg.get("max_downstream_depth", 2),
                semantic_threshold=cascade_cfg.get("semantic_diff_threshold", 0.3),
            )
            concept = teach_output.get("concept_id", "")
            if not concept:
                return

            # Load previous teach output for comparison
            prev_output = self._load_previous_teach_output(concept, iteration)

            if prev_output:
                # UPDATE scenario: compare old vs new teach output
                report = engine.analyze(
                    concept_id=concept,
                    old_output=prev_output,
                    new_output=teach_output,
                    state_manager=self.sm,
                )
            else:
                # NEW scenario: analyze impact without comparison
                report = self._analyze_new_concept_cascade(engine, concept, teach_output)

            if report and report.get("cascade_gaps"):
                # Store cascade gaps for grow to process in this iteration
                state.setdefault("pending_cascade_gaps", []).extend(report["cascade_gaps"])
                # Save cascade report
                self._save_cascade_report(report, iteration)
        except Exception:
            # Cascade is advisory — failures should not break the loop
            pass

    def _analyze_new_concept_cascade(self, engine: Any, concept_id: str, teach_output: dict) -> dict:
        """Analyze cascade effects for a newly taught concept (no previous output)."""
        from datetime import datetime, timezone
        from cascade_engine import SemanticDiff

        cascade_gaps = []
        deps = set(SemanticDiff._extract_deps(teach_output))
        all_concepts = engine._scan_all_concepts()

        # 1. Upstream: concepts we depend on may need updating
        for dep_id in deps:
            if dep_id in all_concepts:
                cascade_gaps.append({
                    "id": f"cascade_new_{concept_id}_{dep_id}_up",
                    "target_concept": dep_id,
                    "source_concept": concept_id,
                    "impact_direction": "upstream",
                    "gap_description": f"{dep_id} 现在被新概念 {concept_id} 依赖，可能需要更新其 downstream 引用或边界说明",
                    "affected_layers": ["d2", "d3", "d4"],
                    "trigger_reason": "new_dependent_added",
                    "depth": 1,
                    "priority": 0.6,
                })

        # 2. Indirect: concepts sharing our dependencies
        for cid, output in all_concepts.items():
            if cid == concept_id:
                continue
            other_deps = set(SemanticDiff._extract_deps(output))
            shared = deps & other_deps
            if shared:
                cascade_gaps.append({
                    "id": f"cascade_new_{concept_id}_{cid}_indirect",
                    "target_concept": cid,
                    "source_concept": concept_id,
                    "impact_direction": "indirect",
                    "gap_description": f"{cid} 与 {concept_id} 共享依赖 {', '.join(shared)}，可能需要更新交叉引用",
                    "affected_layers": ["d2", "d3"],
                    "trigger_reason": "shared_dependency_new_peer",
                    "depth": 2,
                    "priority": 0.5,
                })

        return {
            "concept_id": concept_id,
            "core_change": True,
            "change_summary": {"is_new_concept": True, "dependencies": list(deps)},
            "cascade_gaps": cascade_gaps,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _save_cascade_report(self, report: dict, iteration: int) -> None:
        """Save cascade analysis report to disk."""
        cascade_dir = self.harness_dir / "cascade"
        cascade_dir.mkdir(parents=True, exist_ok=True)
        cascade_path = cascade_dir / f"cascade_iter_{iteration}.json"
        self._atomic_write(cascade_path, report)

    def _load_previous_teach_output(self, concept: str, iteration: int) -> dict:
        """Load previous iteration's teach output for a concept."""
        for i in range(iteration - 1, 0, -1):
            out_dir = self._iter_dir(i)
            teach_path = out_dir / "teach_output.json"
            if teach_path.exists():
                data = self._load_json_safe(teach_path, {})
                if data.get("concept_id") == concept:
                    return data
        return {}


    def _iter_dir(self, iteration: int) -> Path:
        return self.results_dir / f"iteration_{iteration}"

    def _get_grow_candidates(self, iteration: int, state: dict) -> list[dict]:
        """Extract teach_candidates from the latest grow output."""
        # First check if candidates were already extracted into state
        if "grow_candidates" in state:
            return state["grow_candidates"]

        # Read from grow output file of current or previous iteration
        for iter_num in range(iteration, max(0, iteration - 2), -1):
            grow_path = self._iter_dir(iter_num) / "grow_output.json"
            data = self._load_json_safe(grow_path, {})
            candidates = data.get("teach_candidates", [])
            if candidates:
                return candidates

        return []

    def _check_parallelizable(self, candidates: list[dict]) -> tuple[list[dict], list[dict]]:
        """Return (independent_candidates, dependent_candidates).

        Checks relation_to_trigger and requires_prerequisite fields:
        - depends_on / prerequisite_for → dependent
        - requires_prerequisite: true → dependent
        - is_component_of / analogy_of / others → independent
        """
        independent = []
        dependent = []
        for c in candidates:
            # Explicit prerequisite flag takes precedence
            if c.get("requires_prerequisite"):
                dependent.append(c)
                continue
            # Relation-based heuristic
            relation = c.get("relation_to_trigger", "")
            if relation in ["depends_on", "prerequisite_for"]:
                dependent.append(c)
            else:
                independent.append(c)
        return independent, dependent

    def _search_completed_for_iteration(self, iteration: int) -> bool:
        """Check if search_results.json exists for this iteration."""
        return (self._iter_dir(iteration) / "search_output.json").exists()

    def _audit_report_path(self, iteration: int) -> Path:
        return self._iter_dir(iteration) / "audit_report.json"

    def _check_worker_timeout(self, output_path: str, max_wait_seconds: int = 600) -> bool:
        """Check if a worker has exceeded time limit.
        Reads the pending marker file timestamp.
        Returns True if timed out.
        """
        path = Path(output_path)
        if not path.exists():
            return True  # File doesn't exist = timeout

        data = self._load_json_safe(path, {})
        if not data.get("_pending"):
            return False  # Worker completed, not pending

        # Check timestamp in marker
        marker_time_str = data.get("timestamp")
        if marker_time_str:
            try:
                marker_time = datetime.fromisoformat(marker_time_str)
                elapsed = (datetime.now(timezone.utc) - marker_time).total_seconds()
                return elapsed > max_wait_seconds
            except (ValueError, TypeError):
                pass

        # Fallback: use file modification time
        try:
            mtime = path.stat().st_mtime
            from time import time
            elapsed = time() - mtime
            return elapsed > max_wait_seconds
        except OSError:
            return True

    def _analyze_failure_pattern(self, task_name: str) -> dict:
        """Read exceptions.json history for this task.
        If 3+ consecutive failures, analyze root cause and suggest strategy change.
        Returns: {"action": "continue" | "escalate" | "abort", "reason": str}
        """
        current_iteration = self.sm.load_progress().get("current_iteration", 1)
        failure_records = []

        # Scan last 5 iterations for exceptions related to this task
        for i in range(max(1, current_iteration - 4), current_iteration + 1):
            exc_path = self._iter_dir(i) / "exceptions.json"
            exc_data = self._load_json_safe(exc_path, {"records": []})
            for record in exc_data.get("records", []):
                if record.get("task") == task_name:
                    failure_records.append({
                        "iteration": i,
                        "error": record.get("error", "UNKNOWN"),
                        "agent": record.get("agent", "unknown"),
                        "time": record.get("time", ""),
                    })

        # Check for 3+ failures in the same task
        if len(failure_records) >= 3:
            last_three = failure_records[-3:]
            iterations = [r["iteration"] for r in last_three]
            # Verify they span at most 3 consecutive iterations
            if iterations[-1] - iterations[0] <= 2:
                errors = [r["error"] for r in last_three]
                agents = [r["agent"] for r in last_three]

                if len(set(errors)) == 1:
                    return {
                        "action": "escalate",
                        "reason": (
                            f"Task '{task_name}' failed 3+ times with same error "
                            f"'{errors[-1]}'. Suggest strategy change or agent swap."
                        ),
                    }
                elif len(set(agents)) > 1:
                    return {
                        "action": "escalate",
                        "reason": (
                            f"Task '{task_name}' failed across multiple agents. "
                            f"Likely input data or strategy issue."
                        ),
                    }
                else:
                    return {
                        "action": "abort",
                        "reason": (
                            f"Task '{task_name}' repeatedly failed with agent "
                            f"'{agents[-1]}'. Aborting to prevent budget drain."
                        ),
                    }

        return {"action": "continue", "reason": "No consecutive failure pattern detected."}

    def _decrement_budget(self, budget: dict) -> None:
        budget["remaining"] = max(0, budget.get("remaining", 0) - 1)
        budget["used"] = budget.get("used", 0) + 1

    def _report(self, status: str, progress: dict, budget: dict) -> None:
        """Emit a machine-readable status line to stdout."""
        report = {
            "status": status,
            "iteration": progress.get("current_iteration"),
            "remaining_budget": budget.get("remaining"),
            "used_budget": budget.get("used"),
        }
        print(json.dumps(report, ensure_ascii=False))

    @staticmethod
    def _load_json_safe(path: Path, default: dict) -> dict:
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default

    @staticmethod
    def _atomic_write(path: Path, data: dict) -> None:
        import tempfile
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", prefix="tmp_",
            dir=str(path.parent), delete=False,
        )
        try:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
        finally:
            tmp.close()
        os.replace(tmp.name, path)

    def _lattice_concepts_dir(self) -> Path:
        """返回 knowledge-lattice/concepts 目录的正确路径。

        从 harness 向上追溯 workspace 根目录。
        """
        path = self.harness_dir.parent.parent.parent / "knowledge-lattice" / "concepts"
        if not path.exists():
            # fallback：兼容旧相对路径（若目录结构变化）
            fallback = self.harness_dir.parent.parent / "knowledge-lattice" / "concepts"
            if fallback.exists():
                return fallback
        return path

    def _update_lattice_relations(self, updates: list[dict]) -> None:
        """Write relationship updates to knowledge lattice."""
        lattice_dir = self._lattice_concepts_dir()
        for update in updates:
            source_id = update["source_concept_id"]
            target_id = update["target_concept_id"]
            # 读取源概念的 lattice 文件
            source_path = lattice_dir / f"{source_id}.json"
            source_data = self._load_json_safe(source_path, {})
            # 更新 dependency_graph
            deps = source_data.setdefault("dependency_graph", {})
            deps[target_id] = {
                "relation": update["relation_type"],
                "confidence": update["confidence"],
                "bidirectional": update["bidirectional"],
                "rationale": update["rationale"],
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            # 写回
            self._atomic_write(source_path, source_data)
            # 如果 bidirectional，同步更新目标概念
            if update["bidirectional"]:
                target_path = lattice_dir / f"{target_id}.json"
                target_data = self._load_json_safe(target_path, {})
                target_deps = target_data.setdefault("dependency_graph", {})
                target_deps[source_id] = {
                    "relation": update["relation_type"],  # 对称关系保持同类型
                    "confidence": update["confidence"],
                    "bidirectional": True,
                    "rationale": f"反向: {update['rationale']}",
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                }
                self._atomic_write(target_path, target_data)

    def _update_index_relations(self, updates: list[dict]) -> None:
        """Update knowledge-lattice index with relation metadata."""
        index_path = self._lattice_concepts_dir() / "index.json"
        index = self._load_json_safe(index_path, {})
        for update in updates:
            source_id = update["source_concept_id"]
            target_id = update["target_concept_id"]
            if source_id not in index.get("concepts", []):
                index.setdefault("concepts", []).append(source_id)
            if target_id not in index.get("concepts", []):
                index.setdefault("concepts", []).append(target_id)
            # 记录关系统计
            index.setdefault("relation_count", 0)
            index["relation_count"] += 1
        self._atomic_write(index_path, index)

    # ── v3.5 Consolidate knowledge solidification helpers ────────────

    def _lattice_dir(self) -> Path:
        """Return the knowledge-lattice/concepts directory, creating if needed."""
        d = self._lattice_concepts_dir()
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _backup_lattice_file(self, concept_id: str) -> str:
        """Backup a lattice file before mutation. Returns backup path."""
        path = self._lattice_dir() / f"{concept_id}.json"
        if path.exists():
            backup_path = path.with_suffix(".json.backup")
            import shutil
            shutil.copy2(path, backup_path)
            return str(backup_path)
        return ""

    def _load_concept(self, concept_id: str) -> dict:
        """Load a concept lattice file safely."""
        path = self._lattice_dir() / f"{concept_id}.json"
        return self._load_json_safe(path, {})

    def _save_concept(self, concept_id: str, data: dict) -> None:
        """Atomically write a concept lattice file."""
        path = self._lattice_dir() / f"{concept_id}.json"
        self._atomic_write(path, data)

    def _create_new_concepts(self, grow_data: dict) -> list[dict]:
        """Create new concept nodes from grow_output teach_candidates.

        Returns list of creation result dicts for consolidate output.
        """
        results: list[dict] = []
        candidates = grow_data.get("teach_candidates", [])
        for candidate in [c for c in candidates if c.get("is_new_node", False)]:
            concept_id = candidate.get("concept_id", "")
            if not concept_id:
                results.append({
                    "concept_id": "",
                    "status": "error",
                    "prerequisites": [],
                    "lattice_path": "",
                    "error": "Missing concept_id in candidate",
                })
                continue

            # Backup if somehow already exists
            self._backup_lattice_file(concept_id)

            path = self._lattice_dir() / f"{concept_id}.json"
            if path.exists():
                results.append({
                    "concept_id": concept_id,
                    "status": "error",
                    "prerequisites": candidate.get("prerequisite_concepts", []),
                    "lattice_path": str(path),
                    "error": "already_exists",
                })
                continue

            now = datetime.now(timezone.utc).isoformat()
            new_concept = {
                "concept_id": concept_id,
                "core_id": concept_id,
                "status": "learning",
                "version_stack": [],
                "dependencies": candidate.get("prerequisite_concepts", []),
                "downstream_concepts": [],
                "confidence": 0.0,
                "contradictions": [],
                "open_problems": [],
                "audit_history": [],
                "learning_curve": [],
                "cascade_flag": False,
                "created_at": now,
                "updated_at": now,
                "version": 1,
                "consolidation_status": "initial",
                "epistemic_emotion": "curious",
                "dependency_graph": {},
            }
            self._save_concept(concept_id, new_concept)

            # Update index
            index_path = self._lattice_dir() / "index.json"
            index = self._load_json_safe(index_path, {})
            index.setdefault("concepts", []).append(concept_id)
            self._atomic_write(index_path, index)

            results.append({
                "concept_id": concept_id,
                "status": "created",
                "prerequisites": new_concept["dependencies"],
                "lattice_path": str(path),
                "error": None,
            })
        return results

    def _merge_concepts(self, grow_data: dict) -> list[dict]:
        """Execute concept merges from grow_output merge_suggestions.

        Merge is irreversible — only executed when confidence >= 0.85.
        Returns list of merge result dicts for consolidate output.
        """
        results: list[dict] = []
        suggestions = grow_data.get("merge_suggestions", [])
        for suggestion in suggestions:
            primary_id = suggestion.get("primary_id", "")
            secondary_id = suggestion.get("secondary_id", "")
            confidence = suggestion.get("confidence", 0.0)
            rationale = suggestion.get("rationale", "")

            if not primary_id or not secondary_id:
                results.append({
                    "primary_id": primary_id,
                    "secondary_id": secondary_id,
                    "status": "error",
                    "confidence": confidence,
                    "rationale": rationale,
                    "error": "Missing primary_id or secondary_id",
                })
                continue

            if confidence < 0.85:
                results.append({
                    "primary_id": primary_id,
                    "secondary_id": secondary_id,
                    "status": "rejected",
                    "confidence": confidence,
                    "rationale": rationale,
                    "error": f"Merge confidence {confidence:.2f} < 0.85 threshold; not executed",
                })
                continue

            primary = self._load_concept(primary_id)
            secondary = self._load_concept(secondary_id)

            if not primary:
                results.append({
                    "primary_id": primary_id,
                    "secondary_id": secondary_id,
                    "status": "error",
                    "confidence": confidence,
                    "rationale": rationale,
                    "error": f"Primary concept '{primary_id}' not found in lattice",
                })
                continue
            if not secondary:
                results.append({
                    "primary_id": primary_id,
                    "secondary_id": secondary_id,
                    "status": "error",
                    "confidence": confidence,
                    "rationale": rationale,
                    "error": f"Secondary concept '{secondary_id}' not found in lattice",
                })
                continue

            # Backup both before mutation
            self._backup_lattice_file(primary_id)
            self._backup_lattice_file(secondary_id)

            # Merge version_stack (sort by timestamp, dedup by iteration)
            combined = primary.get("version_stack", []) + secondary.get("version_stack", [])
            combined.sort(key=lambda x: x.get("timestamp", ""))
            seen_iters: set = set()
            unique_versions: list = []
            for v in combined:
                it = v.get("iteration", 0)
                if it not in seen_iters:
                    seen_iters.add(it)
                    unique_versions.append(v)
            primary["version_stack"] = unique_versions

            # Merge dependency_graph (keep higher confidence)
            primary_deps = primary.setdefault("dependency_graph", {})
            secondary_deps = secondary.get("dependency_graph", {})
            for target, info in secondary_deps.items():
                if target not in primary_deps:
                    primary_deps[target] = info
                else:
                    sec_conf = info.get("confidence", 0.0)
                    pri_conf = primary_deps[target].get("confidence", 0.0)
                    if sec_conf > pri_conf:
                        primary_deps[target] = info

            # Merge open_problems (dedup)
            primary_problems = primary.setdefault("open_problems", [])
            for p in secondary.get("open_problems", []):
                if p not in primary_problems:
                    primary_problems.append(p)

            # Mark secondary as merged
            now = datetime.now(timezone.utc).isoformat()
            secondary["status"] = "merged"
            secondary["merged_into"] = primary_id
            secondary["merged_at"] = now
            secondary["merge_rationale"] = rationale

            # Redirect all downstream references to secondary_id → primary_id
            self._redirect_dependencies(secondary_id, primary_id)

            # Save both
            primary["updated_at"] = now
            self._save_concept(primary_id, primary)
            self._save_concept(secondary_id, secondary)

            # Update index to note merge
            index_path = self._lattice_dir() / "index.json"
            index = self._load_json_safe(index_path, {})
            if secondary_id in index.get("concepts", []):
                index["concepts"] = [c for c in index["concepts"] if c != secondary_id]
            self._atomic_write(index_path, index)

            results.append({
                "primary_id": primary_id,
                "secondary_id": secondary_id,
                "status": "merged",
                "confidence": confidence,
                "rationale": rationale,
                "error": None,
            })
        return results

    def _redirect_dependencies(self, old_id: str, new_id: str) -> None:
        """Update all concepts' dependency_graph that reference old_id to point to new_id."""
        lattice_dir = self._lattice_dir()
        for path in lattice_dir.glob("*.json"):
            if path.name == "index.json":
                continue
            concept = self._load_json_safe(path, {})
            deps = concept.get("dependency_graph", {})
            if old_id in deps:
                deps[new_id] = deps.pop(old_id)
                deps[new_id]["relation"] = f"redirected_from_{old_id}"
                deps[new_id]["updated_at"] = datetime.now(timezone.utc).isoformat()
                concept["updated_at"] = datetime.now(timezone.utc).isoformat()
                self._atomic_write(path, concept)

    def _trigger_graphify_export(self) -> dict:
        """Call export_to_graphify.py to refresh visualization.

        Non-blocking: failures are caught and reported but do not raise.
        """
        script_path = self.harness_dir.parent / "scripts" / "export_to_graphify.py"
        lattice_dir = self._lattice_concepts_dir().parent
        output_dir = self.harness_dir.parent / "graphify-out"

        result = {
            "triggered": True,
            "success": None,
            "output_dir": str(output_dir),
            "error": None,
        }

        if not script_path.exists():
            result["success"] = False
            result["error"] = f"export_to_graphify.py not found at {script_path}"
            return result

        try:
            import subprocess
            cmd = [
                sys.executable,
                str(script_path),
                "--input-dir", str(lattice_dir),
                "--output-dir", str(output_dir),
            ]
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if proc.returncode == 0:
                result["success"] = True
                # Try to parse stdout for stats
                try:
                    stats = json.loads(proc.stdout.splitlines()[-1])
                    result["stats"] = stats
                except Exception:
                    pass
            else:
                result["success"] = False
                result["error"] = f"exit={proc.returncode} stderr={proc.stderr[:500]}"
        except subprocess.TimeoutExpired:
            result["success"] = False
            result["error"] = "graphify export timed out after 120s"
        except Exception as exc:
            result["success"] = False
            result["error"] = f"exception: {exc}"
        return result


# ── mapping analysis ───────────────────────────────────────────────

    def _check_d1_d3_mapping(self, mapping_d1_d3: dict) -> dict:
        """Check D1↔D3 mapping: Analogy ↔ Formal.

        Detects: orphan formal terms, orphan analogy elements, analogy fractures.
        """
        correspondences = mapping_d1_d3.get("correspondences", [])
        unmapped_d3 = mapping_d1_d3.get("unmapped_d3_terms", [])
        unmapped_d1 = mapping_d1_d3.get("unmapped_d1_elements", [])
        return {
            "orphans_formal": unmapped_d3,
            "orphans_analogy": unmapped_d1,
            "fractures": [],
            "correspondence_count": len(correspondences),
        }

    def _check_d2_d4_mapping(self, mapping_d2_d4: dict) -> dict:
        """Check D2↔D4 mapping: Procedure ↔ Boundary.

        Detects: unguarded boundaries, phantom guards, silent failures.
        """
        guards = mapping_d2_d4.get("guards", [])
        unguarded = mapping_d2_d4.get("unguarded_boundaries", [])
        return {
            "guarded_boundaries": [
                g["d4_condition"] for g in guards if g.get("guard_type") != "none"
            ],
            "unguarded_boundaries": unguarded,
            "phantom_guards": [],
            "silent_failures": [],
        }

    def _check_d3_d4_mapping(self, mapping_d3_d4: dict, teach_output: dict) -> dict:
        """Check D3↔D4 mapping: Formal ↔ Counter-example.

        Detects: unconstructible counters, hidden assumptions, vacuous boundaries.
        """
        constructibility = mapping_d3_d4.get("constructibility", [])
        unconstructible = [
            c["d4_counter_example"]
            for c in constructibility
            if not c.get("constructible_from_d3", False)
        ]
        return {
            "constructible_counters": [
                c["d4_counter_example"]
                for c in constructibility
                if c.get("constructible_from_d3", False)
            ],
            "unconstructible_counters": unconstructible,
            "hidden_assumptions": [],
            "vacuous_boundaries": [],
        }

    def _check_cross_layer_mapping(self, contradictions: list, teach_output: dict) -> list:
        """Interpret contradictions as mapping failures between layers."""
        mapping_failures = []
        for contradiction in contradictions:
            layers = contradiction.get("layers_involved", [])
            layer_set = set(layers)
            if layer_set == {"d1", "d3"}:
                mapping_failures.append({
                    "type": "analogy_fracture",
                    "layers": ["d1", "d3"],
                    "gap": contradiction.get("text", "D1↔D3 contradiction"),
                })
            elif layer_set == {"d2", "d4"}:
                mapping_failures.append({
                    "type": "unguarded_boundary",
                    "layers": ["d2", "d4"],
                    "gap": contradiction.get("text", "D2↔D4 contradiction"),
                })
            elif layer_set == {"d3", "d4"}:
                mapping_failures.append({
                    "type": "hidden_assumption",
                    "layers": ["d3", "d4"],
                    "gap": contradiction.get("text", "D3↔D4 contradiction"),
                })
            else:
                mapping_failures.append({
                    "type": "mapping_misalignment",
                    "layers": layers,
                    "gap": contradiction.get("text", "Cross-layer contradiction"),
                })
        return mapping_failures

    def _check_d1_d2_mapping(self, mapping_d1_d2: dict) -> dict:
        """Check D1↔D2 mapping: Analogy ↔ Procedure.

        Detects:
        - orphan D1 elements (concrete nouns/verbs with no D2 step)
        - orphan D2 steps (steps with no D1 correspondent)
        - implied actions missing (analogy suggests actions not in D2)
        """
        correspondences = mapping_d1_d2.get("correspondences", [])
        unmapped_d1 = mapping_d1_d2.get("unmapped_d1_elements", [])
        unmapped_d2 = mapping_d1_d2.get("unmapped_d2_steps", [])

        # Detect implied actions from D1 that are missing in D2
        d2_step_indices = {
            c.get("d2_step_index") for c in correspondences
            if c.get("d2_step_index") is not None
        }
        implied_actions_missing = []
        for corr in correspondences:
            d1_elem = corr.get("d1_element", "")
            # Heuristic: if D1 element is a verb-like action not reflected in D2
            if d1_elem and corr.get("mapping_type") == "metaphorical":
                implied_actions_missing.append(d1_elem)

        return {
            "orphan_d1_elements": [
                {"element": e, "gap": f"D1 describes '{e}' but D2 has no step to execute it"}
                for e in unmapped_d1
            ],
            "orphan_d2_steps": [
                {"step": s, "gap": f"D2 step {s} has no correspondent in D1 analogy"}
                for s in unmapped_d2
            ],
            "implied_actions_missing": implied_actions_missing,
            "correspondence_count": len(correspondences),
        }

    def _check_d2_d3_mapping(self, mapping_d2_d3: dict) -> dict:
        """Check D2↔D3 mapping: Procedure ↔ Formal.

        Detects:
        - unmanipulated D3 variables (variables never touched by D2)
        - unformalized D2 steps (steps with no D3 correspondent)
        - operation mismatches (informal vs formal operation differ)
        """
        correspondences = mapping_d2_d3.get("correspondences", [])
        unmapped_d3 = mapping_d2_d3.get("unmapped_d3_variables", [])
        unmapped_d2 = mapping_d2_d3.get("unmapped_d2_steps", [])

        # Detect operation mismatches from correspondences
        operation_mismatches = []
        for corr in correspondences:
            informal_op = corr.get("informal_op")
            formal_op = corr.get("formal_op")
            if informal_op and formal_op and informal_op != formal_op:
                operation_mismatches.append({
                    "step": corr.get("d2_step_index"),
                    "informal": informal_op,
                    "formal": formal_op,
                    "gap": (
                        f"D2 says '{informal_op}' but D3 formalizes as "
                        f"'{formal_op}'; operations may differ"
                    ),
                })

        return {
            "unmanipulated_variables": [
                {"variable": v, "gap": f"D3 defines '{v}' but D2 never manipulates it"}
                for v in unmapped_d3
            ],
            "unformalized_steps": [
                {"step": s, "gap": f"D2 step {s} has no formal correspondent"}
                for s in unmapped_d2
            ],
            "operation_mismatches": operation_mismatches,
            "correspondence_count": len(correspondences),
        }

    def _check_cross_concept_mapping(self, teach_output: dict) -> dict:
        """Check cross-concept mapping conflicts across the lattice.

        Detects:
        - definition mismatches (same term, different D3 definitions)
        - analogy collisions (same D1 analogy maps to different D3 ops)
        - boundary violations (dependent concept violates dependency's D4)
        - dependency drifts (B's D2 depends on A's old D3 definition)
        """
        state = self.sm.load_state()
        concept_history = state.get("concept_history", [])
        current_concept = teach_output.get("concept_id")

        definition_mismatches = []
        analogy_collisions = []
        boundary_violations = []
        dependency_drifts = []

        # Need at least 2 concepts to detect cross-concept conflicts
        all_concepts = list(
            dict.fromkeys(concept_history + ([current_concept] if current_concept else []))
        )
        if len(all_concepts) < 2:
            return {
                "definition_mismatches": definition_mismatches,
                "analogy_collisions": analogy_collisions,
                "boundary_violations": boundary_violations,
                "dependency_drifts": dependency_drifts,
            }

        # Build lattice: concept_id -> teach_output data
        lattice = {}
        for concept_id in all_concepts:
            if concept_id == current_concept:
                lattice[concept_id] = teach_output
            else:
                # Load from previous iteration teach outputs
                for i in range(1, 1000):
                    path = self._iter_dir(i) / "teach_output.json"
                    data = self._load_json_safe(path, {})
                    if data.get("concept_id") == concept_id:
                        lattice[concept_id] = data
                        break

        # Compare each pair of concepts
        concept_ids = list(lattice.keys())
        for i, concept_a in enumerate(concept_ids):
            for concept_b in concept_ids[i + 1:]:
                a_data = lattice.get(concept_a, {})
                b_data = lattice.get(concept_b, {})

                a_d3 = a_data.get("d3", {})
                b_d3 = b_data.get("d3", {})
                a_d1 = a_data.get("d1", "")
                b_d1 = b_data.get("d1", "")
                a_d4 = a_data.get("d4", {})

                # 1. Definition mismatch: same term, different D3 definitions
                a_terms = self._extract_defined_terms(a_d3.get("definition", ""))
                b_terms = self._extract_defined_terms(b_d3.get("definition", ""))
                for term in set(a_terms.keys()) & set(b_terms.keys()):
                    if a_terms[term] != b_terms[term]:
                        definition_mismatches.append({
                            "type": "definition_mismatch",
                            "term": term,
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "definition_a": a_terms[term],
                            "definition_b": b_terms[term],
                            "gap": (
                                f"'{term}' defined differently in {concept_a} "
                                f"vs {concept_b}"
                            ),
                        })

                # 2. Analogy collision: same D1 analogy maps to different D3 ops
                a_analogies = self._extract_core_analogies(a_d1)
                b_analogies = self._extract_core_analogies(b_d1)
                for analogy in set(a_analogies.keys()) & set(b_analogies.keys()):
                    if a_analogies[analogy] != b_analogies[analogy]:
                        analogy_collisions.append({
                            "type": "analogy_collision",
                            "analogy": analogy,
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "formal_op_a": a_analogies[analogy],
                            "formal_op_b": b_analogies[analogy],
                            "gap": (
                                f"Both concepts use '{analogy}' but map to "
                                f"different formal operations"
                            ),
                        })

                # 3. Boundary violation: B's usage context violates A's D4 boundaries
                a_boundaries = a_d4.get("boundaries", [])
                b_def = b_d3.get("definition", "")
                for boundary in a_boundaries:
                    condition = boundary.get("condition", "")
                    if condition and condition in b_def:
                        boundary_violations.append({
                            "type": "boundary_violation",
                            "boundary": condition,
                            "concept_a": concept_a,
                            "concept_b": concept_b,
                            "gap": (
                                f"{concept_b} may violate {concept_a}'s boundary: "
                                f"'{condition}'"
                            ),
                        })

                # 4. Dependency drift: requires versioned D3 definitions (not yet tracked)
                # Placeholder: will be populated when version tracking is added.

        return {
            "definition_mismatches": definition_mismatches,
            "analogy_collisions": analogy_collisions,
            "boundary_violations": boundary_violations,
            "dependency_drifts": dependency_drifts,
        }

    def _extract_defined_terms(self, definition_text: str) -> dict:
        """Extract defined terms from D3 definition text.

        Looks for 'term = definition' or 'term: definition' patterns.
        """
        import re

        terms = {}
        if not definition_text:
            return terms
        for match in re.finditer(
            r"([A-Za-z_][A-Za-z0-9_\s]*[A-Za-z0-9_])\s*[:=]\s*([^;.\n]+)",
            definition_text,
        ):
            term = match.group(1).strip()
            definition = match.group(2).strip()
            if term:
                terms[term] = definition
        return terms

    def _extract_core_analogies(self, d1_text: str) -> dict:
        """Extract core analogies from D1 text.

        Returns a dict of analogy -> formal_operation mapping.
        This is a heuristic placeholder; full implementation requires
        NLP parsing of analogy structures.
        """
        return {}

    def _analyze_mappings(self, teach_output: dict, iteration: int) -> dict:
        """Pure function: analyze cross-layer mappings and produce failures.

        This is NOT a new agent spawn. It is a deterministic computation
        that runs inside the orchestrator between teach and audit.
        """
        mappings = teach_output.get("mappings", {})

        failures = {
            "d1_d3": self._check_d1_d3_mapping(mappings.get("d1_d3", {})),
            "d2_d4": self._check_d2_d4_mapping(mappings.get("d2_d4", {})),
            "d3_d4": self._check_d3_d4_mapping(
                mappings.get("d3_d4", {}), teach_output
            ),
            "cross_layer": self._check_cross_layer_mapping([], teach_output),
            "d1_d2": self._check_d1_d2_mapping(mappings.get("d1_d2", {})),
            "d2_d3": self._check_d2_d3_mapping(mappings.get("d2_d3", {})),
            "cross_concept": self._check_cross_concept_mapping(teach_output),
        }

        # Interpret contradiction-agent output if available
        contradictions_path = self._iter_dir(iteration) / "contradictions.json"
        if contradictions_path.exists():
            contradictions = self._load_json_safe(contradictions_path, {})
            failures["cross_layer"] = self._check_cross_layer_mapping(
                contradictions.get("contradictions", []), teach_output
            )

        # Write mapping_failures.json for downstream agents
        failures_path = self._iter_dir(iteration) / "mapping_failures.json"
        self._atomic_write(failures_path, {
            "iteration": iteration,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "failures": failures,
            "gap_count": self._count_gaps(failures),
        })

        return failures

    def _count_gaps(self, failures: dict) -> int:
        """Count total gaps across all failure categories."""
        count = 0

        # d1_d3
        d1_d3 = failures.get("d1_d3", {})
        count += len(d1_d3.get("orphans_formal", []))
        count += len(d1_d3.get("orphans_analogy", []))
        count += len(d1_d3.get("fractures", []))

        # d2_d4
        d2_d4 = failures.get("d2_d4", {})
        count += len(d2_d4.get("unguarded_boundaries", []))
        count += len(d2_d4.get("phantom_guards", []))
        count += len(d2_d4.get("silent_failures", []))

        # d3_d4
        d3_d4 = failures.get("d3_d4", {})
        count += len(d3_d4.get("unconstructible_counters", []))
        count += len(d3_d4.get("hidden_assumptions", []))
        count += len(d3_d4.get("vacuous_boundaries", []))

        # cross_layer
        count += len(failures.get("cross_layer", []))

        # d1_d2 (new)
        d1_d2 = failures.get("d1_d2", {})
        count += len(d1_d2.get("orphan_d1_elements", []))
        count += len(d1_d2.get("orphan_d2_steps", []))
        count += len(d1_d2.get("implied_actions_missing", []))

        # d2_d3 (new)
        d2_d3 = failures.get("d2_d3", {})
        count += len(d2_d3.get("unmanipulated_variables", []))
        count += len(d2_d3.get("unformalized_steps", []))
        count += len(d2_d3.get("operation_mismatches", []))

        # cross_concept (new)
        cross = failures.get("cross_concept", {})
        count += len(cross.get("definition_mismatches", []))
        count += len(cross.get("analogy_collisions", []))
        count += len(cross.get("boundary_violations", []))
        count += len(cross.get("dependency_drifts", []))

        return count


# ── entry point ────────────────────────────────────────────────────

def main() -> None:
    harness_dir = os.environ.get("FCH_HARNESS_DIR", str(Path(__file__).parent))
    orch = FeynmanOrchestrator(harness_dir)
    action = orch.run_step()
    print(json.dumps(action, indent=2, default=str))


# Backward-compatible alias
FCHOrchestrator = FeynmanOrchestrator


if __name__ == "__main__":
    main()
