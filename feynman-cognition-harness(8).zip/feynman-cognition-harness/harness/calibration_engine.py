#!/usr/bin/env python3
"""
Calibration Engine — FCH v3.5
Adaptive threshold calibration using statistical regression on historical UCC records.

Provides data-driven threshold calibration for audit aggregate scores and BDD
confidence scores, replacing hardcoded heuristics (0.90, 0.92) with statistically
informed values and confidence intervals.

Dependencies (optional):
    numpy, sklearn — used for isotonic/logistic regression when available.
    If unavailable, falls back to simple averaging with wide CIs.
"""

from __future__ import annotations

import json
import logging
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("fch.calibration")

# ── graceful dependency handling ──────────────────────────────────

_has_numpy = False
_has_sklearn = False

try:
    import numpy as np
    _has_numpy = True
except Exception:  # pragma: no cover
    np = None  # type: ignore[misc]

try:
    from sklearn.isotonic import IsotonicRegression
    from sklearn.linear_model import LogisticRegression
    _has_sklearn = True
except Exception:  # pragma: no cover
    IsotonicRegression = None  # type: ignore[misc,assignment]
    LogisticRegression = None  # type: ignore[misc,assignment]


# ── cold-start defaults ───────────────────────────────────────────

COLD_START_DEFAULTS: Dict[str, Any] = {
    "audit_aggregate_threshold": {
        "point_estimate": 0.85,
        "confidence_interval": [0.70, 1.0],
        "confidence_level": 0.95,
        "sample_size": 0,
        "method": "heuristic_default",
        "cold_start": True,
        "rationale": (
            "Default chosen based on UCC 1 (0.82) and UCC 3 (aggregate ~0.83). "
            "0.85 balances false-positive and false-negative risk with no data."
        ),
    },
    "bdd_confidence_threshold": {
        "point_estimate": 0.75,
        "confidence_interval": [0.60, 0.90],
        "confidence_level": 0.95,
        "sample_size": 0,
        "method": "heuristic_default",
        "cold_start": True,
        "rationale": (
            "UCC 2 scored 0.78 and produced HoTT (a valid new concept). "
            "0.75 allows exploration while still requiring meaningful confidence."
        ),
    },
}


# ── data structures ─────────────────────────────────────────────

@dataclass
class HistoricalUCCRecord:
    """One record per UCC instance for threshold calibration."""
    ucc_id: str
    timestamp: str
    concept_id: str
    audit_aggregate: float
    audit_threshold_used: float
    audit_passed: bool
    final_quality: str = "UNKNOWN"
    final_quality_source: str = "pending"
    audit_scores: Dict[str, float] = field(default_factory=dict)
    bdd_confidence: Optional[float] = None
    bdd_decision: Optional[str] = None
    gap_count: int = 0
    converged: bool = False
    budget_used: int = 0
    routing: str = "FCH"

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "HistoricalUCCRecord":
        """Instantiate from a JSON-compatible dict."""
        return cls(
            ucc_id=d.get("ucc_id", ""),
            timestamp=d.get("timestamp", ""),
            concept_id=d.get("concept_id", "unknown"),
            audit_aggregate=d.get("audit_aggregate", 0.0),
            audit_threshold_used=d.get("audit_threshold_used", 0.0),
            audit_passed=d.get("audit_passed", False),
            final_quality=d.get("final_quality", "UNKNOWN"),
            final_quality_source=d.get("final_quality_source", "pending"),
            audit_scores=d.get("audit_scores", {}),
            bdd_confidence=d.get("bdd_confidence"),
            bdd_decision=d.get("bdd_decision"),
            gap_count=d.get("gap_count", 0),
            converged=d.get("converged", False),
            budget_used=d.get("budget_used", 0),
            routing=d.get("routing", "FCH"),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-compatible dict."""
        return {
            "ucc_id": self.ucc_id,
            "timestamp": self.timestamp,
            "concept_id": self.concept_id,
            "audit_scores": self.audit_scores,
            "audit_aggregate": self.audit_aggregate,
            "audit_threshold_used": self.audit_threshold_used,
            "audit_passed": self.audit_passed,
            "bdd_confidence": self.bdd_confidence,
            "bdd_decision": self.bdd_decision,
            "final_quality": self.final_quality,
            "final_quality_source": self.final_quality_source,
            "gap_count": self.gap_count,
            "converged": self.converged,
            "budget_used": self.budget_used,
            "routing": self.routing,
        }


@dataclass
class ThresholdOutput:
    """Output of calibration for a single threshold."""
    point_estimate: float
    confidence_interval: Tuple[float, float]
    confidence_level: float
    sample_size: int
    method: str
    cold_start: bool
    target_recall: float = 0.90

    def to_dict(self) -> Dict[str, Any]:
        return {
            "point_estimate": round(self.point_estimate, 3),
            "confidence_interval": [
                round(self.confidence_interval[0], 3),
                round(self.confidence_interval[1], 3),
            ],
            "confidence_level": self.confidence_level,
            "sample_size": self.sample_size,
            "method": self.method,
            "cold_start": self.cold_start,
            "target_recall": self.target_recall,
        }


# ── calibration engine ──────────────────────────────────────────

class CalibrationEngine:
    """Adaptive threshold calibration from historical UCC records.

    Uses isotonic regression (small N) or logistic regression with bootstrap
    (larger N) to produce data-driven thresholds and confidence intervals.

    Gracefully degrades to simple averaging when numpy/sklearn are unavailable.
    """

    def __init__(self, history_path: Optional[Path] = None, min_samples: int = 5):
        self.history_path = history_path
        self.min_samples = min_samples
        self._records: List[HistoricalUCCRecord] = []

    def load_history(self, records: Optional[List[Dict[str, Any]]] = None) -> None:
        """Load historical records from list or from JSONL file at ``history_path``."""
        if records is not None:
            self._records = [HistoricalUCCRecord.from_dict(r) for r in records]
            return

        self._records = []
        if self.history_path is None or not self.history_path.exists():
            return

        with open(self.history_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    self._records.append(HistoricalUCCRecord.from_dict(json.loads(line)))
                except (json.JSONDecodeError, KeyError):
                    log.warning("Skipping malformed history line.")

    def calibrate_thresholds(
        self,
        cold_start_defaults: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Recalibrate all thresholds from loaded history.

        Returns a dict compatible with ``thresholds.json`` containing:
        - ``audit_aggregate_threshold``
        - ``bdd_confidence_threshold``
        - metadata (version, next_calibration_trigger, etc.)
        """
        defaults = cold_start_defaults or COLD_START_DEFAULTS
        n = len(self._records)

        if n < self.min_samples:
            return self._make_cold_start_output(defaults, n)

        audit_data = self._prepare_audit_dataset()
        bdd_data = self._prepare_bdd_dataset()

        audit_thresh = self._calibrate_single_threshold(
            data=audit_data,
            score_field="audit_aggregate",
            outcome_field="final_quality_binary",
            method="logistic_regression_bootstrap" if len(audit_data) >= 10 else "isotonic_regression",
            target_recall=0.90,
        )

        bdd_thresh = self._calibrate_single_threshold(
            data=bdd_data,
            score_field="bdd_confidence",
            outcome_field="final_quality_binary",
            method="logistic_regression_bootstrap" if len(bdd_data) >= 10 else "isotonic_regression",
            target_recall=0.85,
        )

        return {
            "audit_aggregate_threshold": audit_thresh.to_dict(),
            "bdd_confidence_threshold": bdd_thresh.to_dict(),
            "version": _utc_now_iso(),
            "sample_size": n,
            "next_calibration_trigger": f"sample_size >= {n + 5} OR 7_days_elapsed",
        }

    def _prepare_audit_dataset(self) -> List[Dict[str, Any]]:
        """Build calibration rows for audit aggregate."""
        out: List[Dict[str, Any]] = []
        for r in self._records:
            fq = r.final_quality.upper()
            out.append({
                "audit_aggregate": r.audit_aggregate,
                "final_quality_binary": 1 if fq == "GOOD" else 0,
            })
        return out

    def _prepare_bdd_dataset(self) -> List[Dict[str, Any]]:
        """Build calibration rows for BDD confidence (only instances with BDD data)."""
        out: List[Dict[str, Any]] = []
        for r in self._records:
            if r.bdd_confidence is None:
                continue
            fq = r.final_quality.upper()
            out.append({
                "bdd_confidence": r.bdd_confidence,
                "final_quality_binary": 1 if fq == "GOOD" else 0,
            })
        return out

    def _calibrate_single_threshold(
        self,
        data: List[Dict[str, Any]],
        score_field: str,
        outcome_field: str,
        method: str,
        target_recall: float,
    ) -> ThresholdOutput:
        """Calibrate one threshold using the chosen statistical method."""
        if not data:
            return ThresholdOutput(
                point_estimate=COLD_START_DEFAULTS["audit_aggregate_threshold"]["point_estimate"],
                confidence_interval=(0.0, 1.0),
                confidence_level=0.95,
                sample_size=0,
                method="no_data",
                cold_start=True,
                target_recall=target_recall,
            )

        if not _has_numpy or not _has_sklearn:
            return self._fallback_simple_average(data, score_field, outcome_field, target_recall)

        scores = [r[score_field] for r in data]
        outcomes = [r[outcome_field] for r in data]

        if method == "isotonic_regression":
            return self._isotonic_threshold(scores, outcomes, target_recall)
        return self._logistic_threshold(scores, outcomes, target_recall)

    def _isotonic_threshold(
        self,
        scores: List[float],
        outcomes: List[int],
        target_recall: float,
    ) -> ThresholdOutput:
        """Isotonic regression threshold (non-parametric, monotonic)."""
        iso = IsotonicRegression(out_of_bounds="clip")
        iso.fit(scores, outcomes)

        lo, hi = min(scores), max(scores)
        grid = np.linspace(lo, hi, 200)
        probs = iso.predict(grid)

        idx = int(np.argmin(np.abs(probs - target_recall)))
        point = float(np.clip(grid[idx], 0.0, 1.0))

        ci_low, ci_high = self._bootstrap_ci_isotonic(scores, outcomes, target_recall)
        return ThresholdOutput(
            point_estimate=point,
            confidence_interval=(ci_low, ci_high),
            confidence_level=0.95,
            sample_size=len(scores),
            method="isotonic_regression",
            cold_start=False,
            target_recall=target_recall,
        )

    def _logistic_threshold(
        self,
        scores: List[float],
        outcomes: List[int],
        target_recall: float,
    ) -> ThresholdOutput:
        """Logistic regression threshold with bootstrap CI."""
        X = np.array(scores).reshape(-1, 1)
        y = np.array(outcomes)

        model = LogisticRegression(max_iter=1000)
        model.fit(X, y)

        beta0 = float(model.intercept_[0])
        beta1 = float(model.coef_[0][0])

        if abs(beta1) < 1e-9:
            return self._fallback_simple_average_from_scores(scores, outcomes, target_recall)

        logit_p = float(np.log(target_recall / (1 - target_recall)))
        point = float(np.clip((logit_p - beta0) / beta1, 0.0, 1.0))

        ci_low, ci_high = self._bootstrap_ci_logistic(scores, outcomes, target_recall)
        return ThresholdOutput(
            point_estimate=point,
            confidence_interval=(ci_low, ci_high),
            confidence_level=0.95,
            sample_size=len(scores),
            method="logistic_regression_bootstrap",
            cold_start=False,
            target_recall=target_recall,
        )

    def _fallback_simple_average(
        self,
        data: List[Dict[str, Any]],
        score_field: str,
        outcome_field: str,
        target_recall: float,
    ) -> ThresholdOutput:
        """Fallback when numpy/sklearn unavailable: mean of passing scores."""
        good_scores = [r[score_field] for r in data if r[outcome_field] == 1]
        if not good_scores:
            return ThresholdOutput(
                point_estimate=0.85,
                confidence_interval=(0.70, 1.0),
                confidence_level=0.95,
                sample_size=len(data),
                method="fallback_average_no_deps",
                cold_start=True,
                target_recall=target_recall,
            )
        point = sum(good_scores) / len(good_scores)
        return ThresholdOutput(
            point_estimate=round(point, 3),
            confidence_interval=(max(0.0, point - 0.15), min(1.0, point + 0.15)),
            confidence_level=0.95,
            sample_size=len(data),
            method="fallback_average_no_deps",
            cold_start=True,
            target_recall=target_recall,
        )

    def _fallback_simple_average_from_scores(
        self,
        scores: List[float],
        outcomes: List[int],
        target_recall: float,
    ) -> ThresholdOutput:
        """Helper for fallback from raw score lists."""
        good = [s for s, o in zip(scores, outcomes) if o == 1]
        point = sum(good) / len(good) if good else 0.85
        return ThresholdOutput(
            point_estimate=round(point, 3),
            confidence_interval=(max(0.0, point - 0.15), min(1.0, point + 0.15)),
            confidence_level=0.95,
            sample_size=len(scores),
            method="fallback_average_no_deps",
            cold_start=True,
            target_recall=target_recall,
        )

    def _bootstrap_ci_isotonic(
        self,
        scores: List[float],
        outcomes: List[int],
        target_recall: float,
        n_bootstrap: int = 1000,
    ) -> Tuple[float, float]:
        """Bootstrap 95% CI for isotonic regression threshold."""
        rng = np.random.default_rng(42)
        thresholds: List[float] = []
        for _ in range(n_bootstrap):
            idx = rng.integers(0, len(scores), size=len(scores))
            b_scores = [scores[i] for i in idx]
            b_outcomes = [outcomes[i] for i in idx]
            try:
                iso = IsotonicRegression(out_of_bounds="clip")
                iso.fit(b_scores, b_outcomes)
                lo, hi = min(b_scores), max(b_scores)
                grid = np.linspace(lo, hi, 200)
                probs = iso.predict(grid)
                idx2 = int(np.argmin(np.abs(probs - target_recall)))
                thresholds.append(float(np.clip(grid[idx2], 0.0, 1.0)))
            except Exception:
                continue
        if len(thresholds) < 100:
            return 0.0, 1.0
        return float(np.percentile(thresholds, 2.5)), float(np.percentile(thresholds, 97.5))

    def _bootstrap_ci_logistic(
        self,
        scores: List[float],
        outcomes: List[int],
        target_recall: float,
        n_bootstrap: int = 1000,
    ) -> Tuple[float, float]:
        """Bootstrap 95% CI for logistic regression threshold."""
        rng = np.random.default_rng(42)
        thresholds: List[float] = []
        for _ in range(n_bootstrap):
            idx = rng.integers(0, len(scores), size=len(scores))
            b_scores = [scores[i] for i in idx]
            b_outcomes = [outcomes[i] for i in idx]
            try:
                X = np.array(b_scores).reshape(-1, 1)
                y = np.array(b_outcomes)
                m = LogisticRegression(max_iter=1000)
                m.fit(X, y)
                b0, b1 = float(m.intercept_[0]), float(m.coef_[0][0])
                if abs(b1) < 1e-9:
                    continue
                logit_p = float(np.log(target_recall / (1 - target_recall)))
                t = float(np.clip((logit_p - b0) / b1, 0.0, 1.0))
                thresholds.append(t)
            except Exception:
                continue
        if len(thresholds) < 100:
            return 0.0, 1.0
        return float(np.percentile(thresholds, 2.5)), float(np.percentile(thresholds, 97.5))

    @staticmethod
    def _make_cold_start_output(
        defaults: Dict[str, Any],
        n: int,
    ) -> Dict[str, Any]:
        """Return cold-start defaults when insufficient data."""
        out = {
            "audit_aggregate_threshold": dict(defaults["audit_aggregate_threshold"]),
            "bdd_confidence_threshold": dict(defaults["bdd_confidence_threshold"]),
            "version": _utc_now_iso(),
            "sample_size": n,
            "next_calibration_trigger": f"sample_size >= 5 OR 7_days_elapsed",
        }
        out["audit_aggregate_threshold"]["sample_size"] = n
        out["bdd_confidence_threshold"]["sample_size"] = n
        return out


# ── public API ────────────────────────────────────────────────────

def calibrate_thresholds(
    historical_records: List[Dict[str, Any]],
    cold_start_defaults: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Convenience function: calibrate from a list of raw records.

    Args:
        historical_records: List of HistoricalUCCRecord-compatible dicts.
        cold_start_defaults: Optional override for cold-start defaults.

    Returns:
        Threshold output dict ready for JSON serialization.
    """
    engine = CalibrationEngine(min_samples=5)
    engine.load_history(historical_records)
    return engine.calibrate_thresholds(cold_start_defaults)


def should_trigger_calibration(history: List[Dict[str, Any]], last_calibrated_at: Optional[str] = None) -> bool:
    """Determine whether calibration should auto-trigger.

    Triggers every 5 new records or every 7 days (whichever comes first).

    Args:
        history: Current history record list.
        last_calibrated_at: ISO timestamp of last calibration, if any.

    Returns:
        True if calibration should run.
    """
    if len(history) >= 5:
        return True
    if last_calibrated_at:
        try:
            last = datetime.fromisoformat(last_calibrated_at.replace("Z", "+00:00"))
            now = datetime.now(timezone.utc)
            if (now - last).days >= 7:
                return True
        except ValueError:
            pass
    return False


# ── helpers ───────────────────────────────────────────────────────

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ── CLI entry point ──────────────────────────────────────────────

def _main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="FCH v3.5 Calibration Engine")
    parser.add_argument("--recalibrate", action="store_true", help="Run calibration from history.jsonl")
    parser.add_argument("--history", type=str, default=None, help="Path to history.jsonl")
    parser.add_argument("--output", type=str, default="thresholds.json", help="Output path")
    args = parser.parse_args()

    if args.recalibrate:
        history_path = Path(args.history) if args.history else None
        engine = CalibrationEngine(history_path=history_path)
        engine.load_history()
        result = engine.calibrate_thresholds()
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"Calibration complete. Wrote {args.output}")
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        parser.print_help()


if __name__ == "__main__":
    _main()

__all__ = [
    "CalibrationEngine",
    "HistoricalUCCRecord",
    "ThresholdOutput",
    "COLD_START_DEFAULTS",
    "calibrate_thresholds",
    "should_trigger_calibration",
]
