#!/usr/bin/env python3
"""DREAM Trigger — nightly cron entry point for Dream Engine.

Reads config.yaml to check if dream is enabled, then runs DreamEngine.scan_all().
Intended to be called from crontab: 0 2 * * * cd /path/to/harness && python3 dream_trigger.py
"""
import sys
from pathlib import Path

HARNESS_DIR = Path(__file__).parent
sys.path.insert(0, str(HARNESS_DIR))

from dream_engine import DreamEngine


def main() -> int:
    import yaml
    config_path = HARNESS_DIR / "config.yaml"
    if not config_path.exists():
        print("[DREAM] config.yaml not found, aborting", file=sys.stderr)
        return 1

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    dream_cfg = config.get("modules", {}).get("dream", {})
    if not dream_cfg.get("enabled", False):
        print("[DREAM] dream module disabled in config, skipping")
        return 0

    min_concepts = dream_cfg.get("min_concepts_for_scan", 5)
    output_path = dream_cfg.get("output_path", "dreams/")

    engine = DreamEngine(str(HARNESS_DIR))
    result = engine.scan_all(min_concepts=min_concepts, output_path=output_path)

    print(f"[DREAM] scan complete: {result.get('concepts_scanned', 0)} concepts, "
          f"{result.get('patterns_found', 0)} patterns, "
          f"{result.get('contradictions', 0)} contradictions")
    return 0


if __name__ == "__main__":
    sys.exit(main())
