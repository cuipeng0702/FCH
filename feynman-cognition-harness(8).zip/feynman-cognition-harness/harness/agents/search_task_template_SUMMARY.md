# Search Task Template — Summary (v3.5)

## 一句话定义
认知循环的第一步，通过多维度 web 搜索为概念建立事实基础，产出搜索结果 JSON。

## 输入（Input）
- 来源：`{input_path}`（orchestrator 生成）
- 格式：JSON，含 `concept_id`、`concept_name`、`iteration`、`previous_queries`
- 关键字段：`concept_name`（搜索目标）、`previous_queries`（去重依据）、`iteration`（迭代序号）

## 输出（Output）
- 路径：`{output_path}`（约定为 `results/iter{N}/search_results.json`）
- 格式：JSON，含 `queries`、`results`、`synthesis`、`timestamp`
- 验收标准：
  1. 文件存在且 JSON 有效
  2. `queries` 长度 ≥3，且不重复 `previous_queries`
  3. `results` 含 ≥5 条 `relevance >= 0.5` 的记录
  4. `synthesis` 非空且 ≥50 词
  5. 所有 result 有非空 `source`、`url`、`snippet` 和数值 `relevance ∈ [0.0, 1.0]`

## 执行要点（SOP 速查）
1. 执行 ≥3 个不同意图的查询：定义型、类比型、边界/反例型
2. 为每条结果评估 `relevance`，保留 ≥5 条高质量结果
3. 综合所有结果撰写 `synthesis`，覆盖核心定义、直观框架、局限性和冲突信息

## 常见失败模式
- 搜索结果质量低（全部 relevance < 0.5）→ 主 agent 更换关键词重新 spawn search agent
- `queries` 重复 `previous_queries` → 主 agent 检查 orchestrator 去重逻辑
- `synthesis` 过短或只是结果罗列 → 主 agent 要求补充综合或标记为失败

## 关联文件
- 详细模板：`harness/agents/search_task_template.md`
- 人格档案：`harness/agents/search_persona_profile.md`
- 前序输出：无（循环首步）
