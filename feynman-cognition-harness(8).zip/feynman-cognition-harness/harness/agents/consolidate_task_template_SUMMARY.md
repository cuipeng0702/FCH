# Consolidate Task Template — Summary (v3.5)

## 一句话定义
将本轮迭代成果写入知识 lattice，执行节点创建、合并、依赖更新和可视化刷新，是认知循环的固化步骤。

## 输入（Input）
- 来源：`teach_output.json` + `audit_output.json` + `grow_output.json` + `verify_output.json` + `state.json`
- 格式：多个 JSON 文件路径，由 orchestrator 统一传入
- 关键字段：`grow_output.dependency_updates`（需写入 lattice）、`grow_output.teach_candidates`（新节点来源）、`audit_output.valid`（终止条件判断）

## 输出（Output）
- 路径：`{output_path}`（约定为 `results/iter{N}/consolidate_output.json`）
- 格式：JSON，含 `audit_status`、`verification_status`、`active_gaps`、`version_stack_entry`、`new_concepts_created`、`concepts_merged`、`graphify_export_status`、`termination_status`
- 验收标准：
  1. 文件存在且 JSON 有效
  2. `source_outputs` 正确引用 4 个输入文件路径
  3. `version_stack_entry` 已追加到 concept lattice（非仅输出文件）
  4. `termination_status ∈ {continue, yield, halt}`
  5. `new_concepts_created` 每条有 `concept_id`、`status`、`lattice_path`
  6. 合并操作 confidence ≥0.85，否则标记为 `rejected`

## 执行要点（SOP 速查）
1. 将 teach/audit/verify 状态摘要写入 lattice，不复制 D1-D4 内容（仅记录路径）
2. 执行 `dependency_updates`：双向写入关系，更新 `index.json` 的 `relation_count`
3. 新节点创建：初始化完整 lattice 结构，状态设为 `learning`，更新 `index.json`
4. 触发 `graphify` 可视化导出，失败不阻断主流程

## 常见失败模式
- 依赖关系写入后 `index.json` 未同步更新 → 主 agent 运行 lattice 完整性检查脚本
- 合并操作 confidence < 0.85 被执行 → 主 agent 拒绝合并并回滚 `.backup`
- 新节点与已有节点同名 → 主 agent 跳过创建并记录 `error="already_exists"`

## 关联文件
- 详细模板：`harness/agents/consolidate_task_template.md`
- 人格档案：`harness/agents/consolidate_persona_profile.md`
- 前序输出：`harness/agents/verify_output.json`
