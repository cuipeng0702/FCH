# Persona Task Template vs Profile 对比报告

> 审计时间: 2026-05-05
> 审计者: Fix-D (Persona 审计视角对比专家)
> 对比范围: 5 对 persona 文件（task template vs profile）

---

## Expert (边界审查官)

### 角色视角
- 原有：前沿科学家，对未知边界敏感，D4 穷尽性审查 → profile 保留：**是** ✅
- profile 中 "领域专长: 科学哲学、形式化方法边界分析、科研前沿趋势判断、反例构造" 与 template "domain expert, frontier research, open problems, historical debates" 一致
- profile 中 "认知风格: 演绎型 + 反证型。从第一性原理出发，用反例击碎过度推广" 与 template 核心原则 "D4 is the stress-test of D1" 一致

### Input 限制
- 原有：只读 D1/D4（不读 D2/D3） → profile 保留：**是** ✅
- profile 明确声明："禁止读取 D2 或 D3 内容"、"仅用 read 读取 D1 和 D4。绝不触碰 D2/D3。"

### 核心产出
- 原有：BDD 触发识别、D4 边界覆盖度评估 → profile 保留：**是** ✅
- profile 核心技能包含："D4 边界穷举性审查"、"BDD 触发条件识别（框架跳跃级问题检测）"
- 输出 schema 与 template 一致（boundary_analysis, missing_boundaries, growth_seed, frontier_connection, metadata）

### 新增内容合理性
- 8 要素结构与原有角色一致 ✅
- 新增的人格（边界审查官 / Boundary Inspector）冷酷、挑剔、零容忍，与前沿科学家视角一致 ✅

### 修正记录
- **修正**：将"禁用能力"中的"禁止调用搜索工具补充知识"和"禁止 spawn 子 agent"改为"能力边界（非禁用，按需可用）"
  - 原因：用户明确要求"其他不必禁用的能力能不禁用都不禁用"，纪律指的是职责边界而非能力/工具禁用
  - 保留硬性边界：禁止读取 D2/D3、禁止生成/修改 teach 内容
  - 新增弹性描述：搜索工具原则上不主动调用但按需可用；子 agent 按需可 spawn 协助审计子任务

---

## Student (类比追踪者)

### 角色视角
- 原有：中学生，只读 D1/D2，验证类比→步骤的自然生长 → profile 保留：**是** ✅
- profile 中 "经验水平: 中级（相当于优秀中学生 / 低年级本科生，懂逻辑和代数，未接触高等数学）" 与 template "middle school student, knows logic and algebra but not advanced math" 一致
- profile 中 "对'没有直觉根基的步骤'零容忍" 与 template "D2 is the operationalization of D1, not an independent procedure" 一致

### Input 限制
- 原有：只读 D1/D2（不读 D3/D4） → profile 保留：**是** ✅
- profile 明确声明："禁止读取 D3 或 D4 内容"、"仅用 read 读取 D1 和 D2。绝不触碰 D3/D4。"

### 核心产出
- 原有：Foreign Structure 检测、Growth Seed（if...then... 问题） → profile 保留：**是** ✅
- profile 核心技能包含："Foreign Structure 检测（D2 中引入 D1 从未提及的概念）"、"步骤删除测试"
- 输出 schema 与 template 一致（mapping, foreign_structures, growth_seed, metadata）

### 新增内容合理性
- 8 要素结构与原有角色一致 ✅
- 新增的人格（类比追踪者 / Analogy Tracker）聪明、好奇、术语警觉，与中学生视角一致 ✅

### 修正记录
- **修正**：将"禁用能力"中的"禁止调用搜索工具"和"禁止 spawn 子 agent"改为"能力边界（非禁用，按需可用）"
  - 保留硬性边界：禁止读取 D3/D4、禁止生成/修改 teach 内容
  - 新增弹性描述：搜索工具原则上不主动调用但概念理解困难时可用；子 agent 按需可 spawn

---

## Child (直觉锚定者)

### 角色视角
- 原有：8岁小孩，只读 D1，具象化思维，检测术语污染 → profile 保留：**是** ✅
- profile 中 "经验水平: 初级（相当于 8 岁儿童的认知水平：具象思维为主，未接触形式化教育）" 与 template "You are an 8-year-old" 一致
- profile 中 "所有判断基于'能不能在脑中画出画面'和'能不能用自己的话讲出来'" 与 template "Tactile/visual: Every noun is something you can picture or touch" 一致

### Input 限制
- 原有：只读 D1 → profile 保留：**是** ✅
- profile 明确声明："禁止读取 D2/D3/D4（只读 D1）"、"只读 D1。绝不读取 D2/D3/D4 的任何内容。"

### 核心产出
- 原有：具象化测试、好奇心方向判断 → profile 保留：**是** ✅
- profile 核心技能包含："术语污染检测（jargon detection）"、"具象/触觉名词扫描"、"好奇心方向判断：引发'what happens next?' vs 引发'why is that true?'"
- 输出 schema 与 template 一致（verdict.stable, jargon_detected, tactile_visual_nouns, growth_seed）

### 新增内容合理性
- 8 要素结构与原有角色一致 ✅
- 新增的人格（直觉锚定者 / Intuition Anchor）具象化、零术语容忍、画面感强，与 8 岁小孩视角一致 ✅

### 修正记录
- **修正**：将"禁用能力"中的"禁止调用搜索工具"和"禁止 spawn 子 agent"改为"能力边界（非禁用，按需可用）"
  - 保留硬性边界：禁止读取 D2/D3/D4、禁止任何逻辑推演或数学操作（8 岁小孩视角的核心约束）
  - 新增弹性描述：搜索工具原则上不主动调用但遇到不熟悉的日常概念时可用；子 agent 按需可 spawn

---

## Integrator (层间编织者)

### 角色视角
- 原有：系统思维者，读取全部 persona 输出，检测跨层张力 → profile 保留：**是** ✅
- profile 中 "系统思维、模式敏感、矛盾猎手、收敛导向" 与 template "The integrator is not a judge — it is a pattern matcher" 一致
- profile 中 "从多个局部视角中提取全局模式，关注'收敛点'和'发散点'" 与 template "detect: where do the 4 perspectives converge on the same problem? Where do they diverge?" 一致

### Input 限制
- 原有：读取全部 persona 输出 → profile 保留：**是** ✅
- profile 明确声明："read 必须读取全部 4 个 persona 输出（child, student, undergrad, expert）"

### 核心产出
- 原有：跨层张力检测、Grow Queue 生成、Growth Seed 去重 → profile 保留：**是** ✅
- profile 核心技能包含："跨层张力检测（D1↔D2↔D3↔D4 的矛盾识别）"、"Grow Queue 生成"、"Growth Seed 去重与 novelty 评分"
- 输出 schema 与 template 一致（persona_audit, grow_queue, bdd_triggers, growth_seeds, cross_layer_tensions, metadata）

### 新增内容合理性
- 8 要素结构与原有角色一致 ✅
- 新增的人格（层间编织者 / Layer Weaver）不偏不倚、矛盾猎手，与系统整合者视角一致 ✅

### 修正记录
- **修正**：将"禁用能力"中的"禁止调用搜索工具"和"禁止 spawn 子 agent"改为"能力边界（非禁用，按需可用）"
  - 保留硬性边界：禁止独立重新审计 D1-D4（不替代单个 persona）、禁止生成/修改 teach 内容
  - 新增弹性描述：搜索工具原则上不主动调用但需验证跨层映射知识不足时可用；子 agent 按需可 spawn

---

## Undergrad (形式化守门人)

### 角色视角
- 原有：本科生，只读 D1/D3，形式化精确性验证 → profile 保留：**是** ✅
- profile 中 "经验水平: 中级（相当于数学/CS 本科生，熟悉形式化定义、抽象代数、基础证明）" 与 template "You are a math/CS undergrad. You know formal definitions, proofs, and abstract algebra" 一致
- profile 中 "要求每个形式化元素都有直觉根基，每个直觉都有形式化投影" 与 template "D3 is the formal shadow of D1, not a standard textbook definition" 一致

### Input 限制
- 原有：只读 D1/D3（不读 D2/D4） → profile 保留：**是** ✅
- profile 明确声明："禁止读取 D2 或 D4 内容"、"仅用 read 读取 D1 和 D3。绝不触碰 D2/D4。"

### 核心产出
- 原有：D1↔D3 映射检查、符号语义锚定验证 → profile 保留：**是** ✅
- profile 核心技能包含："D1↔D3 语义锚定验证"、"Over-abstract 检测"、"Over-concrete 检测"
- 输出 schema 与 template 一致（mapping, deviations.over_abstract, deviations.over_concrete, growth_seed, metadata）

### 新增内容合理性
- 8 要素结构与原有角色一致 ✅
- 新增的人格（形式化守门人 / Formal Gatekeeper）精确、符号敏感、不耐烦模糊，与本科生视角一致 ✅

### 修正记录
- **修正**：将"禁用能力"中的"禁止调用搜索工具"和"禁止 spawn 子 agent"改为"能力边界（非禁用，按需可用）"
  - 保留硬性边界：禁止读取 D2/D4、禁止生成/修改 D3 形式化定义
  - 新增弹性描述：搜索工具原则上不主动调用但形式化框架背景知识不足时可用；子 agent 按需可 spawn

---

## 总体结论

| Persona | 角色视角保留 | Input 限制保留 | 核心产出保留 | 新增内容合理性 | 修正 |
|---------|-------------|---------------|-------------|---------------|------|
| Expert | ✅ | ✅ | ✅ | ✅ | 1处 |
| Student | ✅ | ✅ | ✅ | ✅ | 1处 |
| Child | ✅ | ✅ | ✅ | ✅ | 1处 |
| Integrator | ✅ | ✅ | ✅ | ✅ | 1处 |
| Undergrad | ✅ | ✅ | ✅ | ✅ | 1处 |

### 发现的问题类型

**统一问题（全部 5 个 persona 共享）**：

所有 profile 在"禁用能力"部分都包含了"禁止调用搜索工具"和"禁止 spawn 子 agent"。这与用户明确要求冲突：

> "其他不必禁用的能力，如 edit / sessions_spawn / message 等能不禁用都不禁用。我之前说的'纪律'指的是职责边界，而不是能力或工具禁用。"
> "每个 subagent 都应有明确权限按需再次 spawn subagent 协助他们处理任务"

**修正策略**：
- 保留**硬性 Input 读取限制**（如 Expert 不读 D2/D3、Child 只读 D1 等）——这是角色的核心审计视角边界，改动会破坏 persona 的纯粹性
- 将"禁止调用搜索工具"和"禁止 spawn 子 agent"从"禁用能力"移至"能力边界（非禁用，按需可用）"
- 为每个 persona 配置了与其审计视角一致的弹性描述（如 Expert "复杂边界审查需要补充前沿知识时可按需使用"，Child "遇到不熟悉的日常概念时可按需使用"）

**未发现问题**：
- 没有 persona 的角色视角被改没或弱化
- 没有引入与角色视角冲突的内容
- 输出 schema 与 template 完全一致
- SOP 流程与 template 的审计逻辑一致
- 交付目标的验收标准与 template 的 completion criteria 一致

---

*报告完成。5 个 persona 的核心特性全部保留，1 处统一修正已应用。*
