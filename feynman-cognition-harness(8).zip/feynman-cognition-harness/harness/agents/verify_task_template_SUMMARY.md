# Verify Task Template — Summary (v3.5)

## 一句话定义
对本轮认知成果执行三维验证（跨时一致性、独立可复现性、外部来源校验），输出结构化置信度评估。

## 输入（Input）
- 来源：`grow_output.json` + `teach_output.json` + `audit_output.json` + `state.json`
- 格式：JSON，含 `grow_output_path`、`teach_output_path`、`audit_output_path`、`state_path`、`concept`、`concept_id`、`iteration`
- 关键字段：`teach_output_path`（D1-D4 来源）、`previous_verification`（跨时对比基准）

## 输出（Output）
- 路径：`{output_path}`（约定为 `results/iter{N}/verify_output.json`）
- 格式：JSON，含 `cross_time_consistent`、`independent_reproduction`、`external_sources`、`confidence`、`verification_details`
- 验收标准：
  1. 文件存在且 JSON 有效
  2. `cross_time_consistent` 和 `independent_reproduction` 为布尔值
  3. `confidence` 含 `overall`、`d1`、`d2`、`d3`、`d4`，均为 [0.0, 1.0] 浮点数
  4. `confidence.overall` 与 d1-d4 平均值偏差 ≤0.05
  5. `verification_details` 中 `cross_time_notes`、`reproduction_notes`、`external_validation_notes` 均非空且 ≥20 词
  6. `metadata.sources_checked == len(external_sources)`

## 执行要点（SOP 速查）
1. 跨时一致性：对比历史 teach_output，允许精炼但不允许矛盾；D4 边界应扩展或保持一致
2. 独立复现：判断 D3 定义是否足够精确，使独立 agent 能从 D3 复现 D2 步骤
3. 外部校验：对 D3 高置信度声明和 D4 反例寻找外部权威来源； dissenting 来源需记录

## 常见失败模式
- `confidence.overall` 较上一轮下降 ≥0.2（confidence collapse）→ 主 agent 触发 Auto-Search（PRD §6.B）
- `overall < 0.90`（Ming Wu 阈值未达）→ 主 agent 记录拖分层，继续迭代或人工审查
- 外部来源为空但 D3 有高置信声明 → 主 agent 要求补充来源或降低置信度

## 关联文件
- 详细模板：`harness/agents/verify_task_template.md`
- 人格档案：`harness/agents/verify_persona_profile.md`
- 前序输出：`harness/agents/teach_output.json`、`harness/agents/grow_output.json`
