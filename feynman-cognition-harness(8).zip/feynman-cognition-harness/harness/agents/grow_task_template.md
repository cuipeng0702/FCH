---
tag: [RUNTIME]
load_when: "子Agent运行时模板"
---

# Grow Agent Task Template

## Objective
Analyze audit findings to identify knowledge gaps, classify them by layer (D1–D4), and generate a targeted learning strategy to close those gaps in the next iteration. This agent must think like a learning strategist, not just a bug reporter.

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "audit_output_path": "string (path to audit_output.json)",
  "teach_output_path": "string (path to teach_output.json)",
  "state_path": "string (path to state.json)",
  "concept": "string",
  "concept_id": "string",
  "iteration": 1,
  "previous_grow": {
    "iteration": 1,
    "gaps": [],
    "strategy": "string"
  }
}
```

Notes:
- Load `audit_output.json`, `teach_output.json`, and `state.json` from their respective paths.
- Also check `state.json` for `pending_cascade_gaps` — these are gaps detected by the cascade engine when upstream/downstream/indirect concepts were affected by changes in another concept. Process them alongside audit gaps.
- `previous_grow` may be `null` on first grow phase.

## Output

Write to: `{output_path}`

Format: JSON with schema (see references/design/PRD.md §7.3):
```json
{
  "iteration": 1,
  "timestamp": "ISO-8601 string",
  "gaps": [
    {
      "gap_id": "string",
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "external_knowledge_required": true,
      "query": "string (search query if external)",
      "search_summary": "string — 搜索结果摘要（如执行了搜索）",
      "resolved_by_new_node": "string|null — 若根因为概念缺失，填写 teach_candidates 中的 concept"
    }
  ],
  "strategy": "string (how to close gaps)",
  "teach_candidates": [
    {
      "concept": "string — 新节点名称",
      "reason": "string — 为什么需要教这个节点",
      "trigger_concept": "string — 哪个概念的 gap 触发了这个候选",
      "trigger_gap_id": "string",
      "relation_to_trigger": "depends_on | is_component_of | analogy_of | prerequisite_for",
      "requires_prerequisite": "bool — true if this candidate must wait for another candidate to complete first",
      "prerequisite_concept": "string|null — the concept_id that must be taught before this one",
      "search_results_summary": "string — 搜索关键发现摘要"
    }
  ],
  "intra_node_fixes": [
    {
      "gap_id": "string",
      "layer": "d1|d2|d3|d4",
      "fix_description": "string — 在现有节点内如何修复",
      "applicable_in_current_node": true
    }
  ],
  "dependency_updates": [
    {
      "source_concept_id": "string — 当前概念",
      "target_concept_id": "string — 候选概念",
      "relation_type": "depends_on | is_component_of | analogy_of | prerequisite_for",
      "confidence": "float 0.0-1.0",
      "bidirectional": "bool",
      "rationale": "string — 为什么建立这个关系"
    }
  ],
  "metadata": {
    "gap_count": 0,
    "external_knowledge_count": 0,
    "priority_layer": "d1|d2|d3|d4|null",
    "search_performed": true,
    "search_sources": ["kimi_search"],
    "teach_candidates_count": 0,
    "intra_node_fixes_count": 0,
    "dependency_updates_count": 0
  }
}
```

## Phase 0: Search (Precondition)

For every gap with `external_knowledge_required: true`:

### 0.1 Query Generation
Generate **3 queries per gap**:
- **Precise**: exact technical/concept name
- **Broad**: context and background
- **Academic**: formal definition or paper

### 0.2 Execute Search
Directly use:
- `kimi_search`
- `kimi_fetch`
- `agent-reach` (if configured)

### 0.3 Summarize
Write findings into `search_summary`:
- New dependency concept discovered?
- Root cause: missing concept or insufficient explanation?
- How do authoritative sources define the related concept?

---

## Phase 1: Gap Mapping & Classification

### Step 1: Map Audit Issues to Gaps
For each audit issue, determine:
- Is this a **knowledge gap** (missing understanding) or a **presentation gap** (understanding exists but poorly expressed)?
- Which D-layer is primarily affected?
- Can this gap be closed by rethinking the explanation, or does it require external knowledge?

### Step 1.5: Process Cascade Gaps (v3.5)
If `state.json` contains `pending_cascade_gaps`:

For each cascade gap:
- **Identify target concept**: Which concept needs updating?
- **Identify affected layers**: Which D-layers are impacted (from the gap's `affected_layers` field)?
- **Determine strategy**:
  - If `affected_layers` is explicit and the target concept already has a teach output → produce an `intra_node_fix` entry with `fix_description` specifying exactly which layers to update and why
  - If the target concept does not exist yet → produce a `teach_candidate` with `trigger_reason: "cascade_from_{source_concept}"`
  - If only a single layer has a small gap → add a regular gap entry in the `gaps` array, with `description` prefixed by `[CASCADE]`
- **Set priority**: Cascade gaps from depth=1 get priority 0.9, depth=2 get 0.7. Process them AFTER critical audit gaps but BEFORE moderate audit gaps.
- **Deduplication**: If a cascade gap targets the same concept+layer as an audit gap, merge them and note both sources in the description.

### Step 2: Classify Gaps by Type
| Type | Definition | Example |
|------|------------|---------|
| **Conceptual Gap** | Core understanding missing | D3 definition is circular or tautological |
| **Procedural Gap** | Know what, not how | D2 steps skip a non-trivial sub-procedure |
| **Boundary Gap** | Don't know where concept breaks | D4 lists only 2 genuine boundaries, rest are trivial |
| **Analogy Gap** | No good mapping to intuition | D1 analogy breaks under simple stress-test |
| **Confidence Gap** | Unsure about formal claim | D3 marks confidence `low` on a central definition |
| **Mapping Gap (NEW)** | Cross-layer mapping failure | D1↔D2 or D2↔D3 mapping incomplete per teach-agent mapping requirements |

### Mapping-Driven Gap Rules (REVISED — Structural Emergence)
| Rule | Detected Pattern | Gap Type | Auto-Fix Strategy |
|------|-----------------|----------|-------------------|
| 9 | orphan_procedure | unexecutable_intuition | add_execution_step |
| 10 | unmanipulated_formal | unmanipulated_formal | add_variable_step |
| 11 | definition_mismatch | definition_collision | disambiguate_term |
| 12 | analogy_collision | analogy_overload | diversify_analogy |
| 13 | boundary_violation | boundary_violation | guard_dependency |
| 14 | dependency_drift | dependency_drift | pin_dependency_version |

**Rule 9 — orphan_procedure**: A D1 analogy element has no corresponding D2 step. The intuition is unexecutable. **Fix**: Add an execution step to D2 that operationalizes the orphan element.

**Rule 10 — unmanipulated_formal**: A D3 variable/term is never manipulated in D2. The formalism is inert. **Fix**: Add a variable introduction/manipulation step to D2, or remove the variable from D3 if it is not essential.

**Rule 11 — definition_mismatch**: Two D3 definitions of the same term (from different iterations or sources) conflict. **Fix**: Disambiguate the term — split into term_A and term_B, or merge definitions with explicit conditions.

**Rule 12 — analogy_collision**: The same D1 analogy is overloaded across multiple concepts, causing cross-talk. **Fix**: Diversify the analogy — invent a new D1 analogy specific to this concept, or namespace analogies by concept_id.

**Rule 13 — boundary_violation**: A D4 boundary condition is violated by a cross-concept dependency (e.g., concept A assumes concept B holds, but B's D4 says it breaks under that condition). **Fix**: Guard the dependency — add a precondition check in D2, or refine D4 to exclude the dependency case.

**Rule 14 — dependency_drift**: A referenced concept's D3 definition has drifted across iterations, breaking the cross-concept mapping. **Fix**: Pin the dependency version — record the exact iteration/hash of the referenced concept's lattice that this concept depends on.
### Step 3: Prioritize Gaps
Priority order (override only with explicit reason):
1. **Critical audit issues first** (severity = critical)
2. **D3 gaps before D1 gaps** (formal understanding drives analogy quality)
3. **Conceptual gaps before presentation gaps**
4. **Gaps requiring external knowledge** (already handled in Phase 0)

### Step 4: Formulate Learning Strategy
The `strategy` field must be a concise, actionable plan. It should state:
- Which gap to tackle first and why
- Whether to adjust the generation strategy (e.g., "switch from analogy-first to formal-first for D3");
- Whether external knowledge acquisition is needed;
- What the target improvement looks like for the next iteration.

## Phase 2: Root Cause Analysis & Strategy Decision

Combine search results + lattice structure (dependency_graph in state.json) to analyze each gap's root cause.

### Root Cause Classification
| Type | Condition | Strategy |
|------|-----------|----------|
| **Missing concept** | Search confirms independent concept exists; current node cannot be self-consistent without it | `new_node_required` |
| **Insufficient explanation** | Existing concepts are adequate but current teach underutilizes them | `intra_node_fix` |
| **Framework boundary** | Root cause touches fundamental assumptions of current framework; may need reframing | `framework_boundary` (defer, do not process immediately) |
| **Cascade impact** | Gap originated from cascade engine detecting upstream/downstream/indirect impact from another concept's change | `cascade_update` — see below |

### Cascade Gap Strategy (v3.5)
For gaps marked `[CASCADE]` or from `pending_cascade_gaps`:
- **cascade_update mode**: When `affected_layers` is explicit and the concept exists, recommend `cascade_update` as the teach mode for the next iteration. The teach agent will only update the affected layers, copying others unchanged.
- **gap_driven mode**: When the cascade gap describes a specific missing element (e.g., "transformer's D2 no longer references the updated attention_mechanism definition"), recommend `gap_driven` mode targeting that specific layer.
- **fresh mode**: Only if the target concept does not exist at all in the lattice.
- **Minimization principle**: Never recommend teaching ALL layers of a cascade-affected concept. Always specify `affected_layers` in the `intra_node_fix` or `teach_candidate` entry.

### teach_candidates Rules
- Only produce when root cause is "missing concept"
- Each candidate must specify relation type to trigger concept
- **Dependency detection**: Analyze whether teach candidates have prerequisite relationships:
  - If candidate A's understanding is required before candidate B can be correctly taught → mark B as `requires_prerequisite: true` with `prerequisite_concept: A`
  - If candidate A is a foundational concept (e.g., "linear algebra basics") and candidate B builds on it (e.g., "eigenvalue decomposition") → B requires A
  - If two candidates are independent topics (e.g., "bubble sort" vs "quicksort") → both `requires_prerequisite: false`
  - `relation_to_trigger` values `depends_on` or `prerequisite_for` automatically imply `requires_prerequisite: true`
  - `relation_to_trigger` values `is_component_of` or `analogy_of` imply `requires_prerequisite: false` (parallelizable)
- Deduplicate if same candidate triggered by multiple gaps

### intra_node_fixes Rules
- Only produce when root cause is "insufficient explanation"
- fix_description must be specific enough for next Teach to execute directly
- No new concept introduction

### dependency_updates Rules
- For each teach_candidate, generate exactly one dependency_update entry
- source_concept_id: the current concept being analyzed (from input)
- target_concept_id: the candidate concept from teach_candidates
- relation_type: use the same value as teach_candidate.relation_to_trigger
- confidence: estimate based on search result clarity (0.5 = tentative, 0.8 = well-supported, 0.95 = authoritative source confirmed)
- bidirectional: true if the relationship is mutual (e.g., analogy_of, is_component_of where both concepts co-define each other); false for hierarchical dependencies (depends_on, prerequisite_for)
- rationale: explain why this relationship exists, citing specific evidence from search results or lattice structure

## Available Tools

- **kimi_search**: for researching gaps that require external knowledge — Grow 可以直接调用，无需 Orchestrator 中转
- **kimi_fetch**: for reading authoritative sources to verify whether a gap is real or a presentation issue — Grow 可以直接调用
- **agent-reach**: 扩展搜索渠道（如果已配置）— 用于 Twitter/X、Reddit、小红书、微信公众号等多平台补充搜索
- **LLM via localhost:18790**: for reasoning through gap classification and strategy generation

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. All required keys present — `iteration`, `timestamp`, `gaps`, `strategy`, `metadata`
4. Every gap has non-empty `gap_id`, `description`, `layer` ∈ {d1, d2, d3, d4}
5. Every gap has boolean `external_knowledge_required`
6. If `external_knowledge_required == true`, then `query` must be non-empty string
7. `strategy` is non-empty string (≥30 words)
8. Top-level `timestamp` key exists and is ISO-8601 formatted
9. `metadata.gap_count` equals `len(gaps)`
10. `metadata.external_knowledge_count` equals count of gaps with `external_knowledge_required: true`
11. `metadata.priority_layer` is one of {d1, d2, d3, d4, null}; null means no gaps or all layers equally critical
12. `metadata.dependency_updates_count` equals `len(dependency_updates)`; if `teach_candidates` is non-empty, `dependency_updates` must also be non-empty with matching concept pairs

## 元认知积累

本轮可用的历史经验（来自 FCMS 沉淀）：
{fcms_pitfalls}

注意：这些经验来自上一轮 FCMS 分析，已被压缩精炼。优先参考与当前步骤最相关的条目。

## Lattice Context 消费（LQL v3.5）

Orchestrator 已自动从 knowledge-lattice 中检索了相关知识，注入到本次输入的 `state.json` 中。请读取 `state.json` 中的 `lattice_context` 字段，并按以下规则消费：

### peer_gaps（相似已解决 gaps）
- 如果 `lattice_context.peer_gaps` 非空，说明 lattice 中其他概念曾遇到类似 gap 并已解决。
- **优先参考**这些 peer_gaps 的 `resolution` 字段：
  - 若 resolution 策略可直接应用于当前 gap，在 `intra_node_fixes` 中引用。
  - 若 resolution 策略需要调整，在 `strategy` 中说明调整思路并引用来源概念。
- 相似度评分 `similarity_score` ≥0.5 的 resolution 最具参考价值。

### proven_strategies（已验证收敛策略）
- 如果 `lattice_context.proven_strategies` 非空，说明本概念在之前的 grow 迭代中已积累过收敛策略。
- **优先沿用**这些策略：
  - 若策略有效（曾用于同 layer gap），在 `strategy` 中延续并优化。
  - 若策略无效或导致过拟合，在 `strategy` 中明确说明并调整方向。
- 策略摘要 ≤100 字，仅作参考，不要直接复制。

### 消费原则
- lattice_context 只保留最相关的 3 条，摘要已压缩。
- 若 lattice_context 为空，按正常 gap analysis 流程执行。
- 所有对 lattice_context 的引用必须在 `metadata` 或 `strategy` 中标注来源概念。

## Yoneda Context 消费（大局观 v3.5）

在规划修复策略前，请先考虑以下网络结构信息（来自 orchestrator 注入的 `lattice_context.yoneda`）：

1. **概念角色**：当前概念在网络中扮演 `{yoneda.role_profile.structural_role}` 角色，中心度 `{yoneda.role_profile.centrality}`。
   - 若角色为 "hub"（枢纽）：其 gaps 可能影响大量下游概念。在 `dependency_updates` 中检查是否需要级联更新下游节点。
   - 若角色为 "bridge"（桥梁）：gaps 可能反映跨社区理解的断裂。考虑是否需要引入跨社区类比来修复。
   - 若角色为 "core"（核心）：优先修复该节点，因为它是社区基础。若 core 概念存在 gap，可能导致整个社区级联缺陷。

2. **社区模式**：当前概念所属社区 `{yoneda.community_patterns[].description}` 共享以下特征。
   - 识别 gaps 时考虑社区层面的**结构性 gaps**：若社区内多个概念共享同一前置依赖且该依赖缺失，建议在 `teach_candidates` 中优先补充该前置概念。
   - 若社区模式为 `confidence_cluster` 且收敛率低，考虑是否需要社区层面的整体重构策略。

3. **跨社区抽象**：`{yoneda.cross_community_patterns[].abstraction}` 是跨社区的共享抽象。
   - Grow 时可利用跨社区桥梁发现新的学习方向：若当前概念与另一社区通过桥梁概念连接，检查桥梁概念是否完整 taught。
   - 若桥梁概念未 taught，在 `teach_candidates` 中建议优先补充。

4. **历史收敛模式**：该概念在 D{layer} 上通常需要 {yoneda.historical_convergence.typical_iterations} 轮收敛，策略为 "{yoneda.historical_convergence.convergence_strategy}"。
   - 在 `strategy` 中遵循此策略，避免已知陷阱：{yoneda.historical_convergence.common_pitfalls}。
   - 利用历史收敛模式预测修复时间：若 typical_iterations 为 3 且当前已迭代 2 次，下一 Teach 应接近收敛。

### 消费原则
- yoneda 字段是可选的；若 `lattice_context` 中不存在 `yoneda`，按正常 gap analysis 流程执行。
- 所有对 yoneda 的引用必须在 `metadata` 或 `strategy` 中标注来源概念。

## Orchestrator Integration

After writing output, announce completion with:
```
DONE: {output_path}
Concept: {concept_id}
Iteration: {iteration}
Gaps identified: {gap_count}
External knowledge needed: {external_knowledge_count}
Priority layer: {priority_layer}
Dependency updates: {dependency_updates_count}
```
