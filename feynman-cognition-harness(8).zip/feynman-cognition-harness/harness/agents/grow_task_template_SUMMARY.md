# Grow Task Template — Summary (v3.5)

## 一句话定义
将 audit 发现的问题转化为结构化知识缺口，规划修复策略并决定是否需要引入新认知节点。

## 输入（Input）
- 来源：`audit_output.json` + `teach_output.json` + `state.json`
- 格式：JSON，含 `audit_output_path`、`teach_output_path`、`state_path`、`concept`、`concept_id`、`iteration`
- 关键字段：`audit_output_path`（问题来源）、`teach_output_path`（映射结构来源）、`state_path`（依赖图来源）、`previous_grow`（历史修复策略参考）

## 输出（Output）
- 路径：`{output_path}`（约定为 `results/iter{N}/grow_output.json`）
- 格式：JSON，含 `gaps`、`strategy`、`teach_candidates`、`intra_node_fixes`、`dependency_updates`、`metadata`
- 验收标准：
  1. 文件存在且 JSON 有效
  2. `gaps` 每条有非空 `gap_id`、`description`、`layer ∈ {d1,d2,d3,d4}`、布尔 `external_knowledge_required`
  3. `external_knowledge_required == true` 时，`query` 非空
  4. `strategy` 非空且 ≥30 词
  5. `metadata.gap_count == len(gaps)`，`metadata.external_knowledge_count == true 的 gap 数量`
  6. `teach_candidates` 非空时，`dependency_updates` 必须非空且概念对匹配

## 执行要点（SOP 速查）
1. Phase 0：对需外部知识的 gap 执行 3 类搜索（精确/宽泛/学术），摘要写入 `search_summary`
2. Phase 1：将 audit issue 映射为知识缺口，分类为 conceptual/procedural/boundary/analogy/confidence/mapping gap
3. Phase 2：根因分析决定策略——缺失概念则生成 `teach_candidates`，解释不足则生成 `intra_node_fixes`

## 常见失败模式
- `teach_candidates` 与 `dependency_updates` 概念对不匹配 → 主 agent 强制补齐缺失的 dependency_update
- 根因误判（将缺失概念判为解释不足）→ 主 agent 检查搜索摘要是否支持新节点结论
- gap 重复出现 ≥3 次未被标记为 persistent → 主 agent 对比历史 consolidate 输出核查

## 关联文件
- 详细模板：`harness/agents/grow_task_template.md`
- 人格档案：`harness/agents/grow_persona_profile.md`
- 前序输出：`harness/agents/audit_output.json`
