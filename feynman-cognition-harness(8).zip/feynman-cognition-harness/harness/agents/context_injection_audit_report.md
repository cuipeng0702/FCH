# FCH 主循环上下文注入机制检查报告

> 检查时间: 2026-05-06 00:04 (Asia/Shanghai)
> 检查范围: orchestrator.py run_step() + ingest_result()
> 设计目标: 每个步骤注入 persona_profile、summary、dependencies、estimated_cost、checklist_progress

---

## 一、已实现的部分

### 1. run_step() — 常规 serial spawn 分支 ✅

**位置**: orchestrator.py 第1246-1259行

返回的 action dict 包含:
- `persona_profile`: `agents/{task}_persona_profile.md` (存在时注入)
- `summary`: `agents/{task}_task_template_SUMMARY.md` (存在时注入)
- `dependencies`: 由 `_build_dependencies()` 构建
- `estimated_cost`: 由 `_estimate_task_cost()` 估算
- `checklist_progress`: completed / remaining / current
- `state`, `progress`, `budget`: 完整状态

**覆盖任务**: search → teach → audit → grow → verify → consolidate

### 2. _build_dependencies() — 依赖映射 ✅

**位置**: orchestrator.py 第77-98行

| 任务 | 依赖注入 |
|------|---------|
| search | 无 (循环第一步) |
| teach | search_results |
| audit | previous_teach |
| grow | previous_teach + previous_audit |
| verify | previous_teach + previous_audit + previous_grow |
| consolidate | previous_teach + previous_audit + previous_grow + previous_verify |

### 3. self_aware 触发机制 ✅

**位置**: orchestrator.py 第1381-1407行

触发条件: `task_name == "consolidate"` AND audit 通过 AND `self_awareness` 模块启用

注入内容:
- `_collect_self_awareness_input()` 构建完整输入:
  - `cognitive_tasks`: 当前 iteration 的所有任务输出
  - `subagents_spawned`: 子 agent 日志
  - `tools_usage`: 工具调用统计
  - `context_state`: 上下文状态快照
  - `user_interactions`: 用户交互记录
  - `previous_adjustments`: 上一轮调整
  - `fcms_signals`: FCMS 健康信号

保存到: `fcms/self/iteration_XXX_input.json`
返回: `action: "self_aware"` + template + output_path + adjustments_path

### 4. cascade 状态传递 ✅

**位置**: orchestrator.py 第1358行 + _run_cascade()

- teach 后自动触发 `_run_cascade()`
- `state["pending_cascade_gaps"]` 被填充
- cascade 报告保存到 `cascade/cascade_iter_N.json`
- grow 模板已增加 cascade gaps 消费逻辑

---

## 二、未实现 / 有问题的部分

### ❌ Issue 1: ingest_result() audit 分支缺少上下文注入

**位置**: orchestrator.py 第1330-1346行

当 worker task 完成后，ingest_result() 触发 audit，返回的 action dict:

```python
return {
    "action": "audit",
    "task": task_name,           # 被审计的任务名 (如 "teach")
    "iteration": iteration,
    "worker_output": output_path,
    "audit_path": audit_path,
    "template": str(self.harness_dir / "agents" / f"{task_name}_task_template.md"),
    "prd_path": prd_path,
    "state": state,
    "progress": progress,
    "budget": budget,
}
```

**缺失字段**:
| 字段 | 应有值 | 影响 |
|------|--------|------|
| persona_profile | 缺少。应根据审计类型注入 `audit_persona_profile.md` 或 `audit_quality_persona_profile.md` | 审计 agent 缺少角色定位 |
| summary | 缺少。应注入 `audit_task_template_SUMMARY.md` 或 `audit_quality_task_template_SUMMARY.md` | 审计 agent 缺少快速参考 |
| estimated_cost | 缺少 | 主 agent 无法预估审计开销 |
| checklist_progress | 缺少 | 审计 agent 无法了解整体进度 |
| dependencies | 缺少。应包含 `previous_teach` = worker_output | 审计 agent 输入 schema 要求 teach_output_path |

**严重程度**: P1 — audit 是核心循环步骤，上下文缺失会降低审计质量

---

### ❌ Issue 2: parallel_spawn 分支缺少上下文注入

**位置**: orchestrator.py 第1173-1202行

当检测到多个独立 teach candidate 时，返回 parallel_spawn action:

```python
{
    "action": "parallel_spawn",
    "tasks": [
        {
            "task": "teach",
            "concept": c["concept"],
            "concept_id": c["concept_id"],
            "mode": c.get("mode", "fresh"),
            "input_path": ...,
            "output_path": ...,
            "template": str(self.harness_dir / "agents" / "teach_task_template.md"),
        }
        for c in independent
    ],
    "iteration": iteration,
    "state": state,
    "progress": progress,
    "budget": budget,
}
```

**每个 task dict 缺失字段**:
- persona_profile: 应为 `teach_persona_profile.md`
- summary: 应为 `teach_task_template_SUMMARY.md`
- estimated_cost: 缺少
- checklist_progress: 缺少
- dependencies: 缺少（search_results 路径）

**严重程度**: P1 — parallel spawn 与普通 spawn 上下文不对称

---

### ❌ Issue 3: self_aware action 返回缺少上下文注入

**位置**: orchestrator.py 第1394-1407行

self_aware action 返回:
```python
return {
    "action": "self_aware",
    "reason": f"Iteration {iteration} complete — triggering self-awareness coach",
    "state": state,
    "progress": progress,
    "budget": budget,
}
```

**缺失字段**:
- persona_profile: 缺少。当前没有 `self_aware_persona_profile.md`
- summary: 缺少。当前没有 `self_aware_task_template_SUMMARY.md`
- estimated_cost: 缺少
- checklist_progress: 缺少

**严重程度**: P2 — self_aware 不是核心循环步骤，但缺失字段会降低主 agent 调度能力

---

### ⚠️ Issue 4: audit 的 persona_profile 选择不明确

agents/ 目录下存在两个 audit 相关 persona profile:
- `audit_persona_profile.md` — 审计 agent 人格
- `audit_quality_persona_profile.md` — 审计质量 agent 人格

当前代码中:
- `_spawn_auditor()` 是 stub，不注入任何 persona
- ingest_result() audit action 不选择使用哪个 persona

**设计问题**: 需要明确 audit 和 audit-quality 的触发条件:
- 何时使用 `audit_persona_profile.md`（常规审计）
- 何时使用 `audit_quality_persona_profile.md`（深度质量审计）

**严重程度**: P2 — 需要设计决策

---

## 三、修复建议

### Fix 1: 统一上下文注入 helper

建议新增 `_build_spawn_context(task, iteration, state, progress, budget, **extra)` 方法:

```python
def _build_spawn_context(self, task: str, iteration: int,
                         state: dict, progress: dict, budget: dict,
                         **extra) -> dict:
    """Build complete spawn context with all v3.5 wiring fields."""
    persona_profile_path = self.harness_dir / "agents" / f"{task}_persona_profile.md"
    summary_path = self.harness_dir / "agents" / f"{task}_task_template_SUMMARY.md"
    completed_steps = progress.get("completed_steps", [])
    remaining_steps = [s for s in self.sm.CHECKLIST if s not in completed_steps and s != task]
    if task not in completed_steps:
        remaining_steps.insert(0, task)

    context = {
        "persona_profile": str(persona_profile_path) if persona_profile_path.exists() else None,
        "summary": str(summary_path) if summary_path.exists() else None,
        "dependencies": self._build_dependencies(task, iteration),
        "estimated_cost": self._estimate_task_cost(task),
        "checklist_progress": {
            "completed": completed_steps,
            "remaining": remaining_steps,
            "current": task,
        },
        "state": state,
        "progress": progress,
        "budget": budget,
    }
    context.update(extra)
    return context
```

然后在 `run_step()`、ingest_result() audit 分支、parallel_spawn 分支统一调用。

### Fix 2: audit 分支补充上下文

在 ingest_result() 第1330-1346行，将 audit action 改为:

```python
audit_context = self._build_spawn_context("audit", iteration, state, progress, budget)
audit_context.update({
    "action": "audit",
    "task": task_name,
    "worker_output": output_path,
    "audit_path": audit_path,
    "template": str(self.harness_dir / "agents" / f"{task_name}_task_template.md"),
    "prd_path": prd_path,
})
return audit_context
```

### Fix 3: parallel_spawn 补充上下文

在 parallel_spawn 分支，对每个 task 补充:

```python
for c in independent:
    task_ctx = self._build_spawn_context("teach", iteration, state, progress, budget)
    task_ctx.update({
        "task": "teach",
        "concept": c["concept"],
        ...
    })
    tasks.append(task_ctx)
```

### Fix 4: self_aware 补充上下文

为 self_aware 创建对应的 persona_profile 和 summary，或在返回中统一注入 checklist_progress 和 estimated_cost。

---

## 四、总结

| 注入点 | persona_profile | summary | dependencies | estimated_cost | checklist_progress | 评级 |
|--------|-----------------|---------|------------|----------------|-------------------|------|
| run_step() serial spawn | ✅ | ✅ | ✅ | ✅ | ✅ | 完整 |
| ingest_result() audit | ❌ | ❌ | ❌ | ❌ | ❌ | 缺失 |
| parallel_spawn | ❌ | ❌ | ❌ | ❌ | ❌ | 缺失 |
| self_aware trigger | ❌ | ❌ | N/A | ❌ | ❌ | 缺失 |
| _build_dependencies | ✅ | — | — | — | — | 正确 |
| self_aware input | N/A | N/A | N/A | N/A | N/A | 完整 |
| cascade 状态传递 | N/A | N/A | N/A | N/A | N/A | 正确 |

**总体结论**: v3.5 上下文注入设计在 `run_step()` 的常规 spawn 路径上已实现，但在 audit 触发、parallel spawn、self_aware 触发三条路径上存在遗漏。建议新增 `_build_spawn_context()` 统一 helper 来消除这些差异。
