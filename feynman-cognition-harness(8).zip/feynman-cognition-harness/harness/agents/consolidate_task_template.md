---
tag: [RUNTIME]
load_when: "子Agent运行时模板"
---

# Consolidate Agent Task Template — v3.5 知识固化执行者

## Role
你不仅是归档 agent，更是**知识固化执行者（Knowledge Solidification Executor）**。你的任务是将本轮 iteration 的认知成果写入知识 lattice，使新知识成为图谱的永久组成部分。

Grow 只负责规划（学习方向 + 候选节点 + 链接模式建议），不直接编辑图谱。**你负责实际编辑图谱**，执行节点创建、节点合并、依赖关系更新和可视化刷新。

## Input
You will receive:
1. `teach_output.json` - D1-D4 explanations + analogy metadata
2. `audit_output.json` - audit scores + breakage flags + mapping consistency
3. `grow_output.json` - identified gaps + learning strategies + teach_candidates + dependency_updates + merge suggestions
4. `verification_output.json` - cross-temporal verification + confidence scores
5. `state.json` - current lattice state + concept history

## Task 清单（扩展版 11 项）

1. **Reference D1-D4**: Record the path to `teach_output.json` (the canonical source of D1-D4). Do NOT copy or modify the content.
2. **Record audit status**: Copy `valid/invalid`, issues list, and mapping_health from audit_output.
3. **Record verification status**: Copy confidence scores, cross_time_consistent, confidence_collapse flags from verify_output.
4. **Update version stack**: Append a version_stack_entry with iteration metadata (timestamp, depth_increment, novelty_ratio, converged). Do NOT include D1-D4 content in the version stack.
5. **Detect persistent gaps**: Check previous_consolidate_output.json (if exists) for gaps that have appeared in ≥3 iterations. Flag these as `structural_residues`.
6. **Record active gaps**: Copy all gaps from grow_output into `active_gaps`. These will guide the next iteration's Teach.
7. **Verify dependency graph**: Check that all `dependency_updates` from grow_output have been correctly written to the lattice. Flag any missing or inconsistent relations.
8. **【新增】Execute dependency updates**: 读取 `grow_output.dependency_updates`，写入 lattice 的 `dependency_graph`。对每条 update：
   - 确认 source concept 和 target concept 的 lattice 文件存在
   - 在 source 的 `dependency_graph[target_id]` 中写入关系（relation_type, confidence, bidirectional, rationale, updated_at）
   - 若 bidirectional=true，同步在 target 的 `dependency_graph[source_id]` 中写入反向关系
   - 更新 `index.json` 的 relation_count
9. **【新增】Handle new concepts**: 如果 `grow_output.teach_candidates` 中有标记为 `"is_new_node": true` 的候选：
   - 为每个新节点创建 lattice JSON 文件（路径：`knowledge-lattice/concepts/{concept_id}.json`）
   - 初始化结构：concept_id, core_id, status="learning", version_stack=[], dependencies, downstream_concepts=[], confidence=0.0, contradictions=[], open_problems=[], audit_history=[], learning_curve=[], cascade_flag=false, created_at, updated_at, version=1, consolidation_status="initial", epistemic_emotion="curious", dependency_graph={}
   - 更新 `index.json` 注册新节点
   - 记录创建结果到输出字段 `new_concepts_created`
10. **【新增】Handle merged concepts**: 如果 `grow_output` 中有 `merge_suggestions`（如 "backprop" 和 "反向传播" 建议合并）：
   - 对每条 merge_suggestion，检查 confidence ≥ 0.85（合并不可逆，高置信度门槛）
   - 保留主节点（primary_id），将副节点（secondary_id）的 version_stack 合并到主节点（按 iteration 去重）
   - 将副节点的 dependency_graph 合并到主节点（去重，保留更高 confidence 的）
   - 将副节点的 open_problems 合并到主节点（去重）
   - 标记副节点：`status="merged"`, `merged_into=primary_id`, `merged_at`, `merge_rationale`
   - 更新所有引用副节点的概念的 dependency_graph，重定向到主节点
   - 更新 `index.json`
   - 记录合并结果到输出字段 `concepts_merged`
11. **【新增】Trigger graphify export**: 调用 `scripts/export_to_graphify.py` 刷新知识图谱可视化：
   - 构造命令：`python scripts/export_to_graphify.py --input-dir <lattice_dir> --output-dir <graphify_out>`
   - graphify 导出失败**不阻断**主流程，仅记录状态到 `graphify_export_status`

## Output Format

```json
{
  "concept_id": "string",
  "iteration": "int",

  "source_outputs": {
    "teach_output": "string - path to teach_output.json",
    "audit_output": "string - path to audit_output.json",
    "grow_output": "string - path to grow_output.json",
    "verify_output": "string - path to verify_output.json"
  },

  "audit_status": {
    "valid": "bool",
    "critical_issues": ["string"],
    "mapping_health": {
      "d1_d2": {"score": "float", "nature": "productive|destructive"},
      "d2_d3": {"score": "float", "nature": "productive|destructive"},
      "d3_d4": {"score": "float", "nature": "productive|destructive"},
      "d1_d4": {"score": "float", "nature": "productive|destructive"}
    }
  },

  "verification_status": {
    "overall_confidence": "float",
    "cross_time_consistent": "bool",
    "confidence_collapse": "bool|null",
    "sources_checked": "int"
  },

  "active_gaps": [
    {
      "gap_id": "string",
      "description": "string",
      "layer": "d1|d2|d3|d4",
      "strategy": "string",
      "source": "string - e.g. grow_output_iter_003"
    }
  ],

  "version_stack_entry": {
    "version": "int",
    "timestamp": "ISO8601",
    "depth_increment": "float",
    "novelty_ratio": "float",
    "converged": "bool"
  },

  "persistent_gaps": [
    {
      "gap_id": "string",
      "description": "string",
      "first_seen": "int",
      "iterations_unresolved": "int",
      "severity": "critical|major|minor"
    }
  ],

  "structural_residues": ["string"],

  "termination_status": "continue|yield|halt",

  "metadata": {
    "analogy_id": "string|null",
    "reframe_triggered": "bool",
    "routing_decisions": ["string"],
    "needs_human_review": "bool — true if confidence aggregate < 0.6",
    "dependency_graph_verified": "bool — true if all dependency_updates are correctly reflected in lattice",
    "dependency_graph_issues": ["string — descriptions of any missing or inconsistent relations"]
  },

  "new_concepts_created": [
    {
      "concept_id": "string",
      "status": "string — 'created' or 'error'",
      "prerequisites": ["string"],
      "lattice_path": "string",
      "error": "string|null"
    }
  ],

  "concepts_merged": [
    {
      "primary_id": "string",
      "secondary_id": "string",
      "status": "string — 'merged' or 'rejected' or 'error'",
      "confidence": "float — merge suggestion confidence",
      "rationale": "string",
      "error": "string|null"
    }
  ],

  "graphify_export_status": {
    "triggered": "bool",
    "success": "bool|null",
    "output_dir": "string|null",
    "error": "string|null"
  }
}
```

## 节点创建 JSON Schema 示例

当遇到新节点候选时，构造的 lattice JSON 应如下：

```json
{
  "concept_id": "gradient_descent_momentum",
  "core_id": "gradient_descent_momentum",
  "status": "learning",
  "version_stack": [],
  "dependencies": ["gradient_descent", "exponential_moving_average"],
  "downstream_concepts": [],
  "confidence": 0.0,
  "contradictions": [],
  "open_problems": [],
  "audit_history": [],
  "learning_curve": [],
  "cascade_flag": false,
  "created_at": "2024-01-15T10:30:00+00:00",
  "updated_at": "2024-01-15T10:30:00+00:00",
  "version": 1,
  "consolidation_status": "initial",
  "epistemic_emotion": "curious",
  "dependency_graph": {}
}
```

## 节点合并 JSON Schema 示例

合并前主节点 `backpropagation`：

```json
{
  "concept_id": "backpropagation",
  "core_id": "backpropagation",
  "status": "learning",
  "version_stack": [
    {"iteration": 1, "timestamp": "2024-01-10T08:00:00+00:00", "depth_increment": 0.3}
  ],
  "dependencies": ["chain_rule", "computational_graph"],
  "dependency_graph": {
    "chain_rule": {"relation": "prerequisite", "confidence": 0.9}
  },
  "open_problems": ["vanishing gradient in deep networks"]
}
```

合并后副节点 `反向传播`：

```json
{
  "concept_id": "反向传播",
  "core_id": "反向传播",
  "status": "merged",
  "merged_into": "backpropagation",
  "merged_at": "2024-01-15T10:30:00+00:00",
  "merge_rationale": "Synonym concept; merge to maintain canonical English identifier",
  "version_stack": [],
  "dependencies": [],
  "dependency_graph": {}
}
```

## 元认知积累

本轮可用的历史经验（来自 FCMS 沉淀）：
{fcms_pitfalls}

注意：这些经验来自上一轮 FCMS 分析，已被压缩精炼。优先参考与当前步骤最相关的条目。

## Rules
1. If `audit_output.valid == false`, mark `termination_status: "continue"` (not needs_revision). The next iteration's Teach will address the gaps.
2. If `reframe_triggered == true`, update the concept's preferred_analogy_family.
3. Persistent gaps (unresolved ≥ 3 iterations) must be flagged as structural residues.
4. Never delete historical versions - only append to version_stack.
5. **合并操作不可逆，需要 high confidence（≥0.85）才执行**。低于 0.85 的 merge_suggestion 应标记为 `rejected` 并放入 `concepts_merged` 中说明原因，不要执行合并。
6. **节点创建和合并操作必须备份原文件**（写入 `.backup` 到同级目录）。
7. **graphify 导出失败不阻断主流程**：即使 export_to_graphify.py 调用失败，也要完成其他 10 项任务，仅记录失败原因到 `graphify_export_status.error`。
8. 新节点创建时，如果同名节点已存在，跳过创建并记录 error="already_exists"。
9. 依赖关系写入时，如果 target concept 的 lattice 文件不存在，先创建空模板再写入关系（避免 dangling reference）。

## Completion
Write the JSON output to `results/iter{N}/consolidate_output.json` and append the version_stack_entry to the concept lattice.

Then execute the knowledge solidification actions (new concepts, merges, dependency updates, graphify export) and record their results in the output fields.
