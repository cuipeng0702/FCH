# Audit Task Template — Summary (v3.5)

## 一句话定义
以对抗性视角审计 D1-D4 的内部一致性、PRD 合规性和知识缺口，是认知循环的质量 gate。

## 输入（Input）
- 来源：`teach_output.json`（路径由 `teach_output_path` 指定）
- 格式：JSON，含 `concept`、`concept_id`、`iteration`、`teach_output_path`、`persona_audit_path`（可选）
- 关键字段：`teach_output_path`（必须加载 teach JSON）、`previous_audit`（迭代稳定性判断）

## 输出（Output）
- 路径：`{output_path}`（约定为 `results/iter{N}/audit_output.json`）
- 格式：JSON，含 `valid`、`issues`、`summary`、`metadata`
- 验收标准：
  1. 文件存在且 JSON 有效
  2. `valid` 为布尔值
  3. `valid == true` 时，`issues` 仅含 `minor` 级别
  4. `valid == false` 时，`issues` 至少含一条 `major` 或 `critical`
  5. 每条 issue 有 `layer ∈ {d1,d2,d3,d4}`、`severity ∈ {minor,major,critical}`、非空 `description`
  6. `metadata.issues_by_layer` 计数之和等于 `len(issues)`
  7. `summary` 非空且 ≥20 词

## 执行要点（SOP 速查）
1. 逐项检查 D1-D4 PRD 硬性要求：D1 ≤150 词、D2 步骤数 3-10、D4 ≥3 边界
2. 执行跨层一致性检查：D1↔D3 是否矛盾、D2 是否可由 D3 推导、D4 是否推翻 D1-D3 声明
3. 若 iteration ≥3 且 `valid` 反复抖动，在 metadata 中标注 `audit_inconsistency`

## 常见失败模式
- `teach_output.json` 缺失或不可读 → 主 agent 直接标记 `valid: false` 并 spawn 修复
- audit 过于宽松，major 问题漏判 → 主 agent 对比 persona audit 结果交叉验证
- iteration ≥3 仍反复无效 → 主 agent 触发 `audit_inconsistency` 人工审查

## 关联文件
- 详细模板：`harness/agents/audit_task_template.md`
- 人格档案：`harness/agents/audit_persona_profile.md`
- 前序输出：`harness/agents/teach_output.json`
