---
tag: [RUNTIME]
load_when: "子Agent运行时模板"
---

# Audit Agent Task Template

## Objective
Independently audit D1–D4 explanations for internal consistency, coverage against PRD §3 requirements, and identification of knowledge gaps. This agent must be adversarial: assume the explanations are flawed until proven otherwise.

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "teach_output_path": "string (path to teach_output.json)",
  "persona_audit_path": "string (optional — path to persona_integrator_output.json)",
  "concept": "string",
  "concept_id": "string",
  "iteration": 1,
  "previous_audit": {
    "iteration": 1,
    "valid": true,
    "issues": []
  }
}
```

Notes:
- Load the actual `teach_output.json` from `teach_output_path` to perform the audit.
- If `persona_audit_path` exists, load it and incorporate persona audit findings. Do NOT repeat issues already flagged by personas unless their conclusions are incorrect.
- `previous_audit` may be `null` on first audit.

## Output

Write to: `{output_path}`

Format: JSON with schema (see references/design/PRD.md §7.3):
```json
{
  "concept": "string",
  "iteration": 1,
  "timestamp": "ISO-8601 string",
  "audit_version": "v3.5.0",
  "depth_checks": {
    "d1": {
      "exists": true,
      "has_analogy": true,
      "analogy_quality": 0.85,
      "issues": ["string — specific issues found"]
    },
    "d2": {
      "exists": true,
      "has_steps": true,
      "step_count": 3,
      "has_success_criteria": true,
      "issues": ["string"]
    },
    "d3": {
      "exists": true,
      "has_definitions": true,
      "formal_rigor": 0.70,
      "issues": ["string"]
    },
    "d4": {
      "exists": true,
      "boundary_count": 3,
      "counter_example_count": 1,
      "issues": ["string"]
    }
  },
  "cross_depth_audits": [
    {
      "from": "string",
      "to": "string",
      "valid": true,
      "issue": "string — if invalid, explain why"
    }
  ],
  "contradictions": [
    {
      "severity": "minor|moderate|critical",
      "between": ["string — which depths contradict"],
      "description": "string — the contradiction"
    }
  ],
  "pseudo_mappings": [
    {
      "mapping": "string — the mapping text",
      "reason": "string — why it is pseudo"
    }
  ],
  "gap_assessment": {
    "gaps_count": 0,
    "honest": true,
    "critical_gaps": ["string"],
    "suggested_new_gaps": []
  },
  "confidence_assessment": {
    "reported": 0.85,
    "estimated": 0.75,
    "variance": 0.10,
    "calibrated": true
  },
  "pass": true,
  "pass_threshold": 0.80,
  "recommendation": "PASS|NEEDS_REVISION|REJECT|ESCALATE",
  "revision_notes": "string — specific instructions for teach agent if revision needed"
}
```

## Adaptive Threshold Context (v3.5)

The current adaptive threshold for aggregate audit score is: **{{ADAPTIVE_THRESHOLD}}**.

- Confidence interval: [{{CI_LOW}}, {{CI_HIGH}}]
- Sample size: {{SAMPLE_SIZE}}
- If SAMPLE_SIZE < 5, this is a cold-start default. Use judgment; do not treat the threshold as statistically validated yet.

## Audit Checklist (PRD §3 + §4 Cross-Reference)

### D1 Audit Items
- [ ] Is there exactly one vivid analogy? (not multiple mixed analogies)
- [ ] Is there zero jargon? (no technical terms without immediate plain-English translation)
- [ ] Are all nouns tactile or visual? (can an 8-year-old picture it?)
- [ ] Is length appropriate? (no hard word limit — quality over quantity)
- [ ] Does the analogy actually map to the concept structure, or is it only superficially similar?
- [ ] **(v3.5 conditional)** If `analogy_matrix_path` was provided: Was analogy selected from the matrix? Does `analogy_id` match `learner_profile.domain_background`?
- [ ] **(v3.5 conditional)** If cross-domain analogy used: Is migration_score ≥ 0.65? Are breakage_indicators checked and documented?
- [ ] **(v3.5 conditional)** If `reframe_triggered == true`: Does the new analogy avoid the `prior_breakage_reason`? Is `prior_analogy_id` excluded from reuse?

### D2 Audit Items
- [ ] Are there ≥3 and ≤10 numbered steps?
- [ ] Is each step executable by a human without external clarification?
- [ ] Is there a success criteria sentence at the end?
- [ ] Are steps ordered logically (no step depends on a later step)?
- [ ] Do the steps actually demonstrate/apply the concept (not generic procedure)?

### D3 Audit Items
- [ ] Does it cite domain-standard terminology?
- [ ] If mathematical: is there a core equation or formal statement?
- [ ] If non-mathematical: is there a definitional sentence + boundary conditions?
- [ ] Is every formal claim marked with confidence (high/medium/low)?
- [ ] Is the definition precise enough to distinguish the concept from near-neighbors?

### D4 Audit Items
- [ ] Are there ≥3 boundary conditions?
- [ ] Does each boundary have a concrete counter-example?
- [ ] Does each boundary explain the failure mechanism (why it breaks, not just that it breaks)?
- [ ] Are the counter-examples genuinely outside the concept's scope (not edge cases within scope)?

### Cross-Layer Consistency Audit Items
- [ ] Does D1 analogy contradict D3 formal definition?
- [ ] Does D2 procedure align with D3 definition?
- [ ] Do D4 boundaries invalidate any claim in D1–D3?
- [ ] If D3 marks a claim as `low` confidence, is that claim avoided or qualified in D1/D2?

## Available Tools

- **kimi_search**: for cross-checking terminology or verifying definitions against external sources
- **kimi_fetch**: for reading authoritative pages to validate formal claims
- **LLM via localhost:18790**: for reasoning through consistency checks

## Severity Definitions

| Severity | Definition | Action Required |
|----------|------------|-----------------|
| **critical** | Violates a hard PRD requirement (e.g., D1 missing analogy, D2 <3 steps, D4 <3 boundaries). Output is invalid. | Orchestrator must trigger fix or reject |
| **major** | Significant quality flaw that undermines understanding (e.g., analogy doesn't map, procedure is ambiguous, counter-example is inside scope). | Orchestrator should trigger fix |
| **minor** | Cosmetic or clarity issue (e.g., typo, wording could be sharper, confidence label missing on one sub-claim). | Orchestrator may accept with note |

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. All required keys present — `concept`, `iteration`, `timestamp`, `depth_checks`, `pass`, `recommendation`
4. Top-level `timestamp` key exists and is ISO-8601 formatted
5. `pass` is boolean
6. `depth_checks` has keys `d1`, `d2`, `d3`, `d4`; each has `exists` (boolean) and `issues` (list)
7. `recommendation` ∈ {PASS, NEEDS_REVISION, REJECT, ESCALATE}
8. If `pass == true` AND `depth_checks` all exist with empty issues arrays → recommendation must be PASS
9. If `pass == false` AND any depth_check has non-empty issues → recommendation must be NEEDS_REVISION or REJECT
10. `confidence_assessment.reported` and `confidence_assessment.estimated` are floats 0.0-1.0
11. `revision_notes` is non-empty string when recommendation == NEEDS_REVISION or REJECT

## Output Validation Rules (v3.5)

**MUST enforce these machine-verifiable constraints before writing output:**

| Check | Rule | Fail Action |
|-------|------|-------------|
| A | `pass` is boolean | If missing/invalid → set `pass: false`, add critical issue to depth_checks.d1.issues |
| B | `depth_checks` has d1-d4 keys | If missing → construct from teach output, add note to revision_notes |
| C | Every depth_check has `exists` (bool) and `issues` (list) | Remove invalid depth_checks, reconstruct from teach output |
| D | `recommendation` ∈ {PASS, NEEDS_REVISION, REJECT, ESCALATE} | If invalid → set NEEDS_REVISION |
| E | `revision_notes` ≥ 20 words when recommendation != PASS | If shorter → expand with specific depth-level instructions |

**Audit3+ Stability Note**: If this is iteration ≥3 and you detect `pass` toggling between true/false with same underlying content, flag `audit_inconsistency` in gap_assessment and recommend manual review.

## Failure Protocol

If the input `teach_output.json` is missing or unreadable:
1. Write output with `valid: false`
2. Add one critical issue: `{"layer": "d1", "severity": "critical", "description": "Input file missing or unreadable at {teach_output_path}"}`
3. Set `summary` to explain the file access failure

## Orchestrator Integration

After writing output, announce completion with:
```
DONE: {output_path}
Concept: {concept_id}
Iteration: {iteration}
Audit valid: {true|false}
Issues: {critical_count} critical, {major_count} major, {minor_count} minor
```
