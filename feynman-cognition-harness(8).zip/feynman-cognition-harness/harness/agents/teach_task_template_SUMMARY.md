# Teach Task Template — Summary (v3.5)

## 一句话定义
将搜索结果转化为 D1-D4 认知分解（直觉类比→操作步骤→形式定义→边界映射），是认知循环的核心生成步骤。

## 输入（Input）
- 来源：`search_results.json`（路径由 orchestrator 传入 `{input_path}`）
- 格式：JSON，含 `concept`、`concept_id`、`iteration`、`strategy`、`search_results`、`teach_mode`、`cascade_context`/`previous_gaps`（可选）
- 关键字段：`search_results`（事实基础）、`teach_mode`（fresh/cascade_update/gap_driven）、`previous_explanations`（迭代优化依据）

## 输出（Output）
- 路径：`{output_path}`（约定为 `results/iter{N}/teach_output.json`）
- 格式：JSON，含 `d1`、`d2`、`d3`、`d4`、`dependency_chain`、`bridge_concepts`、`metadata`
- 验收标准：
  1. 文件存在且 JSON 有效
  2. `d1` 非空字符串且 ≥20 词，为一个生动类比
  3. `d2` 为数组，长度 ≥3 且 ≤10，每步可独立执行
  4. `d3` 含非空 `definition`；数学概念必须含 `notation`
  5. `d4` 含 `boundaries` 数组长度 ≥3，每条有 `condition`、`counter_example`、`failure_mechanism`
  6. `metadata.confidence_estimate ∈ [0.0, 1.0]`

## 执行要点（SOP 速查）
1. 根据 `teach_mode` 选择生成策略：fresh 从零生成，cascade_update 只改 affected_layers，gap_driven 只修复指定 gap 层
2. D1 必须使用类比，所有名词具象可视觉化；D2 步骤末端带成功标准
3. 执行跨层映射自检：D1↔D2、D2↔D3 元素必须一一对应，无 UNMAPPED/UNMANIPULATED

## 常见失败模式
- D1 无类比或混入术语 → 主 agent 触发 reframe，要求更换 analogy
- D4 边界不足 3 条或 counter-example 在范围内 → 主 agent 要求补充或标记 audit 失败
- 跨层映射存在 UNMAPPED → 主 agent 将 gap 传入 grow agent 分析

## 关联文件
- 详细模板：`harness/agents/teach_task_template.md`
- 人格档案：`harness/agents/teach_persona_profile.md`
- 前序输出：`harness/agents/search_results.json`
