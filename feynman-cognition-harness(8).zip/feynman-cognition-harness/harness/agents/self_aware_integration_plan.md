# Self-Aware（明镜）接入方案 v1.0

> FCH v3.5 元认知体系 | 明镜与主循环的集成设计
> 基于：`self_aware_agent_template.md` v1.0 + `self_aware_profile_v2.md` v2.0
> 作者：FCH Self-Aware Integration Designer
> 日期：2026-05-05

---

## 1. 触发时机设计

### 1.1 触发点：每个 iteration 结束后（consolidate audit 通过后）

明镜不是每个 task 结束后触发，而是在**一个完整 cognitive cycle（search → teach → audit → grow → verify → consolidate）全部完成、且 consolidate 的 audit 通过之后**触发。

原因：
- 明镜审计的是一个完整 iteration 的执行全貌，单 task 的审计由 audit agent 完成
- 过早触发会导致数据不完整（grow/verify/consolidate 尚未执行）
- 与 FCMS 的 `_run_fcms_check` 触发点保持一致，便于数据聚合

### 1.2 代码层面：orchestrator.py 的 `ingest_result()` 函数

在 `ingest_result()` 中，当 `task_name == "consolidate"` 且 `audit_action == "continue"` 之后、返回 `"action": "continue"` 之前，插入明镜触发逻辑：

```python
def ingest_result(self, task_name: str, iteration: int, ...):
    # ... existing code ...
    
    if audit_action == "continue":
        # Mark consolidate done
        progress = self.sm.mark_task_done(progress, task_name)
        
        # === v3.5: SELF-AWARENESS trigger ===
        if self._module_enabled("self_awareness"):
            self._run_self_awareness(state, iteration, progress, budget)
        # =====================================
        
        self._save_all(state, progress, budget)
        # ... rest of convergence/termination checks ...
```

### 1.3 触发条件（config.yaml 驱动）

```yaml
# config.yaml
modules:
  self_awareness:
    enabled: true
    trigger_after_each_iteration: true   # 当前配置
    auto_apply_safe_adjustments: true
    report_to_user: true
    max_report_lines: 8
```

**条件矩阵：**

| 条件 | 值 | 说明 |
|------|-----|------|
| `self_awareness.enabled` | `true` | 模块总开关 |
| `trigger_after_each_iteration` | `true` | 每 iteration 结束后触发 |
| 前置条件 | consolidate audit PASS | 必须完成一个完整 cycle |
| 前置条件 | 非 parallel teach 模式 | parallel teach 的统一 audit 后触发 |
| 跳过条件 | `state["_self_aware_skipped"]` | 手动标记跳过（调试用） |

### 1.4 与 dream/cron 的区分

| 机制 | 触发时机 | 职责 | 频率 |
|------|---------|------|------|
| 明镜 (self_aware) | 每个 iteration 结束后 | 执行审计、调参 | 高（每 cycle） |
| FCMS L1-L4 | 每个 task 结束后 | 认知健康监控 | 更高（每 task） |
| DREAM | 每天凌晨 2:00 | 全局整合、长期沉淀 | 低（每天一次） |

---

## 2. 输入数据设计

### 2.1 输入文件路径

```
{harness_dir}/fcms/self/iteration_{iteration:03d}_input.json
```

### 2.2 输入 JSON Schema

```json
{
  "iteration": 3,
  "timestamp": "2026-05-05T14:30:00+08:00",
  "session_id": "5900a4e6-f76a-463d-8f00-b7f3f978bb4c",
  
  "cognitive_tasks": [
    {
      "task_name": "search",
      "duration_sec": 45,
      "tools_used": ["kimi_search", "agent_browser"],
      "output_quality": "sufficient|insufficient|excessive",
      "anomalies": []
    },
    {
      "task_name": "teach",
      "duration_sec": 120,
      "tools_used": ["write", "read"],
      "output_quality": "sufficient",
      "anomalies": []
    },
    {
      "task_name": "audit",
      "duration_sec": 30,
      "tools_used": ["read", "write"],
      "output_quality": "sufficient",
      "anomalies": []
    },
    {
      "task_name": "grow",
      "duration_sec": 60,
      "tools_used": ["read", "write", "exec"],
      "output_quality": "sufficient",
      "anomalies": ["gap_count_high"]
    },
    {
      "task_name": "verify",
      "duration_sec": 25,
      "tools_used": ["read", "write"],
      "output_quality": "sufficient",
      "anomalies": []
    },
    {
      "task_name": "consolidate",
      "duration_sec": 40,
      "tools_used": ["read", "write"],
      "output_quality": "sufficient",
      "anomalies": []
    }
  ],
  
  "subagents_spawned": [
    {
      "agent_id": "sub-teach",
      "task": "teach_task_template.md execution",
      "duration_min": 2.0,
      "success": true,
      "context_overlap_estimate": 0.10,
      "output_path": "/path/to/teach_output.json"
    },
    {
      "agent_id": "sub-audit",
      "task": "audit_task_template.md execution",
      "duration_min": 0.5,
      "success": true,
      "context_overlap_estimate": 0.05,
      "output_path": "/path/to/audit_output.json"
    }
  ],
  
  "tools_usage": [
    {
      "tool_name": "kimi_search",
      "call_count": 3,
      "success_rate": 1.0,
      "avg_latency_ms": 3000,
      "redundant_calls": 0
    },
    {
      "tool_name": "write",
      "call_count": 6,
      "success_rate": 1.0,
      "avg_latency_ms": 500,
      "redundant_calls": 0
    },
    {
      "tool_name": "read",
      "call_count": 8,
      "success_rate": 1.0,
      "avg_latency_ms": 200,
      "redundant_calls": 1
    }
  ],
  
  "context_state": {
    "total_tokens": 45000,
    "critical_info_retention": 0.85,
    "redundancy_ratio": 0.25,
    "user_corrections_this_iter": 1,
    "user_corrections_total": 3,
    "pending_gaps_count": 2,
    "convergence_score": 0.72
  },
  
  "user_interactions": [
    {
      "type": "correction|confirmation|new_requirement|silence",
      "content": "...",
      "timestamp": "..."
    }
  ],
  
  "previous_adjustments": {
    "from_iteration": 2,
    "adjustments_applied": [
      {"target": "max_fix_attempts", "old": 3, "new": 5, "reason": "修复成功率低"}
    ],
    "effectiveness": 0.60
  },
  
  "fcms_signals": {
    "health_score": 0.78,
    "alerts": [],
    "cognitive_patterns": {}
  }
}
```

### 2.3 数据来源与收集方式

| 字段 | 来源 | 收集方式 |
|------|------|---------|
| `iteration` | `progress.json` | `self.sm.load_progress()` |
| `session_id` | `state.json` | `state.get("session_id")` |
| `cognitive_tasks` | `state["{task}_outputs"]` | 遍历 CHECKLIST 各 task，读取 output 文件 metadata |
| `subagents_spawned` | `state["subagent_spawn_log"]` | 需要 orchestrator 在 spawn 时记录（新增） |
| `tools_usage` | `history.jsonl` | `self.sm.load_history()`，按 iteration 过滤聚合 |
| `context_state` | `state.json` | 直接读取 state 关键字段 |
| `user_interactions` | `state["user_interactions"]` | 由主 agent 在交互时写入 state |
| `previous_adjustments` | `fcms/self/` | `self.sm.fcms_load_self_awareness(n=1)` 取最近一次 |
| `fcms_signals` | FCMS report | `_run_fcms_check()` 返回的 report 摘要 |

### 2.4 数据收集函数（新增于 orchestrator.py）

```python
def _collect_self_awareness_input(self, state: dict, iteration: int, progress: dict, budget: dict) -> dict:
    """Collect all data needed for self-awareness coach input."""
    
    # 1. cognitive_tasks: from state outputs + file metadata
    cognitive_tasks = []
    for task_name in self.sm.CHECKLIST:
        outputs = state.get(f"{task_name}_outputs", [])
        for out in outputs:
            if out.get("iteration") == iteration:
                # Estimate duration from file timestamps or state tracking
                duration = out.get("duration_sec", 0)
                cognitive_tasks.append({
                    "task_name": task_name,
                    "duration_sec": duration,
                    "tools_used": out.get("tools_used", []),
                    "output_quality": out.get("quality", "sufficient"),
                    "anomalies": out.get("anomalies", [])
                })
    
    # 2. subagents_spawned: from state log (orchestrator records at spawn time)
    subagents = state.get("subagent_spawn_log", []).get(iteration, [])
    
    # 3. tools_usage: aggregate from history.jsonl
    history = self.sm.load_history()
    tools_usage = self._aggregate_tools_by_iteration(history, iteration)
    
    # 4. context_state: snapshot from current state
    context_state = {
        "total_tokens": state.get("context_tokens", 0),
        "critical_info_retention": state.get("info_retention", 1.0),
        "redundancy_ratio": state.get("redundancy_ratio", 0.0),
        "user_corrections_this_iter": len([u for u in state.get("user_interactions", []) 
                                            if u.get("iteration") == iteration]),
        "user_corrections_total": len(state.get("user_interactions", [])),
        "pending_gaps_count": len(state.get("pending_gaps", [])),
        "convergence_score": state.get("convergence_score", 0.0),
    }
    
    # 5. user_interactions: filtered by iteration
    user_interactions = [u for u in state.get("user_interactions", [])
                         if u.get("iteration") == iteration]
    
    # 6. previous_adjustments: from last self-awareness report
    prev_reports = self.sm.fcms_load_self_awareness(n=1)
    previous_adjustments = {}
    if prev_reports:
        prev = prev_reports[0]
        previous_adjustments = {
            "from_iteration": prev.get("iteration"),
            "adjustments_applied": prev.get("recommended_adjustments", []),
            "effectiveness": prev.get("overall_score", 0.0),
        }
    
    # 7. fcms_signals: from latest FCMS report
    fcms_path = self.harness_dir / "fcms" / f"fcms_iter_{iteration}.json"
    fcms_report = self._load_json_safe(fcms_path, {})
    fcms_signals = {
        "health_score": fcms_report.get("health_score", 0.0),
        "alerts": fcms_report.get("alerts", []),
        "cognitive_patterns": fcms_report.get("cognitive_patterns", {}),
    }
    
    return {
        "iteration": iteration,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": state.get("session_id", ""),
        "cognitive_tasks": cognitive_tasks,
        "subagents_spawned": subagents,
        "tools_usage": tools_usage,
        "context_state": context_state,
        "user_interactions": user_interactions,
        "previous_adjustments": previous_adjustments,
        "fcms_signals": fcms_signals,
    }
```

### 2.5 需要新增的状态字段（orchestrator 在 spawn 时记录）

在 `run_step()` 返回 spawn action 时，主 agent 执行 spawn 后应将信息写回 state：

```python
# 在主 agent 执行 spawn 后，调用：
state.setdefault("subagent_spawn_log", {}).setdefault(iteration, []).append({
    "agent_id": agent_id,
    "task": task,
    "spawned_at": datetime.now(timezone.utc).isoformat(),
    "output_path": output_path,
})
```

或者，更简洁的方式：由 orchestrator 的 `run_step()` 在返回 action 前预写入 `state["_pending_spawn"]`，待 `ingest_result()` 确认完成后更新为正式记录。

---

## 3. 输出数据设计

### 3.1 输出文件路径

| 文件 | 路径 | 用途 |
|------|------|------|
| 评估报告 | `{harness_dir}/fcms/self/sa_{iteration:03d}.json` | 完整 coach_report |
| 调整参数 | `{harness_dir}/fcms/self/adj_{iteration:03d}.json` | 下一 iteration 调整参数 |

复用 `state_manager.py` 的现有方法：
- `fcms_save_self_awareness(report, iteration)` → 保存评估报告
- 调整参数额外写入 `adj_{iteration:03d}.json`

### 3.2 输出 JSON Schema

**评估报告**（`sa_{iteration:03d}.json`）：

```json
{
  "coach_report": {
    "iteration": 3,
    "overall_score": 0.72,
    "health_status": "warning|healthy|critical",
    
    "dimension_scores": {
      "task_efficiency": 0.80,
      "tool_usage": 0.65,
      "subagent_efficiency": 0.55,
      "context_health": 0.85,
      "user_alignment": 0.70,
      "adjustment_effectiveness": 0.60
    },
    
    "top_issues": [
      {
        "rank": 1,
        "dimension": "subagent_efficiency",
        "severity": "warning",
        "description": "3 个子 agent 分析同类数据，上下文重叠度 40%",
        "evidence": ["sub-grow", "sub-consolidate", "sub-cascade"],
        "impact": "budget 浪费 30%，产出重复"
      }
    ],
    
    "previous_adjustment_review": {
      "adjustment": "max_fix_attempts: 3→5",
      "effectiveness": 0.60,
      "verdict": "partially_effective",
      "reason": "修复次数增加但成功率未提升，根因未解决"
    },
    
    "recommended_adjustments": [
      {
        "target": "orchestrator.spawn_strategy",
        "action": "merge_similar_tasks",
        "parameter": {"max_overlap_threshold": 0.30},
        "expected_improvement": "subagent_efficiency +0.20",
        "risk": "low",
        "auto_apply": true
      }
    ]
  },
  "coach_id": "明镜",
  "timestamp": "2026-05-05T14:35:00+08:00"
}
```

**调整参数**（`adj_{iteration:03d}.json`）：

```json
{
  "from_iteration": 3,
  "for_iteration": 4,
  "adjustments": [
    {
      "target": "orchestrator.spawn_strategy",
      "action": "merge_similar_tasks",
      "parameter": {"max_overlap_threshold": 0.30}
    }
  ],
  "coach_id": "明镜",
  "timestamp": "2026-05-05T14:35:00+08:00"
}
```

### 3.3 输出写入流程

```python
def _run_self_awareness(self, state: dict, iteration: int, progress: dict, budget: dict) -> None:
    """Trigger self-awareness coach after iteration completes."""
    
    # 1. Collect input data
    input_data = self._collect_self_awareness_input(state, iteration, progress, budget)
    
    # 2. Write input file
    self_dir = self.harness_dir / "fcms" / "self"
    self_dir.mkdir(parents=True, exist_ok=True)
    input_path = self_dir / f"iteration_{iteration:03d}_input.json"
    self._atomic_write(input_path, input_data)
    
    # 3. Build spawn action for self-aware agent
    sa_output_path = str(self_dir / f"sa_{iteration:03d}.json")
    adj_output_path = str(self_dir / f"adj_{iteration:03d}.json")
    sa_template = str(self.harness_dir / "agents" / "self_aware_agent_template.md")
    
    # 4. Return spawn info via state (parent agent reads and spawns)
    state["_pending_self_aware"] = {
        "iteration": iteration,
        "input_path": str(input_path),
        "output_path": sa_output_path,
        "adjustments_path": adj_output_path,
        "template": sa_template,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    
    # Note: actual spawn is done by parent agent. Orchestrator only prepares data.
    self.sm.save_state(state)
```

### 3.4 调整参数应用机制

**自动应用规则**（config 驱动）：

```yaml
modules:
  self_awareness:
    auto_apply_safe_adjustments: true
```

| 调整类型 | auto_apply | 应用方式 |
|---------|-----------|---------|
| spawn 策略 | ✅ | orchestrator 读取 adj 文件，下一 iteration 生效 |
| 工具偏好 | ✅ | 写入 state["tool_policy_override"] |
| 上下文压缩阈值 | ✅ | 写入 state["compression_threshold"] |
| budget 分配 | ✅ | 修改 budget.json |
| audit 严格度 | ⚠️ | 需 bounds check（0.50-0.95） |
| 终止条件修改 | ❌ | 需人工确认 |
| 路由策略切换 | ❌ | 需人工确认 |

**应用代码**（新增于 orchestrator `run_step()` 开头）：

```python
def run_step(self, concept: str = "") -> dict:
    state = self.sm.load_state()
    progress = self.sm.load_progress()
    budget = self.sm.load_budget()
    
    # === v3.5: Apply pending self-awareness adjustments ===
    iteration = progress.get("current_iteration", 1)
    adj_path = self.harness_dir / "fcms" / "self" / f"adj_{iteration-1:03d}.json"
    if adj_path.exists() and self._module_enabled("self_awareness"):
        adj_data = self._load_json_safe(adj_path, {})
        for adj in adj_data.get("adjustments", []):
            if adj.get("auto_apply", False):
                self._apply_adjustment(adj, state, budget)
    # =======================================================
    
    # ... rest of run_step ...

def _apply_adjustment(self, adj: dict, state: dict, budget: dict) -> None:
    """Apply a single self-awareness adjustment."""
    target = adj.get("target", "")
    action = adj.get("action", "")
    parameter = adj.get("parameter", {})
    
    if target == "orchestrator.spawn_strategy":
        state["spawn_strategy_override"] = parameter
    elif target == "tool_usage.policy":
        state["tool_policy_override"] = parameter
    elif target == "context.compression_threshold":
        state["compression_threshold"] = parameter.get("threshold", 0.25)
    elif target == "budget.reallocation":
        budget.update(parameter)
```

---

## 4. 与 FCMS 的关系

### 4.1 架构定位

```
┌─────────────────────────────────────────────────────────────┐
│                    FCH v3.5 元认知体系                        │
├─────────────────────────────────────────────────────────────┤
│  FCMS (FCH Cognitive Metacognition System)                    │
│  ├── L1 Capture:   信号采集（每 task 后）                      │
│  ├── L2 Evaluate:  认知健康评估（每 iteration）               │
│  ├── L3 Reflect:   模式反思（batch / immediate / dream）       │
│  └── L4 Regulate:  即时调控（阈值调整、budget 重分配）          │
├─────────────────────────────────────────────────────────────┤
│  Self-Awareness (明镜) — 独立模块，互补 FCMS                   │
│  ├── 6 维度执行审计（任务效率、工具使用、子 agent 效率等）        │
│  ├── TOP 3 问题识别 + 量化 impact                               │
│  ├── 上一调整有效性回顾                                        │
│  └── 下一 iteration 调整参数生成（含 expected_improvement）     │
├─────────────────────────────────────────────────────────────┤
│  DREAM (Deep Reflection & Emergence Analysis Mechanism)      │
│  └── 每天 cron 触发，全局整合 + 长期沉淀                        │
└─────────────────────────────────────────────────────────────┘
```

### 4.2 复用 vs 独立

| 维度 | FCMS | Self-Awareness |
|------|------|----------------|
| **关注点** | 认知质量（D1-D4 是否正确、是否收敛） | 执行效率（工具、agent、上下文、budget） |
| **触发频率** | 每 task / 每 iteration | 每 iteration（consolidate 后） |
| **数据输入** | teach/audit/grow 输出内容 | 执行耗时、工具调用、agent spawn 记录 |
| **输出作用** | 调控阈值、budget、路由 | 调整 spawn 策略、工具偏好、压缩策略 |
| **持久化** | `fcms/` 下 L1-L4 目录 | `fcms/self/` 目录 |
| **是否独立模块** | ✅ 是 | ✅ 是，但与 FCMS 共享 `fcms/` 父目录 |

**结论：独立但互补。** 明镜不替代 FCMS 的任何一层，而是补充 FCMS 未覆盖的「执行效率审计」维度。

### 4.3 数据交互

明镜输入中包含 `fcms_signals` 字段，可读取 FCMS 的 health_score 和 alerts 作为交叉参考。但明镜的评分独立计算，不受 FCMS 评分直接影响。

```
FCMS report ──→ fcms_iter_{n}.json ──→ 明镜输入.fcms_signals ──→ 明镜评估报告
                                                ↓
                                        明镜输出.adjustments ──→ orchestrator 应用
```

---

## 5. 主循环 CHECKLIST 设计

### 5.1 结论：明镜**不作为** CHECKLIST 正式步骤

`state_manager.CHECKLIST` 保持为：

```python
CHECKLIST = ["search", "teach", "audit", "grow", "verify", "consolidate"]
```

明镜是**元步骤（meta-step）**，不是认知循环的一部分。理由：

1. **语义清晰**：CHECKLIST 是「认知任务链」，明镜是「执行审计」，不属于同一范畴
2. **避免循环污染**：若明镜作为正式步骤，其自身的执行也需要 audit，导致无限递归
3. **并行性**：明镜可以与 convergence/termination 检查并行执行，不阻塞主循环
4. **可选性**：明镜失败不应导致 iteration 失败（见失败处理）

### 5.2 明镜的执行模式：后台/并行任务

```
[consolidate audit PASS]
         │
         ▼
    ┌─────────────────┐
    │  保存 state     │
    │  更新 progress  │
    └─────────────────┘
         │
         ├──────────────────────┐
         │                      │
         ▼                      ▼
    [convergence check]    [明镜 spawn]
         │                      │
         ▼                      ▼
    [termination check]    [明镜后台运行]
         │                      │
         ▼                      ▼
    [返回 action]          [明镜完成后
         │                   announce 父 agent]
         │                      │
         │                      ▼
         │               [父 agent 可选：
         │                汇报用户 / 应用调整]
         │
         ▼
    [下一 iteration 开始]
         │
         ▼
    [应用上一 iteration 的 adjustments]
```

### 5.3 父 agent 的协调职责

1. 收到 orchestrator `ingest_result(consolidate)` 返回后，检查 `state["_pending_self_aware"]`
2. 若存在，spawn 明镜 subagent（读取 template + input_path）
3. 明镜完成后 auto-announce，父 agent 读取输出
4. 父 agent 按 `auto_apply` 规则应用调整（或标记待人工确认）
5. 父 agent 按 `report_to_user` 配置决定是否向用户发送简报

---

## 6. 失败处理

### 6.1 明镜执行失败

```python
# 父 agent 收到明镜失败 announce 后：
state.setdefault("fcms_self_aware_failures", []).append({
    "iteration": iteration,
    "reason": error_reason,
    "timestamp": datetime.now(timezone.utc).isoformat(),
})

# 连续 2 次失败后，父 agent 向用户汇报：
# "自评估模块异常，建议检查"
```

### 6.2 输入数据缺失

明镜自身处理：在报告中标注缺失字段，继续评估可用数据。不中断。

### 6.3 调整参数应用失败

若 `_apply_adjustment()` 遇到不识别的 target：
- 记录到 `state["adjustment_apply_failures"]`
- 不阻塞主循环
- 下次明镜审计时读取并报告

---

## 7. 配置参考

完整的 `config.yaml` self_awareness 模块配置：

```yaml
modules:
  self_awareness:
    enabled: true
    trigger_after_each_iteration: true
    auto_apply_safe_adjustments: true
    report_to_user: true
    max_report_lines: 8
    dimensions:
      task_efficiency: true
      tool_usage: true
      subagent_efficiency: true
      context_health: true
      user_alignment: true
      adjustment_effectiveness: true
    safety_bounds:
      max_overlap_threshold: 0.50
      min_search_budget_ratio: 0.10
      max_search_budget_ratio: 0.40
      auto_apply_max_per_iteration: 3
```

---

## 8. 需要修改的文件清单

| 文件 | 修改内容 | 优先级 |
|------|---------|--------|
| `orchestrator.py` | 新增 `_run_self_awareness()`、`_collect_self_awareness_input()`、`_apply_adjustment()` | P0 |
| `orchestrator.py` | `ingest_result()` 中 consolidate 后插入明镜触发 | P0 |
| `orchestrator.py` | `run_step()` 开头插入 adjustments 应用逻辑 | P0 |
| `orchestrator.py` | `run_step()` 中 spawn 时记录 subagent_spawn_log | P1 |
| `state_manager.py` | 已支持 `fcms_save_self_awareness()`，无需修改 | - |
| `agents/self_aware_agent_template.md` | 更新输入/输出路径变量说明 | P1 |
| `config.yaml` | 已配置，可补充 safety_bounds | P2 |

---

## 9. 验收标准

1. 每个 iteration 结束后（consolidate audit 通过），自动生成 `iteration_{n:03d}_input.json`
2. 明镜 subagent 被正确 spawn，读取 input 并输出 `sa_{n:03d}.json` + `adj_{n:03d}.json`
3. `auto_apply: true` 的调整参数在下一 iteration 开始前被 orchestrator 自动应用
4. 父 agent 向用户发送的简报不超过 8 行（config 驱动）
5. 明镜失败不阻塞主循环，连续 2 次失败后告警
6. 明镜评分与 FCMS health_score 可交叉对比，但独立计算

---

*本文档是明镜接入主循环的权威设计文档。任何实现修改必须同步更新此文档。*
