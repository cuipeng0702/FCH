---
tag: [RUNTIME]
load_when: "子Agent运行时模板"
---

# Search Agent Task Template

## Objective
Perform comprehensive web search on a concept to gather factual foundation for D1–D4 generation. Produce one complete `search_results.json` per task invocation.

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "concept_id": "string (stable identifier)",
  "concept_name": "string (the concept to research)",
  "iteration": 1,
  "previous_queries": ["string (query from prior iteration)", "..."]
}
```

Notes:
- `previous_queries` may be empty on iteration 1.
- Use `previous_queries` to avoid repeating the same search queries across iterations.
- The orchestrator guarantees `concept_id` and `concept_name` are non-empty.

## Output

Write to: `{output_path}`

Format: JSON with schema (see references/design/PRD.md §7 search_results.json):
```json
{
  "concept_id": "string",
  "queries": ["string (query 1)", "string (query 2)", "..."],
  "results": [
    {
      "source": "string (domain or site name)",
      "url": "string (full URL)",
      "snippet": "string (relevant excerpt)",
      "relevance": "number (0–1)"
    }
  ],
  "synthesis": "string (comprehensive synthesis of key findings)",
  "timestamp": "ISO-8601 string"
}
```

## Search Strategy

### Query Design Rules
1. Execute at least 3 distinct search queries per task invocation.
2. Vary query intent across:
   - **Definition/ formal**: e.g., `"{concept_name} definition"`, `"{concept_name} formal specification"`
   - **Analogy/ intuitive**: e.g., `"{concept_name} explained simply"`, `"{concept_name} analogy"`
   - **Boundary/ counter-example**: e.g., `"{concept_name} limitations"`, `"{concept_name} when it fails"`, `"{concept_name} edge cases"`
3. Do not repeat any query listed in `previous_queries`.
4. Prefer authoritative sources: academic papers, official documentation, textbooks, reputable technical blogs.
5. If first query returns low-quality results, reformulate and retry before recording.

### Result Evaluation Rules
1. For each result, assign `relevance` ∈ [0.0, 1.0] based on:
   - **0.8–1.0**: Directly defines or deeply explains the concept
   - **0.5–0.79**: Related background, useful analogy, or adjacent technique
   - **0.0–0.49**: Tangential or low-quality source
2. Record at least 5 results with `relevance >= 0.5`.
3. Every recorded result must have non-empty `source`, `url`, `snippet`, and numeric `relevance`.
4. `snippet` should be a direct excerpt or a concise paraphrase of the most relevant passage (not the entire page).

### Synthesis Rules
1. `synthesis` must be non-empty (≥50 words).
2. Synthesize across all results — do not merely list them.
3. Cover:
   - Core definition and key properties
   - Most useful intuitive framing(s)
   - Known limitations, edge cases, or failure modes
   - Any notation or formal conventions observed
4. Flag conflicting information and note which source(s) support each claim.

## Available Tools

- **kimi_search** (primary): execute web search queries; use for all initial discovery
- **kimi_fetch** (secondary): read result pages in depth when a search result promises high-value detail but the snippet is insufficient
- **LLM via localhost:18790**: for synthesizing findings and evaluating relevance scores

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}` — `os.path.exists()`
2. Valid JSON — `json.loads()` without exception
3. All required keys present — `concept_id`, `queries`, `results`, `synthesis`, `timestamp`
4. Top-level `timestamp` key exists and is ISO-8601 formatted
5. `queries` array length >= 3
6. `results` array contains at least 5 items with `relevance >= 0.5`
7. Every result has non-empty `source`, `url`, `snippet`, and numeric `relevance` ∈ [0.0, 1.0]
8. `synthesis` is non-empty string (≥50 words) and synthesizes key findings (not a list)
9. No query in `queries` duplicates any item in `previous_queries`
10. `concept_id` in output matches input `concept_id`

## Failure Protocol

If any completion criterion fails, do not write output. Instead:
1. Identify which criterion failed and why
2. Attempt one self-correction using available tools (e.g., run additional queries, re-evaluate relevance scores)
3. If still failing, write a partial failure report to `{output_path}.failed` with keys: `failed_criterion`, `reason`, `attempted_fix`

## 元认知积累

本轮可用的历史经验（来自 FCMS 沉淀）：
{fcms_pitfalls}

注意：这些经验来自上一轮 FCMS 分析，已被压缩精炼。优先参考与当前步骤最相关的条目。

## Lattice Context 消费（LQL v3.5）

Orchestrator 已自动从 knowledge-lattice 中检索了相关知识，注入到本次输入的 `state.json` 中。请读取 `state.json` 中的 `lattice_context` 字段，并按以下规则消费：

### prerequisites（前置知识）
- 如果 `lattice_context.prerequisites` 非空，说明 lattice 中已存在相关前置概念。
- 在搜索时，**优先验证这些前置概念的最新状态**，确认它们是否仍然成立。
- 将这些前置概念的关键词融入搜索查询，确保搜索结果与现有知识体系一致。

### related_concepts（类比概念）
- 如果 `lattice_context.related_concepts` 非空，说明已有与本概念有 `analogy_of` 关系的概念。
- 搜索时**关注这些类比概念的边界条件和失败模式**，类比关系可能揭示本概念的特殊性质。
- 记录任何与类比概念相冲突的信息，这往往是新知识的来源。

### 消费原则
- lattice_context 只保留最相关的 3 条，摘要长度已压缩，仅作参考。
- 如果 lattice_context 为空列表，说明 lattice 中尚无相关概念，按正常搜索策略执行。
- 不要引用 lattice_context 中不存在的概念作为证据。

## Orchestrator Integration

After writing output, announce completion with:
```
DONE: {output_path}
Concept: {concept_id}
Iteration: {iteration}
Queries executed: {N}
High-relevance results: {M}
```
