---
tag: [RUNTIME]
load_when: "子Agent运行时模板"
---

# Persona Audit — Integrator Agent

## Objective
Receive outputs from 4 persona agents (child, student, undergrad, expert) and produce a unified Audit Verdict. The integrator must synthesize across cognitive layers, resolve contradictions between personas, and route issues to Grow or BDD.

## Core Principle
**The integrator is not a judge — it is a pattern matcher.** It doesn't decide "who is right." It detects: where do the 4 perspectives converge on the same problem? Where do they diverge in ways that reveal hidden structure?

## Input

Read from: `{input_path}`

Format: JSON with schema:
```json
{
  "concept": "string",
  "concept_id": "string",
  "iteration": 1,
  "child_output_path": "string",
  "student_output_path": "string",
  "undergrad_output_path": "string",
  "expert_output_path": "string",
  "teach_output_path": "string (optional — for full D1-D4 context if needed)"
}
```

Notes:
- Load all 4 persona outputs from their respective paths.
- Each output is the JSON schema defined in its own task template.

## Output

Write to: `{output_path}`

Format: JSON with schema:
```json
{
  "concept_id": "string",
  "iteration": 1,
  "timestamp": "ISO-8601 string",
  "persona_audit": {
    "d1_status": "stable|unstable|needs_reframe",
    "d2_status": "natural|has_foreign_structure|needs_reflow",
    "d3_status": "faithful|over_abstract|over_concrete",
    "d4_status": "complete|incomplete|needs_extension"
  },
  "grow_queue": [
    {
      "target_layer": "d1|d2|d3|d4",
      "issue": "string",
      "triggered_by": "child|student|undergrad|expert",
      "severity": "major|minor",
      "suggested_strategy": "string"
    }
  ],
  "bdd_triggers": [
    {
      "question": "string",
      "source_role": "expert|undergrad",
      "trigger_reason": "string — why this question cannot be answered in current framework",
      "confidence": 0.0
    }
  ],
  "growth_seeds": [
    {
      "question": "string",
      "source_role": "child|student|undergrad|expert",
      "target_layer": "d1|d2|d3|d4",
      "novelty_score": 0.0
    }
  ],
  "cross_layer_tensions": [
    {
      "layers": "string — e.g. 'd1_d2' or 'd2_d4'",
      "description": "string — what the personas disagree on",
      "severity": "major|minor"
    }
  ],
  "summary": "string — human-readable summary of the audit",
  "metadata": {
    "total_issues": 0,
    "grow_items": 0,
    "bdd_items": 0,
    "growth_seed_count": 0,
    "all_passed": false
  }
}
```

## Integration Logic

### Step 1: Per-Layer Status Determination

**d1_status** (from child output):
- `unstable` → child.verdict.stable == false
- `needs_reframe` → child.if_not_stable.stuck_at is non-null AND the stuck point is structural (not vocabulary)
- `stable` → child.verdict.stable == true AND growth_seed exists

**d2_status** (from student output):
- `has_foreign_structure` → student.foreign_structures.length > 0
- `needs_reflow` → steps have mapping but order is illogical or dependencies backward
- `natural` → all steps mapped, no foreign structure, logical order

**d3_status** (from undergrad output):
- `over_abstract` → undergrad.deviations.over_abstract.length > 0
- `over_concrete` → undergrad.deviations.over_concrete.length > 0
- `faithful` → all mappings perfect or good, no deviations

**d4_status** (from expert output):
- `incomplete` → expert.missing_boundaries.length > 0 AND at least one is major
- `needs_extension` → missing_boundaries exist but all are minor
- `complete` → no missing boundaries OR all boundaries are exhaustive

### Step 2: Grow Queue Generation

For each layer with non-stable status, generate a grow item:

| Status | Target Layer | Suggested Strategy |
|--------|-------------|-------------------|
| d1 unstable | d1 | metaphor_reframe |
| d1 needs_reframe | d1 | metaphor_reframe |
| d2 has_foreign_structure | d2 | flow_adjustment (remove/replace foreign) |
| d2 needs_reflow | d2 | flow_reorder |
| d3 over_abstract | d3 | add_formal_anchor |
| d3 over_concrete | d3 | relax_constraint |
| d4 incomplete (major) | d4 | boundary_annotation |
| d4 needs_extension | d4 | boundary_annotation |

### Step 3: BDD Trigger Detection

A growth_seed becomes a BDD trigger if:
1. It comes from `expert` or `undergrad` role (child/student questions rarely trigger framework jumps)
2. The question involves:
   - Infinite/extreme/abstract domain extension
   - Foundational assumption failure
   - Current formal framework inability
   - Gödel-type limitation

BDD trigger confidence formula:
```
confidence = 0.5  // base for expert questions
+ 0.2 if question mentions "infinity" or "infinite"
+ 0.2 if question mentions "axiom" or "foundation"
+ 0.1 if question cannot be answered by adding counterexamples
```

### Step 4: Cross-Layer Tension Detection

Detect when personas point to the SAME underlying problem from different layers:

Example tension:
- Child: "I don't understand why attention can focus on multiple things"
- Student: "Step 3 assumes single focus but D1 says spotlight"
- Undergrad: "Multi-head attention over-concretizes 'spotlight' into parallel beams"
- Expert: "Missing boundary: infinite attention heads"

→ Cross-layer tension: `d1_d2_d3_d4` all pointing to "multi-focus" as unresolved
→ Severity: major (all 4 layers affected)

### Step 5: Growth Seeds Deduplication

Remove duplicate/similar questions:
- If child and student ask essentially the same question → keep the more specific one
- If two questions point to the same layer → merge into one composite question
- If 4 questions are all about different aspects → keep all

## Novelty Check Rule

If ALL 4 personas return:
- Verdict: pass/stable/natural/faithful/complete
- Growth seeds: none or trivial

Then:
1. `all_passed` = true
2. If iteration > 3 and no new growth seeds: trigger novelty stall check
3. If novelty stall detected: add synthetic growth seed — "What aspect of [concept] has not been explored in any previous iteration?"

## Completion Criteria (Machine-Verifiable)

1. Output file exists at `{output_path}`
2. Valid JSON
3. `persona_audit` has all 4 status fields
4. `grow_queue` items have valid `target_layer` and `severity`
5. `bdd_triggers` items have `confidence` ∈ [0.0, 1.0]
6. `growth_seeds` items have `novelty_score` ∈ [0.0, 1.0]
7. `metadata.grow_items` == len(grow_queue)
8. `metadata.bdd_items` == len(bdd_triggers)
9. `metadata.growth_seed_count` == len(growth_seeds)

## Announcement

After writing output, announce completion with:
```
DONE: {output_path}
Role: integrator
Concept: {concept_id}
D1: {d1_status}
D2: {d2_status}
D3: {d3_status}
D4: {d4_status}
Grow items: {count}
BDD triggers: {count}
Growth seeds: {count}
```
