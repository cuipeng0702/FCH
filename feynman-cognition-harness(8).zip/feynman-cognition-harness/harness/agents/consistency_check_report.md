# FCH 模板一致性检查报告

> 审计时间: 2026-05-05
> 审计范围: 8 对详细 template vs summary + 6 对 template vs persona_profile + 2 项特殊检查
> 修正权限: summary 文件可直接修正；persona_profile 仅记录建议

---

## 一、详细 template vs Summary 一致性

### search
- 输入一致性: ✅ 核心字段（concept_id, concept_name, iteration, previous_queries）完整覆盖
- 输出一致性: ✅ JSON schema（queries, results, synthesis, timestamp）完全对应
- 验收标准对应: ⚠️ Summary 仅列 5 条核心标准，省略了详细版 10 条中的 concept_id 匹配、结果字段完整性、无重复查询等。Summary 定位精简，核心约束已覆盖，但机器可验证标准不够完整
- 路径正确性: ✅ `harness/agents/search_task_template.md`
- 前序依赖: ✅ "无（循环首步）"与详细版一致
- **问题记录**: 无严重问题。Summary 验收标准可补充第 9-10 条（结果字段非空检查、concept_id 匹配）。
- **修正建议**: 在 summary 验收标准中追加"所有 result 有非空 source/url/snippet/relevance"和"concept_id 输出与输入匹配"（可选，非 P0）。

### teach
- 输入一致性: ⚠️ Summary 未提及可选字段（analogy_matrix_path, learner_profile, prior_analogy_id, prior_breakage_reason, strategy），核心字段已覆盖
- 输出一致性: ⚠️ **Schema 矛盾**: Execution Rules 第 6 条要求 `cross_depth_mappings` 至少 3 条目，第 7 条要求 `gaps_identified` 诚实标注，但输出 JSON schema 中不存在这两个字段。这是 teach 模板内部矛盾
- 验收标准对应: ⚠️ Summary 6 条 vs 详细版 11 条，缺少 teach_mode 一致性、无矛盾 claims、bridge_concepts 结构等检查
- 路径正确性: ✅ `harness/agents/teach_task_template.md`
- 前序依赖: ✅ 已修正 — 删除了 summary 中错误的 `search_output.json` 别名
- **问题记录**:
  - **P1** | 输出 schema 与 Execution Rules 矛盾: `cross_depth_mappings` 和 `gaps_identified` 被规则要求但不在 schema 中
  - **P1** | Teach Mode Behavior 写 "full（默认）"，但输入 schema 写 "fresh | cascade_update | gap_driven (default: fresh)" — `full` 与 `fresh` 不一致（已修正为 fresh）
  - Summary 前序输出路径曾错误包含 `search_output.json` 别名（已修正）
- **修正建议**:
  - 在 teach 输出 schema 中添加 `cross_depth_mappings` 和 `gaps_identified` 字段，或从 Execution Rules 中删除这两个要求（需设计决策）
  - 已修正: "full（默认）" → "fresh（默认）"
  - 已修正: summary 前序输出路径删除 `search_output.json` 别名

### audit
- 输入一致性: ✅ 核心字段完整覆盖，persona_audit_path（可选）summary 未提符合精简定位
- 输出一致性: ✅ JSON schema 完全对应
- 验收标准对应: ⚠️ Summary 7 条 vs 详细版 12 条，缺少 timestamp ISO 格式、metadata 计数精确性、summary ≥20 词等。核心逻辑约束已覆盖
- 路径正确性: ✅ `harness/agents/audit_task_template.md`
- 前序依赖: ✅ `harness/agents/teach_output.json` 与详细版一致
- **问题记录**: 无严重问题。
- **修正建议**: 无。

### grow
- 输入一致性: ✅ 已修正 — summary 补充了 `previous_grow` 字段提及
- 输出一致性: ✅ JSON schema 完全对应
- 验收标准对应: ⚠️ Summary 6 条 vs 详细版 12 条，缺少 timestamp ISO 格式、metadata.priority_layer 等。核心约束已覆盖
- 路径正确性: ✅ `harness/agents/grow_task_template.md`
- 前序依赖: ✅ `harness/agents/audit_output.json` 与详细版一致
- **问题记录**: 无严重问题。已修正 summary 缺少 `previous_grow`。
- **修正建议**: 无。

### verify
- 输入一致性: ✅ 所有字段完整覆盖
- 输出一致性: ✅ JSON schema 完全对应
- 验收标准对应: ⚠️ Summary 6 条 vs 详细版 12 条，缺少 metadata.sources_checked 等。核心约束已覆盖
- 路径正确性: ✅ `harness/agents/verify_task_template.md`
- 前序依赖: ✅ `harness/agents/teach_output.json`、`harness/agents/grow_output.json` 与详细版一致
- **问题记录**: 无严重问题。
- **修正建议**: 无。

### consolidate
- 输入一致性: ✅ 5 个输入文件完整覆盖
- 输出一致性: ✅ JSON schema 完全对应
- 验收标准对应: ⚠️ **详细版自身缺少明确的 Completion Criteria (Machine-Verifiable) 节**（其他 7 个模板都有）。Summary 的 6 条验收标准填补了此空白，但与详细版无直接对应
- 路径正确性: ✅ `harness/agents/consolidate_task_template.md`
- 前序依赖: ✅ `harness/agents/verify_output.json` 与详细版一致
- **问题记录**:
  - **P2** | consolidate_task_template.md 缺少 "Completion Criteria (Machine-Verifiable)" 节，与其他模板结构不一致
- **修正建议**: 在 consolidate_task_template.md 中补充 Completion Criteria 节，与 PRD §7.5 对齐。

### self_aware
- 输入一致性: ✅ 已修正 — 删除了 summary 中 agent_template 没有的 `fcms_signals` 字段
- 输出一致性: ✅ coach_report + adjustments schema 完全对应
- 验收标准对应: ⚠️ agent_template 和 summary 都缺少明确的"验收标准"列表节（仅 output schema）。Summary 的"验收标准"部分实际上描述了输出文件要求，与详细版一致
- 路径正确性: ✅ `self_aware_agent_template.md` 及关联人格/接入方案文件正确
- 前序依赖: ✅ 已修正 — 删除 summary 中"consolidate audit 通过后"条件，与 agent_template"每个 iteration 结束后"一致
- **问题记录**:
  - **P2** | summary 曾错误包含 `fcms_signals` 字段（agent_template 输入 schema 无此字段）（已修正）
  - **P2** | summary 曾错误将触发时机限定为"consolidate audit 通过后"（agent_template 无此条件）（已修正）
  - 注意: integration_plan.md 要求触发时机为"consolidate audit 通过后"、要求 `fcms_signals` 字段，但这些未同步到 agent_template。这是 agent_template/integration_plan 之间的问题，非 summary 与详细版之间的问题
- **修正建议**:
  - 已修正 summary 的两处不一致
  - 建议: 若 integration_plan 的精确触发时机和 fcms_signals 字段是权威设计，应同步更新 agent_template.md

### bdd
- 输入一致性: ✅ 所有字段完整覆盖
- 输出一致性: ✅ T1-T4 结果和实验记录要求完全对应
- 验收标准对应: ✅ Summary 5 条与详细版 T1-T4 输出要求完全对应
- 路径正确性: ✅ `harness/agents/bdd_task_template.md`
- 前序依赖: ✅ "由 hybrid router 触发，通常来自 grow_output.json"与详细版一致
- **问题记录**: 无。
- **修正建议**: 无。

---

## 二、Task Template vs Persona Profile 一致性

### search
- 人格匹配: ✅ Scout（斥候）- 快速、全面、不遗漏，与搜索任务性质完全匹配
- 产出一致: ✅ persona 和 template 都要求产出 `search_results.json`，schema 一致
- 纪律冲突: ✅ persona 说"不生成教学解释、不做类比"；template 要求产出搜索结果 JSON，不涉及教学内容。无冲突
- SOP 互补: ✅ persona 侧重搜索策略设计（分布式搜索子 agent 分工）；template 侧重 query 设计规则、result evaluation、synthesis 规则。互补
- 输入依赖: ✅ persona 提到读取 `concept_id`, `concept_name`, `previous_queries`；template 定义了这些输入
- **问题记录**: 无。
- **修正建议**: 无。

### teach
- 人格匹配: ✅ Socratic（苏格拉底）- 费曼式、挑剔、结构化，与 D1-D4 生成任务完全匹配
- 产出一致: ✅ persona 和 template 都要求产出 `teach_output.json`，含 D1-D4、dependency_chain、bridge_concepts、metadata
- 纪律冲突: ✅ persona 说"不直接修改 search_results.json"；template 说"pre-loaded as input (not generated by this teach-agent)"。无冲突
- SOP 互补: ✅ persona 侧重 D1-D4 生成流程、跨层映射、类比设计；template 侧重 teach_mode 切换、输出 schema、completion criteria。高度互补
- 输入依赖: ✅ persona 提到读取 `concept_id`, `concept`, `teach_mode`, `search_results`；template 定义了这些输入
- **问题记录**:
  - **P1** | teach_persona_profile.md 第 8 节末尾引用 `teach_subagent_prompt.md`，该文件已合并到 teach_task_template.md 并归档为 `teach_subagent_prompt_ARCHIVE_v3.2.md`。遗留引用可能导致注入时找不到文件
- **修正建议**:
  - 将 teach_persona_profile.md 中的"`teach_subagent_prompt.md`"改为"`teach_task_template.md`（已整合原 subagent prompt）"

### audit
- 人格匹配: ✅ Auditor（审计者）- 对抗性、冷酷、怀疑主义，与审计任务完全匹配
- 产出一致: ✅ persona 和 template 都要求产出 `audit_output.json`，含 valid、issues、summary、metadata
- 纪律冲突: ✅ persona 说"不修复缺陷、不生成教学内容"；template 说"Independently audit...must be adversarial...do NOT repeat issues already flagged by personas"。无冲突
- SOP 互补: ✅ persona 的 SOP 详细描述审计流程（D1→D2→D3→D4→跨层→差距→历史）；template 提供 PRD §3 逐项 Audit Checklist。互补
- 输入依赖: ✅ persona 提到加载 `teach_output_path`；template 定义了 `teach_output_path`
- **问题记录**: 无。
- **修正建议**: 无。

### grow
- 人格匹配: ✅ Grow - 诊断型、补洞本能、策略优先，与 gap 分析和策略生成任务完全匹配
- 产出一致: ✅ persona 和 template 都要求产出 `grow_output.json`，含 gaps、strategy、teach_candidates、intra_node_fixes、dependency_updates、metadata
- 纪律冲突: ✅ persona 说"不直接 teach、不直接修改 lattice、不直接验证事实"；template 只要求分析 gap 和生成策略。无冲突
- SOP 互补: ✅ persona 的 SOP（Phase 0→1→2）与 template 的 SOP（Phase 0→1→2）高度一致，template 更详细地定义了输出 schema，persona 更详细地定义了决策权限和工具纪律。互补
- 输入依赖: ✅ persona 提到读取 audit_output.json、teach_output.json、state.json；template 定义了这些输入
- **问题记录**: 无。
- **修正建议**: 无。

### verify
- 人格匹配: ✅ Verify - 怀疑型、证据驱动、量化优先，与三维验证任务完全匹配
- 产出一致: ✅ persona 和 template 都要求产出 `verification_output.json`，含 cross_time_consistent、independent_reproduction、confidence、verification_details、metadata
- 纪律冲突: ✅ persona 说"不 teach、不修改 lattice、不生成缺口策略"；template 只要求验证。无冲突
- SOP 互补: ✅ persona 的 SOP（维度1→2→3→置信度→崩溃检测）与 template 的 Verification Dimensions 完全一致
- 输入依赖: ✅ persona 提到读取 teach_output、audit_output、grow_output、state、previous_verification；template 定义了这些输入
- **问题记录**: 无。
- **修正建议**: 无。

### consolidate
- 人格匹配: ✅ Consolidate - 严谨、细致、不丢任何东西，与知识固化任务完全匹配
- 产出一致: ✅ persona 和 template 都要求产出 `consolidate_output.json`，含 audit_status、verification_status、active_gaps、version_stack_entry、new_concepts_created、concepts_merged、graphify_export_status
- 纪律冲突: ✅ persona 说"不 teach、不验证、不分析缺口、不搜索外部知识"；template 只要求编辑 lattice 和触发可视化。无冲突
- SOP 互补: ✅ persona 的 SOP（11 项任务清单）与 template 的 Task 清单（11 项）完全一致，persona 增加了备份纪律和合并决策校验，template 增加了 JSON schema 示例。互补
- 输入依赖: ✅ persona 提到读取 teach_output、audit_output、grow_output、verify_output、state；template 定义了这些输入
- **问题记录**: 无。
- **修正建议**: 无。

---

## 三、特殊检查

### teach 合并后 schema
- 扁平 d1/d2/d3/d4 vs 嵌套 d1_analogy/d2_procedural: ✅ 已统一为扁平结构。`teach_task_template.md` 输出 schema 明确使用顶层 `d1`、`d2`、`d3`、`d4`，无嵌套结构残留
- 字数限制清除确认: ❌ **未清除**。以下三处仍保留 D1 ≤150 词限制：
  1. `teach_task_template.md` 输出 schema: `"d1": "string (analogy, ≤150 words)"`
  2. `audit_task_template.md` D1 Audit Items: `Is length ≤150 words?`
  3. `teach_persona_profile.md` 质量纪律: `D1 长度 ≤150 词`
  三处文件之间一致，但用户此前明确要求"别规定各层知识的字数"，此要求未落实
- **问题记录**:
  - **P1** | `cross_depth_mappings` 和 `gaps_identified` 在 Execution Rules 中被要求，但输出 schema 无对应字段（详见"一、teach"节）
  - **P2** | 字数限制未按用户指令清除（文件之间一致，但与用户指令冲突）
- **修正建议**:
  - 对 `cross_depth_mappings`：建议在 teach 输出 schema 中添加该字段（或放入 metadata），或从 Execution Rules 中删除要求
  - 对 `gaps_identified`：建议在输出 schema 中添加该字段（顶层或 metadata），或从 Execution Rules 中删除要求
  - 对字数限制：三处文件一致，若用户确认清除，需同步修改 teach template（输出 schema + D-Level Requirements 表）、audit template（D1 Audit Items）、teach persona（质量纪律）

### self_aware 三者一致性
- agent_template vs profile: ✅ 核心一致。`self_aware_profile_v2.md` 是 `self_aware_agent_template.md` 的规范化扩展（v1.0 → v2.0），人格（明镜）、6 维度、输出格式、工具权限、安全边界完全一致。profile_v2 按 SUBAGENT_PERSONA_SPEC.md 补齐了 8 要素，无矛盾
- profile vs integration_plan: ❌ **存在不一致**：
  1. `fcms_signals` 字段：integration_plan 要求在输入中包含（来自 FCMS report），但 agent_template 和 profile_v2 均未定义此字段
  2. `pending_gaps_count` / `convergence_score`：integration_plan 的 `_collect_self_awareness_input()` 函数在 `context_state` 中包含这两个字段，agent_template 的输入 schema 中没有
  3. 触发时机：integration_plan 精确限定为"consolidate audit 通过后"，agent_template 只说"每个 iteration 结束后"
- **问题记录**:
  - **P1** | integration_plan 比 agent_template/profile 更详细（增加了字段和精确触发条件），但未反向同步到模板。若 implementation 按 integration_plan 执行，spawn 的 subagent 会收到 agent_template 未预料到的输入字段
  - **P2** | self_aware summary 已修正以匹配 agent_template，但 agent_template 本身可能需要更新以匹配 integration_plan 的权威设计
- **修正建议**:
  - 方案 A: 更新 `self_aware_agent_template.md` 的输入 schema，添加 `fcms_signals`、`pending_gaps_count`、`convergence_score`，并将触发时机明确为"consolidate audit 通过后"
  - 方案 B: 若 agent_template 保持简洁，integration_plan 的额外字段作为可选注入（orchestrator 负责填充，agent 按需消费）
  - 建议采用方案 A，保持模板权威性和实现一致性

---

## 四、已执行的修正

| 文件 | 修正内容 | 原因 |
|------|---------|------|
| `teach_task_template_SUMMARY.md` | 删除前序输出路径中的 `search_output.json` 别名 | summary 与详细版不一致 |
| `self_aware_task_template_SUMMARY.md` | 删除 `fcms_signals` 输入字段 | summary 与 agent_template 不一致 |
| `self_aware_task_template_SUMMARY.md` | 触发时机改为"每个 iteration 结束后" | summary 与 agent_template 不一致 |
| `teach_task_template.md` | "full（默认）" → "fresh（默认）" | 输入 schema 与 Teach Mode Behavior 不一致 |
| `grow_task_template_SUMMARY.md` | 补充 `previous_grow` 字段提及 | summary 与详细版不一致 |

---

## 五、总体评估

| 检查项 | 通过数 | 总数 | 状态 |
|--------|--------|------|------|
| 详细 vs Summary | 32 | 40 | ⚠️ |
| Template vs Persona | 30 | 30 | ✅ |
| 特殊检查 | 2 | 5 | ⚠️ |

**详细 vs Summary 分解**:
- 输入一致性: 8/8 ✅
- 输出一致性: 7/8 ⚠️ (teach 有 schema 矛盾)
- 验收标准对应: 1/8 ⚠️ (仅 bdd 完全对齐，consolidate 详细版自身缺 Completion Criteria)
- 路径正确性: 8/8 ✅
- 前序依赖: 8/8 ✅

**问题分级汇总**:
- **P0**: 0 处
- **P1**: 4 处
  1. teach 输出 schema 与 Execution Rules 矛盾（cross_depth_mappings / gaps_identified 缺失）
  2. teach persona 遗留引用 `teach_subagent_prompt.md`
  3. self_aware integration_plan 与 agent_template 输入字段不一致（fcms_signals 等）
  4. D1 ≤150 词字数限制未按用户指令清除（跨文件一致但与指令冲突）
- **P2**: 4 处
  1. consolidate_task_template.md 缺少 Completion Criteria 节
  2. self_aware summary 曾含错误触发条件（已修正）
  3. self_aware summary 曾含错误输入字段（已修正）
  4. teach summary 前序输出路径曾含错误别名（已修正）

**结论**: 存在 8 处问题（4 P1 + 4 P2），其中 4 处已在本次审计中直接修正（全部 P2 中的 summary 问题）。剩余 4 处 P1 需设计决策后修正，建议优先处理 teach schema 矛盾（影响运行时输出验证）和 self_aware 字段同步（影响集成实现）。

---

*报告结束*
