# BDD Task Template — Summary (v3.5)

## 一句话定义
当认知缺口触及理论框架边界时，通过 T1 理论分析、T2 跨变体比较和 T3 可执行实验验证候选框架的有效性。

## 输入（Input）
- 来源：orchestrator 在路由决策为 BDD 时传入
- 格式：JSON，含 `concept_id`、`framework_name`、`routing_band`、`gap_description`、`prior_analogies`、`t3_tool_registry_path`、`thresholds`
- 关键字段：`framework_name`（候选框架）、`gap_description`（触发 BDD 的缺口）、`t3_tool_registry_path`（实验工具注册表）

## 输出（Output）
- 路径：`bdd_report.json`、`t3_results.jsonl`
- 格式：JSON，含 T1-T4 综合结果和逐条实验记录
- 验收标准：
  1. `bdd_report.json` 存在且 JSON 有效
  2. T1 含 `axioms`、`consistency_score`、`expressive_power_score`、`computational_content_score`、`references`（≥2 条）
  3. T2 含 `dimensions[]`、`overall_preference`、`risk_flags[]`
  4. T3 每条实验含 `verdict ∈ {PASS, FAIL, INCONCLUSIVE}`、`checks`（4 项）、`confidence_adjustment`
  5. T4 `BDD_confidence` 按公式计算：`0.6 × T1_consistency + 0.2 × T2_preference + 0.2 × T3_empirical`

## 执行要点（SOP 速查）
1. T1：形式化框架核心公理，检查内部一致性、表达能力和计算内容
2. T2：将候选框架与原概念及至少一个其他变体比较，4 维度评分
3. T3：调用 `harness/t3_executor.py` 执行实验，优先 Tier 2（形式化工具），回退 Tier 1（结构化思想实验）

## 常见失败模式
- T3 实验调用 `t3_executor.py` 失败 → 主 agent 回退到 Tier 1 思想实验并记录原因
- `BDD_confidence < thresholds.bdd_confidence` → 主 agent 标记需人工审查
- 引用不足 2 条外部来源 → 主 agent 要求补充学术文献或降级置信度

## 关联文件
- 详细模板：`harness/agents/bdd_task_template.md`
- 人格档案：`harness/agents/bdd_persona_profile.md`
- 前序输出：由 hybrid router 触发，通常来自 `grow_output.json` 的 framework_boundary 类 gap
