# FCH 文档系统审计报告

> 审计时间：2026-05-05 22:51 GMT+8
> 审计范围：`/root/.openclaw/workspace/skills/feynman-cognition-harness/`
> 审计工具：文件读取 + 全文搜索 + 交叉引用验证

---

## 评分（5分制）

| 维度 | 评分 | 说明 |
|------|------|------|
| 结构清晰完整 | 3/5 | 核心文件基本齐全，但 orchestrator_runbook.md 缺失，多个 subagent prompt 缺失，archive/ 目录冗余严重 |
| 调用逻辑正确 | 3/5 | 大部分引用正确，但 audit_persona_profile.md 引用已删除的 D1 ≤150 字约束，PRD schema 与 template 扩展字段不一致 |
| 内容闭环 | 3/5 | config.yaml → orchestrator.py 模块开关对应完整，但 grow_output.json PRD schema 与 template 扩展字段未对齐，audit schema 存在双版本 |
| 与v3.5对齐 | 3/5 | 版本号总体统一为 v3.5/v3.5.0，但 audit_persona_profile.md 残留旧约束，grow_task_template.md cascade gaps 处理描述不完整 |

**总分：12/20**

---

## 发现的问题（按严重性 P0/P1/P2）

### P0: orchestrator_runbook.md 缺失
- **位置**：必查文件清单第7项 `harness/agents/orchestrator_runbook.md`
- **影响**：执行手册是 Ralph Loop 协调主 agent 的核心参考文档，缺失导致主 agent 无法正确引用 runbook 来编排子 agent 生命周期。
- **建议**：创建 `harness/agents/orchestrator_runbook.md`，内容应涵盖：迭代编排顺序、子 agent spawn 协议、ingest_result 回灌流程、audit 通过/失败/拒绝的处理分支、并行 teach 的调度逻辑、cascade gap 的传递机制。

### P0: 5 个 subagent prompt 文件缺失
- **位置**：必查文件清单第10项 `harness/agents/*_subagent_prompt.md`
- **影响**：teach、grow、verify、consolidate、search 的 subagent prompt 文件均缺失（仅 audit_subagent_prompt.md 存在）。这些文件定义了 agent 内部的输出格式规范，缺失导致 agent 内部执行缺乏详细 schema 指导。
- **建议**：
  - 创建 `teach_subagent_prompt.md`（基于 teach_task_template.md 的 JSON schema + SOP）
  - 创建 `grow_subagent_prompt.md`（基于 grow_task_template.md 的扩展字段定义）
  - 创建 `verify_subagent_prompt.md`（基于 verify_task_template.md 的 JSON schema）
  - 创建 `consolidate_subagent_prompt.md`（基于 consolidate_task_template.md 的 11 项任务清单）
  - 创建 `search_subagent_prompt.md`（基于 search_task_template.md 的 JSON schema）

### P0: PRD §7.3 grow_output.json schema 与 grow_task_template.md 输出字段严重不一致
- **位置**：`references/design/PRD.md §7.3` vs `harness/agents/grow_task_template.md` 输出格式
- **影响**：PRD 定义的 grow_output.json 只有 `gaps`、`strategy`、`timestamp` 三个顶层字段；但 grow_task_template.md 实际输出了 `teach_candidates`、`intra_node_fixes`、`dependency_updates`、`merge_suggestions`、`fcms_pitfalls` 等大量扩展字段。Consolidate 模板依赖这些扩展字段（任务8-11），但 PRD 中未定义。
- **建议**：**更新 PRD §7.3**，将 grow_output.json 的完整 schema 与 grow_task_template.md 对齐，加入 teach_candidates、intra_node_fixes、dependency_updates、merge_suggestions 等字段的正式定义。

### P0: audit_task_template.md 与 audit_subagent_prompt.md 使用不同 schema
- **位置**：`harness/agents/audit_task_template.md`（引用 PRD §7.3） vs `harness/agents/audit_subagent_prompt.md`（使用 depth_checks/cross_depth_audits/contradictions/pseudo_mappings 结构）
- **影响**：审计 agent 有两个不同的输出格式规范。audit_task_template.md 要求输出 PRD §7.3 的简化格式（issues 数组），而 audit_subagent_prompt.md 要求输出详细的 depth_checks/cross_depth_audits 结构。这会导致子 agent 执行时 schema 混乱。
- **建议**：统一 audit 输出 schema。推荐以 audit_subagent_prompt.md 的详细结构为准（因为 PRD §7.3 过于简化，无法支撑跨层映射审计），更新 PRD §7.3 或删除 audit_task_template.md 对 PRD §7.3 的引用。

### P1: audit_persona_profile.md 残留已删除的 D1 ≤150 字约束
- **位置**：`harness/agents/audit_persona_profile.md` 第172行：`"D1 审计：检查 analogy 存在性、唯一性、零术语、触觉/视觉名词、≤150 字、类比结构映射真实性..."`
- **影响**：PRD §3.1 和 §7.2 已删除 D1 ≤150 words 限制（v3.5 更新为"长度不限，以讲清结构为准"）。审计 agent 若按 persona profile 执行，会错误地将 D1 >150 字标记为问题。
- **建议**：删除 audit_persona_profile.md 第172行的 "≤150 字"。

### P1: grow_task_template.md 缺少 cascade gaps 处理的完整描述
- **位置**：`harness/agents/grow_task_template.md` 输出格式和 SOP
- **影响**：orchestrator.py 的 `_run_cascade` 会将 `pending_cascade_gaps` 存入 state，但 grow_task_template.md 中没有描述如何消费这些 cascade gaps（如何将其纳入 gaps 分析、优先级排序、生成 teach_candidates）。
- **建议**：在 grow_task_template.md 的 SOP 中增加 Phase 0.5：读取 `state.json` 中的 `pending_cascade_gaps`，将其转化为普通 gaps 或独立的 `cascade_gaps` 字段，并在策略制定中考虑级联修复。

### P1: PRD §7.2 teach_output.json schema 与 teach_task_template.md 存在字段命名不一致
- **位置**：`references/design/PRD.md §7.2` vs `harness/agents/teach_task_template.md`
- **影响**：PRD 使用 `cross_depth_mappings`（复数）和 `gaps_identified`（复数），teach_task_template.md 也使用了这些字段名，基本一致。但 PRD 中 `d3.confidence` 是 `"high|medium|low"` 字符串，而 teach_task_template.md 要求 `"confidence_estimate": 0.85` 为 float。这是轻微的语义不一致。
- **建议**：明确 `d3.confidence` 与 `metadata.confidence_estimate` 的分工——前者是声明式置信度标签，后者是量化估计值。在 PRD 中增加 `metadata.confidence_estimate` 字段说明。

### P1: bdd_persona_profile.md 和 audit_quality_persona_profile.md 不在 harness/agents/ 目录
- **位置**：`references/design/bdd_persona_profile.md`、`references/design/audit_quality_persona_profile.md`
- **影响**：这两个文件位于 references/design/ 而非 harness/agents/，与其他 persona profile 的存放位置不一致。SKILL.md 的导航表中提到 persona profile 在 harness/agents/ 下。
- **建议**：移动到 `harness/agents/` 目录，或更新 SKILL.md 导航表说明其位置。

### P2: archive/ 和 references/ 目录存在大量历史版本文件
- **位置**：`archive/20250414-v3.3/`、`archive/20250415-v3.4/`、`references/ARCHIVE/`
- **影响**：历史版本文件未清理，包含旧版 PRD、模板、persona profile。这些文件可能被误引用（尤其是 ARCHIVE 下的 `teach_subagent_prompt.md` 等文件，可能与新文件混淆）。
- **建议**：archive/ 目录内容已压缩，暂不处理。但应确认 ARCHIVE/ 目录下的文件不会再被引用。在 SKILL.md 或 README.md 中明确说明 archive/ 为只读历史备份。

### P2: config.yaml 中 `cascade.enabled: false` 但 orchestrator.py 中 _run_cascade 已完整实现
- **位置**：`harness/config.yaml` 第10行 `enabled: false` vs `harness/orchestrator.py` `_run_cascade` 完整实现
- **影响**：cascade 引擎在代码中已完整实现（双向依赖检测、gap 传播、报告保存），但默认关闭。这不是 bug，是设计选择，但值得注意。
- **建议**：无。如需启用 cascade，主 agent 需将 `enabled` 改为 `true`。

### P2: config.yaml 使用 `config.json` 名称但实际文件是 YAML
- **位置**：`SKILL.md` 提到 `config.json`，但实际文件是 `harness/config.yaml`
- **影响**：轻微的文档不一致。
- **建议**：将 SKILL.md 中的 `config.json` 改为 `config.yaml`。

### P2: PRD.md 未标注版本号
- **位置**：`references/design/PRD.md` 全文
- **影响**：PRD 作为核心设计文档，没有显式版本号标注。难以快速判断其对应 v3.3/v3.4/v3.5。
- **建议**：在 PRD.md 标题或头部增加版本号标注，如 `# FCH Ralph-Style Execution Harness — PRD v3.5`。

---

## 冗余文档清单

| 文件/目录 | 位置 | 说明 |
|-----------|------|------|
| `archive/20250414-v3.3/` | 技能根目录 | 旧版本 v3.3 完整备份 |
| `archive/20250415-v3.4/` | 技能根目录 | 旧版本 v3.4 完整备份 |
| `references/ARCHIVE/` | references/ | 旧版模板和 persona profile 归档 |
| `references/ARCHIVE/teach_subagent_prompt.md` | references/ARCHIVE/ | 旧版 teach subagent prompt |
| `references/ARCHIVE/grow_subagent_prompt.md` | references/ARCHIVE/ | 旧版 grow subagent prompt |
| `references/ARCHIVE/verify_subagent_prompt.md` | references/ARCHIVE/ | 旧版 verify subagent prompt |
| `references/ARCHIVE/consolidate_subagent_prompt.md` | references/ARCHIVE/ | 旧版 consolidate subagent prompt |
| `references/ARCHIVE/search_subagent_prompt.md` | references/ARCHIVE/ | 旧版 search subagent prompt |
| `references/design/bdd_persona_profile.md` | references/design/ | 位置不一致（应在 harness/agents/） |
| `references/design/audit_quality_persona_profile.md` | references/design/ | 位置不一致（应在 harness/agents/） |
| `references/audit/AUDIT_LOG_v3.3_to_v3.4.md` | references/audit/ | 历史审计日志 |
| `references/ops/weekly_memory_maintenance.md` | references/ops/ | 运维文档，非核心运行时文档 |

---

## 引用闭环检查表

| 引用方 | 被引用方 | 状态 | 备注 |
|--------|----------|------|------|
| SKILL.md → README.md | ✅ 存在 | 正确 |
| SKILL.md → PRD.md | ✅ 存在 | 正确 |
| SKILL.md → config.yaml | ⚠️ 存在但名称不一致 | SKILL.md 写 config.json，实际为 config.yaml |
| teach_task_template.md → PRD §7.2 | ✅ 存在 | 字段基本一致 |
| audit_task_template.md → PRD §7.3 | ⚠️ 存在但 schema 不匹配 | PRD §7.3 简化，audit_subagent_prompt.md 使用详细 schema |
| verify_task_template.md → PRD §7.4 | ✅ 存在 | 字段一致 |
| consolidate_task_template.md → PRD §7.5 | ✅ 存在 | consolidate 模板扩展了 PRD §7.5，但核心字段一致 |
| search_task_template.md → PRD §7.1 | ✅ 存在 | 字段一致 |
| grow_task_template.md → PRD §7.3 | ❌ **严重不匹配** | grow 模板输出 teach_candidates/dependency_updates 等，PRD §7.3 未定义 |
| audit_persona_profile.md → PRD §3 D1 | ❌ 引用旧约束 | 仍写 "≤150 字"，PRD 已删除 |
| orchestrator.py → cascade_engine.py | ✅ 存在 | CascadeEngine 类在 cascade_engine.py 中定义 |
| orchestrator.py → PRD.md | ✅ 存在 | `_self_test` 验证 PRD.md 存在 |
| orchestrator.py → *_task_template.md | ✅ 存在 | `_self_test` 验证所有模板存在 |
| orchestrator.py → config.yaml | ✅ 存在 | `__init__` 加载配置 |
| PRD §7.2 → teach_output.json | ✅ 闭环 | teach_task_template.md 输出与 PRD schema 一致 |
| PRD §7.3 → audit_output.json | ⚠️ 部分闭环 | audit_subagent_prompt.md 使用扩展 schema，未在 PRD 中定义 |
| PRD §7.4 → verification_output.json | ✅ 闭环 | verify_task_template.md 输出与 PRD schema 一致 |
| config.yaml module 开关 → orchestrator.py 处理代码 | ✅ 闭环 | 每个 enabled 模块在 orchestrator.py 中都有 `_module_enabled` 检查和对应调用 |

---

## 版本号一致性检查

| 文件 | 版本号出现位置 | 版本号内容 |
|------|---------------|-----------|
| `SKILL.md` | 标题/描述 | v3.5、3.5.0 |
| `README.md` | 标题 | v3.5.0 |
| `harness/config.yaml` | version 字段 | 3.5.0 |
| `harness/agents/teach_persona_profile.md` | 底部 | v3.5 |
| `harness/agents/audit_subagent_prompt.md` | 标题 | v3.5 |
| `harness/agents/search_persona_profile.md` | 底部 | v3.5 |
| `harness/agents/consolidate_task_template.md` | 标题 | v3.5 |
| `references/design/PRD.md` | 无显式版本号 | ❌ 缺失 |
| `harness/agents/grow_task_template.md` | 无显式版本号 | ❌ 缺失 |
| `harness/agents/verify_task_template.md` | 无显式版本号 | ❌ 缺失 |
| `harness/agents/teach_task_template.md` | 无显式版本号 | ❌ 缺失 |
| `harness/agents/audit_task_template.md` | 无显式版本号 | ❌ 缺失 |
| `harness/orchestrator.py` | 类名/注释 | FeynmanOrchestrator、v3.5+ |

**结论**：核心文件版本号统一为 v3.5/v3.5.0，但 PRD.md 和大部分 task template 未标注版本号。

---

## PRD §7.2 最新调整对齐检查

| 调整项 | PRD §7.2 状态 | teach_task_template.md 状态 | 对齐结果 |
|--------|--------------|------------------------------|----------|
| 删除 D1 ≤150 words | ✅ 已删除 | ✅ 已删除（写"长度不限"） | ✅ 对齐 |
| 新增 cross_depth_mappings | ✅ 已存在 | ✅ 已存在 | ✅ 对齐 |
| 新增 gaps_identified | ✅ 已存在 | ✅ 已存在 | ✅ 对齐 |
| teach_mode 字段 | ✅ 已存在（fresh/cascade_update/gap_driven） | ✅ 已存在 | ✅ 对齐 |
| metadata.new_dependencies | ✅ 已存在 | ✅ 已存在 | ✅ 对齐 |
| metadata.update_reason | ✅ 已存在 | ✅ 已存在 | ✅ 对齐 |

**结论**：PRD §7.2 与 teach_task_template.md 总体对齐良好。唯一残留问题是 audit_persona_profile.md 第172行的 "≤150 字" 旧约束。

---

## 总体结论

FCH v3.5 文档系统整体架构清晰，核心文件齐全，版本号基本统一。但存在以下关键问题需要修复：

1. **缺失核心文件**：orchestrator_runbook.md 和 5 个 subagent prompt 文件缺失，严重影响主 agent 编排和子 agent 内部执行规范。
2. **PRD schema 与 template 扩展字段不匹配**：PRD §7.3 的 grow_output.json  schema 过于简化，与 grow_task_template.md 实际输出的 teach_candidates/dependency_updates/merge_suggestions 等字段严重脱节。
3. **审计 schema 双版本问题**：audit_task_template.md 引用 PRD §7.3 简化 schema，而 audit_subagent_prompt.md 使用详细 schema，存在冲突。
4. **旧约束残留**：audit_persona_profile.md 仍引用已删除的 D1 ≤150 字限制。
5. **目录结构不一致**：bdd_persona_profile.md 和 audit_quality_persona_profile.md 位置不符合规范。

**修复优先级**：
- 立即修复（P0）：创建 orchestrator_runbook.md、创建 5 个 subagent prompt、更新 PRD §7.3 grow_output schema
- 尽快修复（P1）：删除 audit_persona_profile.md 的 "≤150 字"、统一 audit schema、补充 grow cascade gaps 处理描述
- 建议修复（P2）：移动 persona profile 到正确目录、给 PRD 和 task template 添加版本号、清理 archive 引用

---

> 审计完成。本报告只读不修改，所有修复建议留待主 agent 决策实施。
